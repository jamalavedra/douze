import { t as require_dist } from "./dist.js";
import { A as unknown, C as object, E as record, O as string, S as number, _ as discriminatedUnion, b as literal, f as _enum, g as boolean, h as array, j as url, y as lazy } from "./schemas.js";
//#region ../shared/src/recipe.ts
/** AC-INF-003.1/.2 — read is safe to replay, destructive needs `confirm`. */
var SideEffect = _enum([
	"read",
	"write",
	"destructive"
]);
_enum([
	"ok",
	"schema_widened",
	"breaking",
	"session_expired",
	"gone"
]);
/**
* AC-REC-001.2 — a recipe records only where a credential comes from, never a value.
* `cookie` needs nothing: the browser attaches it. `page_state` names the expression the
* app itself uses, which the extension re-reads at call time (AC-EXE-001.3).
*/
var CredentialSource = discriminatedUnion("kind", [object({ kind: literal("cookie") }), object({
	kind: literal("page_state"),
	/** Expression evaluated in the page's MAIN world, e.g. `localStorage.getItem('token')`. */
	expression: string(),
	/** Header the value is attached to, e.g. `authorization`. */
	header: string(),
	/** Optional literal prefix, e.g. `Bearer `. */
	prefix: string().default("")
})]);
var AuthDescriptor = object({
	mode: _enum(["browser_relay", "headless"]).default("browser_relay"),
	credential_source: array(CredentialSource).default([{ kind: "cookie" }]),
	/** AC-EXE-004.2 — headless refresh endpoint, applied once on 401. */
	refresh_endpoint: string().optional(),
	/** AC-EXE-004.1 — keychain reference only, never a session value. */
	keychain_ref: string().optional()
});
/** REQ-INF-005 — how a paginated collection is driven. */
var Pagination = object({
	style: _enum([
		"page",
		"cursor",
		"offset"
	]),
	/** Request param carrying the page/cursor/offset. */
	param: string(),
	/** JSONPath to the next cursor in the response, for cursor style. */
	next_path: string().optional()
});
var RequestContract = object({
	method: _enum([
		"GET",
		"HEAD",
		"POST",
		"PUT",
		"PATCH",
		"DELETE"
	]),
	/** Endpoint Template with `{param}` segments — REQ-INF-001. */
	path: string(),
	/** AC-INF-002.4 — JSON Schema, converted to Zod at load time. */
	input_schema: record(string(), unknown()).default({
		type: "object",
		properties: {}
	}),
	/** Static headers observed as required by the app (never credentials). */
	headers: record(string(), string()).default({}),
	/** AC-INF-004.2 — the GraphQL document, stored with the recipe. */
	graphql: object({
		operation: string(),
		document: string()
	}).optional()
});
var ResponseContract = object({
	/** AC-INF-005.1 — JSONPath to the useful subtree, minus the envelope. */
	primary_payload_path: string().optional(),
	output_schema: record(string(), unknown()).default({}),
	pagination: Pagination.optional()
});
/** Flags are advisory metadata the runtime and review UI act on. */
var ToolFlags = object({
	/** AC-INF-002.3 — inferred from a single observation. */
	sparse: boolean().default(false),
	/** AC-INF-004.3 — GraphQL operation was anonymous; name came from the root field. */
	derived_name: boolean().default(false),
	/** AC-REC-003.2 — retained across a recapture that no longer observed it. */
	unverified: boolean().default(false),
	last_observed: string().optional(),
	/** AC-DRF-002.1 — set by a Doctor Run; the runtime rejects calls to this tool. */
	degraded: boolean().default(false),
	degraded_reason: string().optional(),
	/** AC-REC-002.2 — fields the user hand-edited, protected from re-inference. */
	user_edited: array(string()).default([]),
	/** AC-REC-003.1 — inferred values that lost to a user edit, kept as suggestions. */
	suggestions: record(string(), unknown()).default({})
});
var Tool = object({
	name: string().regex(/^[a-z][a-z0-9_]*$/, "tool names are snake_case"),
	description: string(),
	side_effect: SideEffect,
	/** REQ-INF-002 — 0..1 from observation count, schema stability, side-effect certainty. */
	confidence: number().min(0).max(1),
	observations: number().int().nonnegative(),
	/** AC-REC-002.5 — the runtime exposes approved tools only. */
	approved: boolean().default(false),
	request: RequestContract,
	response: ResponseContract.prefault({}),
	/** AC-REC-004.1 — approved tools reference at least one fixture (enforced below). */
	fixtures: array(string()).default([]),
	/** AC-EXE-003.1 — per-tool rate limit; douzed queues rather than drops. */
	rate_limit_per_minute: number().int().positive().optional(),
	/** REQ-CAP-007 — the note that produced this tool, kept as description evidence. */
	annotation: string().optional(),
	flags: ToolFlags.prefault({})
});
var Recipe = object({
	version: number().int().positive(),
	name: string().regex(/^[a-z][a-z0-9-]*$/, "recipe names are kebab-case"),
	enabled: boolean().default(true),
	target: object({ base_url: url() }),
	auth: AuthDescriptor.prefault({}),
	tools: array(Tool).default([])
}).superRefine((recipe, ctx) => {
	const seen = /* @__PURE__ */ new Set();
	for (const [i, tool] of recipe.tools.entries()) {
		if (seen.has(tool.name)) ctx.addIssue({
			code: "custom",
			path: [
				"tools",
				i,
				"name"
			],
			message: `duplicate tool name "${tool.name}" in recipe "${recipe.name}"`
		});
		seen.add(tool.name);
		if (tool.approved && tool.fixtures.length === 0) ctx.addIssue({
			code: "custom",
			path: [
				"tools",
				i,
				"fixtures"
			],
			message: `approved tool "${tool.name}" must reference at least one fixture`
		});
		if (tool.approved && tool.side_effect === "destructive" && !hasConfirm(tool)) ctx.addIssue({
			code: "custom",
			path: [
				"tools",
				i,
				"request",
				"input_schema"
			],
			message: `approved destructive tool "${tool.name}" must require a "confirm" parameter`
		});
	}
});
function hasConfirm(tool) {
	const schema = tool.request.input_schema;
	return Array.isArray(schema.required) && schema.required.includes("confirm");
}
/** The `confirm` parameter injected into every approved destructive tool (AC-REC-002.4). */
var CONFIRM_PARAM = {
	type: "boolean",
	description: "Must be true. This tool performs a destructive action that cannot be undone."
};
//#endregion
//#region ../shared/src/redact.ts
/**
* REQ-CAP-005 — redaction runs in the extension's service worker before an exchange crosses
* the loopback boundary, and again as a gate on every fixture write (AC-REC-004.2).
* TR-6: no secret may reach a recipe, fixture, generated source, or log.
*
* Two rules, both applied everywhere a value is persisted: a **key** on the credential list, and
* a **value** that looks like a credential whatever it is called. The second exists because the
* first cannot be complete — a developer console returns its own API keys under names like
* `publishableKey`, which no list will ever contain. Detection and removal use the same test
* (`looksLikeCredential`), so `findSurvivingSecrets` cannot disagree with what ran before it;
* when they did disagree, an ordinary exchange was refused and the recording silently retained
* nothing.
*/
/** AC-CAP-005.1 — header names whose values are always replaced. */
var CREDENTIAL_HEADERS = [
	"authorization",
	"cookie",
	"set-cookie",
	"x-api-key",
	"x-csrf-token",
	"x-xsrf-token",
	"proxy-authorization"
];
/** AC-CAP-005.2 — body keys whose values are always replaced, matched case-insensitively. */
var SECRET_FIELDS = [
	"password",
	"token",
	"secret",
	"apikey",
	"api_key",
	"refresh_token",
	"access_token",
	"client_secret",
	"private_key",
	"session",
	"credential"
];
var defaultRedaction = () => ({
	headers: [...CREDENTIAL_HEADERS],
	fields: [...SECRET_FIELDS]
});
/**
* AC-CAP-005.3 — the placeholder carries the original type and length so schema inference
* still sees a string of the right shape, but never the value itself.
*/
function placeholder(value) {
	if (typeof value === "string") return `«redacted:string:${value.length}»`;
	if (typeof value === "number") return `«redacted:number»`;
	if (typeof value === "boolean") return `«redacted:boolean»`;
	if (value === null) return `«redacted:null»`;
	return `«redacted:${Array.isArray(value) ? "array" : typeof value}»`;
}
var isPlaceholder = (v) => typeof v === "string" && v.startsWith("«redacted:");
/**
* Substring match after normalisation, not equality. Real payloads carry `old_password`,
* `new_password`, `authToken`, `sessionId`, `tokens` — an exact match misses every one of them,
* and the entropy gate cannot save a human-chosen password.
*/
function matches(name, list) {
	const normalized = name.toLowerCase().replace(/[-_]/g, "");
	return list.some((entry) => normalized.includes(entry.toLowerCase().replace(/[-_]/g, "")));
}
/**
* Redaction runs twice by design — once in the extension's service worker, once again in the
* daemon, which also ingests HAR files. It must therefore be idempotent: re-redacting a
* placeholder would replace it with a placeholder of the placeholder, destroying the original
* length that AC-CAP-005.3 requires schema inference to keep.
*/
function redactHeaders(headers, config = defaultRedaction()) {
	const out = {};
	for (const [name, value] of Object.entries(headers)) out[name] = (matches(name, config.headers) || looksLikeCredential(value)) && !isPlaceholder(value) ? placeholder(value) : value;
	return out;
}
/**
* A form-encoded body arrives as a string, so the object walk below never sees its fields.
* `application/x-www-form-urlencoded` is explicitly allowed by the capture filter, so
* `username=ada&password=hunter2` would otherwise be persisted verbatim (AC-CAP-005.2).
*/
var FORM_BODY = /^(?:[\w.[\]%+-]+=[^&]*)(?:&[\w.[\]%+-]+=[^&]*)*$/;
function redactFormBody(body, config = defaultRedaction()) {
	const params = new URLSearchParams(body);
	let changed = false;
	for (const [key, value] of [...params.entries()]) if ((matches(key, config.fields) || looksLikeCredential(value)) && !isPlaceholder(value)) {
		params.set(key, placeholder(value));
		changed = true;
	}
	return changed ? params.toString() : body;
}
/** Walks any JSON value, replacing values whose *key* matches the secret-field list. */
function redactBody(body, config = defaultRedaction()) {
	if (typeof body === "string" && body.includes("=") && FORM_BODY.test(body)) return redactFormBody(body, config);
	if (typeof body === "string") return !isPlaceholder(body) && looksLikeCredential(body) ? placeholder(body) : body;
	if (Array.isArray(body)) return body.map((item) => redactBody(item, config));
	if (body !== null && typeof body === "object") {
		const out = {};
		for (const [key, value] of Object.entries(body)) out[key] = matches(key, config.fields) && !isPlaceholder(value) ? placeholder(value) : redactBody(value, config);
		return out;
	}
	return body;
}
/**
* REQ-CAP-005 — a URL is persisted whole, so a credential passed as a query parameter would
* bypass header and body redaction entirely. Apps really do this (`?api_key=`, `?token=`), so
* the query string gets the same key-based treatment as a body.
*/
function redactUrl(url, config = defaultRedaction()) {
	let parsed;
	try {
		parsed = new URL(url);
	} catch {
		return url;
	}
	let changed = false;
	for (const [key, value] of [...parsed.searchParams.entries()]) if ((matches(key, config.fields) || looksLikeCredential(value)) && !isPlaceholder(value)) {
		parsed.searchParams.set(key, placeholder(value));
		changed = true;
	}
	const segments = parsed.pathname.split("/").map((segment) => {
		if (!segment || isPlaceholder(segment) || !looksLikeCredential(segment)) return segment;
		changed = true;
		return placeholder(segment);
	});
	if (changed) parsed.pathname = segments.join("/");
	return changed ? parsed.toString() : url;
}
/**
* AC-REC-004.2 — the write gate, and defence in depth rather than the first line of it. Anything
* it detects — JWTs, bearer prefixes, prefixed keys, long high-entropy tokens — is already
* replaced by `redactBody`/`redactHeaders`/`redactUrl`, which share this exact test. What it
* still catches is a document that reached a persistence boundary without passing through them.
* Returns the JSON paths of anything suspicious; an empty array means the write may proceed.
*/
function findSurvivingSecrets(value, path = "$") {
	if (isPlaceholder(value)) return [];
	if (typeof value === "string") return looksLikeCredential(value) ? [path] : [];
	if (Array.isArray(value)) return value.flatMap((v, i) => findSurvivingSecrets(v, `${path}[${i}]`));
	if (value !== null && typeof value === "object") return Object.entries(value).flatMap(([k, v]) => findSurvivingSecrets(v, `${path}.${k}`));
	return [];
}
var JWT = /^ey[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]+$/;
var BEARER = /^(bearer|basic)\s+\S{8,}/i;
/** Openfort and Stripe-style prefixed keys, plus generic `sk_`/`pk_` secrets. */
var PREFIXED_KEY = /\b(sk|pk|rk)_(test|live|prod)?_?[A-Za-z0-9]{16,}\b/;
/** Values that are structure rather than tokens, and must be judged part by part. */
var URLISH = /^https?:\/\//i;
/** A recipe's `request.path`, and every relative URL a capture carries. */
var PATHISH = /^\//;
function looksLikeCredential(value) {
	if (JWT.test(value) || BEARER.test(value) || PREFIXED_KEY.test(value)) return true;
	/**
	* A URL is judged by its parts, never as one string. `https://api.example/v1/players?limit=20`
	* is long, mixed-alphabet, space-free and carries a digit — which is the entropy rule's entire
	* definition of a token, so every ordinary REST call read as a credential. That refused 30 of
	* 31 exchanges from a real dashboard while letting a 96-character GitHub URL through, because
	* that one happened to contain no digit. The review page then showed nothing but GitHub.
	*/
	if (URLISH.test(value) || PATHISH.test(value)) return urlParts(value).some((part) => looksLikeCredential(part));
	if (value.length >= 40 && !/\s/.test(value) && /[A-Za-z]/.test(value) && /\d/.test(value)) return shannonEntropy(value) > 3.5;
	return false;
}
/**
* Path segments and query values, decoded — a placeholder written into a path arrives encoded.
*
* The base makes a bare path parse: a recipe stores `request.path` on its own, and
* `/v1/projects/pro_1a2b3c/policies` is long, mixed-alphabet and space-free, so judging it whole
* refused to write the very recipe the review page had just built.
*/
function urlParts(url) {
	try {
		const parsed = new URL(url, "http://parts.invalid");
		const decode = (part) => {
			try {
				return decodeURIComponent(part);
			} catch {
				return part;
			}
		};
		return [...parsed.pathname.split("/").filter(Boolean).map(decode), ...parsed.searchParams.values()];
	} catch {
		return [];
	}
}
function shannonEntropy(value) {
	const counts = /* @__PURE__ */ new Map();
	for (const char of value) counts.set(char, (counts.get(char) ?? 0) + 1);
	let entropy = 0;
	for (const count of counts.values()) {
		const p = count / value.length;
		entropy -= p * Math.log2(p);
	}
	return entropy;
}
//#endregion
//#region ../shared/src/capture.ts
/** REQ-CAP-003 — the element, route, and gesture immediately preceding an exchange. */
var UiProvenance = object({
	/** Accessible name of the activated control, e.g. "Create order". */
	accessible_name: string(),
	role: string(),
	route: string(),
	title: string()
});
/** AC-CAP-002.3 — how the exchange reached us, and whether its body is trustworthy. */
var CaptureSource = _enum([
	"main_world",
	"web_request",
	"debugger",
	"har"
]);
var Exchange = object({
	id: string(),
	session_id: string(),
	/** Monotonic position within the session; Annotation Spans index into this. */
	position: number().int().nonnegative(),
	started_at: number(),
	duration_ms: number().nonnegative(),
	method: string(),
	url: url(),
	origin: string(),
	request_headers: record(string(), string()).default({}),
	request_body: unknown().optional(),
	status: number().int(),
	response_headers: record(string(), string()).default({}),
	response_body: unknown().optional(),
	response_content_type: string().optional(),
	response_size: number().int().nonnegative().optional(),
	/** AC-CAP-002.2/.3 — body absent because it was binary, oversized, or unobservable. */
	body_missing: boolean().default(false),
	body_missing_reason: _enum([
		"too_large",
		"not_utf8",
		"interceptor_miss",
		"har_no_content"
	]).optional(),
	/** AC-CAP-003.3 — no user gesture preceded this request. */
	background: boolean().default(false),
	provenance: UiProvenance.optional(),
	source: CaptureSource
});
/** REQ-CAP-007 — a note covering every exchange captured since the previous note. */
var AnnotationSpan = object({
	id: string(),
	session_id: string(),
	note: string().min(1),
	start_position: number().int().nonnegative(),
	/** `end < start` denotes an empty span — a note attached with nothing captured since the last. */
	end_position: number().int().min(-1)
});
var CaptureSession = object({
	id: string(),
	/** AC-CAP-001.2 — a session must be named. */
	name: string().min(1),
	/** AC-CAP-001.1 — only exchanges from these origins are recorded. */
	origins: array(string()).min(1),
	started_at: number(),
	stopped_at: number().optional(),
	/** AC-CAP-002.4 — chrome.debugger capture was enabled for this session. */
	debugger_enabled: boolean().default(false)
});
/**
* AC-CAP-004.1 — bundled noise list. Matched as a domain suffix so subdomains are covered.
* Analytics, error reporting, session replay, ads, and telemetry.
*/
var NOISE_HOSTS = [
	"google-analytics.com",
	"googletagmanager.com",
	"doubleclick.net",
	"googlesyndication.com",
	"segment.com",
	"segment.io",
	"sentry.io",
	"bugsnag.com",
	"datadoghq.com",
	"newrelic.com",
	"nr-data.net",
	"fullstory.com",
	"logrocket.com",
	"hotjar.com",
	"mixpanel.com",
	"amplitude.com",
	"posthog.com",
	"intercom.io",
	"heap.io",
	"clarity.ms",
	"launchdarkly.com",
	"statsig.com",
	"pendo.io",
	"facebook.net",
	"cloudflareinsights.com"
];
/** AC-CAP-004.2 — only these response content types can carry an inferable payload. */
var ALLOWED_CONTENT = [
	"application/json",
	"application/graphql",
	"application/x-www-form-urlencoded",
	"text/plain",
	"text/json",
	"+json"
];
var defaultNoise = () => ({ hosts: [...NOISE_HOSTS] });
function isNoiseHost(url, config = defaultNoise()) {
	let host;
	try {
		host = new URL(url).hostname.toLowerCase();
	} catch {
		return true;
	}
	return config.hosts.some((noise) => host === noise || host.endsWith(`.${noise}`));
}
function isInferableContentType(contentType) {
	if (!contentType) return false;
	const normalized = contentType.toLowerCase();
	return ALLOWED_CONTENT.some((allowed) => normalized.includes(allowed));
}
/**
* AC-CAP-004 — the single filter both live capture and HAR import apply, so the two paths
* cannot drift apart (AC-CAP-006.1).
*
* `origins` is the *target* filter, and it is null for live capture. A dashboard almost never
* serves its own API: `dashboard.example.com` calls `api.example.com`, and requiring the target
* to be the page's origin dropped every request that mattered — a recording of a real site
* retained nothing at all. Live capture does not need this check, because it only ever sees
* requests the recorded tab itself made: the interceptor is registered on the granted origin, the
* oracle filters on the recording tab's id, and the debugger is attached to that one tab. The
* noise list and the content type are what remain.
*
* A HAR is different — it is a recording of the whole browser, with no tab to attribute a
* request to — so importing one still names the origins it may keep.
*/
function shouldCapture(candidate, origins, noise = defaultNoise()) {
	if (origins !== null && !origins.includes(candidate.origin)) return false;
	if (isNoiseHost(candidate.url, noise)) return false;
	return isInferableContentType(candidate.response_content_type);
}
//#endregion
//#region ../shared/src/protocol.ts
/**
* ADR-003 — the JSON protocol the extension speaks to douzed over `ws://127.0.0.1:<port>`.
* Two families: `exchange.*` flows extension → daemon (capture), `relay.*` flows
* daemon → extension and back (execution).
*/
var ClientMessage = discriminatedUnion("type", [
	object({
		type: literal("hello"),
		token: string(),
		extension_version: string()
	}),
	object({ type: literal("pong") }),
	object({
		type: literal("exchange.append"),
		exchange: Exchange
	}),
	object({
		type: literal("exchange.session.start"),
		session: CaptureSession
	}),
	object({
		type: literal("exchange.session.stop"),
		session_id: string(),
		retained: number()
	}),
	object({
		type: literal("exchange.annotate"),
		span: AnnotationSpan
	}),
	object({
		type: literal("relay.response"),
		id: string(),
		response: lazy(() => RelayResponse)
	})
]);
/** A single relayed request, issued by the extension from an Executor Tab. */
var RelayRequest = object({
	id: string(),
	origin: string(),
	url: url(),
	method: string(),
	headers: record(string(), string()).default({}),
	body: unknown().optional(),
	/** AC-EXE-001.3 — read these from page state exactly as the app does. */
	credential_source: array(CredentialSource).default([]),
	timeout_ms: number().int().positive().default(12e4)
});
var RelayResponse = object({
	id: string(),
	ok: boolean(),
	status: number().int().optional(),
	headers: record(string(), string()).default({}),
	body: unknown().optional(),
	duration_ms: number().nonnegative().default(0),
	/** Set when the extension itself failed rather than the target. */
	error: string().optional(),
	/** AC-EXE-002.1 — the extension observed a login redirect the status alone would not show. */
	redirected_to_login: boolean().default(false)
});
discriminatedUnion("type", [
	object({
		type: literal("welcome"),
		heartbeat_ms: number()
	}),
	object({ type: literal("ping") }),
	object({
		type: literal("relay.request"),
		request: RelayRequest
	})
]);
/** ADR-003 — douzed pings well inside Chrome's 30-second service-worker idle timeout. */
var HEARTBEAT_MS = 2e4;
/**
* The extension can only find douzed by probing loopback, so both sides walk this range in order.
* 8787 is not ours alone — RStudio Server's default is exactly that — and a squatter on it must
* move the daemon one port along rather than out of the extension's reach entirely.
*/
var PORT_RANGE = [
	8787,
	8788,
	8789,
	8790,
	8791
];
var DEFAULT_PORT = PORT_RANGE[0];
_enum([
	"relay_unreachable",
	"extension_disconnected",
	"session_expired",
	"tool_degraded",
	"confirm_required",
	"rate_limited",
	"timeout"
]);
var DouzeError = class extends Error {
	code;
	detail;
	constructor(code, message, detail = {}) {
		super(message);
		this.code = code;
		this.detail = detail;
		this.name = "DouzeError";
	}
	toResult() {
		return {
			error: this.code,
			message: this.message,
			...this.detail
		};
	}
};
//#endregion
//#region ../shared/src/recipe-file.ts
var import_dist = require_dist();
/**
* AC-REC-001.3 — migrations run in order from the document's version to RECIPE_VERSION and
* report every field they touch. Each entry mutates the raw document in place.
*/
var MIGRATIONS = { 0: (doc) => {
	doc["auth"] = {
		mode: "browser_relay",
		credential_source: [{ kind: "cookie" }]
	};
	return ["auth"];
} };
function parseRecipe(source, filename) {
	let raw;
	try {
		raw = (0, import_dist.parse)(source);
	} catch (cause) {
		return {
			ok: false,
			error: `${filename}: invalid YAML — ${cause.message}`
		};
	}
	if (raw === null || typeof raw !== "object") return {
		ok: false,
		error: `${filename}: recipe must be a YAML mapping`
	};
	const doc = raw;
	const migrated = [];
	let version = typeof doc["version"] === "number" ? doc["version"] : 0;
	while (version < 1) {
		const migration = MIGRATIONS[version];
		if (!migration) return {
			ok: false,
			error: `${filename}: no migration from version ${version}`
		};
		migrated.push(...migration(doc));
		version += 1;
		doc["version"] = version;
	}
	const parsed = Recipe.safeParse(doc);
	if (!parsed.success) return {
		ok: false,
		error: `${filename}: ${parsed.error.issues.map((issue) => `${issue.path.join(".") || "<root>"}: ${issue.message}`).join("; ")}`
	};
	const leaked = findSurvivingSecrets(parsed.data);
	if (leaked.length > 0) return {
		ok: false,
		error: `${filename}: credential-shaped value at ${leaked.join(", ")}`
	};
	return {
		ok: true,
		recipe: parsed.data,
		migrated
	};
}
function serializeRecipe(recipe) {
	const leaked = findSurvivingSecrets(recipe);
	if (leaked.length > 0) throw new Error(`refusing to write recipe "${recipe.name}": credential at ${leaked.join(", ")}`);
	return (0, import_dist.stringify)(recipe, { lineWidth: 100 });
}
//#endregion
export { redactHeaders as _, DouzeError as a, Recipe as b, RelayResponse as c, Exchange as d, isInferableContentType as f, redactBody as g, findSurvivingSecrets as h, DEFAULT_PORT as i, AnnotationSpan as l, shouldCapture as m, serializeRecipe as n, HEARTBEAT_MS as o, isNoiseHost as p, ClientMessage as r, PORT_RANGE as s, parseRecipe as t, CaptureSession as u, redactUrl as v, Tool as x, CONFIRM_PARAM as y };
