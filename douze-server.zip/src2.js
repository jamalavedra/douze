import { _ as redactHeaders, b as Recipe, g as redactBody, h as findSurvivingSecrets, n as serializeRecipe, t as parseRecipe, x as Tool, y as CONFIRM_PARAM } from "./src.js";
import { mkdirSync, readFileSync, readdirSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { homedir } from "node:os";
//#region ../studio/src/paths.ts
/**
* ADR-006 — studio writes to the recipe and fixture directories and nothing else; #RecipeRegistry
* picks the change up by hot reload, so there is no runtime coupling to `douzed`.
*
* These two paths mirror `packages/douzed/src/paths.ts` deliberately: sharing them would mean
* depending on the daemon package for a filesystem convention, which is the coupling ADR-006
* removes. DOUZE_HOME keeps the E2E suite off a real install.
*/
var douzeHome = () => process.env["DOUZE_HOME"] ?? join(homedir(), ".douze");
var studioPaths = (home = douzeHome()) => ({
	recipes: join(home, "recipes"),
	fixtures: join(home, "fixtures")
});
//#endregion
//#region ../studio/src/inference/templating.ts
function pathSegments(url) {
	return new URL(url).pathname.split("/").filter((s) => s.length > 0);
}
function queryParams(url) {
	const out = {};
	for (const [key, value] of new URL(url).searchParams) out[key] = value;
	return out;
}
/**
* AC-INF-001.1 — two exchanges merge only when they share a method and differ in exactly one
* segment, and a cluster only ever varies at one position. That keeps `/a/1` + `/a/2` + `/b/2`
* from collapsing transitively into a template with two holes.
*/
function groupEndpoints(exchanges) {
	const clusters = [];
	for (const exchange of exchanges) {
		const method = exchange.method.toUpperCase();
		const segments = pathSegments(exchange.url);
		const cluster = clusters.find((c) => absorbs(c, method, segments));
		if (!cluster) {
			clusters.push({
				method,
				segments,
				varying: null,
				exchanges: [exchange]
			});
			continue;
		}
		const diff = firstDifference(cluster.segments, segments);
		if (diff !== null) cluster.varying = diff;
		cluster.exchanges.push(exchange);
	}
	return clusters.map(toGroup).sort((a, b) => `${a.method} ${a.path}`.localeCompare(`${b.method} ${b.path}`));
}
function absorbs(cluster, method, segments) {
	if (cluster.method !== method || cluster.segments.length !== segments.length) return false;
	const differing = cluster.segments.flatMap((seg, i) => seg === segments[i] ? [] : [i]);
	if (differing.length === 0) return true;
	if (differing.length > 1) return false;
	const index = differing[0];
	if (!looksIdentifier(cluster.segments[index]) || !looksIdentifier(segments[index])) return false;
	return cluster.varying === null || cluster.varying === index;
}
/** Digits or a UUID prefix: enough to separate `1042` and `9f3a-…` from `refund`. */
var looksIdentifier = (value) => value !== void 0 && (/\d/.test(value) || /^[0-9a-f]{8}-[0-9a-f]{4}/i.test(value));
function firstDifference(a, b) {
	const index = a.findIndex((seg, i) => seg !== b[i]);
	return index === -1 ? null : index;
}
function toGroup(cluster) {
	const varying = cluster.varying ?? soleObservationParameter(cluster);
	if (varying === null) return {
		method: cluster.method,
		path: `/${cluster.segments.join("/")}`,
		params: [],
		exchanges: cluster.exchanges
	};
	const name = nameParameter(cluster, varying);
	const segments = cluster.segments.map((seg, i) => i === varying ? `{${name}}` : seg);
	return {
		method: cluster.method,
		path: `/${segments.join("/")}`,
		params: [name],
		exchanges: cluster.exchanges
	};
}
/**
* A single-observation endpoint has nothing to diff against, so `POST /orders/1044/cancel` would
* become a tool that can only ever cancel order 1044. When the segment reads as an identifier
* *and* the response echoes it back as an id field, that is evidence enough to parameterise it —
* the same evidence AC-INF-001.2 uses for naming. Confidence stays capped at 0.4 either way.
*/
function soleObservationParameter(cluster) {
	for (let index = cluster.segments.length - 1; index >= 0; index -= 1) {
		const segment = cluster.segments[index];
		if (!looksIdentifier(segment) || segment === void 0) continue;
		if (cluster.exchanges.some((e) => findIdField(e.response_body, segment) !== null)) return index;
	}
	return null;
}
/**
* AC-INF-001.2 — prefer a name taken from an `id`-like response field whose value is the segment.
* AC-INF-001.3 — otherwise fall back to the preceding static segment, singularised.
*/
function nameParameter(cluster, index) {
	const preceding = index > 0 ? cluster.segments[index - 1] ?? "resource" : "resource";
	for (const exchange of cluster.exchanges) {
		const value = pathSegments(exchange.url)[index];
		if (value === void 0) continue;
		const field = findIdField(exchange.response_body, value);
		if (field !== null) return qualify(field, preceding);
	}
	return camel(singular(preceding));
}
/** Walks a response body for a key ending in `id` whose value is the observed path segment. */
function findIdField(body, value, depth = 0) {
	if (depth > 3 || body === null || typeof body !== "object") return null;
	if (Array.isArray(body)) {
		for (const item of body) {
			const found = findIdField(item, value, depth + 1);
			if (found !== null) return found;
		}
		return null;
	}
	for (const [key, nested] of Object.entries(body)) if (/(^|_)id$|Id$/.test(key) && String(nested) === value) return key;
	for (const nested of Object.values(body)) {
		const found = findIdField(nested, value, depth + 1);
		if (found !== null) return found;
	}
	return null;
}
/** A bare `id` field is ambiguous across a recipe, so qualify it with its resource. */
function qualify(field, preceding) {
	return field.toLowerCase() === "id" ? `${camel(singular(preceding))}Id` : camel(field);
}
/** `/orders/{orderId}` addresses one record; `/orders/{orderId}/shipments` addresses a collection. */
var addressesOneRecord = (path) => /\{[^}]+\}$/.test(path);
function singular(word) {
	if (/ies$/i.test(word)) return `${word.slice(0, -3)}y`;
	if (/(s|x|z|ch|sh)es$/i.test(word)) return word.slice(0, -2);
	if (/ss$/i.test(word)) return word;
	if (/s$/i.test(word)) return word.slice(0, -1);
	return word;
}
function plural(word) {
	if (/s$/i.test(word)) return word;
	if (/(x|z|ch|sh)$/i.test(word)) return `${word}es`;
	if (/[^aeiou]y$/i.test(word)) return `${word.slice(0, -1)}ies`;
	return `${word}s`;
}
function camel(word) {
	const [head = "", ...rest] = word.split(/[-_\s]+/).filter(Boolean);
	return head.toLowerCase() + rest.map((p) => p.charAt(0).toUpperCase() + p.slice(1).toLowerCase()).join("");
}
function snake(word) {
	return word.replace(/([a-z0-9])([A-Z])/g, "$1_$2").replace(/[-\s]+/g, "_").replace(/[^A-Za-z0-9_]/g, "").toLowerCase().replace(/_+/g, "_").replace(/^_|_$/g, "");
}
//#endregion
//#region ../studio/src/inference/schema.ts
/** AC-INF-002.2 — an open enum needs at least this many observations to be worth emitting. */
var MIN_ENUM_OBSERVATIONS = 3;
/** AC-INF-002.2 — above this many distinct values the field is free-form, not an enum. */
var MAX_ENUM_VALUES = 12;
/**
* REQ-INF-002 — derives JSON Schema from observed values.
*
* A field is required only when it is present in every observation (AC-INF-002.1). String fields
* with a small, stable value set become open enums (AC-INF-002.2): the values are emitted as
* `examples` with an `x-open-enum` marker rather than a closed `enum`, so a JSON Schema → Zod
* conversion at load time yields `z.string()` and an unseen-but-valid value is not rejected
* (AC-INF-002.4).
*/
function inferSchema(samples) {
	const present = samples.filter((s) => s !== void 0);
	if (present.length === 0) return {};
	if (present.every(isPlainObject)) return objectSchema(present);
	if (present.every(Array.isArray)) return {
		type: "array",
		items: inferSchema(present.flat())
	};
	if (present.every((s) => typeof s === "string")) return stringSchema(present);
	if (present.every((s) => typeof s === "number")) return { type: present.every((s) => Number.isInteger(s)) ? "integer" : "number" };
	if (present.every((s) => typeof s === "boolean")) return { type: "boolean" };
	if (present.every((s) => s === null)) return { type: "null" };
	return {};
}
function objectSchema(samples) {
	const keys = [...new Set(samples.flatMap((s) => Object.keys(s)))].sort();
	const properties = {};
	const required = [];
	for (const key of keys) {
		const values = samples.filter((s) => key in s).map((s) => s[key]);
		properties[key] = inferSchema(values);
		if (values.length === samples.length) required.push(key);
	}
	const schema = {
		type: "object",
		properties
	};
	if (required.length > 0) schema["required"] = required;
	return schema;
}
function stringSchema(values) {
	const distinct = [...new Set(values)].sort();
	if (values.length >= MIN_ENUM_OBSERVATIONS && distinct.length < MAX_ENUM_VALUES) return {
		type: "string",
		"x-open-enum": true,
		examples: distinct
	};
	return { type: "string" };
}
var isPlainObject = (value) => value !== null && typeof value === "object" && !Array.isArray(value);
/** Merges independently inferred property sets into one input schema (path + query + body). */
function mergeSchemas(...schemas) {
	const properties = {};
	const required = /* @__PURE__ */ new Set();
	for (const schema of schemas) {
		Object.assign(properties, schema["properties"] ?? {});
		for (const key of schema["required"] ?? []) required.add(key);
	}
	const merged = {
		type: "object",
		properties
	};
	if (required.size > 0) merged["required"] = [...required].sort();
	return merged;
}
/**
* Schema stability: the share of observed fields that held across every observation. A tool whose
* fields come and go is a weaker candidate than one with a fixed shape (REQ-INF-002 confidence).
*/
function stability(schema) {
	const properties = schema["properties"] ?? {};
	const total = Object.keys(properties).length;
	if (total === 0) return 1;
	return (schema["required"] ?? []).length / total;
}
//#endregion
//#region ../studio/src/inference/graphql.ts
function readBody(value) {
	let body = value;
	if (typeof body === "string") try {
		body = JSON.parse(body);
	} catch {
		return null;
	}
	if (body === null || typeof body !== "object" || Array.isArray(body)) return null;
	const record = body;
	if (typeof record["query"] !== "string") return null;
	const variables = record["variables"];
	const name = record["operationName"];
	return {
		query: record["query"],
		variables: variables !== null && typeof variables === "object" ? variables : {},
		...typeof name === "string" && name.length > 0 ? { operationName: name } : {}
	};
}
function isGraphqlExchange(exchange) {
	return readBody(exchange.request_body) !== null;
}
/** AC-INF-004.4 — a 200 with errors is a failed exchange, not a successful contract sample. */
function hasGraphqlErrors(exchange) {
	const body = exchange.response_body;
	if (body === null || typeof body !== "object") return false;
	const errors = body["errors"];
	return Array.isArray(errors) && errors.length > 0;
}
function graphqlVariables(exchange) {
	return readBody(exchange.request_body)?.variables ?? {};
}
/** AC-INF-004.1 — one group, and therefore one candidate, per operation name. */
function splitOperations(exchanges) {
	const groups = /* @__PURE__ */ new Map();
	for (const exchange of exchanges) {
		const body = readBody(exchange.request_body);
		if (!body) continue;
		const identity = identify(body);
		if (!identity) continue;
		const key = identity.operation;
		let group = groups.get(key);
		if (!group) {
			group = {
				operation: identity.operation,
				document: body.query,
				kind: identity.kind,
				derived_name: identity.derived_name,
				path: new URL(exchange.url).pathname,
				exchanges: [],
				failed: []
			};
			groups.set(key, group);
		}
		group.exchanges.push(exchange);
		if (hasGraphqlErrors(exchange)) group.failed.push(exchange);
	}
	return [...groups.values()].sort((a, b) => a.operation.localeCompare(b.operation));
}
var NAMED = /\b(query|mutation)\s+([A-Za-z_][A-Za-z0-9_]*)/;
var ANONYMOUS_ROOT = /\{\s*([A-Za-z_][A-Za-z0-9_]*)/;
function identify(body) {
	const named = NAMED.exec(body.query);
	const kind = named?.[1] === "mutation" || /^\s*mutation\b/.test(body.query) ? "mutation" : "query";
	if (body.operationName !== void 0) return {
		operation: body.operationName,
		kind,
		derived_name: false
	};
	if (named?.[2] !== void 0) return {
		operation: named[2],
		kind,
		derived_name: false
	};
	const root = ANONYMOUS_ROOT.exec(body.query);
	if (root?.[1] === void 0) return null;
	return {
		operation: root[1],
		kind,
		derived_name: true
	};
}
//#endregion
//#region ../studio/src/inference/side-effects.ts
/** AC-INF-003.2 — the destructive vocabulary. Matched case-insensitively, substring, not word. */
var DESTRUCTIVE_PATTERN = /delete|remove|purge|cancel|refund|revoke/i;
var READ_METHODS = /* @__PURE__ */ new Set(["GET", "HEAD"]);
/**
* REQ-INF-003 — classify a candidate's side effect.
*
* AC-INF-003.1 gives the base label from the method. AC-INF-003.2 escalates to `destructive` when
* the path or GraphQL operation name matches the destructive vocabulary. The method is part of the
* matched text, so `DELETE /orders/{orderId}` escalates without needing "delete" in the path.
*
* Escalation applies to writes only: a `GET /orders?status=cancelled` reads cancelled orders, it
* does not cancel anything, and labelling it destructive would only block bulk approval of a
* harmless read (AC-INF-003.3).
*/
function classify(input) {
	const method = input.method.toUpperCase();
	if (READ_METHODS.has(method)) return "read";
	const subject = `${method} ${input.path} ${input.operation ?? ""}`;
	return DESTRUCTIVE_PATTERN.test(subject) ? "destructive" : "write";
}
//#endregion
//#region ../studio/src/inference/payload.ts
/**
* AC-INF-005.1 — envelope keys carry no information, so the Primary Payload Path descends past
* them to the subtree a tool result should actually contain.
*/
var ENVELOPE_KEYS = [
	"data",
	"result",
	"results",
	"items",
	"records",
	"payload",
	"nodes",
	"edges",
	"content",
	"body"
];
/** AC-INF-005.3 — the escape hatch back to the untrimmed body. */
var RAW_PARAM = {
	type: "boolean",
	description: "Return the full untrimmed response body instead of the primary payload."
};
/**
* Returns the JSONPath into the useful subtree, or `$` when the body is already the payload.
* The path is the longest one that holds for every observed body, so a tool never trims into a
* subtree that only some responses have.
*/
function primaryPayloadPath(bodies) {
	const paths = bodies.filter((b) => b !== void 0 && b !== null).map(descend);
	if (paths.length === 0) return "$";
	return paths.reduce(commonPrefix);
}
function descend(body) {
	let node = body;
	const segments = [];
	while (node !== null && typeof node === "object" && !Array.isArray(node)) {
		const record = node;
		const keys = Object.keys(record);
		const envelope = ENVELOPE_KEYS.find((k) => keys.includes(k) && isContainer(record[k]));
		const only = keys.length === 1 && keys[0] !== void 0 && isContainer(record[keys[0]]) ? keys[0] : void 0;
		const next = envelope ?? only;
		if (next === void 0) break;
		segments.push(next);
		node = record[next];
	}
	return segments.length === 0 ? "$" : `$.${segments.join(".")}`;
}
var isContainer = (value) => value !== null && typeof value === "object";
function commonPrefix(a, b) {
	const left = a.split(".");
	const right = b.split(".");
	const shared = [];
	for (const [i, segment] of left.entries()) {
		if (segment !== right[i]) break;
		shared.push(segment);
	}
	return shared.length === 0 ? "$" : shared.join(".");
}
/** Resolves a JSONPath produced by `primaryPayloadPath` (dotted keys only, no wildcards). */
function resolvePath(body, path) {
	if (path === "$") return body;
	let node = body;
	for (const key of path.split(".").slice(1)) {
		if (node === null || typeof node !== "object") return void 0;
		node = node[key];
	}
	return node;
}
var CURSOR_PARAMS = [
	"cursor",
	"after",
	"starting_after",
	"page_token",
	"next_cursor"
];
var OFFSET_PARAMS = [
	"offset",
	"skip",
	"start"
];
var PAGE_PARAMS = [
	"page",
	"page_number",
	"pageNumber"
];
var NEXT_KEYS = [
	"next_cursor",
	"nextCursor",
	"end_cursor",
	"endCursor",
	"next",
	"next_page"
];
/**
* AC-INF-005.2 — a paginated collection exposes its page or cursor parameter and records the
* style, so the runtime can drive the next page instead of returning a truncated first one.
*/
function detectPagination(observedQuery, bodies) {
	const seen = new Set(observedQuery.flatMap((q) => Object.keys(q)));
	const nextPath = findNextPath(bodies);
	const match = (candidates) => candidates.find((c) => seen.has(c));
	const cursor = match(CURSOR_PARAMS);
	if (cursor !== void 0) return {
		style: "cursor",
		param: cursor,
		...nextPath !== void 0 ? { next_path: nextPath } : {}
	};
	const offset = match(OFFSET_PARAMS);
	if (offset !== void 0) return {
		style: "offset",
		param: offset
	};
	const page = match(PAGE_PARAMS);
	if (page !== void 0) return {
		style: "page",
		param: page
	};
}
function findNextPath(bodies, node = bodies[0], path = "$", depth = 0) {
	if (depth > 3 || node === null || typeof node !== "object" || Array.isArray(node)) return void 0;
	const record = node;
	for (const key of NEXT_KEYS) if (key in record) return `${path}.${key}`;
	for (const [key, value] of Object.entries(record)) {
		const found = findNextPath(bodies, value, `${path}.${key}`, depth + 1);
		if (found !== void 0) return found;
	}
}
/** Adds the `raw` escape hatch to an input schema without disturbing its required set. */
function withRawParam(schema) {
	const properties = {
		...schema["properties"],
		raw: RAW_PARAM
	};
	return {
		...schema,
		type: "object",
		properties
	};
}
//#endregion
//#region ../studio/src/inference/confidence.ts
/** Observations past this point add no further confidence. */
var SATURATION = 5;
var WEIGHTS = {
	observations: .5,
	stability: .3,
	sideEffect: .2
};
/** AC-INF-002.3 — a single observation can never produce a confident tool. */
var SPARSE_CEILING = .4;
/**
* REQ-INF-002 — confidence from observation count, schema stability, and side-effect certainty.
*
* Side-effect certainty is highest where the classification is unambiguous: a GET is a read and a
* destructive-vocabulary match is deliberate, while a bare POST could be either.
*/
function score(input) {
	const observations = Math.min(1, input.observations / SATURATION);
	const certainty = input.sideEffect === "write" ? .85 : 1;
	const raw = WEIGHTS.observations * observations + WEIGHTS.stability * clamp(input.stability) + WEIGHTS.sideEffect * certainty;
	const capped = input.observations <= 1 ? Math.min(raw, SPARSE_CEILING) : raw;
	return Math.round(clamp(capped) * 100) / 100;
}
var clamp = (value) => Math.min(1, Math.max(0, value));
//#endregion
//#region ../studio/src/descriptions/naming.ts
/** Intent verbs worth preferring over the method's generic verb when the evidence names one. */
var VERB_HINTS = [
	"transition",
	"archive",
	"unarchive",
	"publish",
	"unpublish",
	"cancel",
	"refund",
	"revoke",
	"approve",
	"reject",
	"assign",
	"unassign",
	"close",
	"reopen",
	"duplicate",
	"export",
	"import",
	"restore",
	"send",
	"invite",
	"upload",
	"retry",
	"resend",
	"suspend",
	"activate",
	"deactivate"
];
var METHOD_VERBS = {
	POST: "create",
	PUT: "update",
	PATCH: "update",
	DELETE: "delete"
};
function nameCandidate(input) {
	if (input.graphqlOperation !== void 0) return snake(input.graphqlOperation);
	const object = objectFrom(input.path);
	const verb = verbFrom(input);
	const noun = verb === "list" ? plural(object) : singular(object);
	return snake(verb === singular(noun) ? noun : `${verb}_${noun}`);
}
/**
* The resource the tool acts on. `POST /orders/{id}/refund` acts on an order, not on a "refund":
* a trailing action segment is the verb, so the noun is the resource that precedes it.
*/
function objectFrom(path) {
	const statics = path.split("/").filter((s) => s.length > 0 && !s.startsWith("{"));
	return [...statics].reverse().find((segment) => !isActionSegment(segment) && !/\d/.test(segment)) ?? statics.at(-1) ?? "resource";
}
var isActionSegment = (segment) => VERB_HINTS.includes(segment.toLowerCase());
function verbFrom(input) {
	const method = input.method.toUpperCase();
	if (method === "GET" || method === "HEAD") return input.addressed ? "get" : "list";
	const action = path0(input.path);
	const hint = hintVerb(input.annotation) ?? hintVerb(input.provenance);
	return action ?? hint ?? METHOD_VERBS[method] ?? "call";
}
function path0(path) {
	const last = path.split("/").filter((s) => s.length > 0 && !s.startsWith("{")).at(-1);
	return last !== void 0 && isActionSegment(last) ? last.toLowerCase() : void 0;
}
function hintVerb(evidence) {
	if (evidence === void 0) return void 0;
	const text = evidence.toLowerCase();
	return VERB_HINTS.find((verb) => text.includes(verb));
}
/**
* AC-INF-006.3 — two candidates that would share a name are disambiguated from the parameters
* that distinguish them, falling back to an ordinal only when nothing distinguishes them.
*/
function disambiguate(entries) {
	const names = entries.map((e) => e.name);
	const counts = /* @__PURE__ */ new Map();
	for (const name of names) counts.set(name, (counts.get(name) ?? 0) + 1);
	const taken = /* @__PURE__ */ new Set();
	return entries.map((entry, index) => {
		if ((counts.get(entry.name) ?? 0) <= 1) {
			taken.add(entry.name);
			return entry.name;
		}
		const others = entries.filter((_, i) => i !== index && entries[i]?.name === entry.name);
		const shared = new Set(others.flatMap((o) => o.parameters));
		const suffix = entry.parameters.filter((p) => !shared.has(p)).sort()[0];
		const candidate = suffix !== void 0 ? `${entry.name}_by_${snake(suffix)}` : `${entry.name}_${index + 1}`;
		let unique = candidate;
		let n = 2;
		while (taken.has(unique)) unique = `${candidate}_${n++}`;
		taken.add(unique);
		return unique;
	});
}
//#endregion
//#region ../studio/src/descriptions/writer.ts
/** AC-INF-006.2 — what it does, what it returns, when to use it. Never more than three. */
var MAX_SENTENCES = 3;
function descriptionInput(tool, provenance) {
	const path = tool.request.path;
	const graphql = tool.request.graphql?.operation;
	return {
		name: tool.name,
		method: tool.request.method,
		path,
		sideEffect: tool.side_effect,
		object: singular(objectNoun(tool.name, objectFrom(path), graphql)),
		addressed: addressesOneRecord(path),
		primaryPayloadPath: tool.response.primary_payload_path ?? "$",
		inputSchema: tool.request.input_schema,
		outputSchema: tool.response.output_schema,
		paginated: tool.response.pagination !== void 0,
		...tool.response.pagination !== void 0 ? { paginationParam: tool.response.pagination.param } : {},
		...tool.annotation !== void 0 ? { annotation: tool.annotation } : {},
		...provenance !== void 0 ? { provenance } : {},
		...graphql !== void 0 ? { graphqlOperation: graphql } : {}
	};
}
/** For GraphQL the path is just `/graphql`, so the noun has to come from the tool name. */
function objectNoun(name, lastStatic, graphql) {
	if (graphql !== void 0) return name.split("_").slice(1).join("_") || name;
	return lastStatic ?? "resource";
}
/**
* #DescriptionWriter, deterministic path. Produces a selection-oriented description with no model
* call, so inference stays replayable offline and a model is an enhancement rather than a
* dependency (ADR-006).
*/
function describeSync(input) {
	return limitSentences([
		action(input),
		returns(input),
		usage(input)
	].join(" "));
}
/** AC-CAP-007.3 — the note describes intent; the button label only describes the control. */
function action(input) {
	if (input.annotation !== void 0) return sentence(capitalize(input.annotation.trim()));
	const noun = input.object;
	switch (input.sideEffect) {
		case "read": return input.addressed ? sentence(`Fetches a single ${noun} by ${pathParams(input.path).join(" and ") || "identifier"}`) : sentence(`Lists ${plural(noun)} from ${input.path}${filters(input)}`);
		case "destructive": return sentence(`${capitalize(verbOf(input.name))}s ${article(noun)}${inputs(input)}; this cannot be undone`);
		default: return sentence(`${capitalize(verbOf(input.name))}s ${article(noun)}${inputs(input)}`);
	}
}
/** What a write takes is part of what it does, and it is what a request is phrased in terms of. */
function inputs(input) {
	const required = (input.inputSchema["required"] ?? []).filter((key) => key !== "confirm" && key !== "raw" && !input.path.includes(`{${key}}`));
	return required.length === 0 ? "" : ` from ${required.slice(0, 4).join(", ")}`;
}
var article = (noun) => `${/^[aeiou]/i.test(noun) ? "an" : "a"} ${noun}`;
/**
* An observed value set is the vocabulary a user will phrase their request in ("show me the
* refunded ones"), so a filter parameter's examples belong in the description, not only in the
* schema — that is what makes the right tool selectable from words the user actually uses.
*/
function filters(input) {
	const properties = input.inputSchema["properties"] ?? {};
	const described = Object.entries(properties).filter(([key]) => key !== "raw" && key !== input.paginationParam).filter(([, value]) => value["x-open-enum"] === true && Array.isArray(value["examples"])).map(([key, value]) => `${key} (${value["examples"].join(", ")})`);
	return described.length === 0 ? "" : `, filterable by ${described.join(" and ")}`;
}
function returns(input) {
	return sentence(`Returns ${describeShape(input.outputSchema, input.object)}${input.primaryPayloadPath === "$" ? "" : ` from \`${input.primaryPayloadPath}\``}${input.paginated ? ", one page at a time" : ""}`);
}
function usage(input) {
	const noun = input.object;
	if (input.sideEffect === "destructive") return sentence(`Use it only on an explicit request to ${verbOf(input.name)} ${article(noun)}, and pass confirm`);
	if (input.sideEffect === "write") return sentence(`Use it when the user asks to ${verbOf(input.name)} ${article(noun)}`);
	return input.addressed ? sentence(`Use it when you already know which ${noun} you need`) : sentence(`Use it to find ${plural(noun)} or to check their current state before acting on one`);
}
function describeShape(schema, noun) {
	if (schema["type"] === "array") {
		const fields = fieldNames(schema["items"] ?? {});
		return fields.length > 0 ? `a list of ${plural(noun)} with ${joinFields(fields)}` : `a list of ${plural(noun)}`;
	}
	const fields = fieldNames(schema);
	return fields.length > 0 ? `the ${noun} with ${joinFields(fields)}` : `the ${noun} payload`;
}
/** Required fields first: a field every observation carried describes the payload better than one
* that showed up once, and only the first few fit in a description. */
function fieldNames(schema, limit = 5) {
	const all = Object.keys(schema["properties"] ?? {});
	const required = new Set(schema["required"] ?? []);
	return [...all.filter((k) => required.has(k)), ...all.filter((k) => !required.has(k))].slice(0, limit);
}
var joinFields = (fields) => `${fields.join(", ")}`;
var pathParams = (path) => [...path.matchAll(/\{([^}]+)\}/g)].map((m) => m[1] ?? "");
var verbOf = (name) => name.split("_")[0] ?? "call";
var capitalize = (text) => text.charAt(0).toUpperCase() + text.slice(1);
var sentence = (text) => /[.!?]$/.test(text) ? text : `${text}.`;
function limitSentences(text, max = MAX_SENTENCES) {
	return text.split(/(?<=[.!?])\s+/).filter((s) => s.trim().length > 0).slice(0, max).join(" ").trim();
}
//#endregion
//#region ../studio/src/inference/engine.ts
var BODY_METHODS = /* @__PURE__ */ new Set([
	"POST",
	"PUT",
	"PATCH",
	"DELETE"
]);
/**
* #InferenceEngine — exchanges to scored candidates. Deterministic and replayable: no model call
* happens here, so re-inferring the same session always produces the same candidates (ADR-006).
*/
function infer(input) {
	const spans = input.annotations ?? [];
	const usable = input.exchanges.filter((e) => e.status > 0 && e.status < 400);
	const graphql = usable.filter(isGraphqlExchange);
	const candidates = [...groupEndpoints(usable.filter((e) => !isGraphqlExchange(e))).map((group) => restCandidate(group, spans)), ...splitOperations(graphql).map((op) => graphqlCandidate(op, spans))];
	const names = disambiguate(candidates.map((c) => ({
		name: c.tool.name,
		parameters: parameterNames(c.tool.request.input_schema)
	})));
	for (const [index, candidate] of candidates.entries()) {
		const name = names[index];
		if (name !== void 0) candidate.tool.name = name;
	}
	return candidates.sort((a, b) => a.tool.name.localeCompare(b.tool.name));
}
function restCandidate(group, spans) {
	const { method, path, params, exchanges } = group;
	const queries = exchanges.map((e) => queryParams(e.url));
	const bodies = BODY_METHODS.has(method) ? exchanges.map((e) => e.request_body) : [];
	const responses = exchanges.map((e) => e.response_body);
	const pagination = detectPagination(queries, responses);
	const inputSchema = withRawParam(optional(mergeSchemas(pathParamSchema(params), inferSchema(queries), inferSchema(bodies)), pagination?.param));
	const payloadPath = primaryPayloadPath(responses);
	const outputSchema = inferSchema(responses.map((body) => resolvePath(body, payloadPath)));
	const sideEffect = classify({
		method,
		path
	});
	const annotation = noteFor(exchanges, spans);
	const provenance = provenanceFor(exchanges);
	return assemble({
		name: nameCandidate({
			method,
			path,
			sideEffect,
			addressed: addressesOneRecord(path),
			annotation,
			provenance: provenance?.accessible_name
		}),
		sideEffect,
		exchanges,
		annotation,
		provenance,
		request: {
			method,
			path,
			input_schema: inputSchema
		},
		payloadPath,
		outputSchema,
		pagination,
		stabilityScore: (stability(inputSchema) + stability(outputSchema)) / 2
	});
}
function optional(schema, key) {
	if (key === void 0) return schema;
	const required = (schema["required"] ?? []).filter((k) => k !== key);
	return required.length > 0 ? {
		...schema,
		required
	} : omitRequired(schema);
}
function omitRequired(schema) {
	const { required: _required, ...rest } = schema;
	return rest;
}
function graphqlCandidate(op, spans) {
	const { operation, document, path, exchanges } = op;
	/**
	* AC-INF-004.4 — a 200 carrying `errors` is a FAILED exchange and contributes to no part of
	* schema inference, input included. A rejected call is precisely the one whose variables are
	* wrong: letting it through demotes every field it omitted to optional, so the tool would
	* advertise that an agent may reproduce the exact request the server refused.
	*/
	const successful = exchanges.filter((e) => !hasGraphqlErrors(e));
	const contractSource = successful.length > 0 ? successful : [];
	const inputSchema = withRawParam(inferSchema(contractSource.map(graphqlVariables)));
	const responses = contractSource.map((e) => e.response_body);
	const payloadPath = graphqlPayloadPath(responses);
	const outputSchema = inferSchema(responses.map((body) => resolvePath(body, payloadPath)));
	const sideEffect = classify({
		method: op.kind === "mutation" ? "POST" : "GET",
		path,
		operation
	});
	const annotation = noteFor(exchanges, spans);
	const provenance = provenanceFor(exchanges);
	return assemble({
		name: nameCandidate({
			method: "POST",
			path,
			sideEffect,
			addressed: false,
			annotation,
			provenance: provenance?.accessible_name,
			graphqlOperation: operation
		}),
		sideEffect,
		exchanges,
		annotation,
		provenance,
		request: {
			method: "POST",
			path,
			input_schema: inputSchema,
			graphql: {
				operation,
				document
			}
		},
		payloadPath,
		outputSchema,
		pagination: void 0,
		stabilityScore: (stability(inputSchema) + stability(outputSchema)) / 2,
		derivedName: op.derived_name,
		contractObservations: successful.length
	});
}
/** A GraphQL result always sits under `data.<rootField>`; the envelope walk finds it. */
function graphqlPayloadPath(responses) {
	return primaryPayloadPath(responses);
}
function assemble(a) {
	const observations = a.contractObservations ?? a.exchanges.length;
	const sample = a.exchanges[0];
	if (sample === void 0) throw new Error(`candidate "${a.name}" has no backing exchange`);
	const tool = Tool.parse({
		name: a.name,
		description: "",
		side_effect: a.sideEffect,
		confidence: score({
			observations,
			stability: a.stabilityScore,
			sideEffect: a.sideEffect
		}),
		observations,
		approved: false,
		request: a.request,
		response: {
			...a.payloadPath !== "$" ? { primary_payload_path: a.payloadPath } : {},
			output_schema: a.outputSchema,
			...a.pagination !== void 0 ? { pagination: a.pagination } : {}
		},
		...a.annotation !== void 0 ? { annotation: a.annotation } : {},
		flags: {
			sparse: observations <= 1,
			derived_name: a.derivedName ?? false,
			last_observed: isoDate(Math.max(...a.exchanges.map((e) => e.started_at)))
		}
	});
	tool.description = describeSync(descriptionInput(tool, a.provenance?.accessible_name));
	return {
		tool,
		evidence: {
			exchange_ids: a.exchanges.map((e) => e.id),
			sample,
			...a.provenance !== void 0 ? { provenance: a.provenance } : {},
			...a.annotation !== void 0 ? { annotation: a.annotation } : {}
		}
	};
}
function pathParamSchema(params) {
	const properties = {};
	for (const param of params) properties[param] = {
		type: "string",
		description: `Path parameter \`${param}\`.`
	};
	return params.length === 0 ? {} : {
		type: "object",
		properties,
		required: [...params].sort()
	};
}
/**
* AC-CAP-007.5 — a span that covers exchanges split across several candidates attaches to each
* of them. AC-CAP-007.4 — a session without spans simply yields no notes.
*/
function noteFor(exchanges, spans) {
	return spans.find((s) => exchanges.some((e) => e.position >= s.start_position && e.position <= s.end_position))?.note;
}
/** The provenance seen most often across the group; a one-off click should not name the tool. */
function provenanceFor(exchanges) {
	const counts = /* @__PURE__ */ new Map();
	for (const exchange of exchanges) {
		if (exchange.background || exchange.provenance === void 0) continue;
		const key = exchange.provenance.accessible_name;
		const entry = counts.get(key);
		if (entry) entry.count += 1;
		else counts.set(key, {
			provenance: exchange.provenance,
			count: 1
		});
	}
	return [...counts.values()].sort((a, b) => b.count - a.count)[0]?.provenance;
}
function parameterNames(schema) {
	return Object.keys(schema["properties"] ?? {}).filter((k) => k !== "raw");
}
function isoDate(epochMs) {
	return new Date(epochMs).toISOString().slice(0, 10);
}
//#endregion
//#region ../studio/src/promotion.ts
/**
* AC-REC-002.3 / AC-INF-003.3 — bulk approval reaches `read` candidates only. A write or a
* destructive tool has to be looked at one at a time; that is the whole point of review.
*/
function approveReads(candidates) {
	const result = {
		approved: [],
		skipped: []
	};
	for (const candidate of candidates) if (candidate.tool.side_effect === "read") {
		approve(candidate);
		result.approved.push(candidate.tool.name);
	} else result.skipped.push(candidate.tool.name);
	return result;
}
/**
* AC-REC-002.4 — approving a destructive candidate injects a required `confirm` parameter.
* `packages/shared/src/recipe.ts` validates this and refuses to serialize a recipe without it,
* so this is the one place that can satisfy that constraint.
*/
function approve(candidate) {
	candidate.tool.approved = true;
	if (candidate.tool.side_effect === "destructive") candidate.tool.request.input_schema = injectConfirm(candidate.tool.request.input_schema);
	return candidate;
}
function unapprove(candidate) {
	candidate.tool.approved = false;
	return candidate;
}
function injectConfirm(schema) {
	const properties = {
		...schema["properties"],
		confirm: CONFIRM_PARAM
	};
	const required = new Set(schema["required"] ?? []);
	required.add("confirm");
	return {
		...schema,
		type: "object",
		properties,
		required: [...required].sort()
	};
}
//#endregion
//#region ../studio/src/merge.ts
/** Fields a user can hand-edit in review and therefore fields re-inference must not clobber. */
var MERGEABLE_FIELDS = [
	"name",
	"description",
	"side_effect",
	"request.input_schema",
	"response.output_schema",
	"response.primary_payload_path"
];
/** What actually identifies a tool: the request it makes, not the name a user gave it. */
function identity(tool) {
	const { method, path, graphql } = tool.request;
	return graphql ? `graphql|${graphql.operation}` : `${method}|${path}`;
}
/**
* REQ-REC-003 — non-destructive regeneration. Re-inference improves what the user has not touched
* and never overwrites what they have; a recipe that punished editing would not be worth editing.
*/
function mergeRecipe(existing, incoming, options = {}) {
	const today = options.today ?? (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
	const fixtures = options.fixtures ?? {};
	const byName = new Map(incoming.map((tool) => [tool.name, tool]));
	/**
	* AC-REC-003.1 — `name` is user-editable, so a renamed tool must still be recognised as the
	* same tool on re-inference. Matching on name alone means a rename produces a duplicate: the
	* renamed tool is marked `unverified` even though its traffic was observed, and the freshly
	* inferred one is added alongside under the old name. Request identity is what actually
	* identifies a tool.
	*/
	const byIdentity = new Map(incoming.map((tool) => [identity(tool), tool]));
	const report = {
		recipe: existing,
		preserved: [],
		retained: [],
		conflicts: [],
		added: []
	};
	const tools = [];
	for (const current of existing.tools) {
		const fresh = byName.get(current.name) ?? byIdentity.get(identity(current));
		if (!fresh) {
			tools.push({
				...current,
				flags: {
					...current.flags,
					unverified: true,
					last_observed: current.flags.last_observed ?? today
				}
			});
			report.retained.push(current.name);
			continue;
		}
		byName.delete(fresh.name);
		byIdentity.delete(identity(fresh));
		const conflict = fixtureConflict(fresh, fixtures[current.name] ?? []);
		if (conflict !== void 0) {
			report.conflicts.push({
				tool: current.name,
				reason: conflict
			});
			tools.push(current);
			continue;
		}
		tools.push(mergeTool(current, fresh, report));
	}
	for (const fresh of byName.values()) {
		tools.push(fresh);
		report.added.push(fresh.name);
	}
	report.recipe = {
		...existing,
		tools
	};
	return report;
}
function mergeTool(current, fresh, report) {
	const merged = structuredClone(current);
	const suggestions = { ...current.flags.suggestions };
	const edited = new Set(current.flags.user_edited);
	for (const field of MERGEABLE_FIELDS) {
		const inferred = getField(fresh, field);
		if (inferred === void 0) continue;
		if (edited.has(field)) {
			if (JSON.stringify(inferred) !== JSON.stringify(getField(current, field))) {
				suggestions[field] = inferred;
				report.preserved.push({
					tool: current.name,
					field
				});
			}
			continue;
		}
		setField(merged, field, inferred);
	}
	merged.confidence = fresh.confidence;
	merged.observations = fresh.observations;
	merged.request.method = fresh.request.method;
	merged.request.path = fresh.request.path;
	if (fresh.request.graphql !== void 0) merged.request.graphql = fresh.request.graphql;
	merged.flags = {
		...merged.flags,
		sparse: fresh.flags.sparse,
		derived_name: fresh.flags.derived_name,
		unverified: false,
		suggestions,
		...fresh.flags.last_observed !== void 0 ? { last_observed: fresh.flags.last_observed } : {}
	};
	return merged;
}
/**
* AC-REC-003.3 — a stored fixture is only valid while the schema it was captured under still
* accepts it. A newly required request field the fixture never carried is the common case.
*/
function fixtureConflict(fresh, fixtures) {
	if (fixtures.length === 0) return void 0;
	const required = fresh.request.input_schema["required"] ?? [];
	for (const fixture of fixtures) {
		const body = fixture.request.body;
		const present = /* @__PURE__ */ new Set([
			...body !== null && typeof body === "object" ? Object.keys(body) : [],
			...pathKeys(fresh.request.path),
			...queryKeys(fixture.request.url)
		]);
		const missing = required.filter((key) => key !== "confirm" && key !== "raw" && !present.has(key));
		if (missing.length > 0) return `fixture ${fixture.tool}.json lacks newly required field(s): ${missing.sort().join(", ")}`;
	}
}
var pathKeys = (path) => [...path.matchAll(/\{([^}]+)\}/g)].map((m) => m[1] ?? "");
function queryKeys(url) {
	try {
		return [...new URL(url).searchParams.keys()];
	} catch {
		return [];
	}
}
function getField(tool, field) {
	const [head, tail] = field.split(".");
	const record = tool;
	if (tail === void 0) return record[head];
	const nested = record[head];
	return nested !== null && typeof nested === "object" ? nested[tail] : void 0;
}
function setField(tool, field, value) {
	const [head, tail] = field.split(".");
	const record = tool;
	if (tail === void 0) {
		record[head] = value;
		return;
	}
	const nested = record[head];
	if (nested !== null && typeof nested === "object") nested[tail] = value;
}
//#endregion
//#region ../studio/src/fixtures.ts
function toFixture(tool, exchange) {
	return {
		tool,
		recorded_at: new Date(exchange.started_at).toISOString(),
		request: {
			method: exchange.method,
			url: exchange.url,
			headers: redactHeaders(exchange.request_headers),
			...exchange.request_body !== void 0 ? { body: redactBody(exchange.request_body) } : {}
		},
		response: {
			status: exchange.status,
			headers: redactHeaders(exchange.response_headers),
			...exchange.response_body !== void 0 ? { body: redactBody(exchange.response_body) } : {}
		}
	};
}
/**
* AC-REC-004.1 / AC-REC-004.2 — the write gate. Redaction runs again here even though the capture
* store already ran it, and a surviving credential-shaped value fails the write rather than
* writing a file someone has to notice later (TR-6).
*/
function writeFixture(fixturesDir, recipe, fixture) {
	const leaked = findSurvivingSecrets(fixture);
	if (leaked.length > 0) throw new Error(`refusing to write fixture for "${fixture.tool}": credential-shaped value at ${leaked.join(", ")}`);
	const relative = join(recipe, `${fixture.tool}.json`);
	const absolute = join(fixturesDir, relative);
	mkdirSync(dirname(absolute), { recursive: true });
	writeFileSync(absolute, `${JSON.stringify(fixture, null, 2)}\n`, { mode: 384 });
	return relative;
}
function readFixtures(fixturesDir, recipe) {
	let entries;
	try {
		entries = readdirSync(join(fixturesDir, recipe));
	} catch {
		return [];
	}
	return entries.filter((name) => name.endsWith(".json")).sort().map((name) => JSON.parse(readFileSync(join(fixturesDir, recipe, name), "utf8")));
}
//#endregion
//#region ../studio/src/api.ts
/**
* #ReviewApp state. Holds candidates in memory for the life of a review and writes only to the
* recipe and fixture directories (ADR-006) — douzed keeps one of these per capture session.
*/
var StudioSession = class StudioSession {
	config;
	candidates;
	paths;
	constructor(config, candidates) {
		this.config = config;
		this.candidates = candidates;
		this.paths = config.paths ?? studioPaths();
	}
	static fromExchanges(config, input) {
		return new StudioSession(config, infer(input));
	}
	find(name) {
		const candidate = this.candidates.find((c) => c.tool.name === name);
		if (!candidate) throw new Error(`no candidate named "${name}"`);
		return candidate;
	}
	view() {
		return this.candidates.map((c) => ({
			name: c.tool.name,
			description: c.tool.description,
			side_effect: c.tool.side_effect,
			confidence: c.tool.confidence,
			observations: c.tool.observations,
			approved: c.tool.approved,
			bulk_approvable: c.tool.side_effect === "read",
			annotation: c.evidence.annotation,
			provenance: c.evidence.provenance?.accessible_name,
			route: c.evidence.provenance?.route,
			request: c.tool.request,
			response: c.tool.response,
			flags: c.tool.flags,
			sample: {
				method: c.evidence.sample.method,
				url: c.evidence.sample.url,
				status: c.evidence.sample.status,
				request_body: c.evidence.sample.request_body,
				response_body: c.evidence.sample.response_body
			}
		}));
	}
	/** AC-REC-002.2 — an inline edit is written to the recipe and the field marked `user_edited`. */
	edit(name, field, value) {
		if (!MERGEABLE_FIELDS.includes(field)) throw new Error(`field "${field}" is not editable`);
		const candidate = this.find(name);
		setField(candidate.tool, field, value);
		const edited = new Set(candidate.tool.flags.user_edited);
		edited.add(field);
		candidate.tool.flags.user_edited = [...edited].sort();
		return candidate;
	}
	approveReads() {
		return approveReads(this.candidates);
	}
	approve(name) {
		return approve(this.find(name));
	}
	unapprove(name) {
		return unapprove(this.find(name));
	}
	/**
	* Writes fixtures first, then the recipe: `Recipe` refuses to serialize an approved tool with no
	* fixture (AC-REC-004.1), so the order is load-bearing rather than incidental.
	*/
	save() {
		mkdirSync(this.paths.recipes, { recursive: true });
		const written = [];
		for (const candidate of this.candidates) {
			if (!candidate.tool.approved) continue;
			const reference = writeFixture(this.paths.fixtures, this.config.recipeName, toFixture(candidate.tool.name, candidate.evidence.sample));
			candidate.tool.fixtures = [reference];
			written.push(reference);
		}
		const fresh = this.candidates.map((c) => c.tool);
		const existing = this.loadExisting();
		const report = existing ? mergeRecipe(existing, fresh, { fixtures: this.fixturesByTool() }) : {
			recipe: this.buildRecipe(fresh),
			preserved: [],
			retained: [],
			conflicts: [],
			added: fresh.map((t) => t.name)
		};
		const path = join(this.paths.recipes, `${this.config.recipeName}.yaml`);
		writeFileSync(path, serializeRecipe(Recipe.parse(report.recipe)), { mode: 384 });
		return {
			...report,
			path,
			fixtures: written
		};
	}
	buildRecipe(tools) {
		return Recipe.parse({
			version: 1,
			name: this.config.recipeName,
			enabled: true,
			target: { base_url: this.config.baseUrl },
			...this.config.auth !== void 0 ? { auth: this.config.auth } : {},
			tools
		});
	}
	loadExisting() {
		const path = join(this.paths.recipes, `${this.config.recipeName}.yaml`);
		let source;
		try {
			source = readFileSync(path, "utf8");
		} catch {
			return null;
		}
		const result = parseRecipe(source, `${this.config.recipeName}.yaml`);
		return result.ok && result.recipe ? result.recipe : null;
	}
	fixturesByTool() {
		const out = {};
		for (const fixture of readFixtures(this.paths.fixtures, this.config.recipeName)) (out[fixture.tool] ??= []).push(fixture);
		return out;
	}
};
/** The origin most exchanges came from, which is the target's base URL. */
function baseUrlFrom(exchanges) {
	const counts = /* @__PURE__ */ new Map();
	for (const exchange of exchanges) counts.set(exchange.origin, (counts.get(exchange.origin) ?? 0) + 1);
	return [...counts.entries()].sort((a, b) => b[1] - a[1])[0]?.[0] ?? "http://localhost";
}
//#endregion
//#region ../studio/src/app.ts
/**
* #ReviewApp — one file, no framework, no build step. The page is a list, one primary button, and
* two editable fields; a component tree would be more code to reach the same screen. Inlined as a
* string so `tsc` needs no asset-copy step and douzed needs no __dirname lookup.
*
* douzed serves this at /review/:sessionId?token=… and the session id and token are inlined here,
* so the page authenticates its own fetches and the reader never opens a terminal.
*
* The audience is someone who has never heard the words "endpoint" or "side effect". Every string
* on the first screen is plain English; the developer-facing detail lives behind one <details>.
*/
var reviewPage = (session) => `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>What Douze can do</title>
<style>
${STYLE}
</style>
</head>
<body>
<!-- Both lines are rewritten in place when the list loads and again after saving, and that
     rewrite IS the confirmation the save worked — so it has to be announced, not just shown. -->
<div aria-live="polite">
  <h1 id="title">What Douze can do</h1>
  <p class="sub" id="sub">Working out what this site can do&hellip;</p>
</div>
<ul id="list"></ul>
<div class="actions" id="actions" hidden>
  <button type="button" class="primary" id="go" disabled>Nothing selected</button>
</div>
<div class="actions" id="after" hidden>
  <button type="button" class="quiet" id="back">Change what&rsquo;s on</button>
</div>
<p id="error" role="alert"></p>
<script>
const SESSION = ${inline(session.id)};
const TOKEN = ${inline(session.token)};
${SCRIPT}
<\/script>
</body>
</html>
`;
/**
* The two dead ends a browser can reach: a link whose token no longer matches — a bookmark kept
* across a reinstall, a URL copied out of a chat — and a session with nothing recorded in it. Both
* are a person looking at a blank tab wondering what they did wrong, so both get a sentence and a
* next move. Neither ever says "token": the reader never chose to have one.
*/
var noticePage = (headline, next) => `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>${escapeText(headline)}</title>
<style>
${STYLE}
</style>
</head>
<body>
<h1>${escapeText(headline)}</h1>
<p class="sub">${escapeText(next)}</p>
</body>
</html>
`;
/** Both pages, one look. Type scale 13/15/17/22, spacing in multiples of 4px. */
var STYLE = `  :root {
    color-scheme: light dark;
    --bg: light-dark(#ffffff, #16181c);
    --fg: light-dark(#15171c, #f1f3f6);
    --muted: light-dark(#565e6c, #a3abba);
    --line: light-dark(#d9dce3, #363b45);
    --accent: light-dark(#1a56c4, #86aaf7);
    --safe: light-dark(#166a44, #6ec99c);
    --changes: light-dark(#82500a, #e2a862);
    --danger: light-dark(#a11f1f, #f28c8c);
  }
  * { box-sizing: border-box; }
  body {
    background: var(--bg); color: var(--fg); margin: 0 auto; max-width: 660px;
    padding: 40px 20px 80px; font: 15px/1.55 ui-sans-serif, system-ui, sans-serif;
  }
  h1 { font-size: 22px; line-height: 1.25; margin: 0 0 8px; }
  .sub { font-size: 15px; color: var(--muted); margin: 0 0 28px; }
  ul { list-style: none; margin: 0; padding: 0; }
  li { border-top: 1px solid var(--line); padding: 20px 0; }
  li:last-of-type { border-bottom: 1px solid var(--line); }
  .head { display: flex; gap: 16px; align-items: flex-start; justify-content: space-between; }
  .desc { font-size: 17px; margin: 0; flex: 1; }
  .meta { font-size: 13px; color: var(--muted); margin: 8px 0 0; display: flex; flex-wrap: wrap; gap: 8px; align-items: baseline; }
  .name { font-family: ui-monospace, monospace; font-size: 13px; color: var(--muted); }
  .chip { display: inline-flex; gap: 4px; align-items: baseline; font-size: 13px; }
  .chip.read { color: var(--safe); }
  .chip.write { color: var(--changes); }
  .chip.destructive { color: var(--danger); }
  .warn { font-size: 13px; color: var(--muted); margin: 4px 0 0; }
  .consequence { font-size: 13px; color: var(--changes); margin: 8px 0 0; }
  .toggle { display: inline-flex; gap: 8px; align-items: center; font-size: 13px; color: var(--muted); cursor: pointer; white-space: nowrap; }
  .toggle input { width: 18px; height: 18px; margin: 0; accent-color: var(--accent); cursor: pointer; }
  details { margin: 12px 0 0; }
  summary { font-size: 13px; color: var(--muted); cursor: pointer; }
  pre { background: light-dark(#f4f5f8, #1e2128); border-radius: 6px; padding: 12px; margin: 8px 0 0; overflow: auto; max-height: 240px; font-size: 13px; }
  .actions { margin: 32px 0 0; display: flex; gap: 16px; align-items: center; flex-wrap: wrap; }
  .primary {
    font: inherit; font-size: 17px; padding: 12px 24px; border: 1px solid transparent; border-radius: 8px;
    background: var(--accent); color: var(--bg); cursor: pointer;
  }
  .primary[disabled] { background: none; color: var(--muted); border-color: var(--line); cursor: not-allowed; }
  .quiet { font: inherit; font-size: 15px; padding: 8px 0; border: none; background: none; color: var(--accent); text-decoration: underline; cursor: pointer; }
  #error { font-size: 15px; color: var(--danger); margin: 16px 0 0; }
  /* A dashed rule alone reads as decoration; the pencil and the text cursor say "you can type
     here" before anyone clicks, and the affordance firms up under the pointer. */
  [contenteditable] { border-bottom: 1px dashed var(--line); outline: none; cursor: text; }
  [contenteditable]::after { content: ' \\270e'; color: var(--muted); font-size: 13px; }
  [contenteditable]:hover { border-bottom-color: var(--accent); }
  [contenteditable]:focus { border-bottom-style: solid; }
  [contenteditable]:focus::after { content: none; }
  :focus-visible { outline: 2px solid var(--accent); outline-offset: 2px; border-radius: 2px; }
  [hidden] { display: none !important; }`;
var SCRIPT = `
// Word AND shape: the category is never carried by colour alone.
const KINDS = {
  read: { word: 'Reads information', mark: '\\u00b7' },
  write: { word: 'Makes changes', mark: '\\u25b2' },
  destructive: { word: 'Deletes things', mark: '\\u25a0' },
};
const WARNINGS = [
  ['sparse', 'Only seen once'],
  ['derived_name', 'Name is a guess'],
  ['unverified', 'Not checked yet'],
];

let state = null;
let seeded = false;
const chosen = new Set();

const el = (tag, props, children) => {
  const node = Object.assign(document.createElement(tag), props || {});
  for (const child of children || []) node.append(child);
  return node;
};
const byId = (id) => document.getElementById(id);
const fail = (sentence) => { byId('error').textContent = sentence; };

async function api(path, body) {
  const init = { headers: { 'x-douze-token': TOKEN } };
  if (body) {
    init.method = 'POST';
    init.headers['content-type'] = 'application/json';
    init.body = JSON.stringify(body);
  }
  const res = await fetch(path, init);
  if (!res.ok) throw new Error(String(res.status));
  return res.json();
}

function editable(tag, candidate, field, className) {
  const node = el(tag, { className: className, textContent: candidate[field], contentEditable: 'plaintext-only' });
  node.setAttribute('aria-label', field === 'name' ? 'Short name for this' : 'What this does');
  node.addEventListener('blur', async () => {
    const value = node.textContent.trim();
    if (value === candidate[field] || value === '') { node.textContent = candidate[field]; return; }
    try {
      await api('/api/review/' + SESSION + '/edit', { name: candidate.name, field: field, value: value });
      fail('');
      await load();
    } catch (error) {
      node.textContent = candidate[field];
      fail("Couldn't save that. Nothing has changed — try again.");
    }
  });
  return node;
}

function item(candidate) {
  const kind = KINDS[candidate.side_effect] || KINDS.read;
  const consequence = el('p', {
    className: 'consequence',
    textContent: 'This will run on your real account.',
    hidden: candidate.side_effect === 'read' || !chosen.has(candidate.name),
  });

  const box = el('input', { type: 'checkbox', checked: chosen.has(candidate.name) });
  box.setAttribute('aria-label', 'Turn on: ' + candidate.description);
  const label = el('span', { textContent: box.checked ? 'On' : 'Off' });
  box.addEventListener('change', () => {
    if (box.checked) chosen.add(candidate.name); else chosen.delete(candidate.name);
    label.textContent = box.checked ? 'On' : 'Off';
    consequence.hidden = candidate.side_effect === 'read' || !box.checked;
    syncButton();
  });

  const seen = candidate.observations === 1 ? 'Seen once' : 'Seen ' + candidate.observations + ' times';
  const meta = el('p', { className: 'meta' }, [
    el('span', { className: 'chip ' + candidate.side_effect }, [
      el('span', { textContent: kind.mark, ariaHidden: 'true' }),
      el('span', { textContent: kind.word }),
    ]),
    el('span', { textContent: seen }),
    editable('code', candidate, 'name', 'name'),
  ]);

  const parts = [
    el('div', { className: 'head' }, [
      editable('p', candidate, 'description', 'desc'),
      el('label', { className: 'toggle' }, [box, label]),
    ]),
    meta,
  ];
  for (const [flag, sentence] of WARNINGS) {
    if (candidate.flags[flag]) parts.push(el('p', { className: 'warn', textContent: sentence }));
  }
  parts.push(consequence);
  parts.push(
    el('details', {}, [
      el('summary', { textContent: 'Technical details' }),
      el('p', { className: 'warn', textContent: candidate.request.method + ' ' + candidate.request.path }),
      el('pre', { textContent: JSON.stringify(candidate.sample, null, 2) }),
      el('pre', { textContent: 'Input schema\\n' + JSON.stringify(candidate.request.input_schema, null, 2) }),
    ]),
  );
  return el('li', {}, parts);
}

function syncButton() {
  const go = byId('go');
  go.disabled = chosen.size === 0;
  go.textContent = chosen.size === 0 ? 'Nothing selected' : 'Turn these on';
}

function render() {
  byId('title').textContent = 'What Douze can do on ' + state.site;
  byId('sub').textContent =
    'Douze watched you use this site and worked out what it could do for you. Turn on the ones you want. ' +
    'Everything it saw stayed on your computer.';
  const list = byId('list');
  list.textContent = '';
  for (const candidate of state.candidates) list.append(item(candidate));
  byId('actions').hidden = false;
  byId('after').hidden = true;
  syncButton();
}

async function load() {
  state = await api('/api/review/' + SESSION);
  const names = new Set(state.candidates.map((c) => c.name));
  for (const name of chosen) if (!names.has(name)) chosen.delete(name);
  // Reads are pre-selected once; a later reload must not undo an unchecked box.
  if (!seeded) {
    seeded = true;
    for (const candidate of state.candidates) if (candidate.side_effect === 'read') chosen.add(candidate.name);
  }
  render();
}

function done(count) {
  byId('title').textContent =
    'Done — ' + count + ' thing' + (count === 1 ? '' : 's') + ' turned on for ' + state.site + '.';
  byId('sub').textContent = 'Open the app you added Douze to and ask it. Nothing else to install.';
  byId('list').textContent = '';
  byId('actions').hidden = true;
  byId('after').hidden = false;
}

byId('go').addEventListener('click', async () => {
  const all = state.candidates.map((c) => c.name);
  try {
    fail('');
    await api('/api/review/' + SESSION + '/enable', { names: all.filter((n) => chosen.has(n)) });
    const off = all.filter((n) => !chosen.has(n));
    if (off.length > 0) await api('/api/review/' + SESSION + '/disable', { names: off });
    const report = await api('/api/review/' + SESSION + '/save', {});
    done(report.tools.length);
  } catch (error) {
    fail("Couldn't save that. Nothing has changed — try again.");
  }
});

byId('back').addEventListener('click', () => { fail(''); render(); });

load().catch(() =>
  fail(
    "Couldn't load what this site can do. Try reloading this page. " +
      "If that doesn't help, click the Douze button in Chrome and record the site again.",
  ),
);
`;
/**
* JSON.stringify escapes quotes and backslashes but not "<", so a value containing a closing
* script tag would end the block and everything after it would be markup. Unreachable through any
* input today; escaping it makes that a property of the page rather than of the id generator.
*/
var inline = (value) => JSON.stringify(value).replaceAll("<", "\\u003c");
var escapeText = (value) => value.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;");
//#endregion
//#region ../studio/src/eject.ts
/**
* #PackageEjector — FRD-8. Compiles one recipe into a standalone incur package.
*
* Eject is the escape hatch, not the default path (ADR-005): the runtime interprets recipes so a
* description edit reaches a running client in seconds, and only an artifact you want to ship,
* run in CI, or hand to a machine with no Douze install is worth generating code for.
*
* Emission is a pure function of the recipe and its fixtures — no clock, no randomness, no
* filesystem ordering — so two ejects of the same recipe are byte-identical (AC-EJT-001.4).
*/
/** Pinned so an eject is reproducible; bump with the workspace's incur. */
var INCUR_VERSION = "0.4.26";
var TSX_VERSION = "4.23.1";
var TYPESCRIPT_VERSION = "7.0.2";
/** AC-EJT-001.1 — one command per approved tool. Unapproved candidates are not tools. */
function eject(input) {
	const { recipe } = input;
	const tools = [...recipe.tools].filter((t) => t.approved).sort((a, b) => a.name.localeCompare(b.name)).map((tool) => describeTool(tool, recipe, input.fixturesDir));
	const files = {
		"package.json": packageJson(recipe),
		"tsconfig.json": tsconfig(recipe),
		"src/tools.ts": toolsModule(recipe, tools),
		"src/execute.ts": executeModule(recipe),
		"src/index.ts": indexModule(recipe),
		"src/replay.ts": replayModule(recipe)
	};
	const written = [];
	for (const [name, contents] of Object.entries(files)) {
		const path = join(input.out, name);
		mkdirSync(dirname(path), { recursive: true });
		writeFileSync(path, contents);
		written.push(name);
	}
	return {
		dir: input.out,
		files: written,
		tools: tools.map((t) => t.name)
	};
}
/** Control flags are never positional: `cancel_order 1044 true` is too easy to get wrong. */
var CONTROL_PARAMS = /* @__PURE__ */ new Set(["raw", "confirm"]);
function describeTool(tool, recipe, fixturesDir) {
	const schema = tool.request.input_schema;
	const properties = schema["properties"] ?? {};
	const required = new Set(schema["required"] ?? []);
	const pathParams = [...tool.request.path.matchAll(/\{(\w+)\}/g)].map((m) => m[1] ?? "");
	const argKeys = [.../* @__PURE__ */ new Set([...pathParams, ...required])].filter((k) => !CONTROL_PARAMS.has(k)).sort();
	const optionKeys = Object.keys(properties).filter((k) => !argKeys.includes(k)).sort();
	const fixture = loadFixture(tool, fixturesDir);
	return {
		name: tool.name,
		description: describe(tool),
		side_effect: tool.side_effect,
		request: {
			method: tool.request.method,
			path: tool.request.path,
			headers: tool.request.headers,
			...tool.request.graphql !== void 0 ? { graphql: tool.request.graphql } : {}
		},
		args_schema: pick(properties, argKeys, argKeys),
		options_schema: pick(properties, optionKeys, optionKeys.filter((k) => k === "confirm")),
		output_schema: tool.response.output_schema,
		...tool.response.primary_payload_path !== void 0 ? { primary_payload_path: tool.response.primary_payload_path } : {},
		examples: examplesFor(tool, recipe, argKeys, optionKeys, properties, fixture),
		...fixture !== void 0 ? { fixture } : {}
	};
}
function describe(tool) {
	const parts = [tool.description];
	if (tool.side_effect === "destructive") parts.push("Destructive: requires confirm=true.");
	return parts.join(" ");
}
function pick(properties, keys, required) {
	const picked = {};
	for (const key of keys) {
		const property = properties[key];
		if (property !== void 0) picked[key] = property;
	}
	const schema = {
		type: "object",
		properties: picked
	};
	if (required.length > 0) schema["required"] = [...required].sort();
	return schema;
}
function loadFixture(tool, fixturesDir) {
	const reference = tool.fixtures[0];
	if (reference === void 0) return void 0;
	let fixture;
	try {
		fixture = JSON.parse(readFileSync(join(fixturesDir, reference), "utf8"));
	} catch {
		return;
	}
	/**
	* TR-6 names "generated source" explicitly, and this fixture is about to be serialised whole
	* into a package the user is told to ship. Fixtures are hand-editable JSON on disk, so the
	* write-time gate in `fixtures.ts` is not a guarantee about what is there now — re-run it.
	*/
	const leaked = findSurvivingSecrets(fixture);
	if (leaked.length > 0) throw new Error(`refusing to eject "${tool.name}": fixture "${reference}" carries a credential-shaped value at ${leaked.join(", ")}`);
	return fixture;
}
/**
* AC-EJT-001.2 — at least one `examples` entry drawn from a fixture. Values come from the
* recorded exchange, so the example is a call that actually happened rather than a restatement
* of the schema.
*/
function examplesFor(tool, recipe, argKeys, optionKeys, properties, fixture) {
	const source = fixture === void 0 ? void 0 : {
		url: fixture.request.url,
		body: fixture.request.body
	};
	const args = {};
	for (const key of argKeys) args[key] = sampleValue(key, properties[key], source);
	const options = {};
	if (tool.side_effect === "destructive" && optionKeys.includes("confirm")) options["confirm"] = true;
	const provenance = fixture === void 0 ? "the recorded session" : `fixture ${tool.fixtures[0] ?? ""}`;
	return [{
		args,
		options,
		description: `Recorded against ${recipe.target.base_url} (${provenance})`
	}];
}
function sampleValue(name, property, source) {
	if (source !== void 0) {
		const fromQuery = queryValue(source.url, name);
		if (fromQuery !== void 0) return fromQuery;
		const fromBody = findValue(source.body, name);
		if (fromBody !== void 0) return fromBody;
		const fromPath = pathValue(source.url, name);
		if (fromPath !== void 0) return fromPath;
	}
	const examples = property?.["examples"];
	if (Array.isArray(examples) && examples.length > 0) return examples[0];
	switch (property?.["type"]) {
		case "integer":
		case "number": return 1;
		case "boolean": return true;
		case "array": return [];
		default: return `<${name}>`;
	}
}
function queryValue(url, name) {
	try {
		return new URL(url).searchParams.get(name) ?? void 0;
	} catch {
		return;
	}
}
/** A path parameter's value is the last identifier-shaped segment of the recorded URL. */
function pathValue(url, name) {
	if (!/id$/i.test(name)) return void 0;
	try {
		return [...new URL(url).pathname.split("/").filter((s) => s.length > 0)].reverse().find((s) => /^\d+$/.test(s));
	} catch {
		return;
	}
}
function findValue(value, key, depth = 3) {
	if (depth < 0 || value === null || typeof value !== "object") return void 0;
	if (Array.isArray(value)) return findValue(value[0], key, depth - 1);
	const record = value;
	const direct = record[key];
	if (key in record && isScalar(direct)) return direct;
	for (const nested of Object.values(record)) {
		const found = findValue(nested, key, depth - 1);
		if (found !== void 0) return found;
	}
}
var isScalar = (value) => typeof value === "string" || typeof value === "number" || typeof value === "boolean";
/** AC-EJT-001.5 — every file names its source recipe and that recipe's schema version. */
function header(recipe) {
	return [
		`// Generated by \`douze eject\` from recipe "${recipe.name}" (recipe schema version ${recipe.version}).`,
		"// Do not edit: re-eject to regenerate. Emission is deterministic and byte-identical.",
		""
	].join("\n");
}
/** AC-EJT-001.4 — sorted keys and fixed formatting; nothing here reads a clock. */
function stableJson(value, indent = 2) {
	return JSON.stringify(sortKeys(value), null, indent);
}
function sortKeys(value) {
	if (Array.isArray(value)) return value.map(sortKeys);
	if (value === null || typeof value !== "object") return value;
	const record = value;
	const out = {};
	for (const key of Object.keys(record).sort()) out[key] = sortKeys(record[key]);
	return out;
}
/** AC-EJT-001.3 — `incur` is the only runtime dependency; nothing here is a Douze module. */
function packageJson(recipe) {
	return `${stableJson({
		_douze: `Generated by \`douze eject\` from recipe "${recipe.name}" (recipe schema version ${recipe.version}). Do not edit; re-eject to regenerate.`,
		name: `${recipe.name}-tools`,
		version: "0.0.0",
		private: true,
		type: "module",
		scripts: {
			start: "tsx src/index.ts",
			test: "tsx src/replay.ts"
		},
		dependencies: { incur: INCUR_VERSION },
		devDependencies: {
			tsx: TSX_VERSION,
			typescript: TYPESCRIPT_VERSION
		}
	})}\n`;
}
function tsconfig(recipe) {
	return `${header(recipe)}${stableJson({
		compilerOptions: {
			target: "ES2023",
			lib: ["ES2023"],
			module: "ESNext",
			moduleResolution: "bundler",
			strict: true,
			skipLibCheck: true,
			noEmit: true,
			types: ["node"]
		},
		include: ["src"]
	})}\n`;
}
function toolsModule(recipe, tools) {
	return `${header(recipe)}${TOOLS_TYPES}
export const RECIPE: EjectedRecipe = ${stableJson({
		name: recipe.name,
		version: recipe.version,
		base_url: recipe.target.base_url,
		auth: recipe.auth
	})}

export const TOOLS: EjectedTool[] = ${stableJson(tools)}
`;
}
var TOOLS_TYPES = `export interface EjectedRecipe {
  name: string
  version: number
  base_url: string
  auth: { mode: string; keychain_ref?: string; refresh_endpoint?: string; credential_source?: unknown[] }
}

export interface EjectedFixture {
  tool: string
  recorded_at: string
  request: { method: string; url: string; headers: Record<string, string>; body?: unknown }
  response: { status: number; headers: Record<string, string>; body?: unknown }
}

export interface EjectedTool {
  name: string
  description: string
  side_effect: 'read' | 'write' | 'destructive'
  request: {
    method: string
    path: string
    headers: Record<string, string>
    graphql?: { operation: string; document: string }
  }
  args_schema: Record<string, unknown>
  options_schema: Record<string, unknown>
  output_schema: Record<string, unknown>
  primary_payload_path?: string
  examples: { args: Record<string, unknown>; options: Record<string, unknown>; description: string }[]
  fixture?: EjectedFixture
}
`;
/**
* The execution module. Relay-first when douzed is reachable (AC-EJT-002.1), direct with the
* degraded notice when it is not and Headless Mode is configured (AC-EJT-002.2). The relay path
* posts to douzed exactly as the interpreted client does, so guards — rate limit, destructive
* confirmation, degradation — still run inside the daemon and cannot be bypassed by ejecting.
*/
function executeModule(recipe) {
	return `${header(recipe)}import { execFileSync } from 'node:child_process'
import { readFileSync } from 'node:fs'
import { homedir } from 'node:os'
import { join } from 'node:path'
import { RECIPE, type EjectedTool } from './tools.js'

/** Copied verbatim from douzed's headless executor: this path must announce itself. */
export const DEGRADED_NOTICE =
  'Executed via Headless Mode — the degraded path. Requests were issued directly from douzed ' +
  'using a stored session rather than through your signed-in browser.'

/** Matches the interpreted runtime's result cap so an ejected call returns the same bytes. */
export const MAX_RESULT_BYTES = 32 * 1024

export interface Result {
  status: number
  duration_ms: number
  data: unknown
  note?: string
  notice?: string
  truncated?: { message: string; untrimmed_bytes: number; returned_bytes: number }
}

export class ToolError extends Error {
  constructor(
    readonly code: string,
    message: string,
  ) {
    super(message)
  }
}

interface Relay {
  url: string
  token: string
}

/** douzed writes its port and install token under DOUZE_HOME; env vars override for CI. */
function relayTarget(): Relay | null {
  const url = process.env['DOUZE_RELAY_URL']
  const token = process.env['DOUZE_INSTALL_TOKEN']
  if (url && token) return { url, token }
  const home = process.env['DOUZE_HOME'] ?? join(homedir(), '.douze')
  try {
    const runtime = JSON.parse(readFileSync(join(home, 'douzed.json'), 'utf8')) as { port: number }
    return {
      url: 'http://127.0.0.1:' + String(runtime.port),
      token: readFileSync(join(home, 'token'), 'utf8').trim(),
    }
  } catch {
    return null
  }
}

export async function execute(tool: EjectedTool, params: Record<string, unknown>): Promise<Result> {
  const started = Date.now()
  const relay = relayTarget()
  if (relay) {
    const response = await viaRelay(relay, tool, params)
    // A null means the daemon was not answering. Any other failure is a real error and must not
    // silently fall through to the degraded path (AC-CON-004.4).
    if (response !== null) {
      return shape(tool, params, response.status ?? 0, response.body, response.duration_ms ?? Date.now() - started)
    }
  }
  const direct = await viaHeadless(tool, params)
  return { ...shape(tool, params, direct.status, direct.body, Date.now() - started), notice: DEGRADED_NOTICE }
}

interface RelayResponse {
  status?: number
  body?: unknown
  duration_ms?: number
}

async function viaRelay(relay: Relay, tool: EjectedTool, params: Record<string, unknown>): Promise<RelayResponse | null> {
  const path = '/relay/' + encodeURIComponent(RECIPE.name) + '/' + encodeURIComponent(tool.name)
  let response: Response
  try {
    response = await fetch(relay.url + path, {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-douze-token': relay.token },
      body: JSON.stringify({ args: params, timeout_ms: 300000 }),
    })
  } catch {
    return null
  }
  const body = (await response.json().catch(() => undefined)) as RelayResponse & { error?: string; code?: string }
  if (!response.ok) {
    throw new ToolError(body?.code ?? 'relay_failed', body?.error ?? 'relay returned ' + String(response.status))
  }
  return body
}

/**
 * AC-EJT-002.2 — the degraded path. Mirrors douzed's headless executor: the stored session is
 * attached as a cookie, and a 401 triggers the recipe's refresh endpoint exactly once.
 */
async function viaHeadless(tool: EjectedTool, params: Record<string, unknown>): Promise<{ status: number; body: unknown }> {
  if (RECIPE.auth.mode !== 'headless' || !RECIPE.auth.keychain_ref) {
    throw new ToolError(
      'relay_unreachable',
      'douzed is not reachable and Headless Mode is not enabled for "' +
        RECIPE.name +
        '". Start douzed so the browser relay can run, or enable Headless Mode.',
    )
  }
  const session = storedSession(RECIPE.auth.keychain_ref)
  if (!session) {
    throw new ToolError(
      'session_expired',
      'No stored session for "' + RECIPE.name + '". Browser relay is required to re-establish it.',
    )
  }

  let response = await issue(tool, params, session)
  if (response.status === 401 && RECIPE.auth.refresh_endpoint) {
    const refreshed = await refresh(session)
    // A single retry, never a loop.
    if (refreshed) response = await issue(tool, params, refreshed)
    if (!refreshed || response.status === 401) {
      throw new ToolError(
        'session_expired',
        'The stored session for "' + RECIPE.name + '" could not be refreshed. Browser relay is required.',
      )
    }
  }
  return response
}

function storedSession(account: string): string | null {
  const override = process.env['DOUZE_HEADLESS_SESSION']
  if (override) return override
  try {
    return execFileSync('security', ['find-generic-password', '-s', 'douze-headless', '-a', account, '-w'], {
      encoding: 'utf8',
    }).trim()
  } catch {
    return null
  }
}

async function issue(tool: EjectedTool, params: Record<string, unknown>, session: string) {
  const descriptor = buildRequest(tool, params)
  const response = await fetch(descriptor.url, {
    method: descriptor.method,
    headers: { ...descriptor.headers, cookie: session },
    ...(descriptor.body === undefined ? {} : { body: JSON.stringify(descriptor.body) }),
    redirect: 'manual',
  })
  return { status: response.status, body: await response.json().catch(() => undefined) }
}

async function refresh(session: string): Promise<string | null> {
  try {
    const response = await fetch(new URL(RECIPE.auth.refresh_endpoint as string, RECIPE.base_url), {
      method: 'POST',
      headers: { cookie: session },
    })
    if (!response.ok) return null
    return response.headers.get('set-cookie') ?? session
  } catch {
    return null
  }
}

/**
 * Path parameters substitute into the Endpoint Template; the rest become a query string or a
 * JSON body depending on the method. Identical to douzed's \`buildRequest\`.
 */
export function buildRequest(tool: EjectedTool, params: Record<string, unknown>) {
  const remaining: Record<string, unknown> = { ...params }
  delete remaining['confirm']
  delete remaining['raw']

  const resolvedPath = tool.request.path.replace(/\\{(\\w+)\\}/g, (_match: string, name: string) => {
    const value = remaining[name]
    delete remaining[name]
    return encodeURIComponent(String(value ?? ''))
  })

  const url = new URL(resolvedPath, RECIPE.base_url)
  let body: unknown

  if (tool.request.graphql) {
    body = {
      operationName: tool.request.graphql.operation,
      query: tool.request.graphql.document,
      variables: remaining,
    }
  } else if (tool.request.method === 'GET' || tool.request.method === 'HEAD') {
    for (const [key, value] of Object.entries(remaining)) {
      if (value !== undefined && value !== null) url.searchParams.set(key, String(value))
    }
  } else {
    body = remaining
  }

  return {
    url: url.toString(),
    method: tool.request.method,
    headers: { ...tool.request.headers, ...(body === undefined ? {} : { 'content-type': 'application/json' }) },
    body,
  }
}

/** Trims to the Primary Payload Path and caps the result, exactly as the interpreted client does. */
export function shape(tool: EjectedTool, params: Record<string, unknown>, status: number, body: unknown, durationMs: number): Result {
  let data = body
  let note: string | undefined
  const path = tool.primary_payload_path

  if (params['raw'] !== true && path) {
    const picked = selectPath(body, path)
    if (picked === MISSING) {
      note = 'primary_payload_path "' + path + '" did not resolve; returning the full body.'
    } else {
      data = picked
    }
  }

  const encoded = Buffer.byteLength(json(data), 'utf8')
  if (encoded <= MAX_RESULT_BYTES) {
    return { status, duration_ms: durationMs, data, ...(note === undefined ? {} : { note }) }
  }
  const returned = cutToBytes(json(data), MAX_RESULT_BYTES)
  return {
    status,
    duration_ms: durationMs,
    data: returned,
    truncated: {
      message: 'Result truncated to ' + String(MAX_RESULT_BYTES) + ' bytes; the untrimmed result was ' + String(encoded) + ' bytes.',
      untrimmed_bytes: encoded,
      returned_bytes: Buffer.byteLength(returned, 'utf8'),
    },
    ...(note === undefined ? {} : { note }),
  }
}

const json = (value: unknown): string => (typeof value === 'string' ? value : (JSON.stringify(value) ?? 'null'))

/**
 * Cuts to at most \`limit\` BYTES without splitting a UTF-8 sequence. Buffer.subarray().toString()
 * turns a split multi-byte sequence into a 3-byte U+FFFD, which lands OVER the cap. A
 * continuation byte is 0b10xxxxxx, so walk back to the last lead byte.
 */
function cutToBytes(value: string, limit: number): string {
  const buffer = Buffer.from(value, 'utf8')
  if (buffer.length <= limit) return value
  let end = limit
  while (end > 0 && (buffer[end] & 0xc0) === 0x80) end -= 1
  return buffer.subarray(0, end).toString('utf8')
}

export const MISSING = Symbol('missing')

/** The rooted dot/bracket subset of JSONPath that recipes actually record. */
export function selectPath(value: unknown, path: string): unknown {
  let current: unknown = value
  const segments = path
    .replace(/^\\$\\.?/, '')
    .replace(/\\[(\\d+)\\]/g, '.$1')
    .replace(/\\['([^']*)'\\]/g, '.$1')
    .split('.')
    .filter((s) => s.length > 0)

  for (const segment of segments) {
    if (current === null || current === undefined) return MISSING
    if (Array.isArray(current)) {
      const index = Number(segment)
      if (!Number.isInteger(index) || index < 0 || index >= current.length) return MISSING
      current = current[index]
      continue
    }
    if (typeof current !== 'object') return MISSING
    const record = current as Record<string, unknown>
    if (!(segment in record)) return MISSING
    current = record[segment]
  }
  return current
}
`;
}
function indexModule(recipe) {
	return `${header(recipe)}import { Cli, Openapi, z } from 'incur'
import { execute, ToolError } from './execute.js'
import { RECIPE, TOOLS } from './tools.js'

const cli = Cli.create(RECIPE.name, {
  version: '0.0.0',
  description: 'Tools recorded from ' + RECIPE.base_url + ' (recipe "' + RECIPE.name + '").',
})

// AC-EJT-001.1 — one command per approved tool. Path and required parameters are \`args\`,
// everything else is \`options\`; the schemas were split at eject time.
for (const tool of TOOLS) {
  cli.command(tool.name, {
    description: tool.description,
    args: Openapi.toZod(tool.args_schema) as z.ZodObject<Record<string, z.ZodType>>,
    options: Openapi.toZod(tool.options_schema) as z.ZodObject<Record<string, z.ZodType>>,
    // AC-EJT-001.2 — the output schema comes from the recipe's response contract.
    output: z.object({
      status: z.number(),
      duration_ms: z.number(),
      data: Openapi.toZod(tool.output_schema),
      note: z.string().optional(),
      notice: z.string().optional(),
      truncated: z
        .object({ message: z.string(), untrimmed_bytes: z.number(), returned_bytes: z.number() })
        .optional(),
    }),
    // AC-EJT-001.2 — at least one example, drawn from the tool's stored fixture.
    examples: tool.examples,
    run: async (c: { args: Record<string, unknown>; options: Record<string, unknown>; error: (o: { code: string; message: string; retryable?: boolean }) => never }) => {
      try {
        return await execute(tool, { ...c.args, ...c.options })
      } catch (error) {
        if (error instanceof ToolError) {
          return c.error({ code: error.code, message: error.message, retryable: false })
        }
        throw error
      }
    },
  } as never)
}

cli.serve()
`;
}
/**
* AC-EJT-002.3 — fixture replay. Each approved tool's stored fixture is checked against the
* schemas the package was emitted with; a fixture that no longer matches exits non-zero and
* names the tool, so a drifted recipe fails the ejected package's own test rather than a call.
*/
function replayModule(recipe) {
	return `${header(recipe)}import { Openapi } from 'incur'
import { selectPath, MISSING } from './execute.js'
import { TOOLS, type EjectedTool } from './tools.js'

function replay(tool: EjectedTool): string | null {
  if (!tool.fixture) return 'no fixture stored for this tool'

  const example = tool.examples[0]
  if (!example) return 'no example emitted for this tool'
  const args = Openapi.toZod(tool.args_schema).safeParse(example.args)
  if (!args.success) return 'example arguments do not satisfy the argument schema: ' + args.error.message

  const body = tool.fixture.response.body
  const path = tool.primary_payload_path
  const payload = path ? selectPath(body, path) : body
  if (payload === MISSING) return 'primary_payload_path "' + String(path) + '" does not resolve in the fixture'

  const output = Openapi.toZod(tool.output_schema).safeParse(payload)
  if (!output.success) return 'fixture response does not match the output schema: ' + output.error.message
  return null
}

const failures: string[] = []
for (const tool of TOOLS) {
  const failure = replay(tool)
  if (failure === null) {
    console.log('ok    ' + tool.name)
  } else {
    console.log('FAIL  ' + tool.name + ' — ' + failure)
    failures.push(tool.name)
  }
}

if (failures.length > 0) {
  console.error(String(failures.length) + ' of ' + String(TOOLS.length) + ' fixture replays failed: ' + failures.join(', '))
  process.exit(1)
}
console.log(String(TOOLS.length) + ' fixture replays passed')
`;
}
//#endregion
export { StudioSession, baseUrlFrom, eject, noticePage, reviewPage };
