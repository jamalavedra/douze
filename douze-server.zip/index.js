#!/usr/bin/env node
import { a as __toESM, i as __require, n as __commonJSMin, r as __exportAll } from "./dist.js";
import { $ as _nonnegative, A as unknown, B as _gte, C as object, D as schemas_exports, E as record, F as toJSONSchema, G as _lte, H as _length, J as _mime, K as _maxLength, O as string, P as iso_exports, Q as _negative, R as _endsWith, S as number, U as _lowercase, V as _includes, W as _lt, X as _minSize, Y as _minLength, Z as _multipleOf, a as ZodLiteral, at as _regex, c as ZodObject, ct as _startsWith, d as ZodUnion, dt as _trim, et as _nonpositive, f as _enum, ft as _uppercase, g as boolean, i as ZodEnum, it as _property, l as ZodOptional, lt as _toLowerCase, n as ZodBoolean, nt as _overwrite, o as ZodNullable, ot as _size, pt as globalRegistry, q as _maxSize, r as ZodDefault, rt as _positive, s as ZodNumber, st as _slugify, t as ZodArray, tt as _normalize, u as ZodString, ut as _toUpperCase, z as _gt } from "./schemas.js";
import { a as serializeMessage, c as number$1, i as ReadBuffer, n as fromJsonSchema, o as process$1, r as McpServer, s as boolean$1 } from "./dist2.js";
import { _ as redactHeaders, a as DouzeError, b as Recipe, c as RelayResponse, d as Exchange, f as isInferableContentType, g as redactBody, h as findSurvivingSecrets, i as DEFAULT_PORT, l as AnnotationSpan, m as shouldCapture, n as serializeRecipe, o as HEARTBEAT_MS, p as isNoiseHost, r as ClientMessage, s as PORT_RANGE, t as parseRecipe, u as CaptureSession, v as redactUrl } from "./src.js";
import { createRequire } from "node:module";
import * as childProcess from "node:child_process";
import { execFile, spawn } from "node:child_process";
import { createHash, randomBytes, randomUUID } from "node:crypto";
import * as fs$2 from "node:fs";
import fsSync, { appendFileSync, existsSync, mkdirSync, readFileSync, readdirSync, stat, statSync, unwatchFile, watch, watchFile, writeFileSync } from "node:fs";
import * as path$1 from "node:path";
import path, { dirname, join, relative, resolve, sep } from "node:path";
import * as util from "node:util";
import { promisify } from "node:util";
import * as zlib$1 from "node:zlib";
import * as os$1 from "node:os";
import os, { homedir, type } from "node:os";
import * as fs$1 from "node:fs/promises";
import fs, { lstat, open, readdir, realpath, stat as stat$1 } from "node:fs/promises";
import { PassThrough, Readable } from "node:stream";
import { fileURLToPath } from "node:url";
import { createServer } from "node:http";
import { DatabaseSync } from "node:sqlite";
import { EventEmitter, once } from "node:events";
//#region ../../node_modules/.pnpm/zod@4.4.3/node_modules/zod/v4/classic/checks.js
var checks_exports = /* @__PURE__ */ __exportAll({
	endsWith: () => _endsWith,
	gt: () => _gt,
	gte: () => _gte,
	includes: () => _includes,
	length: () => _length,
	lowercase: () => _lowercase,
	lt: () => _lt,
	lte: () => _lte,
	maxLength: () => _maxLength,
	maxSize: () => _maxSize,
	mime: () => _mime,
	minLength: () => _minLength,
	minSize: () => _minSize,
	multipleOf: () => _multipleOf,
	negative: () => _negative,
	nonnegative: () => _nonnegative,
	nonpositive: () => _nonpositive,
	normalize: () => _normalize,
	overwrite: () => _overwrite,
	positive: () => _positive,
	property: () => _property,
	regex: () => _regex,
	size: () => _size,
	slugify: () => _slugify,
	startsWith: () => _startsWith,
	toLowerCase: () => _toLowerCase,
	toUpperCase: () => _toUpperCase,
	trim: () => _trim,
	uppercase: () => _uppercase
});
//#endregion
//#region ../../node_modules/.pnpm/zod@4.4.3/node_modules/zod/v4/classic/from-json-schema.js
var z = {
	...schemas_exports,
	...checks_exports,
	iso: iso_exports
};
var RECOGNIZED_KEYS = /*@__PURE__*/ new Set([
	"$schema",
	"$ref",
	"$defs",
	"definitions",
	"$id",
	"id",
	"$comment",
	"$anchor",
	"$vocabulary",
	"$dynamicRef",
	"$dynamicAnchor",
	"type",
	"enum",
	"const",
	"anyOf",
	"oneOf",
	"allOf",
	"not",
	"properties",
	"required",
	"additionalProperties",
	"patternProperties",
	"propertyNames",
	"minProperties",
	"maxProperties",
	"items",
	"prefixItems",
	"additionalItems",
	"minItems",
	"maxItems",
	"uniqueItems",
	"contains",
	"minContains",
	"maxContains",
	"minLength",
	"maxLength",
	"pattern",
	"format",
	"minimum",
	"maximum",
	"exclusiveMinimum",
	"exclusiveMaximum",
	"multipleOf",
	"description",
	"default",
	"contentEncoding",
	"contentMediaType",
	"contentSchema",
	"unevaluatedItems",
	"unevaluatedProperties",
	"if",
	"then",
	"else",
	"dependentSchemas",
	"dependentRequired",
	"nullable",
	"readOnly"
]);
function detectVersion(schema, defaultTarget) {
	const $schema = schema.$schema;
	if ($schema === "https://json-schema.org/draft/2020-12/schema") return "draft-2020-12";
	if ($schema === "http://json-schema.org/draft-07/schema#") return "draft-7";
	if ($schema === "http://json-schema.org/draft-04/schema#") return "draft-4";
	return defaultTarget ?? "draft-2020-12";
}
function resolveRef(ref, ctx) {
	if (!ref.startsWith("#")) throw new Error("External $ref is not supported, only local refs (#/...) are allowed");
	const path = ref.slice(1).split("/").filter(Boolean);
	if (path.length === 0) return ctx.rootSchema;
	const defsKey = ctx.version === "draft-2020-12" ? "$defs" : "definitions";
	if (path[0] === defsKey) {
		const key = path[1];
		if (!key || !ctx.defs[key]) throw new Error(`Reference not found: ${ref}`);
		return ctx.defs[key];
	}
	throw new Error(`Reference not found: ${ref}`);
}
function convertBaseSchema(schema, ctx) {
	if (schema.not !== void 0) {
		if (typeof schema.not === "object" && Object.keys(schema.not).length === 0) return z.never();
		throw new Error("not is not supported in Zod (except { not: {} } for never)");
	}
	if (schema.unevaluatedItems !== void 0) throw new Error("unevaluatedItems is not supported");
	if (schema.unevaluatedProperties !== void 0) throw new Error("unevaluatedProperties is not supported");
	if (schema.if !== void 0 || schema.then !== void 0 || schema.else !== void 0) throw new Error("Conditional schemas (if/then/else) are not supported");
	if (schema.dependentSchemas !== void 0 || schema.dependentRequired !== void 0) throw new Error("dependentSchemas and dependentRequired are not supported");
	if (schema.$ref) {
		const refPath = schema.$ref;
		if (ctx.refs.has(refPath)) return ctx.refs.get(refPath);
		if (ctx.processing.has(refPath)) return z.lazy(() => {
			if (!ctx.refs.has(refPath)) throw new Error(`Circular reference not resolved: ${refPath}`);
			return ctx.refs.get(refPath);
		});
		ctx.processing.add(refPath);
		const zodSchema = convertSchema(resolveRef(refPath, ctx), ctx);
		ctx.refs.set(refPath, zodSchema);
		ctx.processing.delete(refPath);
		return zodSchema;
	}
	if (schema.enum !== void 0) {
		const enumValues = schema.enum;
		if (ctx.version === "openapi-3.0" && schema.nullable === true && enumValues.length === 1 && enumValues[0] === null) return z.null();
		if (enumValues.length === 0) return z.never();
		if (enumValues.length === 1) return z.literal(enumValues[0]);
		if (enumValues.every((v) => typeof v === "string")) return z.enum(enumValues);
		const literalSchemas = enumValues.map((v) => z.literal(v));
		if (literalSchemas.length < 2) return literalSchemas[0];
		return z.union([
			literalSchemas[0],
			literalSchemas[1],
			...literalSchemas.slice(2)
		]);
	}
	if (schema.const !== void 0) return z.literal(schema.const);
	const type = schema.type;
	if (Array.isArray(type)) {
		const typeSchemas = type.map((t) => {
			return convertBaseSchema({
				...schema,
				type: t
			}, ctx);
		});
		if (typeSchemas.length === 0) return z.never();
		if (typeSchemas.length === 1) return typeSchemas[0];
		return z.union(typeSchemas);
	}
	if (!type) return z.any();
	let zodSchema;
	switch (type) {
		case "string": {
			let stringSchema = z.string();
			if (schema.format) {
				const format = schema.format;
				if (format === "email") stringSchema = stringSchema.check(z.email());
				else if (format === "uri" || format === "uri-reference") stringSchema = stringSchema.check(z.url());
				else if (format === "uuid" || format === "guid") stringSchema = stringSchema.check(z.uuid());
				else if (format === "date-time") stringSchema = stringSchema.check(z.iso.datetime());
				else if (format === "date") stringSchema = stringSchema.check(z.iso.date());
				else if (format === "time") stringSchema = stringSchema.check(z.iso.time());
				else if (format === "duration") stringSchema = stringSchema.check(z.iso.duration());
				else if (format === "ipv4") stringSchema = stringSchema.check(z.ipv4());
				else if (format === "ipv6") stringSchema = stringSchema.check(z.ipv6());
				else if (format === "mac") stringSchema = stringSchema.check(z.mac());
				else if (format === "cidr") stringSchema = stringSchema.check(z.cidrv4());
				else if (format === "cidr-v6") stringSchema = stringSchema.check(z.cidrv6());
				else if (format === "base64") stringSchema = stringSchema.check(z.base64());
				else if (format === "base64url") stringSchema = stringSchema.check(z.base64url());
				else if (format === "e164") stringSchema = stringSchema.check(z.e164());
				else if (format === "jwt") stringSchema = stringSchema.check(z.jwt());
				else if (format === "emoji") stringSchema = stringSchema.check(z.emoji());
				else if (format === "nanoid") stringSchema = stringSchema.check(z.nanoid());
				else if (format === "cuid") stringSchema = stringSchema.check(z.cuid());
				else if (format === "cuid2") stringSchema = stringSchema.check(z.cuid2());
				else if (format === "ulid") stringSchema = stringSchema.check(z.ulid());
				else if (format === "xid") stringSchema = stringSchema.check(z.xid());
				else if (format === "ksuid") stringSchema = stringSchema.check(z.ksuid());
			}
			if (typeof schema.minLength === "number") stringSchema = stringSchema.min(schema.minLength);
			if (typeof schema.maxLength === "number") stringSchema = stringSchema.max(schema.maxLength);
			if (schema.pattern) stringSchema = stringSchema.regex(new RegExp(schema.pattern));
			zodSchema = stringSchema;
			break;
		}
		case "number":
		case "integer": {
			let numberSchema = type === "integer" ? z.number().int() : z.number();
			if (typeof schema.minimum === "number") numberSchema = numberSchema.min(schema.minimum);
			if (typeof schema.maximum === "number") numberSchema = numberSchema.max(schema.maximum);
			if (typeof schema.exclusiveMinimum === "number") numberSchema = numberSchema.gt(schema.exclusiveMinimum);
			else if (schema.exclusiveMinimum === true && typeof schema.minimum === "number") numberSchema = numberSchema.gt(schema.minimum);
			if (typeof schema.exclusiveMaximum === "number") numberSchema = numberSchema.lt(schema.exclusiveMaximum);
			else if (schema.exclusiveMaximum === true && typeof schema.maximum === "number") numberSchema = numberSchema.lt(schema.maximum);
			if (typeof schema.multipleOf === "number") numberSchema = numberSchema.multipleOf(schema.multipleOf);
			zodSchema = numberSchema;
			break;
		}
		case "boolean":
			zodSchema = z.boolean();
			break;
		case "null":
			zodSchema = z.null();
			break;
		case "object": {
			const shape = {};
			const properties = schema.properties || {};
			const requiredSet = new Set(schema.required || []);
			for (const [key, propSchema] of Object.entries(properties)) {
				const propZodSchema = convertSchema(propSchema, ctx);
				shape[key] = requiredSet.has(key) ? propZodSchema : propZodSchema.optional();
			}
			if (schema.propertyNames) {
				const keySchema = convertSchema(schema.propertyNames, ctx);
				const valueSchema = schema.additionalProperties && typeof schema.additionalProperties === "object" ? convertSchema(schema.additionalProperties, ctx) : z.any();
				if (Object.keys(shape).length === 0) {
					zodSchema = z.record(keySchema, valueSchema);
					break;
				}
				const objectSchema = z.object(shape).passthrough();
				const recordSchema = z.looseRecord(keySchema, valueSchema);
				zodSchema = z.intersection(objectSchema, recordSchema);
				break;
			}
			if (schema.patternProperties) {
				const patternProps = schema.patternProperties;
				const patternKeys = Object.keys(patternProps);
				const looseRecords = [];
				for (const pattern of patternKeys) {
					const patternValue = convertSchema(patternProps[pattern], ctx);
					const keySchema = z.string().regex(new RegExp(pattern));
					looseRecords.push(z.looseRecord(keySchema, patternValue));
				}
				const schemasToIntersect = [];
				if (Object.keys(shape).length > 0) schemasToIntersect.push(z.object(shape).passthrough());
				schemasToIntersect.push(...looseRecords);
				if (schemasToIntersect.length === 0) zodSchema = z.object({}).passthrough();
				else if (schemasToIntersect.length === 1) zodSchema = schemasToIntersect[0];
				else {
					let result = z.intersection(schemasToIntersect[0], schemasToIntersect[1]);
					for (let i = 2; i < schemasToIntersect.length; i++) result = z.intersection(result, schemasToIntersect[i]);
					zodSchema = result;
				}
				break;
			}
			const objectSchema = z.object(shape);
			if (schema.additionalProperties === false) zodSchema = objectSchema.strict();
			else if (typeof schema.additionalProperties === "object") zodSchema = objectSchema.catchall(convertSchema(schema.additionalProperties, ctx));
			else zodSchema = objectSchema.passthrough();
			break;
		}
		case "array": {
			const prefixItems = schema.prefixItems;
			const items = schema.items;
			if (prefixItems && Array.isArray(prefixItems)) {
				const tupleItems = prefixItems.map((item) => convertSchema(item, ctx));
				const rest = items && typeof items === "object" && !Array.isArray(items) ? convertSchema(items, ctx) : void 0;
				if (rest) zodSchema = z.tuple(tupleItems).rest(rest);
				else zodSchema = z.tuple(tupleItems);
				if (typeof schema.minItems === "number") zodSchema = zodSchema.check(z.minLength(schema.minItems));
				if (typeof schema.maxItems === "number") zodSchema = zodSchema.check(z.maxLength(schema.maxItems));
			} else if (Array.isArray(items)) {
				const tupleItems = items.map((item) => convertSchema(item, ctx));
				const rest = schema.additionalItems && typeof schema.additionalItems === "object" ? convertSchema(schema.additionalItems, ctx) : void 0;
				if (rest) zodSchema = z.tuple(tupleItems).rest(rest);
				else zodSchema = z.tuple(tupleItems);
				if (typeof schema.minItems === "number") zodSchema = zodSchema.check(z.minLength(schema.minItems));
				if (typeof schema.maxItems === "number") zodSchema = zodSchema.check(z.maxLength(schema.maxItems));
			} else if (items !== void 0) {
				const element = convertSchema(items, ctx);
				let arraySchema = z.array(element);
				if (typeof schema.minItems === "number") arraySchema = arraySchema.min(schema.minItems);
				if (typeof schema.maxItems === "number") arraySchema = arraySchema.max(schema.maxItems);
				zodSchema = arraySchema;
			} else zodSchema = z.array(z.any());
			break;
		}
		default: throw new Error(`Unsupported type: ${type}`);
	}
	return zodSchema;
}
function convertSchema(schema, ctx) {
	if (typeof schema === "boolean") return schema ? z.any() : z.never();
	let baseSchema = convertBaseSchema(schema, ctx);
	const hasExplicitType = schema.type || schema.enum !== void 0 || schema.const !== void 0;
	if (schema.anyOf && Array.isArray(schema.anyOf)) {
		const options = schema.anyOf.map((s) => convertSchema(s, ctx));
		const anyOfUnion = z.union(options);
		baseSchema = hasExplicitType ? z.intersection(baseSchema, anyOfUnion) : anyOfUnion;
	}
	if (schema.oneOf && Array.isArray(schema.oneOf)) {
		const options = schema.oneOf.map((s) => convertSchema(s, ctx));
		const oneOfUnion = z.xor(options);
		baseSchema = hasExplicitType ? z.intersection(baseSchema, oneOfUnion) : oneOfUnion;
	}
	if (schema.allOf && Array.isArray(schema.allOf)) if (schema.allOf.length === 0) baseSchema = hasExplicitType ? baseSchema : z.any();
	else {
		let result = hasExplicitType ? baseSchema : convertSchema(schema.allOf[0], ctx);
		const startIdx = hasExplicitType ? 0 : 1;
		for (let i = startIdx; i < schema.allOf.length; i++) result = z.intersection(result, convertSchema(schema.allOf[i], ctx));
		baseSchema = result;
	}
	if (schema.nullable === true && ctx.version === "openapi-3.0") baseSchema = z.nullable(baseSchema);
	if (schema.readOnly === true) baseSchema = z.readonly(baseSchema);
	if (schema.default !== void 0) baseSchema = baseSchema.default(schema.default);
	const extraMeta = {};
	for (const key of [
		"$id",
		"id",
		"$comment",
		"$anchor",
		"$vocabulary",
		"$dynamicRef",
		"$dynamicAnchor"
	]) if (key in schema) extraMeta[key] = schema[key];
	for (const key of [
		"contentEncoding",
		"contentMediaType",
		"contentSchema"
	]) if (key in schema) extraMeta[key] = schema[key];
	for (const key of Object.keys(schema)) if (!RECOGNIZED_KEYS.has(key)) extraMeta[key] = schema[key];
	if (Object.keys(extraMeta).length > 0) ctx.registry.add(baseSchema, extraMeta);
	if (schema.description) baseSchema = baseSchema.describe(schema.description);
	return baseSchema;
}
/**
* Converts a JSON Schema to a Zod schema. This function should be considered semi-experimental. It's behavior is liable to change. */
function fromJSONSchema(schema, params) {
	if (typeof schema === "boolean") return schema ? z.any() : z.never();
	let normalized;
	try {
		normalized = JSON.parse(JSON.stringify(schema));
	} catch {
		throw new Error("fromJSONSchema input is not valid JSON (possibly cyclic); use $defs/$ref for recursive schemas");
	}
	const ctx = {
		version: detectVersion(normalized, params?.defaultTarget),
		defs: normalized.$defs || normalized.definitions || {},
		refs: /* @__PURE__ */ new Map(),
		processing: /* @__PURE__ */ new Set(),
		rootSchema: normalized,
		registry: params?.registry ?? globalRegistry
	};
	return convertSchema(normalized, ctx);
}
//#endregion
//#region ../../node_modules/.pnpm/incur@0.4.26/node_modules/incur/dist/internal/pm.js
/** Detects the package manager from the current process environment and executable path. */
function detectPackageManager() {
	const userAgent = process.env.npm_config_user_agent ?? "";
	const execPath = process.env.npm_execpath ?? "";
	const entry = (() => {
		if (!process.argv[1]) return "";
		try {
			return fs$2.realpathSync(process.argv[1]);
		} catch {
			return process.argv[1];
		}
	})();
	if (userAgent.includes("pnpm")) return "pnpm";
	if (userAgent.includes("bun")) return "bun";
	if (userAgent.startsWith("npm/")) return "npm";
	if (execPath.includes("pnpm")) return "pnpm";
	if (execPath.includes("bun")) return "bun";
	if (execPath.includes("npm")) return "npm";
	if (entry.includes("/.pnpm/") || entry.includes("\\.pnpm\\")) return "pnpm";
	if (entry.includes("/.bun/") || entry.includes("\\bun\\")) return "bun";
	return "npm";
}
/** Detects the package manager runner (`npx`, `pnpx`, `bunx`) from the current process. */
function detectRunner() {
	const packageManager = detectPackageManager();
	if (packageManager === "pnpm") return "pnpx";
	if (packageManager === "bun") return "bunx";
	return "npx";
}
/** Builds the package-manager-specific invocation for installing a package globally. */
function globalInstall(name) {
	const packageManager = detectPackageManager();
	if (packageManager === "pnpm") return {
		args: [
			"add",
			"--global",
			`${name}@latest`
		],
		command: "pnpm"
	};
	if (packageManager === "bun") return {
		args: [
			"add",
			"--global",
			`${name}@latest`
		],
		command: "bun"
	};
	return {
		args: [
			"install",
			"--global",
			`${name}@latest`
		],
		command: "npm"
	};
}
//#endregion
//#region ../../node_modules/.pnpm/incur@0.4.26/node_modules/incur/dist/internal/update.js
var defaultInterval = 1440 * 60 * 1e3;
/** @internal Hidden flag used by detached update checks. */
var checkFlag = "--incur-update-check";
/** @internal Returns a cached available update and schedules a detached refresh when needed. */
function check(name, options = {}) {
	if (notificationsDisabled()) return void 0;
	const provider = resolveProvider(name, options);
	if (!provider?.check || !provider.current) return void 0;
	const file = cachePath(provider.key);
	const cached = readCache(file);
	const checkedAt = Date.now();
	const interval = Math.max(0, options.interval ?? defaultInterval);
	if (!cached || checkedAt - cached.checkedAt >= interval) scheduleRefresh(file, checkedAt, cached?.latest, options.binary);
	if (!cached?.latest || !isNewerVersion(cached.latest, provider.current)) return void 0;
	return {
		current: provider.current,
		latest: cached.latest,
		name: provider.name
	};
}
/** @internal Refreshes the cached latest version through the configured provider. */
async function refresh(name, options = {}) {
	const provider = resolveProvider(name, options);
	if (!provider?.check || !provider.current) return;
	const latest = await provider.check({
		current: provider.current,
		name,
		...provider.package ? { package: provider.package } : void 0
	});
	if (!latest || !parseVersion(latest)) return;
	writeCache(cachePath(provider.key), {
		checkedAt: Date.now(),
		latest
	});
}
/** @internal Installs the latest CLI version through the configured provider. */
async function install$1(name, options = {}) {
	const provider = resolveProvider(name, options);
	if (!provider?.install) throw new Error(`No update installer is configured for '${name}'.`);
	const cached = readCache(cachePath(provider.key));
	await provider.install({
		...provider.current ? { current: provider.current } : void 0,
		...cached?.latest ? { latest: cached.latest } : void 0,
		name,
		...provider.package ? { package: provider.package } : void 0
	});
	return {
		...provider.command ? { command: provider.command } : void 0,
		...provider.deferred ? { deferred: true } : void 0,
		name: provider.name
	};
}
/** @internal Returns whether `candidate` is a newer semantic version than `current`. */
function isNewerVersion(candidate, current) {
	const candidateVersion = parseVersion(candidate);
	const currentVersion = parseVersion(current);
	if (!candidateVersion || !currentVersion) return false;
	for (const key of [
		"major",
		"minor",
		"patch"
	]) {
		if (candidateVersion[key] > currentVersion[key]) return true;
		if (candidateVersion[key] < currentVersion[key]) return false;
	}
	const candidatePrerelease = candidateVersion.prerelease;
	const currentPrerelease = currentVersion.prerelease;
	if (candidatePrerelease.length === 0) return currentPrerelease.length > 0;
	if (currentPrerelease.length === 0) return false;
	const length = Math.max(candidatePrerelease.length, currentPrerelease.length);
	for (let index = 0; index < length; index++) {
		const candidatePart = candidatePrerelease[index];
		const currentPart = currentPrerelease[index];
		if (candidatePart === void 0) return false;
		if (currentPart === void 0) return true;
		if (candidatePart === currentPart) continue;
		if (typeof candidatePart === "bigint" && typeof currentPart === "string") return false;
		if (typeof candidatePart === "string" && typeof currentPart === "bigint") return true;
		return candidatePart > currentPart;
	}
	return false;
}
/** @internal Resolves package defaults and custom provider overrides. */
function resolveProvider(name, options) {
	const executing = resolvePackage(name);
	const packageName = options.package ?? executing?.name;
	if (packageName && !isPackageName(packageName)) return void 0;
	const current = options.version ?? executing?.version;
	const invocation = packageName ? globalInstall(packageName) : void 0;
	const check = options.check ?? (packageName ? () => {
		return fetchLatest(packageName);
	} : void 0);
	const install = options.install ?? (invocation ? () => {
		return exec$1(invocation.command, invocation.args);
	} : void 0);
	if (!check && !install) return void 0;
	return {
		...check ? { check } : void 0,
		...invocation && !options.install ? { command: `${invocation.command} ${invocation.args.join(" ")}` } : void 0,
		...current ? { current } : void 0,
		...options.deferred ? { deferred: true } : void 0,
		...install ? { install } : void 0,
		key: packageName ?? name,
		name: packageName ?? name,
		...packageName ? { package: packageName } : void 0
	};
}
/** @internal Resolves the npm package containing the executing binary. */
function resolvePackage(name) {
	const entry = (() => {
		if (!process.argv[1]) return void 0;
		try {
			return fs$2.realpathSync(process.argv[1]);
		} catch {
			return;
		}
	})();
	if (!entry) return void 0;
	let directory = path$1.dirname(entry);
	while (true) {
		try {
			const metadata = JSON.parse(fs$2.readFileSync(path$1.join(directory, "package.json"), "utf8"));
			if (typeof metadata.name === "string" && typeof metadata.version === "string" && providesCli(metadata, name)) return {
				name: metadata.name,
				version: metadata.version
			};
		} catch {}
		const parent = path$1.dirname(directory);
		if (parent === directory) return void 0;
		directory = parent;
	}
}
/** @internal Returns whether package metadata declares the configured CLI name. */
function providesCli(metadata, name) {
	if (metadata.name === name) return true;
	if (typeof metadata.bin === "object" && metadata.bin !== null && name in metadata.bin) return true;
	if (typeof metadata.bin !== "string" || typeof metadata.name !== "string") return false;
	return metadata.name.split("/").pop() === name;
}
/** @internal Fetches the latest npm package version. */
async function fetchLatest(packageName) {
	const registry = process.env.npm_config_registry || "https://registry.npmjs.org";
	const base = registry.endsWith("/") ? registry : `${registry}/`;
	const response = await fetch(new URL(encodeURIComponent(packageName), base), {
		headers: { accept: "application/vnd.npm.install-v1+json; q=1.0, application/json; q=0.8, */*" },
		signal: AbortSignal.timeout(1e4)
	});
	if (!response.ok) return void 0;
	const latest = (await response.json())["dist-tags"]?.latest;
	return typeof latest === "string" ? latest : void 0;
}
/** @internal Parses a semantic version into precedence components. */
function parseVersion(version) {
	const match = version.match(/^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?(?:\+[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?$/);
	if (!match) return void 0;
	const prerelease = [];
	for (const identifier of match[4]?.split(".") ?? []) {
		if (!/^\d+$/.test(identifier)) {
			prerelease.push(identifier);
			continue;
		}
		if (identifier.length > 1 && identifier.startsWith("0")) return void 0;
		prerelease.push(BigInt(identifier));
	}
	return {
		major: BigInt(match[1]),
		minor: BigInt(match[2]),
		patch: BigInt(match[3]),
		prerelease
	};
}
/** @internal Returns whether a package name is safe to place in an install command. */
function isPackageName(name) {
	return /^(?:@[A-Za-z0-9][A-Za-z0-9._~-]*\/)?[A-Za-z0-9][A-Za-z0-9._~-]*$/.test(name);
}
/** @internal Returns the update cache path for a provider. */
function cachePath(key) {
	const root = process.env.XDG_CACHE_HOME || path$1.join(os$1.homedir(), ".cache");
	return path$1.join(root, "incur", "updates", `${encodeURIComponent(key)}.json`);
}
/** @internal Reads cached update metadata. */
function readCache(file) {
	try {
		const value = JSON.parse(fs$2.readFileSync(file, "utf8"));
		if (typeof value.checkedAt !== "number") return void 0;
		if (value.latest !== void 0 && typeof value.latest !== "string") return void 0;
		return value;
	} catch {
		return;
	}
}
/** @internal Writes cached update metadata. */
function writeCache(file, cache) {
	fs$2.mkdirSync(path$1.dirname(file), { recursive: true });
	fs$2.writeFileSync(file, JSON.stringify(cache) + "\n");
}
/** @internal Marks a check and starts a detached self-invocation to refresh it. */
function scheduleRefresh(file, checkedAt, latest, binary) {
	const invocation = selfInvocation(binary);
	if (!invocation) return;
	try {
		writeCache(file, {
			checkedAt,
			...latest ? { latest } : void 0
		});
		const child = childProcess.spawn(invocation.command, invocation.args, {
			detached: true,
			stdio: "ignore"
		});
		child.once("error", () => {});
		child.unref();
	} catch {}
}
/** @internal Resolves how the current CLI can invoke itself. */
function selfInvocation(binary) {
	if (binary) return {
		args: [checkFlag],
		command: process.execPath
	};
	const entry = process.argv[1];
	if (!entry) return void 0;
	if (entry.startsWith("/$bunfs/")) return {
		args: [checkFlag],
		command: process.execPath
	};
	try {
		if (fs$2.realpathSync(entry) === fs$2.realpathSync(process.execPath)) return {
			args: [checkFlag],
			command: process.execPath
		};
	} catch {}
	return {
		args: [
			...process.execArgv,
			entry,
			checkFlag
		],
		command: process.execPath
	};
}
/** @internal Runs a package-manager command and surfaces its useful error output. */
function exec$1(command, args) {
	return new Promise((resolve, reject) => {
		childProcess.execFile(command, args, (error, stdout, stderr) => {
			if (!error) return resolve();
			reject(new Error(stderr.trim() || stdout.trim() || error.message));
		});
	});
}
/** @internal Returns whether the environment suppresses update notifications. */
function notificationsDisabled() {
	if (process.env.NO_UPDATE_NOTIFIER) return true;
	if (process.env.npm_config_update_notifier === "false") return true;
	return Boolean(process.env.CI && process.env.CI !== "false");
}
//#endregion
//#region ../../node_modules/.pnpm/incur@0.4.26/node_modules/incur/dist/Binary.js
var handoffTimeout = 6e4;
util.promisify(zlib$1.gunzip);
/** @internal Hidden flag used by a detached Windows update handoff. */
var applyFlag = "--incur-binary-apply";
/** Name embedded by `incur build`, or `undefined` outside a compiled artifact. */
var name = typeof __INCUR_BINARY_NAME__ === "string" && __INCUR_BINARY_NAME__ ? __INCUR_BINARY_NAME__ : void 0;
/** Target embedded by `incur build`, or `undefined` outside a compiled artifact. */
var target = typeof __INCUR_BINARY_TARGET__ === "string" && __INCUR_BINARY_TARGET__ ? __INCUR_BINARY_TARGET__ : void 0;
/** Version embedded by `incur build`, or `undefined` outside a compiled artifact. */
var version = typeof __INCUR_BINARY_VERSION__ === "string" && __INCUR_BINARY_VERSION__ ? __INCUR_BINARY_VERSION__ : void 0;
/**
* @internal
* Handles the internal Windows update handoff argument.
*
* Call this before normal CLI argument parsing and stop when it returns `true`.
*/
async function handleArgv(argv = process.argv.slice(2)) {
	if (argv[0] !== "--incur-binary-apply") {
		if (process.platform === "win32" && name && target && version) await cleanupArtifacts(process.execPath);
		return false;
	}
	if (process.platform !== "win32") throw new Error(`${applyFlag} is only supported on Windows.`);
	if (argv.length !== 2 || !argv[1]) throw new Error(`Invalid ${applyFlag} arguments.`);
	const parent = Number(argv[1]);
	if (!Number.isSafeInteger(parent) || parent <= 0) throw new Error(`Invalid ${applyFlag} arguments.`);
	await applyWindowsUpdate(parent);
	return true;
}
/** Applies a validated Windows handoff and rolls back a failed replacement. */
async function applyWindowsUpdate(parent) {
	const state = pathsFromHelper(process.execPath, parent);
	let backedUp = false;
	try {
		await waitForExit(parent);
		await fs$2.promises.rename(state.target, state.backup);
		backedUp = true;
		await fs$2.promises.rename(state.staged, state.target);
	} catch (error) {
		let failure = error;
		let recovery = `The installed executable remains at '${state.target}'.`;
		if (backedUp) try {
			await fs$2.promises.rename(state.backup, state.target);
			backedUp = false;
			recovery = `The previous executable was restored to '${state.target}'.`;
		} catch (rollback) {
			try {
				await fs$2.promises.copyFile(state.backup, state.target, fs$2.constants.COPYFILE_EXCL);
				recovery = `The previous executable was copied back to '${state.target}', and its backup remains at '${state.backup}'.`;
			} catch (recovery) {
				failure = new Error(`Binary update failed and '${state.target}' could not be restored. The previous executable remains at '${state.backup}': ${message(recovery)}`, { cause: rollback });
			}
		}
		await writeError(state, failure, recovery);
		throw failure;
	}
	await remove$1(state.backup);
	await remove$1(state.error);
	await remove$1(state.staged);
	await remove$1(state.helper);
}
/** Derives every replacement path from the running handoff executable. */
function pathsFromHelper(helper, parent) {
	const absolute = path$1.resolve(helper);
	const match = absolute.match(/^(.*)\.incur-handoff-([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})\.exe$/i);
	if (!match?.[1] || !match[2]) throw new Error("Invalid binary update handoff path.");
	const target = match[1];
	const extension = target.toLowerCase().endsWith(".exe") ? ".exe" : "";
	return {
		backup: `${target}.incur-backup-${match[2]}${extension}`,
		error: `${target}.incur-error-${match[2]}.txt`,
		helper: absolute,
		parent,
		staged: `${target}.incur-new-${match[2]}${extension}`,
		target
	};
}
/** Waits for the parent updater process to release the installed executable. */
async function waitForExit(pid) {
	const deadline = Date.now() + handoffTimeout;
	while (isRunning(pid)) {
		if (Date.now() >= deadline) throw new Error(`Timed out waiting for update process ${pid} to exit.`);
		await delay(100);
	}
}
/** Returns whether a process still exists without sending it a signal. */
function isRunning(pid) {
	try {
		process.kill(pid, 0);
		return true;
	} catch (error) {
		return error.code !== "ESRCH";
	}
}
/** Resolves after a short handoff polling interval. */
function delay(duration) {
	return new Promise((resolve) => setTimeout(resolve, duration));
}
/** Removes unlocked handoff copies on the next normal compiled-binary startup. */
async function cleanupArtifacts(executable) {
	const directory = path$1.dirname(executable);
	const prefix = `${path$1.basename(executable)}.incur-handoff-`;
	try {
		const entries = await fs$2.promises.readdir(directory);
		await Promise.all(entries.filter((entry) => entry.startsWith(prefix) && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\.exe$/i.test(entry.slice(prefix.length))).map((entry) => remove$1(path$1.join(directory, entry))));
	} catch {}
}
/** Preserves an actionable detached-handoff failure beside the executable. */
async function writeError(state, error, recovery) {
	const body = [
		`Binary update failed: ${message(error)}`,
		`Recovery: ${recovery}`,
		`Downloaded candidate: ${state.staged}`,
		`Previous executable backup: ${state.backup}`
	].join("\n");
	try {
		await fs$2.promises.writeFile(state.error, `${body}\n`, {
			flag: "wx",
			mode: 384
		});
	} catch {}
}
/** Removes one update artifact when it still exists. */
async function remove$1(file) {
	try {
		await fs$2.promises.unlink(file);
	} catch {}
}
/** Returns a useful error message for a failed rollback. */
function message(error) {
	return error instanceof Error ? error.message : String(error);
}
//#endregion
//#region ../../node_modules/.pnpm/tokenx@1.6.0/node_modules/tokenx/dist/index.mjs
var PATTERNS = {
	whitespace: /^\s+$/,
	structuredWhitespace: /\n\s/,
	cjk: /[\u4E00-\u9FFF\u3400-\u4DBF\u3000-\u30FF\uFF00-\uFFEF\u2E80-\u2EFF\u31C0-\u31EF\u3200-\u32FF\u3300-\u33FF\uAC00-\uD7AF\u1100-\u11FF\u3130-\u318F\uA960-\uA97F\uD7B0-\uD7FF]/,
	numeric: /^\d+$/,
	punctuation: /[.,!?;(){}[\]<>:/\\|@#$%^&*+=`~_"-]/
};
var TOKEN_SPLIT_PATTERN = new RegExp(`(\\s+|${PATTERNS.punctuation.source}+)`);
var DEFAULT_CHARS_PER_TOKEN = 6;
var SHORT_TOKEN_THRESHOLD = 3;
var KANA_CHARS_PER_TOKEN = 1.35;
var DEFAULT_LANGUAGE_CONFIGS = [
	{
		pattern: /[äöüßẞ]/i,
		averageCharsPerToken: 2.6
	},
	{
		pattern: /[éèêëàâîïôûùüÿçœæáíóúñ]/i,
		averageCharsPerToken: 3
	},
	{
		pattern: /[ąćęłńóśźżěščřžýůúďťň]/i,
		averageCharsPerToken: 2.5
	},
	{
		pattern: /[\u0430-\u044F\u0451]/i,
		averageCharsPerToken: 4
	},
	{
		pattern: /[\u03AC-\u03CE]/i,
		averageCharsPerToken: 2.75
	},
	{
		pattern: /^\p{Extended_Pictographic}[\p{Extended_Pictographic}\p{Emoji_Component}]*$/u,
		averageCharsPerToken: .75
	}
];
/**
* Walks a text as (segment, estimated token count) pairs. The segments
* concatenate back to the original text; whitespace segments count zero
* tokens unless they carry structure (indentation or blank lines).
*/
function* walkSegments(text, options = {}) {
	if (!text) return;
	const resolvedOptions = resolveOptions$1(options);
	for (const segment of text.split(TOKEN_SPLIT_PATTERN)) if (segment) yield {
		segment,
		tokenCount: estimateSegmentTokens(segment, resolvedOptions)
	};
}
function resolveOptions$1(options) {
	return {
		defaultCharsPerToken: options.defaultCharsPerToken ?? DEFAULT_CHARS_PER_TOKEN,
		languageConfigs: options.languageConfigs ?? DEFAULT_LANGUAGE_CONFIGS
	};
}
function estimateSegmentTokens(segment, { languageConfigs, defaultCharsPerToken }) {
	if (PATTERNS.whitespace.test(segment)) return PATTERNS.structuredWhitespace.test(segment) ? 1 : 0;
	const languageCharsPerToken = getLanguageSpecificCharsPerToken(segment, languageConfigs);
	if (languageCharsPerToken !== void 0) return Math.ceil(getCharacterCount(segment) / languageCharsPerToken);
	if (PATTERNS.cjk.test(segment)) return estimateCjkTokens(segment);
	if (PATTERNS.numeric.test(segment)) return Math.ceil(segment.length / 3);
	if (segment.length <= SHORT_TOKEN_THRESHOLD) return 1;
	if (PATTERNS.punctuation.test(segment)) return Math.ceil(segment.length / 2);
	return Math.ceil(segment.length / defaultCharsPerToken);
}
function getLanguageSpecificCharsPerToken(segment, languageConfigs) {
	for (const config of languageConfigs) if (segment.search(config.pattern) !== -1) return config.averageCharsPerToken;
}
function getCharacterCount(text) {
	return Array.from(text).length;
}
function estimateCjkTokens(segment) {
	let kanaCount = 0;
	let otherCount = 0;
	for (const character of segment) {
		const codePoint = character.codePointAt(0);
		if (codePoint >= 12352 && codePoint <= 12543) kanaCount++;
		else otherCount++;
	}
	return otherCount + Math.ceil(kanaCount / KANA_CHARS_PER_TOKEN);
}
/**
* Estimates the number of tokens in a text string using heuristic rules
*/
function estimateTokenCount(text, options = {}) {
	if (!text) return 0;
	let tokenCount = 0;
	for (const segmentEstimate of walkSegments(text, options)) tokenCount += segmentEstimate.tokenCount;
	return tokenCount;
}
/**
* Extracts a portion of text based on token positions, similar to Array.prototype.slice()
*/
function sliceByTokens(text, start = 0, end, options = {}) {
	if (!text) return "";
	let segmentEstimates = walkSegments(text, options);
	let totalTokens = 0;
	if (start < 0 || end !== void 0 && end < 0) {
		const bufferedEstimates = Array.from(segmentEstimates);
		for (const { tokenCount } of bufferedEstimates) totalTokens += tokenCount;
		segmentEstimates = bufferedEstimates;
	}
	const normalizedStart = start < 0 ? Math.max(0, totalTokens + start) : Math.max(0, start);
	const normalizedEnd = end === void 0 ? Infinity : end < 0 ? Math.max(0, totalTokens + end) : end;
	if (normalizedStart >= normalizedEnd) return "";
	const parts = [];
	let currentTokenPos = 0;
	for (const { segment, tokenCount } of segmentEstimates) {
		if (currentTokenPos >= normalizedEnd) break;
		const extracted = extractSegmentPart(segment, currentTokenPos, tokenCount, normalizedStart, normalizedEnd);
		if (extracted) parts.push(extracted);
		currentTokenPos += tokenCount;
	}
	return parts.join("");
}
function extractSegmentPart(segment, segmentTokenStart, segmentTokenCount, targetStart, targetEnd) {
	if (segmentTokenCount === 0) return segmentTokenStart >= targetStart && segmentTokenStart < targetEnd ? segment : "";
	const segmentTokenEnd = segmentTokenStart + segmentTokenCount;
	if (segmentTokenStart >= targetEnd || segmentTokenEnd <= targetStart) return "";
	const overlapStart = Math.max(0, targetStart - segmentTokenStart);
	const overlapEnd = Math.min(segmentTokenCount, targetEnd - segmentTokenStart);
	if (overlapStart === 0 && overlapEnd === segmentTokenCount) return segment;
	const charStart = Math.floor(overlapStart / segmentTokenCount * segment.length);
	const charEnd = Math.ceil(overlapEnd / segmentTokenCount * segment.length);
	return segment.slice(charStart, charEnd);
}
//#endregion
//#region ../../node_modules/.pnpm/incur@0.4.26/node_modules/incur/dist/internal/helpers.js
/** Checks whether a value is a plain object record. */
function isRecord(value) {
	return typeof value === "object" && value !== null && !Array.isArray(value);
}
/** Converts a camelCase string to kebab-case. */
function toKebab(value) {
	return value.replace(/[A-Z]/g, (c) => `-${c.toLowerCase()}`);
}
/** Computes the Levenshtein edit distance between two strings. */
function levenshtein(a, b) {
	const m = a.length;
	const n = b.length;
	const dp = Array.from({ length: n + 1 }, (_, i) => i);
	for (let i = 1; i <= m; i++) {
		let prev = dp[0];
		dp[0] = i;
		for (let j = 1; j <= n; j++) {
			const tmp = dp[j];
			dp[j] = a[i - 1] === b[j - 1] ? prev : 1 + Math.min(prev, dp[j], dp[j - 1]);
			prev = tmp;
		}
	}
	return dp[n];
}
/** Suggests the closest command name from a set, returning it if within a reasonable edit distance. */
function suggest(input, candidates) {
	const threshold = input.length <= 4 ? 2 : Math.floor(input.length / 2);
	const lower = input.toLowerCase();
	const all = Array.isArray(candidates) ? candidates : [...candidates];
	let best;
	let bestScore = Infinity;
	for (const c of all) {
		const lc = c.toLowerCase();
		const dist = levenshtein(lower, lc);
		let score;
		if (lc.startsWith(lower) && lc !== lower) score = dist;
		else if (lc.includes(lower)) score = 100 + dist;
		else if (dist <= threshold) score = 200 + dist;
		else continue;
		if (score < bestScore) {
			bestScore = score;
			best = c;
		}
	}
	return best;
}
//#endregion
//#region ../../node_modules/.pnpm/incur@0.4.26/node_modules/incur/dist/Completions.js
/**
* Generates a shell hook script that registers dynamic completions for the CLI.
* The hook calls back into the binary with `COMPLETE=<shell>` at every tab press.
*/
function register$4(shell, name) {
	switch (shell) {
		case "bash": return bashRegister(name);
		case "zsh": return zshRegister(name);
		case "fish": return fishRegister(name);
		case "nushell": return nushellRegister(name);
	}
}
/**
* Computes completion candidates for the given argv words and cursor index.
* Walks the command tree to resolve the active command, then suggests
* subcommands, options, or positional argument hints.
*/
function complete(commands, rootCommand, argv, index, globals) {
	const current = argv[index] ?? "";
	let scope = {
		commands,
		leaf: rootCommand
	};
	for (let i = 0; i < index; i++) {
		const token = argv[i];
		if (token.startsWith("-")) continue;
		let entry = scope.commands.get(token);
		if (!entry) continue;
		if (entry._alias && entry.target) entry = scope.commands.get(entry.target);
		if (!entry) continue;
		if (entry._group && entry.commands) scope = { commands: entry.commands };
		else {
			scope = {
				commands: /* @__PURE__ */ new Map(),
				leaf: entry
			};
			break;
		}
	}
	const candidates = [];
	if (current.startsWith("-")) {
		const leaf = scope.leaf;
		if (leaf?.options) {
			const shape = leaf.options.shape;
			for (const key of Object.keys(shape)) {
				const flag = `--${toKebab(key)}`;
				if (flag.startsWith(current)) candidates.push({
					value: flag,
					description: descriptionOf(shape[key])
				});
			}
			if (leaf.alias) for (const [name, short] of Object.entries(leaf.alias)) {
				const flag = `-${short}`;
				if (flag.startsWith(current)) {
					const desc = descriptionOf(shape[name]);
					candidates.push({
						value: flag,
						description: desc
					});
				}
			}
		}
		if (globals) {
			const globalShape = globals.schema.shape;
			for (const key of Object.keys(globalShape)) {
				const flag = `--${toKebab(key)}`;
				if (flag.startsWith(current) && !candidates.some((c) => c.value === flag)) candidates.push({
					value: flag,
					description: descriptionOf(globalShape[key])
				});
			}
			if (globals.alias) for (const [name, short] of Object.entries(globals.alias)) {
				const flag = `-${short}`;
				if (flag.startsWith(current) && !candidates.some((c) => c.value === flag)) {
					const desc = descriptionOf(globalShape[name]);
					candidates.push({
						value: flag,
						description: desc
					});
				}
			}
		}
		return candidates;
	}
	if (index > 0) {
		const prev = argv[index - 1];
		const leaf = scope.leaf;
		if (prev.startsWith("-")) {
			if (leaf?.options) {
				const name = resolveOptionName(prev, leaf);
				if (name) {
					const values = possibleValues(name, leaf.options);
					if (values) {
						for (const v of values) if (v.startsWith(current)) candidates.push({ value: v });
						return candidates;
					}
					if (!isBooleanOption$1(name, leaf.options)) return candidates;
				}
			}
			if (globals) {
				const name = resolveOptionName(prev, {
					options: globals.schema,
					alias: globals.alias
				});
				if (name) {
					const values = possibleValues(name, globals.schema);
					if (values) {
						for (const v of values) if (v.startsWith(current)) candidates.push({ value: v });
						return candidates;
					}
					if (!isBooleanOption$1(name, globals.schema)) return candidates;
				}
			}
		}
	}
	for (const [name, entry] of scope.commands) {
		if (entry._alias) continue;
		if (name.startsWith(current)) candidates.push({
			value: name,
			description: entry.description,
			...entry._group ? { noSpace: true } : void 0
		});
	}
	return candidates;
}
/**
* Formats completion candidates into shell-specific output.
* - bash: `\013`-separated values (noSpace candidates end with `\001`)
* - zsh: `value:description` newline-separated (`:` escaped in values)
* - fish: `value\tdescription` newline-separated
* - nushell: JSON array of `{value, description}` records
*/
function format$1(shell, candidates) {
	switch (shell) {
		case "bash": return candidates.map((c) => c.noSpace ? `${c.value}\x01` : c.value).join("\v");
		case "zsh": return candidates.map((c) => {
			const escaped = c.value.replaceAll(":", "\\:");
			return c.description ? `${escaped}:${c.description}` : escaped;
		}).join("\n");
		case "fish": return candidates.map((c) => c.description ? `${c.value}\t${c.description}` : c.value).join("\n");
		case "nushell": {
			const records = candidates.map((c) => {
				const record = { value: c.value };
				if (c.description) record.description = c.description;
				return record;
			});
			return JSON.stringify(records);
		}
	}
}
/** @internal Resolves a flag token (e.g. `--foo-bar` or `-f`) to its camelCase option name. */
function resolveOptionName(token, entry) {
	if (!entry.options) return void 0;
	const known = new Set(Object.keys(entry.options.shape));
	const kebabToCamel = /* @__PURE__ */ new Map();
	for (const name of known) {
		const kebab = name.replace(/[A-Z]/g, (c) => `-${c.toLowerCase()}`);
		if (kebab !== name) kebabToCamel.set(kebab, name);
	}
	if (token.startsWith("--")) {
		const raw = token.slice(2);
		const name = kebabToCamel.get(raw) ?? raw;
		return known.has(name) ? name : void 0;
	}
	if (token.startsWith("-") && token.length === 2 && entry.alias) {
		const short = token.slice(1);
		for (const [name, alias] of Object.entries(entry.alias)) if (alias === short) return name;
	}
}
/** @internal Checks if an option's inner type is boolean or count. */
function isBooleanOption$1(name, schema) {
	const field = schema.shape[name];
	if (!field) return false;
	if (typeof field.meta === "function" && field.meta()?.count === true) return true;
	return unwrap$2(field).constructor.name === "ZodBoolean";
}
/** @internal Extracts possible values from enum schemas. */
function possibleValues(name, schema) {
	const field = schema.shape[name];
	if (!field) return void 0;
	const inner = unwrap$2(field);
	if (inner.constructor.name === "ZodEnum") return Object.values(inner._zod.def.entries);
	if (inner.constructor.name === "ZodNativeEnum") return Object.keys(inner._zod.def.values);
}
/** @internal Unwraps ZodDefault/ZodOptional to get the inner type. */
function unwrap$2(schema) {
	let s = schema;
	while (s._zod?.def?.innerType) s = s._zod.def.innerType;
	return s;
}
/** @internal Extracts a description from a Zod schema's metadata. */
function descriptionOf(schema) {
	if (!schema) return void 0;
	return schema.description;
}
/** @internal Sanitizes a CLI name into a valid shell identifier. */
function ident(name) {
	return name.replace(/[^a-zA-Z0-9_]/g, "_");
}
function bashRegister(name) {
	const id = ident(name);
	return `_incur_complete_${id}() {
    local IFS=$'\\013'
    local _COMPLETE_INDEX=\${COMP_CWORD}
    local _completions
    _completions=( $(
        export COMPLETE="bash"
        export _COMPLETE_INDEX="$_COMPLETE_INDEX"
        "${name}" -- "\${COMP_WORDS[@]}"
    ) )
    if [[ $? != 0 ]]; then
        unset COMPREPLY
        return
    fi
    local _nospace=false
    COMPREPLY=()
    for _c in "\${_completions[@]}"; do
        if [[ "$_c" == *$'\\001' ]]; then
            _nospace=true
            COMPREPLY+=("\${_c%$'\\001'}")
        else
            COMPREPLY+=("$_c")
        fi
    done
    if [[ $_nospace == true ]]; then
        compopt -o nospace
    fi
}
complete -o default -o bashdefault -o nosort -F _incur_complete_${id} ${name}`;
}
function zshRegister(name) {
	const id = ident(name);
	return `#compdef ${name}
_incur_complete_${id}() {
    local completions=("\${(@f)$(
        export _COMPLETE_INDEX=$(( CURRENT - 1 ))
        export COMPLETE="zsh"
        "${name}" -- "\${words[@]}" 2>/dev/null
    )}")
    if [[ -n $completions ]]; then
        _describe 'values' completions -S ''
    fi
}
compdef _incur_complete_${id} ${name}`;
}
function fishRegister(name) {
	return `complete --keep-order --exclusive --command ${name} \\
    --arguments "(COMPLETE=fish ${name} -- (commandline --current-process --tokenize --cut-at-cursor) (commandline --current-token))"`;
}
function nushellRegister(name) {
	return `# External completer for ${name}
# Add to $env.config.completions.external.completer or use in a dispatch completer.
let _incur_complete_${ident(name)} = {|spans|
    COMPLETE=nushell ${name} -- ...$spans | from json
}`;
}
//#endregion
//#region ../../node_modules/.pnpm/incur@0.4.26/node_modules/incur/dist/Errors.js
/** Base error with shortMessage, details from cause chain, and walk(). */
var BaseError = class extends Error {
	name = "Incur.BaseError";
	/** The short, human-readable error message (without details). */
	shortMessage;
	/** Details extracted from the cause's message, if any. */
	details;
	constructor(shortMessage, options = {}) {
		const details = options.cause instanceof Error ? options.cause.message : void 0;
		const message = details ? `${shortMessage}\n\nDetails: ${details}` : shortMessage;
		super(message, options.cause ? { cause: options.cause } : void 0);
		this.shortMessage = shortMessage;
		this.details = details;
	}
	/**
	* Traverses the cause chain.
	* Without a callback, returns the deepest cause.
	* With a callback, returns the first cause where `fn` returns `true`.
	*/
	walk(fn) {
		return walk$3(this, fn);
	}
};
/** CLI error with code, hint, and retryable flag. */
var IncurError = class extends BaseError {
	name = "Incur.IncurError";
	/** Machine-readable error code (e.g. `'NOT_AUTHENTICATED'`). */
	code;
	/** Actionable hint for the user. */
	hint;
	/** Whether the operation can be retried. */
	retryable;
	/** Process exit code. When set, `serve()` uses this instead of `1`. */
	exitCode;
	constructor(options) {
		super(options.message, options.cause ? { cause: options.cause } : void 0);
		this.code = options.code;
		this.hint = options.hint;
		this.retryable = options.retryable ?? false;
		this.exitCode = options.exitCode;
	}
};
/** Validation error with per-field error details. */
var ValidationError = class extends BaseError {
	name = "Incur.ValidationError";
	/** Per-field validation errors. */
	fieldErrors;
	constructor(options) {
		super(options.message, options.cause ? { cause: options.cause } : void 0);
		this.fieldErrors = options.fieldErrors ?? [];
	}
};
/** Error thrown when argument parsing fails (unknown flags, missing values). */
var ParseError = class extends BaseError {
	name = "Incur.ParseError";
	constructor(options) {
		super(options.message, options.cause ? { cause: options.cause } : void 0);
	}
};
/** Walks the cause chain, returning the deepest cause or the first matching cause. */
function walk$3(error, fn) {
	if (fn) {
		let current = error?.cause;
		while (current) {
			if (fn(current)) return current;
			current = current?.cause;
		}
		return;
	}
	let current = error;
	while (current?.cause) current = current.cause;
	return current;
}
//#endregion
//#region ../../node_modules/.pnpm/incur@0.4.26/node_modules/incur/dist/Fetch.js
/** Reserved flags consumed by the fetch gateway (not forwarded as query params). */
var reservedFlags = /* @__PURE__ */ new Set([
	"method",
	"body",
	"data",
	"header"
]);
var reservedShort = {
	X: "method",
	d: "data",
	H: "header"
};
/** Parses curl-style argv into a structured fetch input. */
function parseArgv(argv) {
	const segments = [];
	const headers = new Headers();
	const query = new URLSearchParams();
	let method;
	let body;
	let i = 0;
	while (i < argv.length) {
		const token = argv[i];
		if (token.startsWith("--")) {
			const eqIdx = token.indexOf("=");
			if (eqIdx !== -1) {
				const key = token.slice(2, eqIdx);
				const value = token.slice(eqIdx + 1);
				if (reservedFlags.has(key)) handleReserved(key, value);
				else query.set(key, value);
				i++;
			} else {
				const key = token.slice(2);
				const value = argv[i + 1];
				if (value === void 0) throw new Error(`Missing value for --${key}`);
				if (reservedFlags.has(key)) handleReserved(key, value);
				else query.set(key, value);
				i += 2;
			}
		} else if (token.startsWith("-") && token.length === 2) {
			const short = token[1];
			const mapped = reservedShort[short];
			if (mapped) {
				const value = argv[i + 1];
				if (value === void 0) throw new Error(`Missing value for -${short}`);
				handleReserved(mapped, value);
				i += 2;
			} else i++;
		} else {
			segments.push(token);
			i++;
		}
	}
	function handleReserved(key, value) {
		if (key === "method") method = value.toUpperCase();
		else if (key === "body" || key === "data") body = value;
		else if (key === "header") {
			const colonIdx = value.indexOf(":");
			if (colonIdx !== -1) {
				const name = value.slice(0, colonIdx).trim();
				const val = value.slice(colonIdx + 1).trim();
				headers.set(name, val);
			}
		}
	}
	return {
		path: segments.length > 0 ? `/${segments.join("/")}` : "/",
		method: method ?? (body !== void 0 ? "POST" : "GET"),
		headers,
		body,
		query
	};
}
/** Constructs a standard Request from a FetchInput. */
function buildRequest$1(input) {
	const url = new URL(input.path, "http://localhost");
	input.query.forEach((value, key) => url.searchParams.set(key, value));
	const init = {
		method: input.method,
		headers: input.headers
	};
	if (input.body !== void 0) {
		init.body = input.body;
		if (!input.headers.has("content-type")) input.headers.set("content-type", "application/json");
	}
	return new Request(url.toString(), init);
}
/** Returns true if the response body is a stream that should be consumed incrementally. */
function isStreamingResponse(response) {
	return response.body !== null && response.headers.get("content-type") === "application/x-ndjson";
}
/** Parses a streaming response body as an async generator of parsed NDJSON chunks. */
async function* parseStreamingResponse(response) {
	const reader = response.body.getReader();
	const decoder = new TextDecoder();
	let buffer = "";
	while (true) {
		const { value, done } = await reader.read();
		if (done) break;
		buffer += decoder.decode(value, { stream: true });
		let newlineIdx;
		while ((newlineIdx = buffer.indexOf("\n")) !== -1) {
			const line = buffer.slice(0, newlineIdx).trim();
			buffer = buffer.slice(newlineIdx + 1);
			if (line.length === 0) continue;
			try {
				yield JSON.parse(line);
			} catch {
				yield line;
			}
		}
	}
	const remaining = buffer.trim();
	if (remaining.length > 0) try {
		yield JSON.parse(remaining);
	} catch {
		yield remaining;
	}
}
/** Parses a fetch Response into structured output. */
async function parseResponse(response) {
	const text = await response.text();
	let data;
	try {
		data = JSON.parse(text);
	} catch {
		data = text;
	}
	return {
		ok: response.ok,
		status: response.status,
		data,
		headers: response.headers
	};
}
//#endregion
//#region ../../node_modules/.pnpm/incur@0.4.26/node_modules/incur/dist/Filter.js
/** Parses a filter expression string into structured filter paths. */
function parse$1(expression) {
	const paths = [];
	const tokens = [];
	let current = "";
	let depth = 0;
	for (let i = 0; i < expression.length; i++) {
		const ch = expression[i];
		if (ch === "[") depth++;
		else if (ch === "]") depth--;
		if (ch === "," && depth === 0) {
			tokens.push(current);
			current = "";
		} else current += ch;
	}
	if (current) tokens.push(current);
	for (const token of tokens) {
		const path = [];
		let remaining = token;
		while (remaining.length > 0) {
			const bracketIdx = remaining.indexOf("[");
			if (bracketIdx === -1) {
				for (const part of remaining.split(".")) if (part) path.push({ key: part });
				break;
			}
			const before = remaining.slice(0, bracketIdx);
			for (const part of before.split(".")) if (part) path.push({ key: part });
			const closeBracket = remaining.indexOf("]", bracketIdx);
			const [startStr, endStr] = remaining.slice(bracketIdx + 1, closeBracket).split(",");
			path.push({
				start: Number(startStr),
				end: Number(endStr)
			});
			remaining = remaining.slice(closeBracket + 1);
			if (remaining.startsWith(".")) remaining = remaining.slice(1);
		}
		paths.push(path);
	}
	return paths;
}
/** Applies parsed filter paths to a data value, returning a filtered copy. */
function apply(data, paths) {
	if (paths.length === 0) return data;
	if (paths.length === 1 && paths[0].length === 1 && "key" in paths[0][0]) {
		const key = paths[0][0].key;
		if (Array.isArray(data)) return data.map((item) => apply(item, paths));
		if (typeof data === "object" && data !== null) {
			const val = data[key];
			if (typeof val !== "object" || val === null) return val;
			return { [key]: val };
		}
		return;
	}
	if (Array.isArray(data)) return data.map((item) => apply(item, paths));
	const result = {};
	for (const path of paths) merge(result, data, path, 0);
	return result;
}
function merge(target, data, segments, index) {
	if (index >= segments.length || typeof data !== "object" || data === null) return;
	const segment = segments[index];
	if ("key" in segment) {
		const val = data[segment.key];
		if (val === void 0) return;
		if (index + 1 >= segments.length) {
			target[segment.key] = val;
			return;
		}
		const next = segments[index + 1];
		if ("start" in next) {
			if (!Array.isArray(val)) return;
			const sliced = val.slice(next.start, next.end);
			if (index + 2 >= segments.length) {
				target[segment.key] = sliced;
				return;
			}
			target[segment.key] = sliced.map((item) => {
				const sub = {};
				merge(sub, item, segments, index + 2);
				return sub;
			});
			return;
		}
		if (typeof val !== "object" || val === null) return;
		if (!target[segment.key] || typeof target[segment.key] !== "object") target[segment.key] = {};
		merge(target[segment.key], val, segments, index + 1);
		return;
	}
}
//#endregion
//#region ../../node_modules/.pnpm/@toon-format+toon@2.3.1/node_modules/@toon-format/toon/dist/index.mjs
var NULL_LITERAL = "null";
var DEFAULT_DELIMITER = {
	comma: ",",
	tab: "	",
	pipe: "|"
}.comma;
/**
* Escapes special characters in a string for encoding.
*
* @remarks
* Handles backslashes, quotes, newlines, carriage returns, and tabs.
* Other U+0000–U+001F control characters are emitted as `\uXXXX`.
*/
function escapeString(value) {
	return value.replace(/\\/g, `\\\\`).replace(/"/g, `\\"`).replace(/\n/g, `\\n`).replace(/\r/g, `\\r`).replace(/\t/g, `\\t`).replace(/[\u0000-\u001F]/g, (c) => `\\u${c.charCodeAt(0).toString(16).padStart(4, "0")}`);
}
function isBooleanOrNullLiteral(token) {
	return token === "true" || token === "false" || token === "null";
}
/**
* Assigns an own data property without invoking inherited accessors.
*
* @remarks
* Plain assignment of `__proto__` would hit the `Object.prototype` setter and
* corrupt the prototype chain; `defineProperty` avoids that but is markedly
* slower, so every other key takes plain assignment.
*/
function setOwnProperty(target, key, value) {
	if (key === "__proto__") {
		Object.defineProperty(target, key, {
			value,
			enumerable: true,
			writable: true,
			configurable: true
		});
		return;
	}
	target[key] = value;
}
function normalizeValue(value) {
	if (value === null) return null;
	if (typeof value === "object" && value !== null && "toJSON" in value && typeof value.toJSON === "function") {
		const next = value.toJSON();
		if (next !== value) return normalizeValue(next);
	}
	if (typeof value === "string" || typeof value === "boolean") return value;
	if (typeof value === "number") {
		if (Object.is(value, -0)) return 0;
		if (!Number.isFinite(value)) return null;
		return value;
	}
	if (typeof value === "bigint") {
		if (value >= Number.MIN_SAFE_INTEGER && value <= Number.MAX_SAFE_INTEGER) return Number(value);
		return value.toString();
	}
	if (value instanceof Date) return value.toISOString();
	if (Array.isArray(value)) return value.map(normalizeValue);
	if (value instanceof Set) return Array.from(value).map(normalizeValue);
	if (value instanceof Map) return Object.fromEntries(Array.from(value, ([k, v]) => [String(k), normalizeValue(v)]));
	if (isPlainObject(value)) {
		const encodedValues = {};
		for (const key in value) if (Object.hasOwn(value, key)) setOwnProperty(encodedValues, key, normalizeValue(value[key]));
		return encodedValues;
	}
	return null;
}
function isJsonPrimitive(value) {
	return value === null || typeof value === "string" || typeof value === "number" || typeof value === "boolean";
}
function isJsonArray(value) {
	return Array.isArray(value);
}
function isJsonObject(value) {
	return value !== null && typeof value === "object" && !Array.isArray(value);
}
function isEmptyObject(value) {
	return Object.keys(value).length === 0;
}
function isPlainObject(value) {
	if (value === null || typeof value !== "object") return false;
	const prototype = Object.getPrototypeOf(value);
	return prototype === null || prototype === Object.prototype;
}
function isArrayOfPrimitives(value) {
	return value.length === 0 || value.every((item) => isJsonPrimitive(item));
}
function isArrayOfArrays(value) {
	return value.length === 0 || value.every((item) => isJsonArray(item));
}
function isArrayOfObjects$1(value) {
	return value.length === 0 || value.every((item) => isJsonObject(item));
}
var NUMERIC_LIKE_PATTERN = /^-?\d+(?:\.\d+)?(?:e[+-]?\d+)?$/i;
var LEADING_ZERO_PATTERN = /^0\d+$/;
/**
* Checks if a key can be used without quotes.
*
* @remarks
* Valid unquoted keys must start with a letter or underscore,
* followed by letters, digits, underscores, or dots.
*/
function isValidUnquotedKey(key) {
	return /^[A-Z_][\w.]*$/i.test(key);
}
/**
* Checks if a key segment is a valid identifier for safe folding/expansion.
*
* @remarks
* Identifier segments are more restrictive than unquoted keys:
* - Must start with a letter or underscore
* - Followed only by letters, digits, or underscores (no dots)
* - Used for safe key folding and path expansion
*/
function isIdentifierSegment(key) {
	return /^[A-Z_]\w*$/i.test(key);
}
/**
* Determines if a string value can be safely encoded without quotes.
*
* @remarks
* A string needs quoting if it:
* - Is empty
* - Has leading or trailing whitespace
* - Could be confused with a literal (boolean, null, number)
* - Contains structural characters (colons, brackets, braces)
* - Contains quotes or backslashes (need escaping)
* - Contains control characters (newlines, tabs, etc.)
* - Contains the active delimiter
* - Starts with a list marker (hyphen)
*/
function isSafeUnquoted(value, delimiter = DEFAULT_DELIMITER) {
	if (!value) return false;
	if (value !== value.trim()) return false;
	if (isBooleanOrNullLiteral(value) || isNumericLike(value)) return false;
	if (value.includes(":")) return false;
	if (value.includes("\"") || value.includes("\\")) return false;
	if (/[[\]{}]/.test(value)) return false;
	if (/[\u0000-\u001F]/.test(value)) return false;
	if (value.includes(delimiter)) return false;
	if (value.startsWith("-")) return false;
	return true;
}
/**
* Checks if a string looks like a number.
*
* @remarks
* Match numbers like `42`, `-3.14`, `1e-6`, `05`, etc.
*/
function isNumericLike(value) {
	return NUMERIC_LIKE_PATTERN.test(value) || LEADING_ZERO_PATTERN.test(value);
}
/**
* Attempts to fold a single-key object chain into a dotted path.
*
* @remarks
* Folding traverses nested objects with single keys, collapsing them into a dotted path.
* It stops when:
* - A non-single-key object is encountered
* - An array is encountered (arrays are not "single-key objects")
* - A primitive value is reached
* - The flatten depth limit is reached
* - Any segment fails safe mode validation
*
* Safe mode requirements:
* - `options.keyFolding` must be `'safe'`
* - Every segment must be a valid identifier (no dots, no special chars)
* - The folded key must not collide with existing sibling keys
* - No segment should require quoting
*
* @param key - The starting key to fold
* @param value - The value associated with the key
* @param siblings - Array of all sibling keys at this level (for collision detection)
* @param options - Resolved encoding options
* @returns A FoldResult if folding is possible, undefined otherwise
*/
function tryFoldKeyChain(key, value, siblings, options, rootLiteralKeys, pathPrefix, flattenDepth) {
	if (options.keyFolding !== "safe") return;
	if (!isJsonObject(value)) return;
	const { segments, tail, leafValue } = collectSingleKeyChain(key, value, flattenDepth ?? options.flattenDepth);
	if (segments.length < 2) return;
	if (!segments.every((seg) => isIdentifierSegment(seg))) return;
	const foldedKey = buildFoldedKey(segments);
	const absolutePath = pathPrefix ? `${pathPrefix}.${foldedKey}` : foldedKey;
	if (siblings.includes(foldedKey)) return;
	if (rootLiteralKeys && rootLiteralKeys.has(absolutePath)) return;
	return {
		foldedKey,
		remainder: tail,
		leafValue,
		segmentCount: segments.length
	};
}
/**
* Collects a chain of single-key objects into segments.
*
* @remarks
* Traverses nested objects, collecting keys until:
* - A non-single-key object is found
* - An array is encountered
* - A primitive is reached
* - An empty object is reached
* - The depth limit is reached
*
* @param startKey - The initial key to start the chain
* @param startValue - The value to traverse
* @param maxDepth - Maximum number of segments to collect
* @returns Object containing segments array, tail value, and leaf value
*/
function collectSingleKeyChain(startKey, startValue, maxDepth) {
	const segments = [startKey];
	let currentValue = startValue;
	while (segments.length < maxDepth) {
		if (!isJsonObject(currentValue)) break;
		const keys = Object.keys(currentValue);
		if (keys.length !== 1) break;
		const nextKey = keys[0];
		const nextValue = currentValue[nextKey];
		segments.push(nextKey);
		currentValue = nextValue;
	}
	if (!isJsonObject(currentValue) || isEmptyObject(currentValue)) return {
		segments,
		tail: void 0,
		leafValue: currentValue
	};
	return {
		segments,
		tail: currentValue,
		leafValue: currentValue
	};
}
function buildFoldedKey(segments) {
	return segments.join(".");
}
function encodePrimitive(value, delimiter) {
	if (value === null) return NULL_LITERAL;
	if (typeof value === "boolean") return String(value);
	if (typeof value === "number") return String(value);
	return encodeStringLiteral(value, delimiter);
}
function encodeStringLiteral(value, delimiter = DEFAULT_DELIMITER) {
	if (isSafeUnquoted(value, delimiter)) return value;
	return `"${escapeString(value)}"`;
}
function encodeKey(key) {
	if (isValidUnquotedKey(key)) return key;
	return `"${escapeString(key)}"`;
}
function encodeAndJoinPrimitives(values, delimiter = DEFAULT_DELIMITER) {
	return values.map((v) => encodePrimitive(v, delimiter)).join(delimiter);
}
function formatHeader(length, options) {
	const key = options?.key;
	const fields = options?.fields;
	const delimiter = options?.delimiter ?? ",";
	let header = "";
	if (key != null) header += encodeKey(key);
	header += `[${length}${delimiter !== DEFAULT_DELIMITER ? delimiter : ""}]`;
	if (fields) {
		const quotedFields = fields.map((f) => encodeKey(f));
		header += `{${quotedFields.join(delimiter)}}`;
	}
	header += ":";
	return header;
}
function* encodeJsonValue(value, options, depth) {
	if (isJsonPrimitive(value)) {
		const encodedPrimitive = encodePrimitive(value, options.delimiter);
		if (encodedPrimitive !== "") yield encodedPrimitive;
		return;
	}
	if (isJsonArray(value)) yield* encodeArrayLines(void 0, value, depth, options);
	else if (isJsonObject(value)) yield* encodeObjectLines(value, depth, options);
}
function* encodeObjectLines(value, depth, options, rootLiteralKeys, pathPrefix, remainingDepth) {
	const keys = Object.keys(value);
	if (depth === 0 && !rootLiteralKeys) rootLiteralKeys = new Set(keys.filter((k) => k.includes(".")));
	const effectiveFlattenDepth = remainingDepth ?? options.flattenDepth;
	for (const [key, val] of Object.entries(value)) yield* encodeKeyValuePairLines(key, val, depth, options, keys, rootLiteralKeys, pathPrefix, effectiveFlattenDepth);
}
function* encodeKeyValuePairLines(key, value, depth, options, siblings, rootLiteralKeys, pathPrefix, flattenDepth) {
	const currentPath = pathPrefix ? `${pathPrefix}.${key}` : key;
	const effectiveFlattenDepth = flattenDepth ?? options.flattenDepth;
	if (options.keyFolding === "safe" && siblings) {
		const foldResult = tryFoldKeyChain(key, value, siblings, options, rootLiteralKeys, pathPrefix, effectiveFlattenDepth);
		if (foldResult) {
			const { foldedKey, remainder, leafValue, segmentCount } = foldResult;
			const encodedFoldedKey = encodeKey(foldedKey);
			if (remainder === void 0) {
				if (isJsonPrimitive(leafValue)) {
					yield indentedLine(depth, `${encodedFoldedKey}: ${encodePrimitive(leafValue, options.delimiter)}`, options.indent);
					return;
				} else if (isJsonArray(leafValue)) {
					yield* encodeArrayLines(foldedKey, leafValue, depth, options);
					return;
				} else if (isJsonObject(leafValue) && isEmptyObject(leafValue)) {
					yield indentedLine(depth, `${encodedFoldedKey}:`, options.indent);
					return;
				}
			}
			if (isJsonObject(remainder)) {
				yield indentedLine(depth, `${encodedFoldedKey}:`, options.indent);
				const remainingDepth = effectiveFlattenDepth - segmentCount;
				const foldedPath = pathPrefix ? `${pathPrefix}.${foldedKey}` : foldedKey;
				yield* encodeObjectLines(remainder, depth + 1, options, rootLiteralKeys, foldedPath, remainingDepth);
				return;
			}
		}
	}
	const encodedKey = encodeKey(key);
	if (isJsonPrimitive(value)) yield indentedLine(depth, `${encodedKey}: ${encodePrimitive(value, options.delimiter)}`, options.indent);
	else if (isJsonArray(value)) yield* encodeArrayLines(key, value, depth, options);
	else if (isJsonObject(value)) {
		yield indentedLine(depth, `${encodedKey}:`, options.indent);
		if (!isEmptyObject(value)) yield* encodeObjectLines(value, depth + 1, options, rootLiteralKeys, currentPath, effectiveFlattenDepth);
	}
}
function* encodeArrayLines(key, value, depth, options) {
	if (value.length === 0) {
		yield indentedLine(depth, key != null ? `${encodeKey(key)}: []` : "[]", options.indent);
		return;
	}
	if (isArrayOfPrimitives(value)) {
		yield indentedLine(depth, encodeInlineArrayLine(value, options.delimiter, key), options.indent);
		return;
	}
	if (isArrayOfArrays(value)) {
		if (value.every((arr) => isArrayOfPrimitives(arr))) {
			yield* encodeArrayOfArraysAsListItemsLines(key, value, depth, options);
			return;
		}
	}
	if (isArrayOfObjects$1(value)) {
		const header = extractTabularHeader(value);
		if (header) yield* encodeArrayOfObjectsAsTabularLines(key, value, header, depth, options);
		else yield* encodeMixedArrayAsListItemsLines(key, value, depth, options);
		return;
	}
	yield* encodeMixedArrayAsListItemsLines(key, value, depth, options);
}
function* encodeArrayOfArraysAsListItemsLines(prefix, values, depth, options) {
	yield indentedLine(depth, formatHeader(values.length, {
		key: prefix,
		delimiter: options.delimiter
	}), options.indent);
	for (const arr of values) if (isArrayOfPrimitives(arr)) {
		const arrayLine = encodeInlineArrayLine(arr, options.delimiter);
		yield indentedListItem(depth + 1, arrayLine, options.indent);
	}
}
function encodeInlineArrayLine(values, delimiter, prefix) {
	const header = formatHeader(values.length, {
		key: prefix,
		delimiter
	});
	const joinedValue = encodeAndJoinPrimitives(values, delimiter);
	if (values.length === 0) return header;
	return `${header} ${joinedValue}`;
}
function* encodeArrayOfObjectsAsTabularLines(prefix, rows, header, depth, options) {
	yield indentedLine(depth, formatHeader(rows.length, {
		key: prefix,
		fields: header,
		delimiter: options.delimiter
	}), options.indent);
	yield* writeTabularRowsLines(rows, header, depth + 1, options);
}
function extractTabularHeader(rows) {
	if (rows.length === 0) return;
	const firstRow = rows[0];
	const firstKeys = Object.keys(firstRow);
	if (firstKeys.length === 0) return;
	if (isTabularArray(rows, firstKeys)) return firstKeys;
}
function isTabularArray(rows, header) {
	for (const row of rows) {
		if (Object.keys(row).length !== header.length) return false;
		for (const key of header) {
			if (!Object.hasOwn(row, key)) return false;
			if (!isJsonPrimitive(row[key])) return false;
		}
	}
	return true;
}
function* writeTabularRowsLines(rows, header, depth, options) {
	for (const row of rows) yield indentedLine(depth, encodeAndJoinPrimitives(header.map((key) => row[key]), options.delimiter), options.indent);
}
function* encodeMixedArrayAsListItemsLines(prefix, items, depth, options) {
	yield indentedLine(depth, formatHeader(items.length, {
		key: prefix,
		delimiter: options.delimiter
	}), options.indent);
	for (const item of items) yield* encodeListItemValueLines(item, depth + 1, options);
}
function* encodeObjectAsListItemLines(obj, depth, options) {
	if (isEmptyObject(obj)) {
		yield indentedLine(depth, "-", options.indent);
		return;
	}
	const entries = Object.entries(obj);
	const [firstKey, firstValue] = entries[0];
	const restEntries = entries.slice(1);
	if (isJsonArray(firstValue) && isArrayOfObjects$1(firstValue)) {
		const header = extractTabularHeader(firstValue);
		if (header) {
			yield indentedListItem(depth, formatHeader(firstValue.length, {
				key: firstKey,
				fields: header,
				delimiter: options.delimiter
			}), options.indent);
			yield* writeTabularRowsLines(firstValue, header, depth + 2, options);
			if (restEntries.length > 0) yield* encodeObjectLines(Object.fromEntries(restEntries), depth + 1, options);
			return;
		}
	}
	const encodedKey = encodeKey(firstKey);
	if (isJsonPrimitive(firstValue)) yield indentedListItem(depth, `${encodedKey}: ${encodePrimitive(firstValue, options.delimiter)}`, options.indent);
	else if (isJsonArray(firstValue)) if (firstValue.length === 0) yield indentedListItem(depth, `${encodedKey}: []`, options.indent);
	else if (isArrayOfPrimitives(firstValue)) yield indentedListItem(depth, `${encodedKey}${encodeInlineArrayLine(firstValue, options.delimiter)}`, options.indent);
	else {
		yield indentedListItem(depth, `${encodedKey}${formatHeader(firstValue.length, { delimiter: options.delimiter })}`, options.indent);
		for (const item of firstValue) yield* encodeListItemValueLines(item, depth + 2, options);
	}
	else if (isJsonObject(firstValue)) {
		yield indentedListItem(depth, `${encodedKey}:`, options.indent);
		if (!isEmptyObject(firstValue)) yield* encodeObjectLines(firstValue, depth + 2, options);
	}
	if (restEntries.length > 0) yield* encodeObjectLines(Object.fromEntries(restEntries), depth + 1, options);
}
function* encodeListItemValueLines(value, depth, options) {
	if (isJsonPrimitive(value)) yield indentedListItem(depth, encodePrimitive(value, options.delimiter), options.indent);
	else if (isJsonArray(value)) if (isArrayOfPrimitives(value)) yield indentedListItem(depth, encodeInlineArrayLine(value, options.delimiter), options.indent);
	else {
		yield indentedListItem(depth, formatHeader(value.length, { delimiter: options.delimiter }), options.indent);
		for (const item of value) yield* encodeListItemValueLines(item, depth + 1, options);
	}
	else if (isJsonObject(value)) yield* encodeObjectAsListItemLines(value, depth, options);
}
function indentedLine(depth, content, indentSize) {
	return " ".repeat(indentSize * depth) + content;
}
function indentedListItem(depth, content, indentSize) {
	return indentedLine(depth, "- " + content, indentSize);
}
/**
* Applies a replacer function to a `JsonValue` and all its descendants.
*
* The replacer is called for:
* - The root value (with key='', path=[])
* - Every object property (with the property name as key)
* - Every array element (with the string index as key: '0', '1', etc.)
*
* @param root - The normalized `JsonValue` to transform
* @param replacer - The replacer function to apply
* @returns The transformed `JsonValue`
*/
function applyReplacer(root, replacer) {
	const replacedRoot = replacer("", root, []);
	if (replacedRoot === void 0) return transformChildren(root, replacer, []);
	return transformChildren(normalizeValue(replacedRoot), replacer, []);
}
/**
* Recursively transforms the children of a `JsonValue` using the replacer.
*
* @param value - The value whose children should be transformed
* @param replacer - The replacer function to apply
* @param path - Current path from root
* @returns The value with transformed children
*/
function transformChildren(value, replacer, path) {
	if (isJsonObject(value)) return transformObject(value, replacer, path);
	if (isJsonArray(value)) return transformArray(value, replacer, path);
	return value;
}
/**
* Transforms an object by applying the replacer to each property.
*
* @param obj - The object to transform
* @param replacer - The replacer function to apply
* @param path - Current path from root
* @returns A new object with transformed properties
*/
function transformObject(obj, replacer, path) {
	const result = {};
	for (const [key, value] of Object.entries(obj)) {
		const childPath = [...path, key];
		const replacedValue = replacer(key, value, childPath);
		if (replacedValue === void 0) continue;
		setOwnProperty(result, key, transformChildren(normalizeValue(replacedValue), replacer, childPath));
	}
	return result;
}
/**
* Transforms an array by applying the replacer to each element.
*
* @param arr - The array to transform
* @param replacer - The replacer function to apply
* @param path - Current path from root
* @returns A new array with transformed elements
*/
function transformArray(arr, replacer, path) {
	const result = [];
	for (let i = 0; i < arr.length; i++) {
		const value = arr[i];
		const childPath = [...path, i];
		const replacedValue = replacer(String(i), value, childPath);
		if (replacedValue === void 0) continue;
		const normalizedValue = normalizeValue(replacedValue);
		result.push(transformChildren(normalizedValue, replacer, childPath));
	}
	return result;
}
/**
* Encodes a JavaScript value into TOON format string.
*
* @param input - Any JavaScript value (objects, arrays, primitives)
* @param options - Optional encoding configuration
* @returns TOON formatted string
*
* @example
* ```ts
* encode({ name: 'Alice', age: 30 })
* // name: Alice
* // age: 30
*
* encode({ users: [{ id: 1 }, { id: 2 }] })
* // users[2]{id}:
* //   1
* //   2
*
* encode({ tags: [] })
* // tags: []
*
* encode(data, { indent: 4, keyFolding: 'safe' })
* ```
*/
function encode(input, options) {
	return Array.from(encodeLines(input, options)).join("\n");
}
/**
* Encodes a JavaScript value into TOON format as a sequence of lines.
*
* This function yields TOON lines one at a time without building the full string,
* making it suitable for streaming large outputs to files, HTTP responses, or process stdout.
*
* @param input - Any JavaScript value (objects, arrays, primitives)
* @param options - Optional encoding configuration
* @returns Iterable of TOON lines (without trailing newlines)
*
* @example
* ```ts
* // Stream to stdout
* for (const line of encodeLines({ name: 'Alice', age: 30 })) {
*   console.log(line)
* }
*
* // Collect to array
* const lines = Array.from(encodeLines(data))
*
* // Equivalent to encode()
* const toonString = Array.from(encodeLines(data, options)).join('\n')
* ```
*/
function encodeLines(input, options) {
	const normalizedValue = normalizeValue(input);
	const resolvedOptions = resolveOptions(options);
	return encodeJsonValue(resolvedOptions.replacer ? applyReplacer(normalizedValue, resolvedOptions.replacer) : normalizedValue, resolvedOptions, 0);
}
function resolveOptions(options) {
	return {
		indent: options?.indent ?? 2,
		delimiter: options?.delimiter ?? DEFAULT_DELIMITER,
		keyFolding: options?.keyFolding ?? "off",
		flattenDepth: options?.flattenDepth ?? Number.POSITIVE_INFINITY,
		replacer: options?.replacer
	};
}
//#endregion
//#region ../../node_modules/.pnpm/incur@0.4.26/node_modules/incur/dist/internal/json.js
/** Serializes JSON with BigInt values represented as decimal strings. */
function stringify(value, space) {
	return JSON.stringify(value, (_key, value) => {
		if (typeof value === "bigint") return value.toString();
		return value;
	}, space);
}
/** Converts a value to JSON-compatible data. */
function normalize(value) {
	return JSON.parse(stringify(value));
}
//#endregion
//#region ../../node_modules/.pnpm/incur@0.4.26/node_modules/incur/dist/internal/yaml.js
/** @internal Cached `yaml` module, shared by `load()` and `loadSync()`. */
var cached;
/** Loads the `yaml` module on demand, so runs that never touch YAML don't pay its startup cost. */
async function load() {
	cached ??= await import("./dist.js").then((n) => /* @__PURE__ */ __toESM(n.t(), 1));
	return cached;
}
/**
* Synchronous variant of `load()` for sync call paths (e.g. `Formatter.format`).
*
* Falls back to `require` when `load()` hasn't run yet. Async paths should call `load()`
* first so environments without synchronous module resolution (e.g. compiled binaries,
* bundled workers) never hit the fallback.
*/
function loadSync() {
	cached ??= createRequire(import.meta.url)("yaml");
	return cached;
}
//#endregion
//#region ../../node_modules/.pnpm/incur@0.4.26/node_modules/incur/dist/Formatter.js
/** Serializes a value to the specified format. Defaults to TOON. */
function format(value, fmt = "toon") {
	if (value == null) return "";
	if (fmt === "json") {
		if (typeof value === "string") {
			const trimmed = value.trim();
			if (trimmed.startsWith("{") || trimmed.startsWith("[")) try {
				return JSON.stringify(JSON.parse(value), null, 2);
			} catch {}
		}
		return stringify(value, 2);
	}
	if (fmt === "yaml") return loadSync().stringify(value);
	if (fmt === "md") return formatMarkdown(value);
	if (fmt === "jsonl") {
		if (Array.isArray(value)) return value.map((v) => stringify(v)).join("\n");
		return stringify(value);
	}
	if (isScalar$1(value)) return String(value);
	return encode(value);
}
/** Whether a value is a scalar (string, number, boolean, null, undefined). */
function isScalar$1(value) {
	return value === null || value === void 0 || typeof value !== "object";
}
/** Whether all values in an object are scalars. */
function isFlat(obj) {
	return Object.values(obj).every(isScalar$1);
}
/** Whether a value is an array of plain objects. */
function isArrayOfObjects(value) {
	return Array.isArray(value) && value.length > 0 && value.every((v) => typeof v === "object" && v !== null && !Array.isArray(v));
}
/** Renders an aligned markdown table from headers and rows. */
function table(headers, rows) {
	const widths = headers.map((h, i) => Math.max(h.length, ...rows.map((r) => (r[i] ?? "").length)));
	const pad = (s, i) => s.padEnd(widths[i]);
	return `${`| ${headers.map(pad).join(" | ")} |`}\n${`|${widths.map((w) => "-".repeat(w + 2)).join("|")}|`}\n${rows.map((r) => `| ${headers.map((_, i) => pad(r[i] ?? "", i)).join(" | ")} |`).join("\n")}`;
}
/** Renders a key-value table from a flat object. */
function kvTable(obj) {
	return table(["Key", "Value"], Object.entries(obj).map(([k, v]) => [k, String(v)]));
}
/** Renders a columnar table from an array of objects. */
function columnarTable(items) {
	const keys = [...new Set(items.flatMap(Object.keys))];
	return table(keys, items.map((item) => keys.map((k) => String(item[k] ?? ""))));
}
/** Formats a value as Markdown, recursing into nested objects. */
function formatMarkdown(value, path = []) {
	if (isScalar$1(value)) {
		if (path.length === 0) return String(value);
		return `## ${path.join(".")}\n\n${String(value)}`;
	}
	if (Array.isArray(value)) {
		if (isArrayOfObjects(value)) {
			const table = columnarTable(value);
			if (path.length === 0) return table;
			return `## ${path.join(".")}\n\n${table}`;
		}
		return formatMarkdown(String(value), path);
	}
	const obj = value;
	const entries = Object.entries(obj);
	if (path.length === 0 && isFlat(obj)) return kvTable(obj);
	if (path.length > 0 || entries.length > 1 || entries.some(([, v]) => !isScalar$1(v))) return entries.map(([key, val]) => {
		const childPath = [...path, key];
		if (isScalar$1(val)) return `## ${childPath.join(".")}\n\n${String(val)}`;
		if (isArrayOfObjects(val)) return `## ${childPath.join(".")}\n\n${columnarTable(val)}`;
		if (typeof val === "object" && val !== null && !Array.isArray(val)) {
			const nested = val;
			if (isFlat(nested)) return `## ${childPath.join(".")}\n\n${kvTable(nested)}`;
			return formatMarkdown(nested, childPath);
		}
		return `## ${childPath.join(".")}\n\n${String(val)}`;
	}).join("\n\n");
	return kvTable(obj);
}
//#endregion
//#region ../../node_modules/.pnpm/incur@0.4.26/node_modules/incur/dist/Parser.js
/** Parses raw argv tokens against Zod schemas for args and options. */
function parse(argv, options = {}) {
	const { args: argsSchema, options: optionsSchema, alias, defaults } = options;
	const optionNames = createOptionNames(optionsSchema, alias);
	const positionals = [];
	const rawArgvOptions = {};
	let i = 0;
	while (i < argv.length) {
		const token = argv[i];
		if (token.startsWith("--no-") && token.length > 5) {
			const name = normalizeOptionName(token.slice(5), optionNames);
			if (!name) throw new ParseError({ message: `Unknown flag: ${token}` });
			rawArgvOptions[name] = false;
			i++;
		} else if (token.startsWith("--")) {
			const eqIdx = token.indexOf("=");
			if (eqIdx !== -1) {
				const raw = token.slice(2, eqIdx);
				const name = normalizeOptionName(raw, optionNames);
				if (!name) throw new ParseError({ message: `Unknown flag: --${raw}` });
				setOption(rawArgvOptions, name, token.slice(eqIdx + 1), optionsSchema);
				i++;
			} else {
				const name = normalizeOptionName(token.slice(2), optionNames);
				if (!name) throw new ParseError({ message: `Unknown flag: ${token}` });
				if (isCountOption(name, optionsSchema)) {
					rawArgvOptions[name] = (rawArgvOptions[name] ?? 0) + 1;
					i++;
				} else if (isBooleanOption(name, optionsSchema)) {
					rawArgvOptions[name] = true;
					i++;
				} else {
					const value = argv[i + 1];
					if (value === void 0) throw new ParseError({ message: `Missing value for flag: ${token}` });
					setOption(rawArgvOptions, name, value, optionsSchema);
					i += 2;
				}
			}
		} else if (token.startsWith("-") && !token.startsWith("--") && token.length >= 2) {
			const chars = token.slice(1);
			for (let j = 0; j < chars.length; j++) {
				const short = chars[j];
				const name = optionNames.aliasToName.get(short);
				if (!name) throw new ParseError({ message: `Unknown flag: -${short}` });
				if (!(j === chars.length - 1)) if (isCountOption(name, optionsSchema)) rawArgvOptions[name] = (rawArgvOptions[name] ?? 0) + 1;
				else if (isBooleanOption(name, optionsSchema)) rawArgvOptions[name] = true;
				else throw new ParseError({ message: `Non-boolean flag -${short} must be last in a stacked alias` });
				else if (isCountOption(name, optionsSchema)) rawArgvOptions[name] = (rawArgvOptions[name] ?? 0) + 1;
				else if (isBooleanOption(name, optionsSchema)) rawArgvOptions[name] = true;
				else {
					const value = argv[i + 1];
					if (value === void 0) throw new ParseError({ message: `Missing value for flag: -${short}` });
					setOption(rawArgvOptions, name, value, optionsSchema);
					i++;
				}
			}
			i++;
		} else {
			positionals.push(token);
			i++;
		}
	}
	const rawArgs = {};
	if (argsSchema) {
		const keys = Object.keys(argsSchema.shape);
		for (let j = 0; j < keys.length; j++) {
			const key = keys[j];
			if (isArrayField(key, argsSchema)) {
				if (j !== keys.length - 1) throw new Error(`Variadic arg "${key}" must be the last key in the args schema`);
				const rest = positionals.slice(j);
				if (rest.length > 0) rawArgs[key] = rest;
			} else if (positionals[j] !== void 0) rawArgs[key] = positionals[j];
		}
	}
	const args = argsSchema ? zodParse(argsSchema, rawArgs) : {};
	const rawDefaults = normalizeOptionDefaults(defaults, optionsSchema, optionNames);
	if (optionsSchema) for (const [name, value] of Object.entries(rawArgvOptions)) rawArgvOptions[name] = coerce(value, name, optionsSchema);
	const mergedOptions = {
		...rawDefaults,
		...rawArgvOptions
	};
	return {
		args,
		options: optionsSchema ? zodParse(optionsSchema, mergedOptions) : {}
	};
}
/** Builds lookup tables for option names and short aliases. */
function createOptionNames(schema, alias) {
	const aliasToName = /* @__PURE__ */ new Map();
	if (alias) for (const [name, short] of Object.entries(alias)) aliasToName.set(short, name);
	const knownOptions = new Set(schema ? Object.keys(schema.shape) : []);
	const kebabToCamel = /* @__PURE__ */ new Map();
	for (const name of knownOptions) {
		const kebab = toKebab(name);
		if (kebab !== name) kebabToCamel.set(kebab, name);
	}
	return {
		aliasToName,
		kebabToCamel,
		knownOptions
	};
}
/** Normalizes a long option name, accepting kebab-case aliases for camelCase schema keys. */
function normalizeOptionName(raw, options) {
	const name = options.kebabToCamel.get(raw) ?? raw;
	return options.knownOptions.has(name) ? name : void 0;
}
/** Normalizes config-backed defaults and validates config structure/key names. */
function normalizeOptionDefaults(defaults, schema, optionNames) {
	if (defaults === void 0) return {};
	if (!isRecord(defaults)) throw new ParseError({ message: "Invalid config section: expected an object of option defaults" });
	if (!schema) {
		const [first] = Object.keys(defaults);
		if (first) throw new ParseError({ message: `Unknown config option: ${first}` });
		return {};
	}
	const normalized = {};
	for (const [rawName, value] of Object.entries(defaults)) {
		const name = normalizeOptionName(rawName, optionNames);
		if (!name) throw new ParseError({ message: `Unknown config option: ${rawName}` });
		normalized[name] = value;
	}
	return normalized;
}
/** Unwraps ZodDefault/ZodOptional to get the inner type. */
function unwrap$1(schema) {
	let s = schema;
	while (s.def?.innerType) s = s.def.innerType;
	return s;
}
/** Checks if an option's inner type is boolean. */
function isBooleanOption(name, schema) {
	if (!schema) return false;
	const field = schema.shape[name];
	if (!field) return false;
	return unwrap$1(field).constructor.name === "ZodBoolean";
}
/** Checks if an option is a count type (z.count()). */
function isCountOption(name, schema) {
	if (!schema) return false;
	const field = schema.shape[name];
	if (!field) return false;
	return typeof field.meta === "function" && field.meta()?.count === true;
}
/** Checks if a field's inner type is an array. */
function isArrayField(name, schema) {
	if (!schema) return false;
	const field = schema.shape[name];
	if (!field) return false;
	return unwrap$1(field).constructor.name === "ZodArray";
}
/** Sets an option value, collecting into arrays for array schemas. */
function setOption(raw, name, value, schema) {
	if (isArrayField(name, schema)) {
		const existing = raw[name];
		if (Array.isArray(existing)) existing.push(value);
		else raw[name] = [value];
	} else raw[name] = value;
}
/** Wraps zod schema.parse(), converting ZodError to ValidationError. */
function zodParse(schema, data) {
	try {
		return schema.parse(data);
	} catch (err) {
		const issues = err?.issues ?? err?.error?.issues ?? [];
		const fieldErrors = issues.map((issue) => ({
			code: issue.code,
			missing: !hasPath(data, issue.path ?? []),
			path: (issue.path ?? []).join("."),
			expected: issue.expected ?? "",
			received: issue.received ?? "",
			message: issue.message ?? ""
		}));
		throw new ValidationError({
			message: issues.map((i) => i.message).join("; ") || "Validation failed",
			fieldErrors,
			cause: err instanceof Error ? err : void 0
		});
	}
}
/** Checks whether the raw input contains the full issue path. */
function hasPath(data, path) {
	if (path.length === 0) return true;
	let current = data;
	for (const part of path) {
		if (!isRecord(current) && !Array.isArray(current)) return false;
		if (!(part in current)) return false;
		current = current[part];
	}
	return true;
}
/** Parses environment variables against a Zod schema. Falls back to `process.env` → `Deno.env` when no source is provided. */
function parseEnv(schema, source = defaultEnvSource()) {
	const raw = {};
	for (const [key, field] of Object.entries(schema.shape)) {
		const value = source[key];
		if (value !== void 0) raw[key] = coerceEnv(value, field);
	}
	return zodParse(schema, raw);
}
/** Coerces an env var string to the type expected by the schema field. */
function coerceEnv(value, field) {
	const typeName = unwrap$1(field).constructor.name;
	if (typeName === "ZodNumber") return Number(value);
	if (typeName === "ZodBoolean") return value === "true" || value === "1";
	return value;
}
/** Coerces a raw string value to the type expected by the schema. */
function coerce(value, name, schema) {
	const field = schema.shape[name];
	if (!field) return value;
	const typeName = unwrap$1(field).constructor.name;
	if (typeName === "ZodNumber" && typeof value === "string") return Number(value);
	if (typeName === "ZodBoolean" && typeof value === "string") return value === "true";
	return value;
}
/** Parses known global options from argv, passing unknown flags and positionals through to `rest`. */
function parseGlobals(argv, schema, alias, options = {}) {
	const optionNames = createOptionNames(schema, alias);
	const rest = [];
	const rawOptions = {};
	let i = 0;
	while (i < argv.length) {
		const token = argv[i];
		if (token === "--") {
			for (let j = i; j < argv.length; j++) rest.push(argv[j]);
			break;
		}
		if (token.startsWith("--no-") && token.length > 5) {
			const name = normalizeOptionName(token.slice(5), optionNames);
			if (!name) rest.push(token);
			else rawOptions[name] = false;
			i++;
		} else if (token.startsWith("--")) {
			const eqIdx = token.indexOf("=");
			if (eqIdx !== -1) {
				const name = normalizeOptionName(token.slice(2, eqIdx), optionNames);
				if (!name) rest.push(token);
				else setOption(rawOptions, name, token.slice(eqIdx + 1), schema);
				i++;
			} else {
				const name = normalizeOptionName(token.slice(2), optionNames);
				if (!name) {
					rest.push(token);
					i++;
				} else if (isCountOption(name, schema)) {
					rawOptions[name] = (rawOptions[name] ?? 0) + 1;
					i++;
				} else if (isBooleanOption(name, schema)) {
					rawOptions[name] = true;
					i++;
				} else {
					const value = argv[i + 1];
					if (value === void 0) throw new ParseError({ message: `Missing value for flag: ${token}` });
					setOption(rawOptions, name, value, schema);
					i += 2;
				}
			}
		} else if (token.startsWith("-") && !token.startsWith("--") && token.length >= 2) {
			const chars = token.slice(1);
			let allKnown = true;
			for (let j = 0; j < chars.length; j++) if (!optionNames.aliasToName.has(chars[j])) {
				allKnown = false;
				break;
			}
			if (!allKnown) {
				rest.push(token);
				i++;
			} else {
				for (let j = 0; j < chars.length; j++) {
					const short = chars[j];
					const name = optionNames.aliasToName.get(short);
					if (!(j === chars.length - 1)) if (isCountOption(name, schema)) rawOptions[name] = (rawOptions[name] ?? 0) + 1;
					else if (isBooleanOption(name, schema)) rawOptions[name] = true;
					else throw new ParseError({ message: `Non-boolean flag -${short} must be last in a stacked alias` });
					else if (isCountOption(name, schema)) rawOptions[name] = (rawOptions[name] ?? 0) + 1;
					else if (isBooleanOption(name, schema)) rawOptions[name] = true;
					else {
						const value = argv[i + 1];
						if (value === void 0) throw new ParseError({ message: `Missing value for flag: -${short}` });
						setOption(rawOptions, name, value, schema);
						i++;
					}
				}
				i++;
			}
		} else {
			rest.push(token);
			i++;
		}
	}
	if (options.validate === false) return {
		parsed: rawOptions,
		rest
	};
	for (const [name, value] of Object.entries(rawOptions)) rawOptions[name] = coerce(value, name, schema);
	return {
		parsed: zodParse(schema, rawOptions),
		rest
	};
}
/** Returns the best available env source for the current runtime. */
function defaultEnvSource() {
	if (typeof globalThis !== "undefined") {
		const g = globalThis;
		if (g.process?.env) return g.process.env;
		if (g.Deno?.env) return new Proxy({}, { get: (_, key) => g.Deno.env.get(key) });
	}
	return {};
}
//#endregion
//#region ../../node_modules/.pnpm/incur@0.4.26/node_modules/incur/dist/internal/command.js
/** @internal Sentinel symbol for `ok()` and `error()` return values. */
var sentinel$1 = Symbol.for("incur.sentinel");
/** @internal Unified command execution used by CLI, HTTP, and MCP transports. */
async function execute(command, options) {
	const { argv, inputOptions, agent, format, formatExplicit, name, path, version, envSource = process.env, env: envSchema, globals = {}, vars: varsSchema, middlewares = [], request } = options;
	const displayName = options.displayName ?? name;
	const parseMode = options.parseMode ?? "argv";
	const varsMap = varsSchema ? varsSchema.parse({}) : {};
	let result;
	let streamConsumed;
	let resolveStreamConsumed;
	let resolveResultReady;
	const resultReady = new Promise((r) => {
		resolveResultReady = r;
	});
	const runCommand = async () => {
		let args;
		let parsedOptions;
		if (parseMode === "argv") {
			const parsed = parse(argv, {
				alias: command.alias,
				args: command.args,
				defaults: options.defaults,
				options: command.options
			});
			args = parsed.args;
			parsedOptions = parsed.options;
		} else if (parseMode === "split") {
			args = parse(argv, { args: command.args }).args;
			parsedOptions = command.options ? zodParse(command.options, inputOptions) : {};
		} else {
			const split = splitParams(inputOptions, command);
			args = command.args ? zodParse(command.args, split.args) : {};
			parsedOptions = command.options ? zodParse(command.options, split.options) : {};
		}
		const commandEnv = command.env ? parseEnv(command.env, envSource) : {};
		const okFn = (data, meta = {}) => ({
			[sentinel$1]: "ok",
			data,
			cta: meta.cta
		});
		const errorFn = (opts) => ({
			[sentinel$1]: "error",
			...opts
		});
		const raw = command.run({
			agent,
			args,
			displayName,
			env: commandEnv,
			error: errorFn,
			format,
			formatExplicit,
			globals,
			name,
			ok: okFn,
			options: parsedOptions,
			request,
			var: varsMap,
			version
		});
		if (isAsyncGenerator(raw)) {
			if (middlewares.length > 0) {
				streamConsumed = new Promise((r) => {
					resolveStreamConsumed = r;
				});
				async function* wrapped() {
					try {
						return yield* raw;
					} finally {
						resolveStreamConsumed();
					}
				}
				result = { stream: wrapped() };
				resolveResultReady();
				await streamConsumed;
			} else result = { stream: raw };
			return;
		}
		const awaited = await raw;
		if (isSentinel$1(awaited)) {
			if (awaited[sentinel$1] === "ok") {
				const ok = awaited;
				result = {
					ok: true,
					data: ok.data,
					...ok.cta ? { cta: ok.cta } : void 0
				};
			} else {
				const err = awaited;
				result = {
					ok: false,
					error: {
						code: err.code,
						message: err.message,
						...err.retryable !== void 0 ? { retryable: err.retryable } : void 0
					},
					...err.cta ? { cta: err.cta } : void 0,
					...err.exitCode !== void 0 ? { exitCode: err.exitCode } : void 0
				};
			}
			return;
		}
		result = {
			ok: true,
			data: awaited
		};
	};
	try {
		const cliEnv = envSchema ? parseEnv(envSchema, envSource) : {};
		if (middlewares.length > 0) {
			const errorFn = (opts) => {
				result = {
					ok: false,
					error: {
						code: opts.code,
						message: opts.message,
						...opts.retryable !== void 0 ? { retryable: opts.retryable } : void 0
					},
					...opts.cta ? { cta: opts.cta } : void 0,
					...opts.exitCode !== void 0 ? { exitCode: opts.exitCode } : void 0
				};
			};
			const mwCtx = {
				agent,
				command: path,
				displayName,
				env: cliEnv,
				error: errorFn,
				format,
				formatExplicit,
				globals,
				name,
				request,
				set(key, value) {
					varsMap[key] = value;
				},
				var: varsMap,
				version
			};
			const chainPromise = middlewares.reduceRight((next, mw) => async () => {
				await mw(mwCtx, next);
			}, runCommand)();
			await Promise.race([chainPromise, resultReady]);
			if (streamConsumed) return result;
			await chainPromise;
		} else await runCommand();
	} catch (error) {
		if (error instanceof ValidationError) return {
			ok: false,
			error: {
				code: "VALIDATION_ERROR",
				message: error.message,
				fieldErrors: error.fieldErrors
			}
		};
		return {
			ok: false,
			error: {
				code: error instanceof IncurError ? error.code : "UNKNOWN",
				message: error instanceof Error ? error.message : String(error),
				...error instanceof IncurError ? { retryable: error.retryable } : void 0
			},
			...error instanceof IncurError && error.exitCode !== void 0 ? { exitCode: error.exitCode } : void 0
		};
	}
	return result ?? {
		ok: true,
		data: void 0
	};
}
/** @internal Splits flat params into args vs options using schema shapes. */
function splitParams(params, command) {
	const argKeys = new Set(command.args ? Object.keys(command.args.shape) : []);
	const a = {};
	const o = {};
	for (const [key, value] of Object.entries(params)) if (argKeys.has(key)) a[key] = value;
	else o[key] = value;
	return {
		args: a,
		options: o
	};
}
/** @internal Type guard for sentinel results. */
function isSentinel$1(value) {
	return typeof value === "object" && value !== null && sentinel$1 in value;
}
/** @internal Type guard for async generators. */
function isAsyncGenerator(value) {
	return typeof value === "object" && value !== null && Symbol.asyncIterator in value && typeof value.next === "function";
}
/** @internal Creates a builtin subcommand with typesafe alias inference. */
function subcommand(def) {
	return def;
}
/** Supported shell names for completions. */
var shells = [
	"bash",
	"fish",
	"nushell",
	"zsh"
];
/** Built-in command metadata shared by help, completions, and handler logic. */
var builtinCommands = [
	{
		name: "completions",
		description: "Generate shell completion script",
		args: object({ shell: _enum(shells).describe("Shell to generate completions for") }),
		hint(name) {
			const rows = [
				[
					"bash",
					`eval "$(${name} completions bash)"`,
					"# add to ~/.bashrc"
				],
				[
					"fish",
					`${name} completions fish | source`,
					"# add to ~/.config/fish/config.fish"
				],
				[
					"nushell",
					`see \`${name} completions nushell\``,
					"# add to config.nu"
				],
				[
					"zsh",
					`eval "$(${name} completions zsh)"`,
					"# add to ~/.zshrc"
				]
			];
			const shellW = Math.max(...rows.map((r) => r[0].length));
			const cmdW = Math.max(...rows.map((r) => r[1].length));
			return "Setup:\n" + rows.map(([s, cmd, comment]) => `  ${s.padEnd(shellW)}  ${cmd.padEnd(cmdW)}  ${comment}`).join("\n");
		}
	},
	{
		name: "mcp",
		description: "Register as MCP server",
		subcommands: [subcommand({
			name: "add",
			description: "Register as MCP server",
			alias: { command: "c" },
			options: object({
				agent: string().optional().describe("Target a specific agent (e.g. claude-code, cursor)"),
				command: string().optional().describe("Override the command agents will run (e.g. \"pnpm my-cli --mcp\")"),
				noGlobal: boolean().optional().describe("Install to project instead of globally")
			})
		}), subcommand({
			name: "doctor",
			description: "Validate MCP server startup and tool listing"
		})]
	},
	{
		name: "skills",
		aliases: ["skill"],
		description: "Sync skill files to agents",
		subcommands: [subcommand({
			name: "add",
			description: "Sync skill files to agents",
			options: object({
				depth: number().optional().describe("Grouping depth for skill files (default: 1)"),
				noGlobal: boolean().optional().describe("Install to project instead of globally")
			})
		}), subcommand({
			name: "list",
			aliases: ["ls"],
			description: "List skills"
		})]
	}
];
/** @internal Finds a builtin command by its name or alias. */
function findBuiltin(token) {
	return builtinCommands.find((b) => b.name === token || b.aliases?.includes(token));
}
/** @internal Finds a builtin subcommand by its name or alias. */
function findBuiltinSubcommand(builtin, token) {
	return builtin.subcommands?.find((sub) => sub.name === token || sub.aliases?.includes(token));
}
//#endregion
//#region ../../node_modules/.pnpm/incur@0.4.26/node_modules/incur/dist/Help.js
/** Formats help text for a router CLI or command group. */
function formatRoot(name, options = {}) {
	const { aliases, configFlag, description, globals, version, commands = [], root = false } = options;
	const lines = [];
	const title = version ? `${name}@${version}` : name;
	lines.push(description ? `${title} \u2014 ${description}` : title);
	lines.push("");
	lines.push(`Usage: ${name} <command>`);
	if (aliases?.length) lines.push(`Aliases: ${aliases.join(", ")}`);
	if (commands.length > 0) {
		lines.push("");
		lines.push("Commands:");
		const maxLen = Math.max(...commands.map((c) => c.name.length));
		for (const cmd of commands) if (cmd.description) {
			const padding = " ".repeat(maxLen - cmd.name.length);
			lines.push(`  ${cmd.name}${padding}  ${cmd.description}`);
		} else lines.push(`  ${cmd.name}`);
	}
	lines.push(...globalOptionsLines(root, configFlag, globals));
	return lines.join("\n");
}
/** Formats help text for a leaf command. */
function formatCommand(name, options = {}) {
	const { alias, aliases, configFlag, description, globals, version, args, env, envSource, hint, root = false, options: opts, examples } = options;
	const lines = [];
	const title = version ? `${name}@${version}` : name;
	lines.push(description ? `${title} \u2014 ${description}` : title);
	lines.push("");
	const { usage } = options;
	if (usage && usage.length > 0) {
		const usageLines = usage.map((u) => {
			const parts = [];
			if (u.prefix) parts.push(u.prefix);
			parts.push(name);
			if (u.args) for (const key of Object.keys(u.args)) parts.push(`<${key}>`);
			if (u.options) for (const key of Object.keys(u.options)) parts.push(`--${key} <${key}>`);
			if (u.suffix) parts.push(u.suffix);
			return parts.join(" ");
		});
		const pad = " ".repeat(7);
		lines.push(`Usage: ${usageLines[0]}`);
		for (const line of usageLines.slice(1)) lines.push(`${pad}${line}`);
	} else {
		const synopsis = buildSynopsis(name, args);
		const commandSuffix = options.commands && options.commands.length > 0 ? " | <command>" : "";
		lines.push(`Usage: ${synopsis}${opts ? " [options]" : ""}${commandSuffix}`);
	}
	if (aliases?.length) lines.push(`Aliases: ${aliases.join(", ")}`);
	if (args) {
		const entries = argsEntries(args);
		if (entries.length > 0) {
			lines.push("");
			lines.push("Arguments:");
			const maxLen = Math.max(...entries.map((e) => e.name.length));
			for (const entry of entries) lines.push(`  ${entry.name}${" ".repeat(maxLen - entry.name.length)}  ${entry.description}`);
		}
	}
	if (opts) {
		const entries = optionEntries(opts, alias);
		if (entries.length > 0) {
			lines.push("");
			lines.push("Options:");
			const maxLen = Math.max(...entries.map((e) => e.flag.length));
			for (const entry of entries) {
				const padding = " ".repeat(maxLen - entry.flag.length);
				const prefix = entry.deprecated ? "[deprecated] " : "";
				const desc = entry.defaultValue !== void 0 ? `${prefix}${entry.description} (default: ${entry.defaultValue})` : `${prefix}${entry.description}`;
				lines.push(`  ${entry.flag}${padding}  ${desc}`);
			}
		}
	}
	if (examples && examples.length > 0) {
		lines.push("");
		lines.push("Examples:");
		const maxLen = Math.max(...examples.map((e) => (e.command ? `${name} ${e.command}` : name).length));
		for (const ex of examples) {
			const cmd = ex.command ? `${name} ${ex.command}` : name;
			if (ex.description) lines.push(`  ${cmd}${" ".repeat(maxLen - cmd.length)}  # ${ex.description}`);
			else lines.push(`  ${cmd}`);
		}
	}
	if (hint) {
		lines.push("");
		lines.push(hint);
	}
	const { commands } = options;
	if (commands && commands.length > 0) {
		lines.push("");
		lines.push("Commands:");
		const maxLen = Math.max(...commands.map((c) => c.name.length));
		for (const cmd of commands) if (cmd.description) {
			const padding = " ".repeat(maxLen - cmd.name.length);
			lines.push(`  ${cmd.name}${padding}  ${cmd.description}`);
		} else lines.push(`  ${cmd.name}`);
	}
	if (!options.hideGlobalOptions) lines.push(...globalOptionsLines(root, configFlag, globals));
	if (env) {
		const entries = envEntries(env);
		if (entries.length > 0) {
			lines.push("");
			lines.push("Environment Variables:");
			const maxLen = Math.max(...entries.map((e) => e.name.length));
			for (const entry of entries) {
				const padding = " ".repeat(maxLen - entry.name.length);
				const parts = [entry.description];
				const source = envSource ?? defaultEnvSource();
				if (entry.name in source) parts.push(`set: ${redact(source[entry.name])}`);
				if (entry.defaultValue !== void 0) parts.push(`default: ${entry.defaultValue}`);
				const desc = parts.length > 1 ? `${parts[0]} (${parts.slice(1).join(", ")})` : parts[0];
				lines.push(`  ${entry.name}${padding}  ${desc}`);
			}
		}
	}
	return lines.join("\n");
}
/** Builds the synopsis string with `<required>`, `[optional]`, and `<variadic...>` placeholders. */
function buildSynopsis(name, args) {
	if (!args) return name;
	const parts = [name];
	for (const [key, schema] of Object.entries(args.shape)) {
		const type = resolveTypeName$1(schema);
		const label = (type.includes("|") ? type : key) + (type === "array" ? "..." : "");
		parts.push(schema._zod.optout === "optional" ? `[${label}]` : `<${label}>`);
	}
	return parts.join(" ");
}
/** Extracts arg entries from a Zod object schema. */
function argsEntries(schema) {
	const entries = [];
	for (const [key, field] of Object.entries(schema.shape)) entries.push({
		name: key,
		description: field.description ?? ""
	});
	return entries;
}
/** Extracts env var entries from a Zod object schema. */
function envEntries(schema) {
	const entries = [];
	for (const [key, field] of Object.entries(schema.shape)) {
		const defaultValue = extractDefault(field);
		entries.push({
			name: key,
			description: field.description ?? "",
			defaultValue
		});
	}
	return entries;
}
/** Extracts option entries from a Zod object schema. */
function optionEntries(schema, alias) {
	const entries = [];
	for (const [key, field] of Object.entries(schema.shape)) {
		const type = resolveTypeName$1(field);
		const short = alias?.[key];
		const kebab = toKebab(key);
		const valueHint = type === "boolean" ? "" : ` <${type}>`;
		const flag = short ? `--${kebab}, -${short}${valueHint}` : `--${kebab}${valueHint}`;
		let defaultValue = extractDefault(field);
		if (type === "boolean" && defaultValue === false) defaultValue = void 0;
		const deprecated = extractDeprecated(field);
		entries.push({
			flag,
			description: field.description ?? "",
			defaultValue,
			deprecated
		});
	}
	return entries;
}
/** Resolves a human-readable type name from a Zod schema. */
function resolveTypeName$1(schema) {
	if (isCountSchema(schema)) return "count";
	const unwrapped = unwrap(schema);
	if (unwrapped instanceof ZodString) return "string";
	if (unwrapped instanceof ZodNumber) return "number";
	if (unwrapped instanceof ZodBoolean) return "boolean";
	if (unwrapped instanceof ZodArray) return "array";
	if (unwrapped instanceof ZodEnum) return Object.values(unwrapped._zod.def.entries).join("|");
	if (unwrapped instanceof ZodUnion) {
		const options = unwrapped._zod?.def?.options;
		if (options?.every((o) => o instanceof ZodLiteral)) return options.map((o) => String(o._zod.def.values[0])).join("|");
	}
	return "value";
}
/** Checks if a schema is a count type (`.meta({ count: true })`). */
function isCountSchema(schema) {
	const s = schema;
	return typeof s?.meta === "function" && s.meta()?.count === true;
}
/** Unwraps optional/default/nullable wrappers to get the inner type. */
function unwrap(schema) {
	if (schema instanceof ZodOptional) return unwrap(schema.unwrap());
	if (schema instanceof ZodDefault) return unwrap(schema.removeDefault());
	if (schema instanceof ZodNullable) return unwrap(schema.unwrap());
	return schema;
}
/** Extracts the default value from a Zod schema, if any. */
function extractDefault(schema) {
	if (schema instanceof ZodDefault) {
		const raw = schema._def.defaultValue;
		const value = typeof raw === "function" ? raw() : raw;
		if (Array.isArray(value) && value.length === 0) return void 0;
		return value;
	}
	if (schema instanceof ZodOptional) return extractDefault(schema.unwrap());
}
/** Reads the `deprecated` flag from a Zod schema's `.meta()`. */
function extractDeprecated(schema) {
	return (schema?.meta?.())?.deprecated === true ? true : void 0;
}
/** Renders the built-in commands and global options block. Root-only items are hidden for subcommands. */
function globalOptionsLines(root = false, configFlag, globals) {
	const lines = [];
	if (root) {
		const builtins = builtinCommands.flatMap((b) => {
			if (!b.subcommands) return [{
				name: b.name,
				desc: b.description
			}];
			if (b.subcommands.length === 1) return [{
				name: `${b.name} ${b.subcommands[0].name}`,
				desc: b.subcommands[0].description
			}];
			const names = b.subcommands.map((s) => s.name).join(", ");
			return [{
				name: b.name,
				desc: `${b.description} (${names})`
			}];
		});
		const maxCmd = Math.max(...builtins.map((b) => b.name.length));
		lines.push("", "Integrations:", ...builtins.map((b) => `  ${b.name}${" ".repeat(maxCmd - b.name.length)}  ${b.desc}`));
	}
	if (globals) {
		const entries = optionEntries(globals.schema, globals.alias);
		if (entries.length > 0) {
			const maxLen = Math.max(...entries.map((e) => e.flag.length));
			lines.push("", "Custom Global Options:", ...entries.map((entry) => {
				const padding = " ".repeat(maxLen - entry.flag.length);
				const prefix = entry.deprecated ? "[deprecated] " : "";
				const desc = entry.defaultValue !== void 0 ? `${prefix}${entry.description} (default: ${entry.defaultValue})` : `${prefix}${entry.description}`;
				return `  ${entry.flag}${padding}  ${desc}`;
			}));
		}
	}
	const flags = [
		...configFlag ? [{
			flag: `--${configFlag} <path>`,
			desc: "Load JSON option defaults from a file"
		}] : [],
		{
			flag: "--filter-output <keys>",
			desc: "Filter output by key paths (e.g. foo,bar.baz,a[0,3])"
		},
		{
			flag: "--format <toon|json|yaml|md|jsonl>",
			desc: "Output format"
		},
		{
			flag: "--help",
			desc: "Show help"
		},
		{
			flag: "--llms, --llms-full",
			desc: "Print LLM-readable manifest"
		},
		...root ? [{
			flag: "--mcp",
			desc: "Start as MCP stdio server"
		}] : [],
		...configFlag ? [{
			flag: `--no-${configFlag}`,
			desc: "Disable JSON option defaults for this run"
		}] : [],
		{
			flag: "--schema",
			desc: "Show JSON Schema for command"
		},
		{
			flag: "--token-count",
			desc: "Print token count of output (instead of output)"
		},
		{
			flag: "--token-limit <n>",
			desc: "Limit output to n tokens"
		},
		{
			flag: "--token-offset <n>",
			desc: "Skip first n tokens of output"
		},
		{
			flag: "--full-output",
			desc: "Show full output envelope"
		},
		...root ? [{
			flag: "--update",
			desc: "Update to latest version"
		}] : [],
		...root ? [{
			flag: "--version",
			desc: "Show version"
		}] : []
	].sort((a, b) => a.flag.localeCompare(b.flag));
	const maxLen = Math.max(...flags.map((f) => f.flag.length));
	lines.push("", "Global Options:", ...flags.map((f) => `  ${f.flag}${" ".repeat(maxLen - f.flag.length)}  ${f.desc}`));
	return lines;
}
/** Redacts a value, showing only the last 4 characters for long values. */
function redact(value) {
	if (value.length <= 4) return "****";
	return `****${value.slice(-4)}`;
}
//#endregion
//#region ../../node_modules/.pnpm/incur@0.4.26/node_modules/incur/dist/internal/cta.js
/** @internal Formats a CTA block into the output metadata shape. */
function formatCtaBlock(name, block) {
	if (!block || block.commands.length === 0) return void 0;
	return {
		description: block.description ?? (block.commands.length === 1 ? "Suggested command:" : "Suggested commands:"),
		commands: block.commands.map((c) => formatCta(name, c))
	};
}
/** @internal Renders a formatted CTA block as plain text for inline tool output. */
function renderCtaText(block) {
	const lines = [block.description];
	for (const c of block.commands) lines.push(`  ${c.command}${c.description ? ` - ${c.description}` : ""}`);
	return lines.join("\n");
}
/** @internal Formats a CTA by prefixing the CLI name. */
function formatCta(name, cta) {
	if (typeof cta === "string") return { command: `${name} ${cta}` };
	let cmd = `${cta.command === name || cta.command.startsWith(`${name} `) ? "" : `${name} `}${cta.command}`;
	if (cta.args) for (const [key, value] of Object.entries(cta.args)) cmd += value === true ? ` <${key}>` : ` ${value}`;
	if (cta.options) for (const [key, value] of Object.entries(cta.options)) cmd += value === true ? ` --${key} <${key}>` : ` --${key} ${value}`;
	return {
		command: cmd,
		...cta.description ? { description: cta.description } : void 0
	};
}
//#endregion
//#region ../../node_modules/.pnpm/incur@0.4.26/node_modules/incur/dist/Schema.js
/**
* Converts a Zod schema to a JSON Schema object. Strips the `$schema`
* meta-property. Represents bigints and dates as `{ type: "string" }`
* since JSON lacks native types for them.
*/
function toJsonSchema(schema) {
	const result = toJSONSchema(schema, {
		unrepresentable: "any",
		override: (ctx) => {
			const type = ctx.zodSchema._zod?.def?.type;
			if (type === "bigint" || type === "date") ctx.jsonSchema.type = "string";
		}
	});
	delete result.$schema;
	return result;
}
//#endregion
//#region ../../node_modules/.pnpm/incur@0.4.26/node_modules/incur/dist/Mcp.js
/** Starts a stdio MCP server that exposes commands as tools. */
async function serve(name, version, commands, options = {}) {
	const stdio = importStdioModule();
	const mcp = await import("./dist2.js").then((n) => n.t);
	const { fromJsonSchema, McpServer } = mcp;
	const StdioServerTransport = await importStdioServerTransport(mcp, stdio);
	const server = new McpServer({
		name,
		...options.title ? { title: options.title } : void 0,
		version
	}, options.instructions ? { instructions: options.instructions } : void 0);
	registerTools(server, commands, {
		env: options.env,
		fromJsonSchema,
		middlewares: options.middlewares,
		name,
		sendNotification: (notification) => server.server.notification(notification),
		tools: options.tools,
		vars: options.vars,
		version
	});
	const transport = new StdioServerTransport(options.input ?? process.stdin, options.output ?? process.stdout);
	await server.connect(transport);
}
async function importStdioServerTransport(mcp, stdio) {
	const transport = mcp.StdioServerTransport;
	if (transport) return transport;
	const result = await stdio;
	if (result.error) throw result.error;
	return result.module.StdioServerTransport;
}
function importStdioModule() {
	return importModule("@modelcontextprotocol/server/stdio").then((module) => ({ module })).catch((error) => ({ error }));
}
var importModule = (specifier) => import(specifier);
/** @internal Executes a tool call and returns a CallToolResult. */
async function callTool(tool, params, options = {}) {
	const allMiddleware = [
		...options.middlewares ?? [],
		...tool.middlewares ?? [],
		...tool.command.middleware ?? []
	];
	const result = await execute(tool.command, {
		agent: true,
		argv: [],
		env: options.env,
		format: "json",
		formatExplicit: true,
		inputOptions: params,
		middlewares: allMiddleware,
		name: options.name ?? tool.name,
		parseMode: "flat",
		path: tool.name,
		request: options.request,
		vars: options.vars,
		version: options.version
	});
	if ("stream" in result) {
		const chunks = [];
		const progressToken = options.extra?.mcpReq?._meta?.progressToken;
		let i = 0;
		try {
			for await (const chunk of result.stream) {
				chunks.push(chunk);
				if (progressToken !== void 0 && options.sendNotification) await options.sendNotification({
					method: "notifications/progress",
					params: {
						progressToken,
						progress: ++i,
						message: stringify(chunk)
					}
				});
			}
		} catch (err) {
			return {
				content: [{
					type: "text",
					text: err instanceof Error ? err.message : String(err)
				}],
				isError: true
			};
		}
		return { content: [{
			type: "text",
			text: stringify(chunks)
		}] };
	}
	if (!result.ok) {
		const cta = formatCtaBlock(options.name ?? tool.name, result.cta);
		const text = result.error.fieldErrors ? JSON.stringify(result.error) : result.error.message ?? "Command failed";
		return {
			content: [{
				type: "text",
				text: cta ? `${text}\n\n${renderCtaText(cta)}` : text
			}],
			...cta ? { _meta: { cta } } : void 0,
			isError: true
		};
	}
	const data = result.data ?? null;
	const jsonData = normalize(data);
	const cta = formatCtaBlock(options.name ?? tool.name, result.cta);
	const text = stringify(jsonData);
	return {
		content: [{
			type: "text",
			text: cta ? `${text}\n\n${renderCtaText(cta)}` : text
		}],
		...data !== null && tool.outputSchema ? { structuredContent: jsonData } : void 0,
		...cta ? { _meta: { cta } } : void 0
	};
}
/** @internal Registers direct or progressively discovered MCP tools. */
function registerTools(server, commands, options) {
	const tools = collectTools(commands, [], [], options.tools);
	if (tools.length === 0) return;
	if ((options.tools?.discovery ?? "progressive") === "direct") {
		for (const tool of tools) registerDirectTool(server, tool, options);
		return;
	}
	registerDiscoveryTools(server, tools, options);
}
function registerDirectTool(server, tool, options) {
	const mergedShape = {
		...tool.command.args?.shape,
		...tool.command.options?.shape
	};
	const hasInput = Object.keys(mergedShape).length > 0;
	server.registerTool(tool.name, {
		...tool.description ? { description: tool.description } : void 0,
		...hasInput ? { inputSchema: object(mergedShape) } : void 0,
		...tool.outputSchema ? { outputSchema: options.fromJsonSchema(tool.outputSchema) } : void 0,
		...tool.annotations ? { annotations: tool.annotations } : void 0,
		...tool.instructions ? { _meta: { instructions: tool.instructions } } : void 0
	}, async (...callArgs) => {
		return callTool(tool, hasInput ? callArgs[0] : {}, callOptions(options, hasInput ? callArgs[1] : callArgs[0]));
	});
}
function registerDiscoveryTools(server, tools, options) {
	const byName = new Map(tools.map((tool) => [tool.name, tool]));
	server.registerTool("search_tools", {
		description: "Search or page through available tools by capability. Returns names and descriptions without loading their schemas. Inspect a result before calling it.",
		inputSchema: object({
			limit: number().int().min(1).max(20).default(5).describe("Maximum matches."),
			offset: number().int().min(0).default(0).describe("Matches to skip."),
			query: string().default("").describe("Capability to find. Empty lists all tools.")
		}),
		annotations: catalogAnnotations
	}, async (params) => {
		const matches = searchTools(tools, params.query);
		const page = matches.slice(params.offset, params.offset + params.limit);
		return toolResult({
			tools: page.map((tool) => ({
				name: tool.name,
				...tool.description ? { description: tool.description } : void 0,
				...tool.annotations ? { annotations: tool.annotations } : void 0
			})),
			...params.offset + page.length < matches.length ? { nextOffset: params.offset + page.length } : void 0
		});
	});
	server.registerTool("get_tool_details", {
		description: "Inspect one tool returned by search_tools. Returns its complete input schema and metadata.",
		inputSchema: object({ name: string().min(1).describe("Exact tool name.") }),
		annotations: catalogAnnotations
	}, async (params) => {
		const tool = byName.get(params.name);
		if (!tool) return toolError(`Unknown tool: ${params.name}`);
		return toolResult({
			name: tool.name,
			...tool.description ? { description: tool.description } : void 0,
			inputSchema: tool.inputSchema,
			...tool.outputSchema ? { outputSchema: tool.outputSchema } : void 0,
			...tool.annotations ? { annotations: tool.annotations } : void 0,
			...tool.instructions ? { instructions: tool.instructions } : void 0
		});
	});
	server.registerTool("call_read_tool", {
		description: "Execute a tool marked read-only after inspecting its schema with get_tool_details.",
		inputSchema: callSchema,
		annotations: readAnnotations
	}, async (params, extra) => {
		const tool = byName.get(params.name);
		if (!tool) return toolError(`Unknown tool: ${params.name}`);
		if (tool.annotations?.readOnlyHint !== true) return toolError(`Tool is not read-only: ${params.name}`);
		return callTool(tool, params.arguments, callOptions(options, extra));
	});
	server.registerTool("call_write_tool", {
		description: "Execute a writable or unclassified tool after inspecting its schema with get_tool_details.",
		inputSchema: callSchema,
		annotations: writeAnnotations
	}, async (params, extra) => {
		const tool = byName.get(params.name);
		if (!tool) return toolError(`Unknown tool: ${params.name}`);
		if (tool.annotations?.readOnlyHint === true) return toolError(`Tool is read-only: ${params.name}`);
		return callTool(tool, params.arguments, callOptions(options, extra));
	});
}
var callSchema = object({
	name: string().min(1).describe("Exact tool name."),
	arguments: record(string(), unknown()).default({}).describe("Arguments from its schema.")
});
var catalogAnnotations = {
	destructiveHint: false,
	idempotentHint: true,
	openWorldHint: false,
	readOnlyHint: true
};
var readAnnotations = {
	destructiveHint: false,
	idempotentHint: true,
	openWorldHint: true,
	readOnlyHint: true
};
var writeAnnotations = {
	destructiveHint: true,
	idempotentHint: false,
	openWorldHint: true,
	readOnlyHint: false
};
function callOptions(options, extra) {
	return {
		env: options.env,
		extra,
		middlewares: options.middlewares,
		name: options.name,
		request: options.request?.(extra),
		...options.sendNotification ? { sendNotification: options.sendNotification } : void 0,
		vars: options.vars,
		version: options.version
	};
}
function searchTools(tools, query) {
	const normalized = normalizeSearch(query);
	const terms = normalized.split(" ").filter(Boolean);
	return tools.map((tool) => ({
		tool,
		score: toolScore(tool, normalized, terms)
	})).filter(({ score }) => score > 0).sort((a, b) => b.score - a.score || a.tool.name.localeCompare(b.tool.name)).map(({ tool }) => tool);
}
function toolScore(tool, query, terms) {
	const name = normalizeSearch(tool.name);
	const description = normalizeSearch(tool.description ?? "");
	if (name === query) return 1e3;
	let score = name.startsWith(query) ? 100 : name.includes(query) ? 50 : 0;
	for (const term of terms) {
		if (name.split(" ").includes(term)) score += 20;
		else if (name.includes(term)) score += 10;
		if (description.includes(term)) score += 2;
	}
	return score;
}
function normalizeSearch(value) {
	return value.toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
}
function toolResult(value) {
	return { content: [{
		type: "text",
		text: stringify(value)
	}] };
}
function toolError(message) {
	return {
		...toolResult({ error: message }),
		isError: true
	};
}
/** @internal Recursively collects leaf commands as tool entries. */
function collectTools(commands, prefix, parentMiddlewares = [], filter) {
	const tools = filterTools(collectToolEntries(commands, prefix, parentMiddlewares), filter);
	assertUniqueToolNames(tools);
	return tools.sort((a, b) => a.name.localeCompare(b.name));
}
function collectToolEntries(commands, prefix, parentMiddlewares = []) {
	const result = [];
	for (const [name, entry] of commands) {
		if ("_alias" in entry) continue;
		if (entry.mcp === false) continue;
		const path = [...prefix, name];
		if ("_group" in entry && entry._group) {
			const groupMw = [...parentMiddlewares, ...entry.middlewares ?? []];
			result.push(...collectToolEntries(entry.commands, path, groupMw));
		} else {
			const mcp = entry.mcp === false ? void 0 : entry.mcp;
			const outputSchema = entry.output ? mcpOutputSchema(entry.output) : void 0;
			result.push({
				name: mcp?.name ?? path.join("_"),
				description: mcp?.description ?? entry.description,
				inputSchema: buildToolSchema(entry.args, entry.options),
				...outputSchema ? { outputSchema } : void 0,
				...mcp?.annotations ? { annotations: mcp.annotations } : void 0,
				...mcp?.instructions ? { instructions: mcp.instructions } : void 0,
				command: entry,
				...parentMiddlewares.length > 0 ? { middlewares: parentMiddlewares } : void 0
			});
		}
	}
	return result;
}
/** Filters MCP tools by include and exclude patterns. */
function filterTools(tools, filter) {
	if (!filter) return tools;
	const includes = filter.include?.map(patternToRegExp);
	const excludes = filter.exclude?.map(patternToRegExp) ?? [];
	return tools.filter((tool) => {
		if (excludes.some((pattern) => pattern.test(tool.name))) return false;
		if (!includes || includes.length === 0) return true;
		return includes.some((pattern) => pattern.test(tool.name));
	});
}
function patternToRegExp(pattern) {
	const escaped = pattern.replace(/[|\\{}()[\]^$+?.]/g, "\\$&").replace(/\*/g, ".*");
	return new RegExp(`^${escaped}$`);
}
function assertUniqueToolNames(tools) {
	const seen = /* @__PURE__ */ new Set();
	for (const tool of tools) {
		if (seen.has(tool.name)) throw new Error(`Duplicate MCP tool name: ${tool.name}`);
		seen.add(tool.name);
	}
}
function mcpOutputSchema(output) {
	const schema = toJsonSchema(output);
	if (schema.type === "object") return schema;
}
/** @internal Builds a merged JSON Schema from args and options Zod schemas. */
function buildToolSchema(args, options) {
	const properties = {};
	const required = [];
	for (const schema of [args, options]) {
		if (!schema) continue;
		const json = toJsonSchema(schema);
		Object.assign(properties, json.properties ?? {});
		required.push(...json.required ?? []);
	}
	if (required.length > 0) return {
		type: "object",
		properties,
		required
	};
	return {
		type: "object",
		properties
	};
}
//#endregion
//#region ../../node_modules/.pnpm/incur@0.4.26/node_modules/incur/dist/internal/dereference.js
/**
* Dereferences all local `$ref` pointers in a JSON object (e.g. `{"$ref": "#/components/schemas/User"}`),
* replacing them inline with the resolved values. Only handles local (`#/...`) references.
*
* Handles circular references by caching a mutable placeholder before recursing.
*
* Minimal reimplementation of the dereferencing behavior from `@apidevtools/json-schema-ref-parser`
* (https://github.com/APIDevTools/json-schema-ref-parser). Only supports in-memory, local-pointer
* resolution — no file/URL resolution, no `$id` scoping.
*/
function dereference(root) {
	return walk$2(root, root, /* @__PURE__ */ new Map());
}
function walk$2(node, root, cache) {
	if (Array.isArray(node)) return node.map((item) => walk$2(item, root, cache));
	if (typeof node !== "object" || node === null) return node;
	const obj = node;
	if (typeof obj.$ref === "string" && obj.$ref.startsWith("#")) {
		const ref = obj.$ref;
		if (cache.has(ref)) return cache.get(ref);
		const resolved = resolvePointer(root, ref);
		if (typeof resolved !== "object" || resolved === null || Array.isArray(resolved)) {
			const dereferenced = walk$2(resolved, root, cache);
			cache.set(ref, dereferenced);
			return dereferenced;
		}
		const placeholder = {};
		cache.set(ref, placeholder);
		const dereferenced = walk$2(resolved, root, cache);
		if (typeof dereferenced !== "object" || dereferenced === null || Array.isArray(dereferenced)) {
			cache.set(ref, dereferenced);
			return dereferenced;
		}
		Object.assign(placeholder, dereferenced);
		return placeholder;
	}
	const result = {};
	for (const key of Object.keys(obj)) result[key] = walk$2(obj[key], root, cache);
	return result;
}
/** Resolves a JSON Pointer (e.g. `#/components/schemas/User`) against a root object. */
function resolvePointer(root, pointer) {
	const fragment = pointer.slice(1);
	if (fragment === "" || fragment === "/") return root;
	const parts = fragment.slice(1).split("/").map((p) => p.replace(/~1/g, "/").replace(/~0/g, "~"));
	let current = root;
	for (const part of parts) {
		if (typeof current !== "object" || current === null) throw new Error(`Cannot resolve $ref "${pointer}": path segment "${part}" not found`);
		current = current[part];
		if (current === void 0) throw new Error(`Cannot resolve $ref "${pointer}": "${part}" not found`);
	}
	return current;
}
//#endregion
//#region ../../node_modules/.pnpm/incur@0.4.26/node_modules/incur/dist/Openapi.js
/** Generates an OpenAPI 3.2 document from an incur CLI's command tree. */
function fromCli(cli, options = {}) {
	const commands = toCommands.get(cli);
	if (!commands) throw new Error("No commands registered on this CLI instance");
	const paths = {};
	const root = toRootDefinition.get(cli);
	if (root) addCommand(paths, [], root);
	for (const [name, entry] of commands) addEntry(paths, splitCommandName(name), entry);
	return {
		openapi: "3.2.0",
		info: {
			title: options.title ?? cli.name,
			version: options.version ?? "0.0.0",
			...options.description ?? cli.description ? { description: options.description ?? cli.description } : void 0
		},
		...options.servers ? { servers: options.servers } : void 0,
		paths
	};
}
function addEntry(paths, segments, entry) {
	if ("_alias" in entry) return;
	if ("_fetch" in entry) return;
	if ("_group" in entry) {
		for (const [name, child] of entry.commands) addEntry(paths, [...segments, ...splitCommandName(name)], child);
		return;
	}
	addCommand(paths, segments, entry);
}
function splitCommandName(name) {
	return name.split(/\s+/).filter(Boolean);
}
function addCommand(paths, segments, command) {
	const argsSchema = command.args ? toJsonSchema(command.args) : void 0;
	const optionsSchema = command.options ? toJsonSchema(command.options) : void 0;
	const outputSchema = command.output ? toJsonSchema(command.output) : void 0;
	const args = objectProperties(argsSchema);
	const requiredArgs = new Set(requiredProperties(argsSchema));
	const method = inferMethod(segments);
	const pathVariants = createPathVariants(segments, args, requiredArgs);
	for (const variant of pathVariants) {
		const parameters = [];
		for (const name of variant.args) {
			const schema = args[name] ?? { type: "string" };
			parameters.push({
				name,
				in: "path",
				required: true,
				schema
			});
		}
		if (method === "get" || method === "delete") for (const [name, schema] of Object.entries(objectProperties(optionsSchema))) parameters.push({
			name,
			in: "query",
			...requiredProperties(optionsSchema).includes(name) ? { required: true } : void 0,
			schema
		});
		const operation = {
			operationId: operationId(segments, method, variant.args),
			...command.description ? { summary: command.description } : void 0,
			...parameters.length ? { parameters } : void 0,
			...requestBody(method, optionsSchema),
			responses: responses(outputSchema)
		};
		const item = paths[variant.path] ?? {};
		item[method] = operation;
		paths[variant.path] = item;
	}
}
function createPathVariants(segments, args, requiredArgs) {
	const names = Object.keys(args);
	const requiredCount = names.findIndex((name) => !requiredArgs.has(name));
	const baseCount = requiredCount === -1 ? names.length : requiredCount;
	const variants = [];
	for (let count = baseCount; count <= names.length; count++) {
		const included = names.slice(0, count);
		const suffix = included.map((name) => `{${name}}`);
		variants.push({
			args: included,
			path: `/${[...segments, ...suffix].map(encodePathSegment).join("/")}`
		});
	}
	if (variants.length === 0) variants.push({
		args: [],
		path: `/${segments.map(encodePathSegment).join("/")}`
	});
	return variants;
}
function inferMethod(segments) {
	const text = segments.map(splitCamelCase).join(" ").toLowerCase();
	if (/\b(delete|remove|rm|destroy|clear)\b/.test(text)) return "delete";
	if (/\b(update|edit|modify|set|enable|disable|rename|patch)\b/.test(text)) return "patch";
	if (/\b(get|list|show|read|search|find|status|describe|info|health|check)\b/.test(text)) return "get";
	return "post";
}
function splitCamelCase(value) {
	return value.replace(/([a-z0-9])([A-Z])/g, "$1 $2");
}
function requestBody(method, schema) {
	if (!schema || method === "get" || method === "delete") return {};
	return { requestBody: {
		required: requiredProperties(schema).length > 0,
		content: { "application/json": { schema } }
	} };
}
function responses(schema) {
	return {
		"200": {
			description: "Command completed successfully.",
			content: { "application/json": { schema: {
				type: "object",
				required: [
					"ok",
					"data",
					"meta"
				],
				properties: {
					ok: { const: true },
					data: schema ?? {},
					meta: metaSchema()
				}
			} } }
		},
		"400": errorResponse("Validation error."),
		"500": errorResponse("Command failed.")
	};
}
function errorResponse(description) {
	return {
		description,
		content: { "application/json": { schema: {
			type: "object",
			required: [
				"ok",
				"error",
				"meta"
			],
			properties: {
				ok: { const: false },
				error: {
					type: "object",
					required: ["code", "message"],
					properties: {
						code: { type: "string" },
						message: { type: "string" },
						retryable: { type: "boolean" }
					}
				},
				meta: metaSchema()
			}
		} } }
	};
}
function metaSchema() {
	return {
		type: "object",
		required: ["command", "duration"],
		properties: {
			command: { type: "string" },
			duration: { type: "string" }
		}
	};
}
function objectProperties(schema) {
	return schema?.properties ?? {};
}
function requiredProperties(schema) {
	return schema?.required ?? [];
}
function operationId(segments, method, args) {
	return `${method}${[...segments, ...args.length ? [args.join(" ")] : []].join(" ").replace(/(?:^|[\s_-]+)(\w)/g, (_, char) => char.toUpperCase())}`;
}
function encodePathSegment(segment) {
	if (segment.startsWith("{") && segment.endsWith("}")) return segment;
	return encodeURIComponent(segment);
}
/** Resolves an OpenAPI document from a JSON object or JSON URL. */
async function resolve$2(source, options = {}) {
	if (typeof source !== "string" && !(source instanceof URL)) return source;
	const response = await fetch(resolveUrl(source, options.baseUrl));
	if (!response.ok) throw new Error(`Failed to fetch OpenAPI spec from ${source}: ${response.status}`);
	return await response.json();
}
function resolveUrl(source, baseUrl) {
	if (source instanceof URL) return source;
	try {
		return new URL(source);
	} catch {
		if (baseUrl === void 0) throw new Error(`Relative OpenAPI spec URL requires a fetch URL base: ${source}`);
		const base = new URL(baseUrl);
		if (!base.pathname.endsWith("/")) base.pathname = `${base.pathname}/`;
		return new URL(source, base);
	}
}
/** Generates incur command entries from an OpenAPI spec. Resolves all `$ref` pointers. */
async function generateCommands$1(spec, fetch, options = {}) {
	const resolved = dereference(structuredClone(spec));
	const commands = /* @__PURE__ */ new Map();
	const operations = openapiOperations(resolved.paths ?? {});
	const namespaceInfo = getNamespaceInfo(operations);
	const { config } = options;
	if (config?.compact) compactOperations(operations);
	for (const { method, operation: op, path } of operations) {
		const segments = commandSegments({
			method,
			mode: config?.mode ?? "operation",
			namespaceInfo,
			operation: op,
			path
		});
		const httpMethod = method.toUpperCase();
		const pathParams = (op.parameters ?? []).filter((p) => p.in === "path");
		const queryParams = (op.parameters ?? []).filter((p) => p.in === "query");
		const headerParams = headerOptions([...(op.parameters ?? []).filter((p) => p.in === "header"), ...config?.security === false ? [] : securityHeaderParams(resolved, op)]);
		const bodySchema = op.requestBody?.content?.["application/json"]?.schema;
		const bodyProps = bodySchema?.properties ?? {};
		const bodyRequired = new Set(bodySchema?.required ?? []);
		let argsSchema;
		if (pathParams.length > 0) {
			const shape = {};
			for (const p of pathParams) {
				let zodType = p.schema ? toZod(p.schema) : string();
				if (p.description) zodType = zodType.describe(p.description);
				shape[p.name] = coerceIfNeeded(zodType);
			}
			argsSchema = object(shape);
		}
		const optShape = {};
		const usedOptionNames = /* @__PURE__ */ new Set();
		for (const p of queryParams) {
			let zodType = p.schema ? toZod(p.schema) : string();
			if (!p.required) zodType = zodType.optional();
			if (p.description) zodType = zodType.describe(p.description);
			optShape[p.name] = coerceIfNeeded(zodType);
			usedOptionNames.add(p.name);
		}
		for (const [key, schema] of Object.entries(bodyProps)) {
			let zodType = toZod(schema);
			if (!bodyRequired.has(key)) zodType = zodType.optional();
			optShape[key] = zodType;
			usedOptionNames.add(key);
		}
		for (const p of headerParams) {
			const optionName = resolveHeaderOptionName(p.optionName, usedOptionNames);
			p.optionName = optionName;
			let zodType = p.schema ? toZod(p.schema) : string();
			if (!p.required) zodType = zodType.optional();
			zodType = zodType.describe(p.description ?? `${p.name} header`);
			optShape[optionName] = coerceIfNeeded(zodType);
			usedOptionNames.add(optionName);
		}
		const optionsSchema = Object.keys(optShape).length > 0 ? object(optShape) : void 0;
		setCommand(commands, segments, {
			description: op.summary ?? op.description,
			mcp: {
				annotations: mcpAnnotations(method),
				...op.summary && op.description && op.summary !== op.description ? { description: `${op.summary}\n\n${op.description}` } : void 0
			},
			args: argsSchema,
			options: optionsSchema,
			run: createHandler({
				basePath: options.basePath,
				fetch,
				forwardHeaders: config?.forwardHeaders,
				httpMethod,
				path,
				headerParams,
				pathParams,
				queryParams,
				bodyProps
			})
		});
	}
	return commands;
}
function mcpAnnotations(method) {
	const readOnly = [
		"get",
		"head",
		"options",
		"trace"
	].includes(method);
	return {
		destructiveHint: !readOnly,
		idempotentHint: readOnly || method === "delete" || method === "put",
		openWorldHint: true,
		readOnlyHint: readOnly
	};
}
var openapiMethods = /* @__PURE__ */ new Set([
	"delete",
	"get",
	"head",
	"options",
	"patch",
	"post",
	"put",
	"trace"
]);
function openapiOperations(paths) {
	const operations = [];
	for (const [path, methods] of Object.entries(paths)) for (const [method, operation] of Object.entries(methods)) if (openapiMethods.has(method)) operations.push({
		method,
		operation,
		path
	});
	return operations;
}
function securityHeaderParams(spec, operation) {
	const schemes = spec.components?.securitySchemes ?? {};
	const requirements = operation.security ?? spec.security ?? [];
	const headers = [];
	for (const requirement of requirements) for (const name of Object.keys(requirement)) {
		const scheme = schemes[name];
		const parameter = securityHeaderParam(name, scheme);
		if (parameter) headers.push(parameter);
	}
	return headers;
}
function securityHeaderParam(name, scheme) {
	if (!scheme) return void 0;
	if (scheme.type === "apiKey" && scheme.in === "header" && scheme.name) return {
		description: scheme.description ?? `${scheme.name} header`,
		in: "header",
		name: scheme.name,
		required: false,
		schema: { type: "string" }
	};
	if (scheme.type === "http" && authorizationSchemes.has(scheme.scheme?.toLowerCase() ?? "")) return {
		description: scheme.description ?? `${name} authorization header`,
		in: "header",
		name: "authorization",
		required: false,
		schema: { type: "string" }
	};
}
var authorizationSchemes = /* @__PURE__ */ new Set(["basic", "bearer"]);
/** Patterns longer than this are dropped by `compact`; oversized regexes add schema bytes without helping callers. */
var compactPatternLimit = 100;
/** String formats zod serializes back into oversized regex patterns. */
var dateTimeFormats = /* @__PURE__ */ new Set([
	"date",
	"date-time",
	"duration",
	"time"
]);
/** Rewrites operation parameter and request-body schemas with `compactSchema` in place. */
function compactOperations(operations) {
	for (const { operation } of operations) {
		for (const parameter of operation.parameters ?? []) if (parameter.schema) parameter.schema = compactSchema(parameter.schema);
		const body = operation.requestBody?.content?.["application/json"];
		if (body?.schema) body.schema = compactSchema(body.schema);
	}
}
/** Returns a copy stripped of `example(s)` and oversized `pattern` regexes; drops subschemas emptied by stripping. */
function compactSchema(schema, seen = /* @__PURE__ */ new Map()) {
	const cached = seen.get(schema);
	if (cached) return cached;
	const out = { ...schema };
	seen.set(schema, out);
	delete out.example;
	delete out.examples;
	if (typeof out.pattern === "string" && out.pattern.length > compactPatternLimit) delete out.pattern;
	if (typeof out.format === "string" && dateTimeFormats.has(out.format)) delete out.format;
	for (const key of [
		"allOf",
		"anyOf",
		"oneOf",
		"prefixItems"
	]) {
		if (!Array.isArray(out[key])) continue;
		const entries = out[key].map((entry) => compactSchema(entry, seen)).filter((entry) => Object.keys(entry).length > 0);
		if (entries.length > 0) out[key] = entries;
		else delete out[key];
	}
	for (const key of [
		"additionalProperties",
		"contains",
		"items",
		"not",
		"propertyNames"
	]) {
		const value = out[key];
		if (isSchemaObject(value)) out[key] = compactSchema(value, seen);
	}
	for (const key of [
		"$defs",
		"patternProperties",
		"properties"
	]) {
		const value = out[key];
		if (!isSchemaObject(value)) continue;
		const map = {};
		for (const [name, entry] of Object.entries(value)) map[name] = isSchemaObject(entry) ? compactSchema(entry, seen) : entry;
		out[key] = map;
	}
	return out;
}
function isSchemaObject(value) {
	return typeof value === "object" && value !== null && !Array.isArray(value);
}
function headerOptions(parameters) {
	const seen = /* @__PURE__ */ new Set();
	const headers = [];
	for (const parameter of parameters) {
		const normalized = parameter.name.toLowerCase();
		if (seen.has(normalized)) continue;
		seen.add(normalized);
		headers.push({
			...parameter,
			optionName: normalized
		});
	}
	return headers;
}
function resolveHeaderOptionName(optionName, used) {
	if (!used.has(optionName)) return optionName;
	const prefix = `header-${optionName}`;
	if (!used.has(prefix)) return prefix;
	for (let index = 2;; index++) {
		const candidate = `${prefix}-${index}`;
		if (!used.has(candidate)) return candidate;
	}
}
function getNamespaceInfo(operations) {
	const pathOperations = /* @__PURE__ */ new Map();
	const parentPaths = /* @__PURE__ */ new Set();
	for (const { path } of operations) {
		pathOperations.set(path, (pathOperations.get(path) ?? 0) + 1);
		const segments = namespaceNames(path);
		for (let i = 1; i < segments.length; i++) parentPaths.add(`/${segments.slice(0, i).join("/")}`);
	}
	return {
		parentPaths,
		pathOperations
	};
}
function commandSegments(options) {
	const { method, mode, namespaceInfo, operation, path } = options;
	if (mode === "operation") return [{ name: operation.operationId ?? `${method}_${path.replace(/[/{}]/g, "_")}` }];
	const segments = namespaceSegments(path, operation);
	const needsMethod = segments.length === 0 || namespaceInfo.parentPaths.has(namespacePath(path)) || (namespaceInfo.pathOperations.get(path) ?? 0) > 1;
	const describedSegments = describeNamespaceLeaf(segments, operation.summary ?? operation.description);
	return [...describedSegments.length > 0 ? describedSegments : [{ name: "root" }], ...needsMethod ? [{ name: method }] : []];
}
function namespaceSegments(path, operation) {
	return path.split("/").map((segment) => namespaceSegment(segment, operation)).filter(isCommandSegment);
}
function namespaceNames(path) {
	return namespaceSegments(path).map((segment) => segment.name);
}
function namespacePath(path) {
	return `/${namespaceNames(path).join("/")}`;
}
function namespaceSegment(segment, operation) {
	if (!segment) return void 0;
	const name = segment.startsWith("{") && segment.endsWith("}") ? segment.slice(1, -1) : segment;
	const description = operation?.parameters?.find((parameter) => parameter.in === "path" && parameter.name === name)?.description;
	return {
		...description ? { description } : void 0,
		name: name.replace(/[^\w.-]+/g, "-")
	};
}
function isCommandSegment(segment) {
	return segment !== void 0;
}
function describeNamespaceLeaf(segments, description) {
	if (!description || segments.length === 0) return segments;
	return segments.map((segment, index) => index === segments.length - 1 && !segment.description ? {
		...segment,
		description
	} : segment);
}
function setCommand(commands, segments, command) {
	const [head, ...tail] = segments;
	if (!head) return;
	if (tail.length === 0) {
		commands.set(head.name, command);
		return;
	}
	setCommand(getGroup(commands, head).commands, tail, command);
}
function getGroup(commands, segment) {
	const existing = commands.get(segment.name);
	if (existing && "_group" in existing) {
		if (!existing.description && segment.description) existing.description = segment.description;
		return existing;
	}
	const group = {
		_group: true,
		commands: /* @__PURE__ */ new Map(),
		...segment.description ? { description: segment.description } : void 0
	};
	commands.set(segment.name, group);
	return group;
}
function createHandler(config) {
	return async (context) => {
		const { args = {}, options = {} } = context;
		let urlPath = (config.basePath ?? "") + config.path;
		for (const p of config.pathParams) {
			const value = args[p.name];
			if (value !== void 0) urlPath = urlPath.replace(`{${p.name}}`, String(value));
		}
		const query = new URLSearchParams();
		for (const p of config.queryParams) {
			const value = options[p.name];
			if (value !== void 0) query.set(p.name, String(value));
		}
		let body;
		const bodyKeys = Object.keys(config.bodyProps);
		if (bodyKeys.length > 0) {
			const bodyObj = {};
			for (const key of bodyKeys) if (options[key] !== void 0) bodyObj[key] = options[key];
			if (Object.keys(bodyObj).length > 0) body = JSON.stringify(bodyObj);
		}
		const input = {
			path: urlPath,
			method: config.httpMethod,
			headers: new Headers(),
			body,
			query
		};
		for (const p of config.headerParams) {
			const value = options[p.optionName];
			if (value !== void 0) input.headers.set(p.name, String(value));
		}
		for (const name of config.forwardHeaders ?? []) {
			const value = context.request?.headers.get(name);
			if (!input.headers.has(name) && value !== null && value !== void 0) input.headers.set(name, value);
		}
		if (body && !input.headers.has("content-type")) input.headers.set("content-type", "application/json");
		const request = buildRequest$1(input);
		const output = await parseResponse(await config.fetch(request));
		if (!output.ok) return context.error({
			code: `HTTP_${output.status}`,
			message: typeof output.data === "object" && output.data !== null && "message" in output.data ? String(output.data.message) : typeof output.data === "string" ? output.data : `HTTP ${output.status}`
		});
		return output.data;
	};
}
/** Converts a JSON Schema object to a Zod schema. */
function toZod(schema) {
	return fromJSONSchema(schema);
}
/** Wraps a Zod schema with coercion if the base type is number or boolean (argv is always strings). */
function coerceIfNeeded(schema) {
	const isOptional = schema instanceof ZodOptional;
	const inner = isOptional ? schema.unwrap() : schema;
	const coerced = (() => {
		if (inner instanceof ZodNumber) return isOptional ? number$1().optional() : number$1();
		if (inner instanceof ZodBoolean) return isOptional ? boolean$1().optional() : boolean$1();
		if (inner instanceof ZodUnion) {
			const options = inner._zod?.def?.options;
			if (options?.some((o) => o instanceof ZodNumber)) return isOptional ? number$1().optional() : number$1();
			if (options?.some((o) => o instanceof ZodBoolean)) return isOptional ? boolean$1().optional() : boolean$1();
		}
	})();
	if (!coerced) return schema;
	const desc = schema.description ?? inner.description;
	return desc ? coerced.describe(desc) : coerced;
}
//#endregion
//#region ../../node_modules/.pnpm/incur@0.4.26/node_modules/incur/dist/McpSource.js
var protocolVersion = "2025-06-18";
/** Resolves a remote MCP server by initializing it and listing its tools. */
async function resolve$1(source, options = {}) {
	const session = sourceSession(source);
	await request(session, "initialize", {
		protocolVersion,
		capabilities: {},
		clientInfo: {
			name: "incur",
			version: options.version ?? "1.0.0"
		}
	});
	session.initialized = true;
	await request(session, "notifications/initialized");
	const listed = (await request(session, "tools/list")).tools ?? [];
	if (isProgressiveCatalog(listed)) return {
		discovery: "progressive",
		tools: await discoverTools(session),
		session
	};
	return {
		tools: listed,
		session
	};
}
/** Generates incur command entries from remote MCP tools. */
function generateCommands(resolved) {
	const commands = /* @__PURE__ */ new Map();
	for (const tool of resolved.tools) {
		const options = tool.inputSchema ? inputOptions(tool.inputSchema) : void 0;
		const output = outputSchema(tool.outputSchema);
		commands.set(tool.name, {
			description: tool.description,
			...tool.annotations ? { mcp: { annotations: tool.annotations } } : void 0,
			...options ? { options } : void 0,
			...output ? { output } : void 0,
			async run(context) {
				const parameters = {
					name: tool.name,
					arguments: {
						...context.args,
						...context.options
					}
				};
				const result = await request(resolved.session, "tools/call", resolved.discovery === "progressive" ? {
					name: tool.annotations?.readOnlyHint === true ? "call_read_tool" : "call_write_tool",
					arguments: parameters
				} : parameters);
				if (result.isError) return context.error({
					code: "MCP_TOOL_ERROR",
					message: resultText(result)
				});
				return resultValue(result);
			}
		});
	}
	return commands;
}
function isProgressiveCatalog(tools) {
	if (tools.length !== 4) return false;
	const names = new Set(tools.map((tool) => tool.name));
	return names.has("search_tools") && names.has("get_tool_details") && names.has("call_read_tool") && names.has("call_write_tool");
}
async function discoverTools(session) {
	const tools = [];
	let offset = 0;
	while (offset !== void 0) {
		const search = await callRemoteTool(session, "search_tools", {
			query: "",
			limit: 20,
			offset
		});
		for (const match of search.tools ?? []) {
			if (!match.name) continue;
			const tool = await callRemoteTool(session, "get_tool_details", { name: match.name });
			if (tool.name) tools.push(tool);
		}
		if (search.nextOffset !== void 0 && search.nextOffset <= offset) throw new Error("MCP tool catalog returned a non-advancing offset");
		offset = search.nextOffset;
	}
	return tools;
}
async function callRemoteTool(session, name, arguments_) {
	const result = await request(session, "tools/call", {
		name,
		arguments: arguments_
	});
	if (result.isError) throw new Error(resultText(result) || `MCP tool failed: ${name}`);
	return resultValue(result);
}
function sourceSession(source) {
	if (typeof source === "string" || source instanceof URL) return {
		url: new URL(source),
		fetch: globalThis.fetch.bind(globalThis)
	};
	return {
		url: new URL(source.url),
		fetch: source.fetch ?? globalThis.fetch.bind(globalThis),
		...source.headers ? { headers: source.headers } : void 0
	};
}
async function request(session, method, params) {
	const notification = method.startsWith("notifications/");
	const id = notification ? void 0 : crypto.randomUUID();
	const headers = new Headers(session.headers);
	headers.set("content-type", "application/json");
	headers.set("accept", "application/json, text/event-stream");
	if (session.id) headers.set("mcp-session-id", session.id);
	if (session.initialized) headers.set("MCP-Protocol-Version", protocolVersion);
	const body = JSON.stringify({
		jsonrpc: "2.0",
		...id ? { id } : void 0,
		method,
		params
	});
	const response = await session.fetch(new Request(session.url, {
		method: "POST",
		headers,
		body
	}));
	const sessionId = response.headers.get("mcp-session-id");
	if (sessionId) session.id = sessionId;
	if (!response.ok) throw new Error(`MCP HTTP ${response.status}`);
	if (notification && response.status === 202) return {};
	const text = await response.text();
	if (!text) return {};
	const message = (response.headers.get("content-type") ?? "").includes("text/event-stream") ? parseSse(text, id) : JSON.parse(text);
	if (message.error) throw new Error(message.error.message ?? "MCP request failed");
	return message.result ?? {};
}
function parseSse(text, id) {
	for (const event of text.split(/\r?\n\r?\n/)) {
		const data = event.split(/\r?\n/).filter((line) => line.startsWith("data:")).map((line) => line.slice(5).trimStart()).join("\n");
		if (!data) continue;
		const message = JSON.parse(data);
		if (id === void 0 || message.id === id) return message;
	}
	throw new Error("MCP SSE response did not include the matching JSON-RPC message");
}
function inputOptions(schema) {
	const properties = schema.properties ?? {};
	const required = new Set(schema.required ?? []);
	const shape = {};
	for (const [key, property] of Object.entries(properties)) {
		let zodType = toZod(property);
		if (!required.has(key)) zodType = zodType.optional();
		if (typeof property.description === "string") zodType = zodType.describe(property.description);
		shape[key] = coerceIfNeeded(zodType);
	}
	return Object.keys(shape).length > 0 ? object(shape) : void 0;
}
function outputSchema(schema) {
	if (!schema || schema.type !== "object") return void 0;
	try {
		return fromJSONSchema(schema);
	} catch {
		return;
	}
}
function resultText(result) {
	return (Array.isArray(result.content) ? result.content : []).map((item) => item.type === "text" ? item.text : "").filter(Boolean).join("\n");
}
function resultValue(result) {
	if (result.structuredContent !== void 0) return result.structuredContent;
	const textItems = (Array.isArray(result.content) ? result.content : []).filter((item) => item.type === "text").map((item) => item.text);
	if (textItems.length === 1) try {
		return JSON.parse(textItems[0]);
	} catch {
		return textItems[0];
	}
	return textItems;
}
//#endregion
//#region ../../node_modules/.pnpm/incur@0.4.26/node_modules/incur/dist/Skill.js
/** Generates a compact Markdown command index for `--llms`. */
function index(name, commands, description) {
	const lines = [`# ${name}`];
	if (description) lines.push("", description);
	lines.push("");
	lines.push("| Command | Description |");
	lines.push("|---------|-------------|");
	for (const cmd of commands) {
		const signature = buildSignature(name, cmd);
		const desc = cmd.description ?? "";
		lines.push(`| \`${signature}\` | ${desc} |`);
	}
	lines.push("", `Run \`${name} --llms-full\` for full manifest. Run \`${name} <command> --schema\` for argument details.`);
	return lines.join("\n");
}
/** @internal Builds a command signature with arg placeholders. */
function buildSignature(cli, cmd) {
	const base = !cmd.name ? cli : `${cli} ${cmd.name}`;
	if (!cmd.args) return base;
	const shape = cmd.args.shape;
	const json = toJsonSchema(cmd.args);
	const required = new Set(json.required ?? []);
	const properties = json.properties;
	return `${base} ${Object.keys(shape).map((k) => {
		const label = properties?.[k]?.type === "array" ? `${k}...` : k;
		return required.has(k) ? `<${label}>` : `[${label}]`;
	}).join(" ")}`;
}
/** Generates a Markdown skill file from a CLI name and collected command data. */
function generate(name, commands, groups = /* @__PURE__ */ new Map()) {
	if (!(groups.size > 0)) return commands.map((cmd) => renderCommandBody(name, cmd)).join("\n\n");
	const sections = [`# ${name}`];
	let lastGroup;
	for (const cmd of commands) {
		const segment = !cmd.name ? "" : cmd.name.split(" ")[0];
		if (segment !== lastGroup) {
			lastGroup = segment;
			if (segment) {
				const desc = groups.get(segment);
				const heading = desc ? `## ${name} ${segment}\n\n${desc}` : `## ${name} ${segment}`;
				sections.push(heading);
			}
		}
		sections.push(renderCommandBody(name, cmd, segment ? 3 : 2));
	}
	return sections.join("\n\n");
}
/** Splits commands into skill files grouped by depth. */
function split(name, commands, depth, groups = /* @__PURE__ */ new Map()) {
	if (depth === 0) return [{
		dir: "",
		content: renderGroup(name, name, commands, groups, name)
	}];
	const buckets = /* @__PURE__ */ new Map();
	for (const cmd of commands) {
		if (!cmd.name) {
			const key = slugify(name);
			const bucket = buckets.get(key) ?? [];
			bucket.push(cmd);
			buckets.set(key, bucket);
			continue;
		}
		const key = cmd.name.split(" ").slice(0, depth).join("-");
		const bucket = buckets.get(key) ?? [];
		bucket.push(cmd);
		buckets.set(key, bucket);
	}
	return [...buckets.entries()].sort(([a], [b]) => a.localeCompare(b)).map(([dir, cmds]) => {
		const first = cmds[0];
		const prefix = !first.name ? "" : first.name.split(" ").slice(0, depth).join(" ");
		return {
			dir,
			content: renderGroup(name, prefix ? `${name} ${prefix}` : name, cmds, groups, prefix || void 0)
		};
	});
}
/** @internal Renders a group-level frontmatter + command bodies. */
function renderGroup(cli, title, cmds, groups, prefix) {
	const groupDesc = prefix ? groups.get(prefix) : void 0;
	const fallbackDesc = cmds.length === 1 && cmds[0].description ? cmds[0].description : void 0;
	const desc = groupDesc ?? fallbackDesc;
	const description = desc ? `${desc.replace(/\.$/, "")}. Run \`${title} --help\` for usage details.` : `Run \`${title} --help\` for usage details.`;
	return `${`---\n${loadSync().stringify({
		name: slugify(title),
		description,
		requires_bin: cli,
		command: title
	}, { lineWidth: 0 }).trimEnd()}\n---`}\n\n${cmds.map((cmd) => renderCommandBody(cli, cmd)).join("\n\n---\n\n")}`;
}
/** @internal Renders a command's heading and sections without frontmatter. */
function renderCommandBody(cli, cmd, level = 1) {
	const fullName = !cmd.name ? cli : `${cli} ${cmd.name}`;
	const sections = [];
	const h = (n) => "#".repeat(n);
	let heading = `${h(level)} ${fullName}`;
	if (cmd.description) heading += `\n\n${cmd.description}`;
	sections.push(heading);
	const sub = h(level + 1);
	if (cmd.args) {
		const shape = cmd.args.shape;
		const json = toJsonSchema(cmd.args);
		const required = new Set(json.required ?? []);
		const properties = json.properties;
		const rows = Object.entries(shape).map(([key, field]) => {
			const prop = properties?.[key];
			return `| \`${key}\` | \`${resolveTypeName(prop)}\` | ${required.has(key) ? "yes" : "no"} | ${field.description ?? ""} |`;
		});
		sections.push(`${sub} Arguments\n\n| Name | Type | Required | Description |\n|------|------|----------|-------------|\n${rows.join("\n")}`);
	}
	if (cmd.env) {
		const shape = cmd.env.shape;
		const json = toJsonSchema(cmd.env);
		const required = new Set(json.required ?? []);
		const properties = json.properties;
		const rows = Object.entries(shape).map(([key, field]) => {
			const prop = properties?.[key];
			const type = resolveTypeName(prop);
			const def = prop?.default !== void 0 ? String(prop.default) : "";
			const req = required.has(key) ? "yes" : "no";
			const desc = field.description ?? "";
			return `| \`${key}\` | \`${type}\` | ${req} | ${def ? `\`${def}\`` : ""} | ${desc} |`;
		});
		sections.push(`${sub} Environment Variables\n\n| Name | Type | Required | Default | Description |\n|------|------|----------|---------|-------------|\n${rows.join("\n")}`);
	}
	if (cmd.options) {
		const shape = cmd.options.shape;
		const properties = toJsonSchema(cmd.options).properties;
		const rows = Object.entries(shape).map(([key, field]) => {
			const prop = properties?.[key];
			const type = resolveTypeName(prop);
			const def = prop?.default !== void 0 ? String(prop.default) : "";
			const rawDesc = field.description ?? "";
			const desc = prop?.deprecated ? `**Deprecated.** ${rawDesc}` : rawDesc;
			return `| \`--${key}\` | \`${type}\` | ${def ? `\`${def}\`` : ""} | ${desc} |`;
		});
		sections.push(`${sub} Options\n\n| Flag | Type | Default | Description |\n|------|------|---------|-------------|\n${rows.join("\n")}`);
	}
	if (cmd.output) {
		const outputSchema = toJsonSchema(cmd.output);
		const table = schemaToTable(outputSchema);
		if (table) sections.push(`${sub} Output\n\n${table}`);
		else {
			const type = resolveTypeName(outputSchema);
			sections.push(`${sub} Output\n\nType: \`${type}\``);
		}
	}
	if (cmd.examples && cmd.examples.length > 0) {
		const lines = cmd.examples.map((ex) => {
			return `${ex.description ? `# ${ex.description}\n` : ""}${cli} ${ex.command}`;
		});
		sections.push(`${sub} Examples\n\n\`\`\`sh\n${lines.join("\n\n")}\n\`\`\``);
	}
	if (cmd.hint) sections.push(`> ${cmd.hint}`);
	return sections.join("\n\n");
}
/** Computes a deterministic hash of command structure for staleness detection. */
function hash(commands) {
	const data = commands.map((cmd) => ({
		name: cmd.name,
		description: cmd.description,
		hint: cmd.hint,
		args: cmd.args ? toJsonSchema(cmd.args) : void 0,
		env: cmd.env ? toJsonSchema(cmd.env) : void 0,
		options: cmd.options ? toJsonSchema(cmd.options) : void 0,
		output: cmd.output ? toJsonSchema(cmd.output) : void 0
	}));
	return createHash("sha256").update(JSON.stringify(data)).digest("hex").slice(0, 16);
}
/** @internal Renders a JSON Schema object as a Markdown table. Returns `undefined` for non-object schemas. */
function schemaToTable(schema, prefix = "") {
	if (schema.type !== "object") return void 0;
	const properties = schema.properties;
	if (!properties || Object.keys(properties).length === 0) return void 0;
	const required = new Set(schema.required ?? []);
	const rows = [];
	for (const [key, prop] of Object.entries(properties)) {
		const name = prefix ? `${prefix}.${key}` : key;
		const type = resolveTypeName(prop);
		const req = required.has(key) ? "yes" : "no";
		const desc = prop.description ?? "";
		rows.push(`| \`${name}\` | \`${type}\` | ${req} | ${desc} |`);
		if (prop.type === "object" && prop.properties) {
			const nested = schemaToTable(prop, name);
			if (nested) {
				const lines = nested.split("\n");
				rows.push(...lines.slice(2));
			}
		}
		if (prop.type === "array" && prop.items) {
			const items = prop.items;
			if (items.type === "object" && items.properties) {
				const nested = schemaToTable(items, `${name}[]`);
				if (nested) {
					const lines = nested.split("\n");
					rows.push(...lines.slice(2));
				}
			}
		}
	}
	return `| Field | Type | Required | Description |\n|-------|------|----------|-------------|\n${rows.join("\n")}`;
}
/** @internal Converts a string to a lowercase slug (e.g. `"my-cli"` → `"my-cli"`, `"My Tool"` → `"my-tool"`). */
function slugify(s) {
	return s.toLowerCase().replace(/[^a-z0-9-]+/g, "-").replace(/-{2,}/g, "-").replace(/^-|-$/g, "");
}
/** @internal Resolves a simple type name from a JSON Schema property. */
function resolveTypeName(prop) {
	if (!prop) return "unknown";
	const type = prop.type;
	if (type) return type === "integer" ? "number" : type;
	return "unknown";
}
//#endregion
//#region ../../node_modules/.pnpm/incur@0.4.26/node_modules/incur/dist/SyncMcp.js
/** Registers the CLI as an MCP server via `npx add-mcp` and direct config writes for unsupported agents. */
async function register$3(name, options = {}) {
	const runner = detectRunner();
	const command = options.command ?? defaultCommand(options.cli ?? name, runner);
	const targetAgents = options.agents ?? [];
	const ampOnly = targetAgents.length === 1 && targetAgents[0] === "amp";
	const agents = [];
	if (!ampOnly) {
		const args = [
			command,
			"--name",
			name,
			"-y"
		];
		if (options.global !== false) args.push("-g");
		for (const agent of targetAgents.filter((a) => a !== "amp")) args.push("-a", agent);
		const [cmd, ...prefix] = runner.split(" ");
		const { stdout } = await exec(cmd, [
			...prefix,
			"add-mcp",
			...args
		]);
		agents.push(...stdout.split("\n").filter((l) => l.includes("✓") || l.includes("✔")).map((l) => l.replace(/[│┃|]/g, "").replace(/.*[✓✔]\s*/, "").replace(/:.*/, "").trim()).filter(Boolean));
	}
	if (targetAgents.length === 0 || targetAgents.includes("amp")) {
		if (registerAmp(name, command)) agents.push("Amp");
	}
	return {
		command,
		agents
	};
}
/** @internal Registers an MCP server in Amp's settings.json. */
function registerAmp(name, command) {
	const configPath = join(homedir(), ".config", "amp", "settings.json");
	let config = {};
	if (existsSync(configPath)) try {
		config = JSON.parse(readFileSync(configPath, "utf-8"));
	} catch {
		return false;
	}
	const [cmd, ...args] = splitCommand(command);
	if (!cmd) return false;
	const servers = config["amp.mcpServers"] ?? {};
	servers[name] = {
		command: cmd,
		args
	};
	config["amp.mcpServers"] = servers;
	const dir = dirname(configPath);
	if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
	writeFileSync(configPath, JSON.stringify(config, null, 2) + "\n");
	return true;
}
/** @internal Builds the default MCP command for the current launch mode. */
function defaultCommand(name, runner) {
	return shouldUseBareCommand(name) ? `${name} --mcp` : `${runner} ${detectPackageSpecifier(name)} --mcp`;
}
/** @internal Returns node_modules path details for the current entrypoint. */
function nodeModulesInfo() {
	const match = (process.argv[1]?.replace(/\\/g, "/"))?.match(/^(.+)\/node_modules\/(.+)$/);
	if (!match) return null;
	return {
		root: match[1],
		entry: match[2]
	};
}
/** @internal Uses the bare command only when the binary is expected on PATH. */
function shouldUseBareCommand(name) {
	const bin = process.argv[1];
	if (!bin) return false;
	const info = nodeModulesInfo();
	if (info) return !info.entry.startsWith(".bin/") && !packageDependsOn(info.root, name);
	const file = bin.replace(/\\/g, "/").split("/").pop();
	return file === name || file === `${name}.cmd` || file === `${name}.ps1`;
}
/** @internal Checks whether the entrypoint came from a project dependency install. */
function packageDependsOn(root, name) {
	try {
		const pkg = JSON.parse(readFileSync(join(root, "package.json"), "utf-8"));
		return [
			pkg.dependencies,
			pkg.devDependencies,
			pkg.optionalDependencies,
			pkg.peerDependencies
		].some((dependencies) => name in (dependencies ?? {}));
	} catch {
		return false;
	}
}
/** @internal Detects the package specifier used to run this CLI (handles dlx/npx URL and version installs). */
function detectPackageSpecifier(name) {
	const info = nodeModulesInfo();
	if (!info) return name;
	try {
		const deps = JSON.parse(readFileSync(join(info.root, "package.json"), "utf-8")).dependencies ?? {};
		const spec = deps[name];
		if (!spec || Object.keys(deps).length !== 1) return name;
		if (/^https?:\/\//.test(spec) || spec.startsWith("file:")) return spec;
		if (/^\d/.test(spec)) return `${name}@${spec}`;
	} catch {}
	return name;
}
/** Splits a command string into tokens, respecting single and double quotes. */
function splitCommand(input) {
	const tokens = [];
	let current = "";
	let quote = null;
	for (let i = 0; i < input.length; i++) {
		const ch = input[i];
		if (quote) if (ch === quote) quote = null;
		else current += ch;
		else if (ch === "\"" || ch === "'") quote = ch;
		else if (ch === " ") {
			if (current) tokens.push(current);
			current = "";
		} else current += ch;
	}
	if (current) tokens.push(current);
	return tokens;
}
/** Promisified execFile with stderr in error message. */
function exec(cmd, args) {
	return new Promise((resolve, reject) => {
		execFile(cmd, args, (error, stdout, stderr) => {
			if (error) {
				const msg = stderr?.trim() || stdout?.trim() || error.message;
				reject(new Error(msg));
			} else resolve({
				stdout,
				stderr
			});
		});
	});
}
//#endregion
//#region ../../node_modules/.pnpm/incur@0.4.26/node_modules/incur/dist/internal/agents.js
var home = os$1.homedir();
var configHome = process.env.XDG_CONFIG_HOME || path$1.join(home, ".config");
var claudeHome = process.env.CLAUDE_CONFIG_DIR?.trim() || path$1.join(home, ".claude");
var codexHome = process.env.CODEX_HOME?.trim() || path$1.join(home, ".codex");
/** All known agent definitions. */
var all = [
	{
		name: "Amp",
		globalSkillsDir: path$1.join(configHome, "agents", "skills"),
		projectSkillsDir: ".agents/skills",
		universal: true,
		detect: () => fs$2.existsSync(path$1.join(configHome, "amp"))
	},
	{
		name: "Cline",
		globalSkillsDir: path$1.join(home, ".agents", "skills"),
		projectSkillsDir: ".agents/skills",
		universal: true,
		detect: () => fs$2.existsSync(path$1.join(home, ".cline"))
	},
	{
		name: "Codex",
		globalSkillsDir: path$1.join(codexHome, "skills"),
		projectSkillsDir: ".agents/skills",
		universal: true,
		detect: () => fs$2.existsSync(codexHome)
	},
	{
		name: "Cursor",
		globalSkillsDir: path$1.join(home, ".cursor", "skills"),
		projectSkillsDir: ".agents/skills",
		universal: true,
		detect: () => fs$2.existsSync(path$1.join(home, ".cursor"))
	},
	{
		name: "Gemini CLI",
		globalSkillsDir: path$1.join(home, ".gemini", "skills"),
		projectSkillsDir: ".agents/skills",
		universal: true,
		detect: () => fs$2.existsSync(path$1.join(home, ".gemini"))
	},
	{
		name: "GitHub Copilot",
		globalSkillsDir: path$1.join(home, ".copilot", "skills"),
		projectSkillsDir: ".agents/skills",
		universal: true,
		detect: () => fs$2.existsSync(path$1.join(home, ".copilot"))
	},
	{
		name: "Kimi CLI",
		globalSkillsDir: path$1.join(configHome, "agents", "skills"),
		projectSkillsDir: ".agents/skills",
		universal: true,
		detect: () => fs$2.existsSync(path$1.join(home, ".kimi"))
	},
	{
		name: "OpenCode",
		globalSkillsDir: path$1.join(configHome, "opencode", "skills"),
		projectSkillsDir: ".agents/skills",
		universal: true,
		detect: () => fs$2.existsSync(path$1.join(configHome, "opencode"))
	},
	{
		name: "Claude Code",
		globalSkillsDir: path$1.join(claudeHome, "skills"),
		projectSkillsDir: ".claude/skills",
		universal: false,
		detect: () => fs$2.existsSync(claudeHome)
	},
	{
		name: "Windsurf",
		globalSkillsDir: path$1.join(home, ".codeium", "windsurf", "skills"),
		projectSkillsDir: ".windsurf/skills",
		universal: false,
		detect: () => fs$2.existsSync(path$1.join(home, ".codeium", "windsurf"))
	},
	{
		name: "Continue",
		globalSkillsDir: path$1.join(home, ".continue", "skills"),
		projectSkillsDir: ".continue/skills",
		universal: false,
		detect: () => fs$2.existsSync(path$1.join(home, ".continue"))
	},
	{
		name: "Roo",
		globalSkillsDir: path$1.join(home, ".roo", "skills"),
		projectSkillsDir: ".roo/skills",
		universal: false,
		detect: () => fs$2.existsSync(path$1.join(home, ".roo"))
	},
	{
		name: "Kilo",
		globalSkillsDir: path$1.join(home, ".kilocode", "skills"),
		projectSkillsDir: ".kilocode/skills",
		universal: false,
		detect: () => fs$2.existsSync(path$1.join(home, ".kilocode"))
	},
	{
		name: "Goose",
		globalSkillsDir: path$1.join(configHome, "goose", "skills"),
		projectSkillsDir: ".goose/skills",
		universal: false,
		detect: () => fs$2.existsSync(path$1.join(configHome, "goose"))
	},
	{
		name: "Augment",
		globalSkillsDir: path$1.join(home, ".augment", "skills"),
		projectSkillsDir: ".augment/skills",
		universal: false,
		detect: () => fs$2.existsSync(path$1.join(home, ".augment"))
	},
	{
		name: "Trae",
		globalSkillsDir: path$1.join(home, ".trae", "skills"),
		projectSkillsDir: ".trae/skills",
		universal: false,
		detect: () => fs$2.existsSync(path$1.join(home, ".trae"))
	},
	{
		name: "Junie",
		globalSkillsDir: path$1.join(home, ".junie", "skills"),
		projectSkillsDir: ".junie/skills",
		universal: false,
		detect: () => fs$2.existsSync(path$1.join(home, ".junie"))
	},
	{
		name: "Crush",
		globalSkillsDir: path$1.join(configHome, "crush", "skills"),
		projectSkillsDir: ".crush/skills",
		universal: false,
		detect: () => fs$2.existsSync(path$1.join(configHome, "crush"))
	},
	{
		name: "Kiro CLI",
		globalSkillsDir: path$1.join(home, ".kiro", "skills"),
		projectSkillsDir: ".kiro/skills",
		universal: false,
		detect: () => fs$2.existsSync(path$1.join(home, ".kiro"))
	},
	{
		name: "Qwen Code",
		globalSkillsDir: path$1.join(home, ".qwen", "skills"),
		projectSkillsDir: ".qwen/skills",
		universal: false,
		detect: () => fs$2.existsSync(path$1.join(home, ".qwen"))
	},
	{
		name: "OpenHands",
		globalSkillsDir: path$1.join(home, ".openhands", "skills"),
		projectSkillsDir: ".openhands/skills",
		universal: false,
		detect: () => fs$2.existsSync(path$1.join(home, ".openhands"))
	}
];
/** Detects which agents are installed on the system. */
function detect() {
	return all.filter((a) => a.detect());
}
/**
* Installs skill directories to the canonical location and creates symlinks for
* detected non-universal agents.
*
* @param sourceDir - Directory containing skill subdirectories (each with a `SKILL.md`).
* @param options - Installation options.
* @returns Installed canonical paths.
*/
function install(sourceDir, options = {}) {
	const isGlobal = options.global !== false;
	const cwd = options.cwd || process.cwd();
	const base = isGlobal ? home : cwd;
	const canonicalBase = path$1.join(base, ".agents", "skills");
	const detected = options.agents ?? detect();
	const paths = [];
	const agents = [];
	for (const skill of discoverSkills(sourceDir)) {
		const canonicalDir = path$1.join(canonicalBase, skill.name);
		rmForce(canonicalDir);
		fs$2.mkdirSync(canonicalDir, { recursive: true });
		if (skill.root) fs$2.copyFileSync(path$1.join(skill.dir, "SKILL.md"), path$1.join(canonicalDir, "SKILL.md"));
		else fs$2.cpSync(skill.dir, canonicalDir, { recursive: true });
		paths.push(canonicalDir);
		for (const agent of detected) {
			if (agent.universal) continue;
			const agentSkillsDir = isGlobal ? agent.globalSkillsDir : path$1.join(cwd, agent.projectSkillsDir);
			const agentDir = path$1.join(agentSkillsDir, skill.name);
			if (resolveParent(agentDir) === resolveParent(canonicalDir)) continue;
			try {
				rmForce(agentDir);
				fs$2.mkdirSync(path$1.dirname(agentDir), { recursive: true });
				const realLinkDir = resolveParent(path$1.dirname(agentDir));
				const realTarget = resolveParent(canonicalDir);
				const rel = path$1.relative(realLinkDir, realTarget);
				fs$2.symlinkSync(rel, agentDir);
				agents.push({
					agent: agent.name,
					path: agentDir,
					mode: "symlink"
				});
			} catch {
				try {
					fs$2.cpSync(canonicalDir, agentDir, { recursive: true });
					agents.push({
						agent: agent.name,
						path: agentDir,
						mode: "copy"
					});
				} catch {}
			}
		}
	}
	return {
		paths,
		agents
	};
}
/**
* Removes a skill by name from the canonical location and all detected agent directories.
*/
function remove(skillName, options = {}) {
	const isGlobal = options.global !== false;
	const cwd = options.cwd || process.cwd();
	const base = isGlobal ? home : cwd;
	rmForce(path$1.join(base, ".agents", "skills", skillName));
	for (const agent of detect()) {
		if (agent.universal) continue;
		const agentSkillsDir = isGlobal ? agent.globalSkillsDir : path$1.join(cwd, agent.projectSkillsDir);
		rmForce(path$1.join(agentSkillsDir, skillName));
	}
}
/** Recursively discovers skill directories (those containing a `SKILL.md`). */
function discoverSkills(rootDir) {
	const results = [];
	function visit(dir) {
		let entries;
		try {
			entries = fs$2.readdirSync(dir, { withFileTypes: true });
		} catch {
			return;
		}
		for (const entry of entries) {
			if (!entry.isDirectory()) continue;
			const subDir = path$1.join(dir, entry.name);
			const skillPath = path$1.join(subDir, "SKILL.md");
			if (fs$2.existsSync(skillPath)) {
				const nameMatch = fs$2.readFileSync(skillPath, "utf8").match(/^name:\s*(.+)$/m);
				results.push({
					name: sanitizeName(nameMatch?.[1] ?? entry.name),
					dir: subDir
				});
			}
			visit(subDir);
		}
	}
	visit(rootDir);
	const rootSkill = path$1.join(rootDir, "SKILL.md");
	if (fs$2.existsSync(rootSkill)) {
		const name = sanitizeName(fs$2.readFileSync(rootSkill, "utf8").match(/^name:\s*(.+)$/m)?.[1] ?? "skill");
		if (!results.some((r) => r.name === name)) results.push({
			name,
			dir: rootDir,
			root: true
		});
	}
	return results;
}
/** Sanitizes a skill name for use as a directory name. */
function sanitizeName(name) {
	return name.trim().replace(/[/\\]/g, "-").replace(/\.\./g, "").slice(0, 255);
}
/** Removes a file, directory, or symlink (including broken symlinks). */
function rmForce(target) {
	try {
		if (fs$2.lstatSync(target).isSymbolicLink()) fs$2.unlinkSync(target);
		else fs$2.rmSync(target, {
			recursive: true,
			force: true
		});
	} catch {}
}
/** Resolves parent directories through symlinks. */
function resolveParent(dir) {
	try {
		return fs$2.realpathSync(dir);
	} catch {
		const parent = path$1.dirname(dir);
		if (parent === dir) return dir;
		try {
			return path$1.join(fs$2.realpathSync(parent), path$1.relative(parent, dir));
		} catch {
			return dir;
		}
	}
}
//#endregion
//#region ../../node_modules/.pnpm/incur@0.4.26/node_modules/incur/dist/SyncSkills.js
/** Generates skill files from a command map and installs them natively. */
async function sync(name, commands, options = {}) {
	const { depth = 1, description, global = true } = options;
	const cwd = options.cwd ?? (global ? resolvePackageRoot() : process.cwd());
	await load();
	const groups = /* @__PURE__ */ new Map();
	if (description) groups.set(name, description);
	const files = split(name, collectSkillCommands(commands, [], groups, options.rootCommand), depth, groups);
	const tmpDir = await fs.mkdtemp(path.join(os.tmpdir(), `incur-skills-${name}-`));
	try {
		const skills = [];
		for (const file of files) {
			const filePath = file.dir ? path.join(tmpDir, file.dir, "SKILL.md") : path.join(tmpDir, "SKILL.md");
			await fs.mkdir(path.dirname(filePath), { recursive: true });
			await fs.writeFile(filePath, `${file.content}\n`);
			const meta = parseSkillFrontmatter(file.content);
			skills.push({
				name: meta.name ?? (file.dir || name),
				description: meta.description
			});
		}
		if (options.include) for (const pattern of options.include) {
			const globPattern = pattern === "_root" ? "SKILL.md" : path.join(pattern, "SKILL.md");
			for await (const match of fs.glob(globPattern, { cwd })) try {
				const content = await fs.readFile(path.resolve(cwd, match), "utf8");
				const meta = parseSkillFrontmatter(content);
				const skillName = pattern === "_root" ? meta.name ?? name : path.basename(path.dirname(match));
				const dest = path.join(tmpDir, skillName, "SKILL.md");
				await fs.mkdir(path.dirname(dest), { recursive: true });
				await fs.writeFile(dest, content);
				if (!skills.some((s) => s.name === skillName)) skills.push({
					name: skillName,
					description: meta.description,
					external: true
				});
			} catch {}
		}
		const { paths, agents } = install(tmpDir, {
			global,
			cwd
		});
		const currentNames = new Set(paths.map((p) => path.basename(p)));
		const prev = readMeta(name);
		if (prev?.skills) for (const old of prev.skills) {
			if (currentNames.has(old)) continue;
			remove(old, {
				global,
				cwd
			});
		}
		writeMeta(name, hash(collectSkillCommands(commands, [], /* @__PURE__ */ new Map(), options.rootCommand)), [...currentNames], [...paths, ...agents.map((agent) => agent.path)]);
		return {
			skills: skills.sort((a, b) => a.name.localeCompare(b.name)),
			paths,
			agents
		};
	} finally {
		await fs.rm(tmpDir, {
			recursive: true,
			force: true
		});
	}
}
/** Lists skills derived from a CLI's command map with install status. */
async function list(name, commands, options = {}) {
	const { depth = 1, description } = options;
	const cwd = options.cwd ?? process.cwd();
	await load();
	const groups = /* @__PURE__ */ new Map();
	if (description) groups.set(name, description);
	const files = split(name, collectSkillCommands(commands, [], groups, options.rootCommand), depth, groups);
	const skills = [];
	const installed = readInstalledSkills(name, { cwd });
	for (const file of files) {
		const meta = parseSkillFrontmatter(file.content);
		const skillName = meta.name ?? (file.dir || name);
		skills.push({
			name: skillName,
			description: meta.description,
			installed: installed.has(skillName)
		});
	}
	if (options.include) for (const pattern of options.include) {
		const globPattern = pattern === "_root" ? "SKILL.md" : path.join(pattern, "SKILL.md");
		for await (const match of fs.glob(globPattern, { cwd })) try {
			const meta = parseSkillFrontmatter(await fs.readFile(path.resolve(cwd, match), "utf8"));
			const skillName = pattern === "_root" ? meta.name ?? name : path.basename(path.dirname(match));
			if (!skills.some((s) => s.name === skillName)) skills.push({
				name: skillName,
				description: meta.description,
				installed: installed.has(skillName)
			});
		} catch {}
	}
	return skills.sort((a, b) => a.name.localeCompare(b.name));
}
/** Returns whether any previously synced skills are still installed on disk. */
function hasInstalledSkills(name, options = {}) {
	return readInstalledSkills(name, options).size > 0;
}
/** Resolves the package root from the executing bin script (`process.argv[1]`). Walks up from the bin's directory looking for `package.json`. Falls back to `process.cwd()`. */
function resolvePackageRoot() {
	const bin = process.argv[1];
	if (!bin) return process.cwd();
	let dir = path.dirname((() => {
		try {
			return fsSync.realpathSync(bin);
		} catch {
			return process.execPath;
		}
	})());
	const root = path.parse(dir).root;
	while (dir !== root) {
		try {
			fsSync.accessSync(path.join(dir, "package.json"));
			return dir;
		} catch {}
		dir = path.dirname(dir);
	}
	return process.cwd();
}
/** Returns the hash file path for a CLI. */
function hashPath(name) {
	const dir = process.env.XDG_DATA_HOME || path.join(os.homedir(), ".local", "share");
	return path.join(dir, "incur", `${name}.json`);
}
/** @internal Writes the skills metadata for staleness detection and cleanup. */
function writeMeta(name, hash, skills, paths) {
	const file = hashPath(name);
	const dir = path.dirname(file);
	if (!fsSync.existsSync(dir)) fsSync.mkdirSync(dir, { recursive: true });
	fsSync.writeFileSync(file, JSON.stringify({
		hash,
		skills,
		paths,
		at: (/* @__PURE__ */ new Date()).toISOString()
	}) + "\n");
}
/** @internal Reads the stored metadata for a CLI. */
function readMeta(name) {
	try {
		return JSON.parse(fsSync.readFileSync(hashPath(name), "utf-8"));
	} catch {
		return;
	}
}
/** Reads the names of previously synced skills that are still installed on disk. */
function readInstalledSkills(name, options = {}) {
	const meta = readMeta(name);
	if (!meta?.skills?.length) return /* @__PURE__ */ new Set();
	if (meta.paths?.length) {
		const installed = meta.paths.filter((skillPath) => isInstalledSkillPath(skillPath)).map((skillPath) => path.basename(skillPath));
		return new Set(installed);
	}
	const cwd = options.cwd ?? process.cwd();
	const bases = [path.join(os.homedir(), ".agents", "skills"), path.join(cwd, ".agents", "skills")];
	const installed = meta.skills.filter((skill) => bases.some((base) => isInstalledSkillPath(path.join(base, skill))));
	return new Set(installed);
}
/** Returns whether a skill directory currently contains a skill file. */
function isInstalledSkillPath(skillPath) {
	return fsSync.existsSync(path.join(skillPath, "SKILL.md"));
}
/** Reads the stored skills hash for a CLI. Returns `undefined` if no hash exists. */
function readHash(name) {
	return readMeta(name)?.hash;
}
//#endregion
//#region ../../node_modules/.pnpm/incur@0.4.26/node_modules/incur/dist/Cli.js
var destructiveCommandHint = "Confirm with the user before executing this destructive command.";
function create(nameOrDefinition, definition) {
	const name = typeof nameOrDefinition === "string" ? nameOrDefinition : nameOrDefinition.name;
	const def = typeof nameOrDefinition === "string" ? definition ?? {} : nameOrDefinition;
	const version$1 = def.version ?? version;
	const rootDef = "run" in def ? def : void 0;
	const rootFetchSource = "fetch" in def && def.fetch !== void 0 ? def.fetch : void 0;
	const rootFetch = rootFetchSource === void 0 ? void 0 : resolveFetch(rootFetchSource);
	const rootFetchBaseUrl = rootFetchSource === void 0 ? void 0 : fetchBaseUrl(rootFetchSource);
	const commands = /* @__PURE__ */ new Map();
	const middlewares = [];
	const pending = [];
	const mcpHandler = createMcpHttpHandler(def.mcp?.name ?? name, version$1 ?? "0.0.0", {
		instructions: def.mcp?.instructions,
		stateless: def.mcp?.stateless,
		title: def.mcp?.title,
		tools: def.mcp?.tools
	});
	if (def.openapi && rootFetch) pending.push((async () => {
		const generated = await generateCommands$1(await resolve$2(def.openapi, { baseUrl: rootFetchBaseUrl }), rootFetch, { config: def.openapiConfig });
		for (const [name, command] of generated) commands.set(name, command);
	})());
	const cli = {
		name,
		description: def.description,
		env: def.env,
		vars: def.vars,
		command(nameOrCli, def) {
			if (typeof nameOrCli === "string") {
				if (isMcpSourceDefinition(def)) {
					pending.push((async () => {
						const generated = generateCommands(await resolve$1(def.mcp));
						const entry = {
							_group: true,
							description: def.description,
							commands: generated,
							...def.outputPolicy ? { outputPolicy: def.outputPolicy } : void 0
						};
						assertNoGlobalOptionConflicts(nameOrCli, entry, toGlobals.get(cli));
						commands.set(nameOrCli, entry);
					})());
					return cli;
				}
				if (def && "fetch" in def && isFetchSource(def.fetch)) {
					const fetch = resolveFetch(def.fetch);
					if (def.openapi) {
						pending.push((async () => {
							const generated = await generateCommands$1(await resolve$2(def.openapi, { baseUrl: fetchBaseUrl(def.fetch) }), fetch, {
								basePath: def.basePath,
								config: def.openapiConfig
							});
							const entry = {
								_group: true,
								description: def.description,
								commands: generated,
								...def.outputPolicy ? { outputPolicy: def.outputPolicy } : void 0,
								...def.mcp === false ? { mcp: false } : void 0
							};
							assertNoGlobalOptionConflicts(nameOrCli, entry, toGlobals.get(cli));
							commands.set(nameOrCli, entry);
						})());
						return cli;
					}
					commands.set(nameOrCli, {
						_fetch: true,
						basePath: def.basePath,
						description: def.description,
						fetch,
						...def.outputPolicy ? { outputPolicy: def.outputPolicy } : void 0
					});
					return cli;
				}
				assertNoGlobalOptionConflicts(nameOrCli, def, toGlobals.get(cli));
				commands.set(nameOrCli, def);
				if (def.aliases) for (const a of def.aliases) commands.set(a, {
					_alias: true,
					target: nameOrCli
				});
				return cli;
			}
			const mountedRootDef = toRootDefinition.get(nameOrCli);
			if (mountedRootDef) {
				assertNoGlobalOptionConflicts(nameOrCli.name, mountedRootDef, toGlobals.get(cli));
				commands.set(nameOrCli.name, mountedRootDef);
				const rootAliases = toRootAliases.get(nameOrCli);
				if (rootAliases) for (const a of rootAliases) commands.set(a, {
					_alias: true,
					target: nameOrCli.name
				});
				return cli;
			}
			const sub = nameOrCli;
			const subCommands = toCommands.get(sub);
			const subOutputPolicy = toOutputPolicy.get(sub);
			const subMiddlewares = toMiddlewares.get(sub);
			const entry = {
				_group: true,
				description: sub.description,
				commands: subCommands,
				...subOutputPolicy ? { outputPolicy: subOutputPolicy } : void 0,
				...subMiddlewares?.length ? { middlewares: subMiddlewares } : void 0
			};
			assertNoGlobalOptionConflicts(sub.name, entry, toGlobals.get(cli));
			commands.set(sub.name, entry);
			return cli;
		},
		async fetch(req) {
			if (pending.length > 0) await Promise.all(pending);
			const globalsDesc = toGlobals.get(cli);
			return fetchImpl(name, commands, req, {
				description: def.description,
				envSchema: def.env,
				globals: globalsDesc,
				mcpHandler,
				middlewares,
				name,
				rootCommand: rootDef,
				vars: def.vars,
				version: version$1
			});
		},
		async serve(argv = process.argv.slice(2), serveOptions = {}) {
			if (await handleArgv(argv)) return;
			if (pending.length > 0) await Promise.all(pending);
			const globalsDesc = toGlobals.get(cli);
			return serveImpl(name, commands, argv, {
				...serveOptions,
				aliases: def.aliases,
				banner: def.banner,
				config: def.config,
				description: def.description,
				envSchema: def.env,
				format: def.format,
				globals: globalsDesc,
				mcp: def.mcp,
				middlewares,
				outputPolicy: def.outputPolicy,
				rootCommand: rootDef,
				rootFetch,
				sync: def.sync,
				update: def.update,
				vars: def.vars,
				version: version$1
			});
		},
		use(handler) {
			middlewares.push(handler);
			return cli;
		}
	};
	if (rootDef) toRootDefinition.set(cli, rootDef);
	if (rootDef && def.aliases) toRootAliases.set(cli, def.aliases);
	if (def.options) toRootOptions.set(cli, def.options);
	if (def.config !== void 0) toConfigEnabled.set(cli, true);
	if (def.outputPolicy) toOutputPolicy.set(cli, def.outputPolicy);
	if (def.globals) {
		toGlobals.set(cli, {
			schema: def.globals,
			alias: def.globalAlias
		});
		const builtinNames = [
			"verbose",
			"format",
			"json",
			"llms",
			"llmsFull",
			"mcp",
			"help",
			"incurBinaryApply",
			"incurUpdateCheck",
			"update",
			"version",
			"schema",
			"filterOutput",
			"tokenLimit",
			"tokenOffset",
			"tokenCount",
			...def.config?.flag ? [def.config.flag, `no${def.config.flag[0].toUpperCase()}${def.config.flag.slice(1)}`] : []
		];
		const globalKeys = Object.keys(def.globals.shape);
		for (const key of globalKeys) if (builtinNames.includes(key)) throw new Error(`Global option '${key}' conflicts with a built-in flag. Choose a different name.`);
		const reservedShorts = /* @__PURE__ */ new Set(["h"]);
		if (def.globalAlias) {
			for (const [name, short] of Object.entries(def.globalAlias)) if (reservedShorts.has(short)) throw new Error(`Global alias '-${short}' for '${name}' conflicts with a built-in short flag. Choose a different alias.`);
		}
	}
	toMiddlewares.set(cli, middlewares);
	toCommands.set(cli, commands);
	return cli;
}
/** @internal Shared serve implementation for both router and leaf CLIs. */
async function serveImpl(name, commands, argv, options = {}) {
	const stdout = options.stdout ?? ((s) => process.stdout.write(s));
	const exit = options.exit ?? ((code) => process.exit(code));
	const tty = process.stdout.isTTY === true;
	let human = tty;
	const configEnabled = options.config !== void 0;
	const configFlag = options.config?.flag;
	const displayName = resolveDisplayName(name, options.aliases);
	function writeln(s) {
		stdout(s.endsWith("\n") ? s : `${s}\n`);
	}
	async function writeBanner() {
		if (!options.banner || help) return;
		const banner = typeof options.banner === "function" ? {
			render: options.banner,
			mode: "all"
		} : options.banner;
		const mode = banner.mode ?? "all";
		if (mode !== "all" && mode !== (human ? "human" : "agent")) return;
		try {
			const text = await banner.render();
			if (text) writeln(text);
		} catch {}
	}
	let builtinFlags;
	try {
		builtinFlags = extractBuiltinFlags(argv, { configFlag });
	} catch (error) {
		const message = error instanceof Error ? error.message : String(error);
		if (human) writeln(formatHumanError({
			code: "UNKNOWN",
			message
		}));
		else writeln(format({
			code: "UNKNOWN",
			message
		}, "toon"));
		exit(1);
		return;
	}
	const { fullOutput, format: formatFlag, formatExplicit, filterOutput, tokenLimit, tokenOffset, tokenCount, llms, llmsFull, mcp: mcpFlag, help, update, updateCheck, version, schema, configPath, configDisabled, rest } = builtinFlags;
	human = tty && !formatExplicit;
	const updateOptions = {
		...typeof options.update === "object" ? options.update : void 0,
		binary: target !== void 0,
		version: options.version
	};
	let globals = {};
	let filtered = rest;
	function parseGlobalOptions(validate) {
		if (!options.globals) return true;
		try {
			const result = parseGlobals(rest, options.globals.schema, options.globals.alias, { validate });
			if (validate) globals = result.parsed;
			filtered = result.rest;
			return true;
		} catch (error) {
			const message = error instanceof Error ? error.message : String(error);
			if (human) writeln(formatHumanError({
				code: "UNKNOWN",
				message
			}));
			else writeln(format({
				code: "UNKNOWN",
				message
			}, "toon"));
			exit(1);
			return false;
		}
	}
	if (!parseGlobalOptions(false)) return;
	if (formatFlag === "yaml") await load();
	if (updateCheck) {
		if (options.update !== false) try {
			await refresh(name, updateOptions);
		} catch {}
		return;
	}
	if (update && !help) {
		try {
			const result = await install$1(name, updateOptions);
			if (human) {
				const lines = [result.deferred ? `✓ Update staged for ${result.name}` : `✓ Updated ${result.name}`];
				if (result.command) lines.push(`  ${result.command}`);
				if (result.deferred) lines.push("  Installation will finish after this process exits.");
				writeln(lines.join("\n"));
			} else writeln(format(result, formatFlag));
		} catch (error) {
			const output = {
				code: "UPDATE_FAILED",
				message: error instanceof Error ? error.message : String(error)
			};
			if (human) writeln(formatHumanError(output));
			else writeln(format(output, formatFlag));
			exit(1);
		}
		return;
	}
	if (mcpFlag) {
		await serve(options.mcp?.name ?? name, options.version ?? "0.0.0", commands, {
			middlewares: options.middlewares,
			env: options.envSchema,
			vars: options.vars,
			version: options.version,
			...options.mcp?.instructions ? { instructions: options.mcp.instructions } : void 0,
			...options.mcp?.title ? { title: options.mcp.title } : void 0,
			...options.mcp?.tools ? { tools: options.mcp.tools } : void 0
		});
		return;
	}
	const completeShell = process.env.COMPLETE;
	if (completeShell) {
		const sepIdx = argv.indexOf("--");
		const words = sepIdx !== -1 ? argv.slice(sepIdx + 1) : argv;
		if (words.length === 0) stdout([name, ...options.aliases ?? []].map((n) => register$4(completeShell, n)).join("\n"));
		else {
			const index = Number(process.env._COMPLETE_INDEX ?? words.length - 1);
			const candidates = complete(commands, options.rootCommand, words, index, options.globals ? {
				schema: options.globals.schema,
				alias: options.globals.alias
			} : void 0);
			const current = words[index] ?? "";
			const nonFlags = words.slice(0, index).filter((w) => !w.startsWith("-"));
			if (nonFlags.length <= 1) {
				for (const b of builtinCommands) if (b.name.startsWith(current) && !candidates.some((c) => c.value === b.name)) candidates.push({
					value: b.name,
					description: b.description,
					...b.subcommands ? { noSpace: true } : void 0
				});
			} else if (nonFlags.length === 2) {
				const parent = nonFlags[nonFlags.length - 1];
				const builtin = findBuiltin(parent);
				if (builtin?.subcommands) {
					for (const sub of builtin.subcommands) for (const value of [sub.name, ...sub.aliases ?? []]) if (value.startsWith(current) && !candidates.some((c) => c.value === value)) candidates.push({
						value,
						description: sub.description
					});
				}
			}
			const out = format$1(completeShell, candidates);
			if (out) stdout(out);
		}
		return;
	}
	let skillsCta;
	if (!llms && !llmsFull && !schema && !help && !update && !updateCheck && !version) {
		const isSkillsAdd = builtinIdx(filtered, name, "skills") !== -1;
		const isMcpAdd = builtinIdx(filtered, name, "mcp") !== -1;
		if (!isSkillsAdd && !isMcpAdd) {
			const stored = readHash(name);
			if (stored && hasInstalledSkills(name, { cwd: options.sync?.cwd })) {
				if (hash(collectSkillCommands(commands, [], /* @__PURE__ */ new Map(), options.rootCommand)) !== stored) skillsCta = {
					description: "Skills are out of date:",
					commands: [{
						command: process.env.npm_config_user_agent || process.env.npm_execpath ? `${detectRunner()} ${detectPackageSpecifier(name)} skills add` : `${displayName} skills add`,
						description: "sync outdated skills"
					}]
				};
			}
		}
	}
	if (llms || llmsFull) {
		let scopedCommands = commands;
		const prefix = [];
		let scopedDescription = options.description;
		for (const token of filtered) {
			const rawEntry = scopedCommands.get(token);
			if (!rawEntry) break;
			const entry = resolveAlias(scopedCommands, rawEntry);
			if (isGroup(entry)) {
				scopedCommands = entry.commands;
				scopedDescription = entry.description;
				prefix.push(token);
			} else {
				scopedCommands = /* @__PURE__ */ new Map([[token, entry]]);
				break;
			}
		}
		const scopedRoot = prefix.length === 0 ? options.rootCommand : void 0;
		const collectPrefix = prefix.length > 0 ? [] : prefix;
		if (llmsFull) {
			if (!formatExplicit || formatFlag === "md") {
				const groups = /* @__PURE__ */ new Map();
				const cmds = collectSkillCommands(scopedCommands, collectPrefix, groups, scopedRoot);
				writeln(generate(prefix.length > 0 ? `${name} ${prefix.join(" ")}` : name, cmds, groups));
				return;
			}
			writeln(format(buildManifest(scopedCommands, prefix, options.globals?.schema), formatFlag));
			return;
		}
		if (!formatExplicit || formatFlag === "md") {
			const cmds = collectSkillCommands(scopedCommands, collectPrefix, /* @__PURE__ */ new Map(), scopedRoot);
			writeln(index(prefix.length > 0 ? `${name} ${prefix.join(" ")}` : name, cmds, scopedDescription));
			return;
		}
		writeln(format(buildIndexManifest(scopedCommands, prefix, options.globals?.schema), formatFlag));
		return;
	}
	const completionsIdx = builtinIdx(filtered, name, "completions");
	if (completionsIdx !== -1) {
		const shell = filtered[completionsIdx + 1];
		if (help || !shell) {
			const b = findBuiltin("completions");
			writeln(formatCommand(`${name} completions`, {
				args: b.args,
				description: b.description,
				hideGlobalOptions: true,
				hint: b.hint?.(name)
			}));
			return;
		}
		if (!shells.includes(shell)) {
			writeln(formatHumanError({
				code: "INVALID_SHELL",
				message: `Unknown shell '${shell}'. Supported: ${shells.join(", ")}`
			}));
			exit(1);
			return;
		}
		writeln([name, ...options.aliases ?? []].map((n) => register$4(shell, n)).join("\n"));
		return;
	}
	const skillsIdx = builtinIdx(filtered, name, "skills");
	if (skillsIdx !== -1) {
		const builtin = findBuiltin("skills");
		const skillsSub = filtered[skillsIdx + 1];
		const sub = skillsSub ? findBuiltinSubcommand(builtin, skillsSub) : void 0;
		if (skillsSub && !sub) {
			const suggestion = suggest(skillsSub, builtin.subcommands?.flatMap((sub) => [sub.name, ...sub.aliases ?? []]) ?? []);
			const message = `'${skillsSub}' is not a command for '${name} skills'.${suggestion ? ` Did you mean '${suggestion}'?` : ""}`;
			const ctaCommands = [];
			if (suggestion) {
				const corrected = argv.map((t) => t === skillsSub ? suggestion : t);
				ctaCommands.push({ command: `${name} ${corrected.join(" ")}` });
			}
			ctaCommands.push({
				command: `${name} skills --help`,
				description: "see all available commands"
			});
			const cta = {
				description: ctaCommands.length === 1 ? "Suggested command:" : "Suggested commands:",
				commands: ctaCommands
			};
			if (human) {
				writeln(formatHumanError({
					code: "COMMAND_NOT_FOUND",
					message
				}));
				writeln(formatHumanCta(cta));
			} else writeln(format({
				code: "COMMAND_NOT_FOUND",
				message,
				cta
			}, "toon"));
			exit(1);
			return;
		}
		if (!skillsSub) {
			writeln(formatBuiltinHelp(name, builtin));
			return;
		}
		if (sub?.name === "list") {
			if (help) {
				writeln(formatBuiltinSubcommandHelp(name, builtin, "list"));
				return;
			}
			try {
				const result = await list(name, commands, {
					cwd: options.sync?.cwd,
					depth: options.sync?.depth ?? 1,
					description: options.description,
					include: options.sync?.include,
					rootCommand: options.rootCommand
				});
				if (result.length === 0) {
					writeln("No skills found.");
					return;
				}
				const lines = [];
				const maxLen = Math.max(...result.map((s) => s.name.length));
				for (const s of result) {
					const icon = s.installed ? "✓" : "✗";
					const padding = s.description ? `${" ".repeat(maxLen - s.name.length)}  ${s.description}` : "";
					lines.push(`  ${icon} ${s.name}${padding}`);
				}
				const installedCount = result.filter((s) => s.installed).length;
				lines.push("");
				lines.push(`${result.length} skill${result.length === 1 ? "" : "s"} (${installedCount} installed)`);
				writeln(lines.join("\n"));
			} catch (err) {
				writeln(format({
					code: "LIST_SKILLS_FAILED",
					message: err instanceof Error ? err.message : String(err)
				}, formatExplicit ? formatFlag : "toon"));
				exit(1);
			}
			return;
		}
		if (help) {
			writeln(formatBuiltinSubcommandHelp(name, builtin, "add"));
			return;
		}
		const rest = filtered.slice(skillsIdx + 2);
		const depthArg = rest.indexOf("--depth");
		const depthEq = rest.find((t) => t.startsWith("--depth="));
		const depth = depthArg !== -1 ? Number(rest[depthArg + 1]) : depthEq ? Number(depthEq.split("=")[1]) : options.sync?.depth ?? 1;
		const global = rest.includes("--no-global") ? false : void 0;
		try {
			stdout("Syncing...");
			const result = await sync(name, commands, {
				cwd: options.sync?.cwd,
				depth,
				description: options.description,
				global,
				include: options.sync?.include,
				rootCommand: options.rootCommand
			});
			stdout("\r\x1B[K");
			const lines = [];
			const skillLabel = (s) => s.name;
			const maxLen = Math.max(...result.skills.map((s) => skillLabel(s).length));
			for (const s of result.skills) {
				const label = skillLabel(s);
				const padding = s.description ? `${" ".repeat(maxLen - label.length)}  ${s.description}` : "";
				lines.push(`  ✓ ${label}${padding}`);
			}
			lines.push("");
			lines.push(`${result.skills.length} skill${result.skills.length === 1 ? "" : "s"} synced`);
			const body = options.sync?.body;
			if (body) {
				lines.push("");
				lines.push(body);
			}
			const suggestions = options.sync?.suggestions;
			if (suggestions && suggestions.length > 0) {
				lines.push("");
				lines.push(`Your agent can now use ${name}. Try asking:`);
				for (const s of suggestions) lines.push(`  "${s}"`);
			}
			lines.push("");
			lines.push(`Run \`${name} --help\` to see the full command reference.`);
			writeln(lines.join("\n"));
			if (fullOutput || formatExplicit) {
				const output = { skills: result.paths };
				if (body) output.body = body;
				if (fullOutput && result.agents.length > 0) output.agents = result.agents;
				writeln(format(output, formatExplicit ? formatFlag : "toon"));
			}
		} catch (err) {
			writeln(format({
				code: "SYNC_SKILLS_FAILED",
				message: err instanceof Error ? err.message : String(err)
			}, formatExplicit ? formatFlag : "toon"));
			exit(1);
		}
		return;
	}
	const mcpIdx = builtinIdx(filtered, name, "mcp");
	if (mcpIdx !== -1) {
		const builtin = findBuiltin("mcp");
		const mcpSub = filtered[mcpIdx + 1];
		const sub = mcpSub ? findBuiltinSubcommand(builtin, mcpSub) : void 0;
		if (mcpSub && !sub) {
			const suggestion = suggest(mcpSub, builtin.subcommands?.flatMap((sub) => [sub.name, ...sub.aliases ?? []]) ?? []);
			const message = `'${mcpSub}' is not a command for '${name} mcp'.${suggestion ? ` Did you mean '${suggestion}'?` : ""}`;
			const ctaCommands = [];
			if (suggestion) {
				const corrected = argv.map((t) => t === mcpSub ? suggestion : t);
				ctaCommands.push({ command: `${name} ${corrected.join(" ")}` });
			}
			ctaCommands.push({
				command: `${name} mcp --help`,
				description: "see all available commands"
			});
			const cta = {
				description: ctaCommands.length === 1 ? "Suggested command:" : "Suggested commands:",
				commands: ctaCommands
			};
			if (human) {
				writeln(formatHumanError({
					code: "COMMAND_NOT_FOUND",
					message
				}));
				writeln(formatHumanCta(cta));
			} else writeln(format({
				code: "COMMAND_NOT_FOUND",
				message,
				cta
			}, "toon"));
			exit(1);
			return;
		}
		if (!mcpSub) {
			writeln(formatBuiltinHelp(name, builtin));
			return;
		}
		if (help) {
			writeln(formatBuiltinSubcommandHelp(name, builtin, sub.name));
			return;
		}
		if (sub.name === "doctor") {
			const result = await runMcpDoctor(name, commands, options);
			writeln(format(result, formatExplicit ? formatFlag : "toon"));
			if (!result.ok) exit(1);
			return;
		}
		const rest = filtered.slice(mcpIdx + 2);
		const global = rest.includes("--no-global") ? false : true;
		let command = options.mcp?.command;
		const agents = [...options.mcp?.agents ?? []];
		for (let i = 0; i < rest.length; i++) if ((rest[i] === "--command" || rest[i] === "-c") && rest[i + 1]) command = rest[++i];
		else if (rest[i] === "--agent" && rest[i + 1]) agents.push(rest[++i]);
		try {
			const mcpName = options.mcp?.name ?? name;
			stdout("Registering MCP server...");
			const result = await register$3(mcpName, {
				...mcpName === name ? void 0 : { cli: name },
				command,
				global,
				agents
			});
			stdout("\r\x1B[K");
			const lines = [];
			lines.push(`✓ Registered ${mcpName} as MCP server`);
			if (result.agents.length > 0) lines.push(`  Agents: ${result.agents.join(", ")}`);
			lines.push("");
			lines.push(`Agents can now use ${mcpName} tools.`);
			const suggestions = options.sync?.suggestions;
			if (suggestions && suggestions.length > 0) {
				lines.push("");
				lines.push("Try asking:");
				for (const s of suggestions) lines.push(`  "${s}"`);
			}
			writeln(lines.join("\n"));
			if (fullOutput || formatExplicit) writeln(format({
				name: mcpName,
				command: result.command,
				agents: result.agents
			}, formatExplicit ? formatFlag : "toon"));
		} catch (err) {
			writeln(format({
				code: "MCP_ADD_FAILED",
				message: err instanceof Error ? err.message : String(err)
			}, formatExplicit ? formatFlag : "toon"));
			exit(1);
		}
		return;
	}
	if (version && !help && options.version) {
		writeln(options.version);
		return;
	}
	if (filtered.length === 0) {
		if (options.rootCommand && human && options.rootCommand.args && hasRequiredArgs(options.rootCommand.args)) {
			const cmd = options.rootCommand;
			await writeBanner();
			writeln(formatCommand(name, {
				alias: cmd.alias,
				aliases: options.aliases,
				configFlag,
				description: cmd.description ?? options.description,
				globals: options.globals,
				version: options.version,
				args: cmd.args,
				env: cmd.env,
				envSource: options.env,
				hint: cmd.hint,
				options: cmd.options,
				examples: formatExamples(cmd.examples),
				usage: cmd.usage,
				commands: commands.size > 0 ? collectHelpCommands(commands) : void 0,
				root: true
			}));
			return;
		}
		if (options.rootCommand || options.rootFetch) {} else {
			await writeBanner();
			writeln(formatRoot(name, {
				aliases: options.aliases,
				configFlag,
				description: options.description,
				globals: options.globals,
				version: options.version,
				commands: collectHelpCommands(commands),
				root: true
			}));
			return;
		}
	}
	const resolved = filtered.length === 0 && options.rootCommand ? {
		command: options.rootCommand,
		path: name,
		rest: []
	} : filtered.length === 0 && options.rootFetch ? {
		fetchGateway: {
			_fetch: true,
			fetch: options.rootFetch,
			description: options.description
		},
		middlewares: [],
		path: name,
		rest: []
	} : resolveCommand(commands, filtered);
	if (help && "fetchGateway" in resolved) {
		const commandName = resolved.path === name ? name : `${name} ${resolved.path}`;
		if (resolved.path === name && commands.size > 0) writeln(formatRoot(name, {
			aliases: options.aliases,
			configFlag,
			description: options.description,
			version: options.version,
			commands: collectHelpCommands(commands),
			root: true
		}));
		else writeln(formatFetchHelp(commandName, resolved.fetchGateway.description));
		return;
	}
	if (help) {
		if ("help" in resolved || "error" in resolved) {
			const helpName = "help" in resolved ? `${name} ${resolved.path}` : name;
			const helpDesc = "help" in resolved ? resolved.description : options.description;
			const helpCmds = "help" in resolved ? resolved.commands : commands;
			const isRoot = helpName === name;
			if (isRoot && options.rootCommand && helpCmds.size > 0) {
				const cmd = options.rootCommand;
				writeln(formatCommand(name, {
					alias: cmd.alias,
					aliases: options.aliases,
					configFlag,
					description: cmd.description ?? options.description,
					globals: options.globals,
					version: options.version,
					args: cmd.args,
					env: cmd.env,
					envSource: options.env,
					hint: cmd.hint,
					options: cmd.options,
					examples: formatExamples(cmd.examples),
					usage: cmd.usage,
					commands: collectHelpCommands(helpCmds),
					root: true
				}));
			} else writeln(formatRoot(helpName, {
				aliases: isRoot ? options.aliases : void 0,
				configFlag,
				description: helpDesc,
				globals: options.globals,
				version: isRoot ? options.version : void 0,
				commands: collectHelpCommands(helpCmds),
				root: isRoot
			}));
		} else if ("command" in resolved) {
			const cmd = resolved.command;
			const isRootCmd = resolved.path === name;
			const commandName = isRootCmd ? name : `${name} ${resolved.path}`;
			const helpSubcommands = isRootCmd && options.rootCommand && commands.size > 0 ? collectHelpCommands(commands) : void 0;
			writeln(formatCommand(commandName, {
				alias: cmd.alias,
				aliases: isRootCmd ? options.aliases : cmd.aliases,
				configFlag,
				description: cmd.description,
				globals: options.globals,
				version: isRootCmd ? options.version : void 0,
				args: cmd.args,
				env: cmd.env,
				envSource: options.env,
				hint: cmd.hint,
				options: cmd.options,
				examples: formatExamples(cmd.examples),
				usage: cmd.usage,
				commands: helpSubcommands,
				root: isRootCmd
			}));
		}
		return;
	}
	if (schema) {
		if ("help" in resolved) {
			writeln(formatRoot(`${name} ${resolved.path}`, {
				configFlag,
				description: resolved.description,
				globals: options.globals,
				commands: collectHelpCommands(resolved.commands)
			}));
			return;
		}
		if ("error" in resolved) {
			const parent = resolved.path ? `${name} ${resolved.path}` : name;
			const suggestion = suggest(resolved.error, resolved.commands.keys());
			const didYouMean = suggestion ? ` Did you mean '${suggestion}'?` : "";
			writeln(`Error: '${resolved.error}' is not a command for '${parent}'.${didYouMean}`);
			exit(1);
			return;
		}
		if ("fetchGateway" in resolved) {
			writeln("--schema is not supported for fetch commands.");
			exit(1);
			return;
		}
		const cmd = resolved.command;
		const format$3 = formatExplicit ? formatFlag : "toon";
		const result = {};
		if (cmd.args) result.args = toJsonSchema(cmd.args);
		if (cmd.env) result.env = toJsonSchema(cmd.env);
		if (cmd.options) result.options = toJsonSchema(cmd.options);
		if (cmd.output) result.output = toJsonSchema(cmd.output);
		if (options.globals?.schema) result.globals = toJsonSchema(options.globals.schema);
		writeln(format(result, format$3));
		return;
	}
	if ("help" in resolved) {
		writeln(formatRoot(`${name} ${resolved.path}`, {
			configFlag,
			description: resolved.description,
			globals: options.globals,
			commands: collectHelpCommands(resolved.commands)
		}));
		return;
	}
	let updateCta;
	if (human && options.update !== false) {
		const update = check(name, updateOptions);
		if (update) updateCta = {
			description: `Update available for ${update.name}:`,
			commands: [{
				command: `${displayName} --update`,
				description: `upgrade from ${update.current} to ${update.latest}`
			}]
		};
	}
	const noticeCta = mergeFormattedCtas(skillsCta, updateCta);
	const start = performance.now();
	const resolvedFormat = "command" in resolved && resolved.command.format;
	const format$2 = formatExplicit ? formatFlag : resolvedFormat || options.format || "toon";
	if (format$2 === "yaml") await load();
	const rootFallbackBlocked = "error" in resolved && !resolved.path && (() => {
		const candidates = [...resolved.commands.keys()];
		for (const b of builtinCommands) candidates.push(b.name);
		return suggest(resolved.error, candidates) !== void 0;
	})();
	const effective = "error" in resolved && options.rootFetch && !resolved.path && !rootFallbackBlocked ? {
		fetchGateway: {
			_fetch: true,
			fetch: options.rootFetch,
			description: options.description
		},
		middlewares: [],
		path: name,
		rest: filtered
	} : "error" in resolved && options.rootCommand && !resolved.path && !rootFallbackBlocked ? {
		command: options.rootCommand,
		path: name,
		rest: filtered
	} : resolved;
	const effectiveOutputPolicy = "outputPolicy" in resolved && resolved.outputPolicy || options.outputPolicy;
	const renderOutput = !(human && !formatExplicit && effectiveOutputPolicy === "agent-only");
	const filterPaths = filterOutput ? parse$1(filterOutput) : void 0;
	function truncate(s) {
		if (tokenLimit == null && tokenOffset == null) return {
			text: s,
			truncated: false
		};
		const total = estimateTokenCount(s);
		const offset = tokenOffset ?? 0;
		const end = tokenLimit != null ? offset + tokenLimit : total;
		if (offset === 0 && end >= total) return {
			text: s,
			truncated: false
		};
		const sliced = sliceByTokens(s, offset, end);
		const actualEnd = Math.min(end, total);
		const nextOffset = actualEnd < total ? actualEnd : void 0;
		return {
			text: `${sliced}\n[truncated: showing tokens ${offset}–${actualEnd} of ${total}]`,
			truncated: true,
			nextOffset
		};
	}
	function write(output) {
		if (filterPaths && output.ok && output.data != null) output = {
			...output,
			data: apply(output.data, filterPaths)
		};
		if (noticeCta) {
			const existing = output.meta.cta;
			output = {
				...output,
				meta: {
					...output.meta,
					cta: existing ? {
						description: existing.description,
						commands: [...existing.commands, ...noticeCta.commands]
					} : noticeCta
				}
			};
		}
		if (tokenCount) {
			const base = output.ok ? output.data : output.error;
			const formatted = base != null ? format(base, format$2) : "";
			return writeln(String(estimateTokenCount(formatted)));
		}
		const cta = output.meta.cta;
		if (human && !fullOutput) {
			if (output.ok && output.data != null && renderOutput) writeln(truncate(format(output.data, format$2)).text);
			else if (!output.ok) writeln(formatHumanError(output.error));
			if (cta) writeln(formatHumanCta(cta));
			return;
		}
		if (fullOutput) {
			if (tokenLimit != null || tokenOffset != null) {
				const t = truncate(output.ok && output.data != null ? format(output.data, format$2) : !output.ok ? format(output.error, format$2) : "");
				if (t.truncated) {
					const envelope = output.ok ? {
						ok: true,
						data: t.text
					} : {
						ok: false,
						error: t.text
					};
					const meta = { ...output.meta };
					if (t.nextOffset != null) meta.nextOffset = t.nextOffset;
					envelope.meta = meta;
					return writeln(format(envelope, format$2));
				}
			}
			return writeln(format(output, format$2));
		}
		const base = output.ok ? output.data : output.error;
		const formatted = format(base, format$2);
		if (!cta) {
			if (formatted) writeln(truncate(formatted).text);
			return;
		}
		writeln(truncate(format(typeof base === "object" && base !== null ? {
			...base,
			cta
		} : {
			data: base,
			cta
		}, format$2)).text);
	}
	if ("error" in effective) {
		const helpCmd = effective.path ? `${name} ${effective.path} --help` : `${name} --help`;
		const parent = effective.path ? `${name} ${effective.path}` : name;
		const candidates = "commands" in effective ? [...effective.commands.keys()] : [];
		if (!effective.path) for (const b of builtinCommands) candidates.push(b.name);
		const suggestion = suggest(effective.error, candidates);
		const didYouMean = suggestion ? ` Did you mean '${suggestion}'?` : "";
		const message = `'${effective.error}' is not a command for '${parent}'.${didYouMean}`;
		const ctaCommands = [];
		if (suggestion) {
			const corrected = argv.map((t) => t === effective.error ? suggestion : t);
			ctaCommands.push({ command: `${name} ${corrected.join(" ")}` });
		}
		ctaCommands.push({
			command: helpCmd,
			description: "see all available commands"
		});
		const cta = {
			description: ctaCommands.length === 1 ? "Suggested command:" : "Suggested commands:",
			commands: ctaCommands
		};
		if (human && !fullOutput) {
			writeln(formatHumanError({
				code: "COMMAND_NOT_FOUND",
				message
			}));
			writeln(formatHumanCta(noticeCta ? {
				...cta,
				commands: [...cta.commands, ...noticeCta.commands]
			} : cta));
			exit(1);
			return;
		}
		write({
			ok: false,
			error: {
				code: "COMMAND_NOT_FOUND",
				message
			},
			meta: {
				command: effective.error,
				cta,
				duration: `${Math.round(performance.now() - start)}ms`
			}
		});
		exit(1);
		return;
	}
	if ("fetchGateway" in effective) {
		if (!parseGlobalOptions(true)) return;
		const { fetchGateway, path, rest: fetchRest } = effective;
		const fetchMiddleware = [...options.middlewares ?? [], ...effective.middlewares ?? []];
		const runFetch = async () => {
			const input = parseArgv(fetchRest);
			if (fetchGateway.basePath) input.path = fetchGateway.basePath + input.path;
			const request = buildRequest$1(input);
			const response = await fetchGateway.fetch(request);
			if (isStreamingResponse(response)) {
				await handleStreaming(parseStreamingResponse(response), {
					name,
					path,
					start,
					format: format$2,
					formatExplicit,
					human,
					renderOutput,
					fullOutput,
					truncate,
					write,
					writeln,
					exit
				});
				return;
			}
			const output = await parseResponse(response);
			if (output.ok) write({
				ok: true,
				data: output.data,
				meta: {
					command: path,
					duration: `${Math.round(performance.now() - start)}ms`
				}
			});
			else {
				write({
					ok: false,
					error: {
						code: `HTTP_${output.status}`,
						message: typeof output.data === "object" && output.data !== null && "message" in output.data ? String(output.data.message) : typeof output.data === "string" ? output.data : `HTTP ${output.status}`
					},
					meta: {
						command: path,
						duration: `${Math.round(performance.now() - start)}ms`
					}
				});
				exit(1);
			}
		};
		try {
			const cliEnv = options.envSchema ? parseEnv(options.envSchema, options.env ?? process.env) : {};
			if (fetchMiddleware.length > 0) {
				const varsMap = options.vars ? options.vars.parse({}) : {};
				const errorFn = (opts) => ({
					[sentinel]: "error",
					...opts
				});
				const mwCtx = {
					agent: !human,
					command: path,
					displayName,
					env: cliEnv,
					error: errorFn,
					format: format$2,
					formatExplicit,
					globals,
					name,
					set(key, value) {
						varsMap[key] = value;
					},
					var: varsMap,
					version: options.version
				};
				const handleMwSentinel = (result) => {
					if (!isSentinel(result) || result[sentinel] !== "error") return;
					const err = result;
					const cta = formatCtaBlock(displayName, err.cta);
					write({
						ok: false,
						error: {
							code: err.code,
							message: err.message,
							...err.retryable !== void 0 ? { retryable: err.retryable } : void 0
						},
						meta: {
							command: path,
							duration: `${Math.round(performance.now() - start)}ms`,
							...cta ? { cta } : void 0
						}
					});
					exit(err.exitCode ?? 1);
				};
				await fetchMiddleware.reduceRight((next, mw) => async () => {
					handleMwSentinel(await mw(mwCtx, next));
				}, runFetch)();
			} else await runFetch();
		} catch (error) {
			write({
				ok: false,
				error: {
					code: error instanceof IncurError ? error.code : "UNKNOWN",
					message: error instanceof Error ? error.message : String(error)
				},
				meta: {
					command: path,
					duration: `${Math.round(performance.now() - start)}ms`
				}
			});
			exit(error instanceof IncurError ? error.exitCode ?? 1 : 1);
		}
		return;
	}
	const { command, path, rest: commandRest } = effective;
	if (!parseGlobalOptions(true)) return;
	const allMiddleware = [
		...options.middlewares ?? [],
		..."middlewares" in resolved ? resolved.middlewares ?? [] : [],
		...command.middleware ?? []
	];
	if (human) emitDeprecationWarnings(commandRest, command.options, command.alias);
	let defaults;
	if (configEnabled) try {
		defaults = await loadCommandOptionDefaults(name, path, {
			configDisabled,
			configPath,
			files: options.config?.files,
			loader: options.config?.loader
		});
	} catch (error) {
		write({
			ok: false,
			error: {
				code: error instanceof IncurError ? error.code : "UNKNOWN",
				message: error instanceof Error ? error.message : String(error)
			},
			meta: {
				command: path,
				duration: `${Math.round(performance.now() - start)}ms`
			}
		});
		exit(error instanceof IncurError ? error.exitCode ?? 1 : 1);
		return;
	}
	const result = await execute(command, {
		agent: !human,
		argv: commandRest,
		defaults,
		displayName,
		env: options.envSchema,
		envSource: options.env,
		format: format$2,
		formatExplicit,
		globals,
		inputOptions: {},
		middlewares: allMiddleware,
		name,
		path,
		vars: options.vars,
		version: options.version
	});
	const duration = `${Math.round(performance.now() - start)}ms`;
	if ("stream" in result) {
		await handleStreaming(result.stream, {
			name: displayName,
			path,
			start,
			format: format$2,
			formatExplicit,
			human,
			renderOutput,
			fullOutput,
			truncate,
			write,
			writeln,
			exit
		});
		return;
	}
	if (result.ok) {
		const cta = formatCtaBlock(displayName, result.cta);
		write({
			ok: true,
			data: result.data,
			meta: {
				command: path,
				duration,
				...cta ? { cta } : void 0
			}
		});
	} else {
		const cta = formatCtaBlock(displayName, result.cta);
		if (human && !formatExplicit && result.error.fieldErrors) {
			writeln(formatHumanValidationError(displayName, path, command, new ValidationError({
				message: result.error.message,
				fieldErrors: result.error.fieldErrors
			}), options.env, configFlag));
			exit(1);
			return;
		}
		write({
			ok: false,
			error: {
				code: result.error.code,
				message: result.error.message,
				...result.error.retryable !== void 0 ? { retryable: result.error.retryable } : void 0,
				...result.error.fieldErrors ? { fieldErrors: result.error.fieldErrors } : void 0
			},
			meta: {
				command: path,
				duration,
				...cta ? { cta } : void 0
			}
		});
		exit(result.exitCode ?? 1);
	}
}
/** @internal Creates a lazy MCP HTTP handler scoped to a CLI instance. */
function createMcpHttpHandler(name, version, options = {}) {
	let session;
	async function createServer(commands, mcpOptions, stateless) {
		const { fromJsonSchema, McpServer, WebStandardStreamableHTTPServerTransport } = await import("./dist2.js").then((n) => n.t);
		const server = new McpServer({
			name,
			...options.title ? { title: options.title } : void 0,
			version
		}, options.instructions ? { instructions: options.instructions } : void 0);
		registerTools(server, commands, {
			env: mcpOptions?.env,
			fromJsonSchema,
			middlewares: mcpOptions?.middlewares,
			name,
			request: (extra) => extra?.http?.req,
			sendNotification: (notification) => server.server.notification(notification),
			tools: options.tools,
			vars: mcpOptions?.vars,
			version
		});
		const transport = new WebStandardStreamableHTTPServerTransport(stateless ? { enableJsonResponse: true } : {
			sessionIdGenerator: () => crypto.randomUUID(),
			enableJsonResponse: true
		});
		await server.connect(transport);
		return {
			server,
			transport
		};
	}
	return async (req, commands, mcpOptions) => {
		const stateless = options.stateless ?? true;
		if (stateless && req.method !== "POST") return new Response(null, {
			status: 405,
			headers: { Allow: "POST" }
		});
		if (!stateless) {
			session ??= createServer(commands, mcpOptions, false).catch((error) => {
				session = void 0;
				throw error;
			});
			return (await session).transport.handleRequest(req);
		}
		const abortReason = () => req.signal.reason ?? new DOMException("This operation was aborted", "AbortError");
		if (req.signal.aborted) throw abortReason();
		const { server, transport } = await createServer(commands, mcpOptions, true);
		let closing;
		const close = () => closing ??= server.close();
		let rejectAbort;
		const aborted = new Promise((_resolve, reject) => {
			rejectAbort = reject;
		});
		let didAbort = false;
		const abort = () => {
			if (didAbort) return;
			didAbort = true;
			rejectAbort(abortReason());
			close();
		};
		req.signal.addEventListener("abort", abort, { once: true });
		if (req.signal.aborted) abort();
		try {
			if (req.signal.aborted) return await aborted;
			return await Promise.race([transport.handleRequest(req), aborted]);
		} finally {
			req.signal.removeEventListener("abort", abort);
			await close();
		}
	};
}
function isOpenapiRoute(segments) {
	if (segments.length === 1) return segments[0] === "openapi.json" || segments[0] === "openapi.yml" || segments[0] === "openapi.yaml";
	return segments[0] === ".well-known" && segments[1] === "openapi.json" && segments.length === 2;
}
function generatedOpenapi(name, commands, options) {
	const openapiCli = {
		name,
		description: options.description
	};
	toCommands.set(openapiCli, commands);
	if (options.rootCommand) toRootDefinition.set(openapiCli, options.rootCommand);
	return fromCli(openapiCli, {
		title: name,
		...options.version ? { version: options.version } : void 0,
		...options.description ? { description: options.description } : void 0
	});
}
/** @internal Handles an HTTP request by resolving a command and returning a JSON Response. */
async function fetchImpl(name, commands, req, options = {}) {
	const start = performance.now();
	const url = new URL(req.url);
	const segments = url.pathname.split("/").filter(Boolean);
	if (req.method === "GET" && isOpenapiRoute(segments)) {
		const spec = generatedOpenapi(name, commands, options);
		const yaml = segments[0] === "openapi.yml" || segments[0] === "openapi.yaml";
		return new Response(yaml ? (await load()).stringify(spec) : JSON.stringify(spec), {
			status: 200,
			headers: {
				"content-type": yaml ? "application/yaml" : "application/json",
				"cache-control": "public, max-age=300"
			}
		});
	}
	if (segments[0] === "mcp" && segments.length === 1 && options.mcpHandler) return options.mcpHandler(req, commands, {
		middlewares: options.middlewares,
		env: options.envSchema,
		vars: options.vars
	});
	if (segments[0] === ".well-known" && segments[1] === "skills" && segments.length >= 3 && req.method === "GET") {
		await load();
		const groups = /* @__PURE__ */ new Map();
		const cmds = collectSkillCommands(commands, [], groups, options.rootCommand);
		if (segments[2] === "index.json" && segments.length === 3) {
			const skills = split(name, cmds, 1, groups).map((f) => {
				const fmMatch = f.content.match(/^---\n([\s\S]*?)\n---/);
				const meta = fmMatch ? loadSync().parse(fmMatch[1]) : {};
				return {
					name: f.dir || name,
					description: meta.description ?? "",
					files: ["SKILL.md"]
				};
			});
			return new Response(JSON.stringify({ skills }), {
				status: 200,
				headers: {
					"content-type": "application/json",
					"cache-control": "public, max-age=300"
				}
			});
		}
		if (segments.length === 4 && segments[3] === "SKILL.md") {
			const skillName = segments[2];
			const file = split(name, cmds, 1, groups).find((f) => (f.dir || name) === skillName);
			if (file) return new Response(file.content, {
				status: 200,
				headers: {
					"content-type": "text/markdown",
					"cache-control": "public, max-age=300"
				}
			});
			return new Response("Not Found", { status: 404 });
		}
		return new Response("Not Found", { status: 404 });
	}
	let inputOptions = {};
	if (req.method === "GET") for (const [key, value] of url.searchParams) inputOptions[key] = value;
	else try {
		if ((req.headers.get("content-type") ?? "").includes("application/json")) inputOptions = await req.json();
	} catch {}
	function jsonResponse(body, status) {
		return new Response(stringify(body), {
			status,
			headers: { "content-type": "application/json" }
		});
	}
	if (segments.length === 0) {
		if (options.rootCommand) return executeCommand(name, options.rootCommand, [], inputOptions, req, start, options);
		return jsonResponse({
			ok: false,
			error: {
				code: "COMMAND_NOT_FOUND",
				message: "No root command defined."
			},
			meta: {
				command: "/",
				duration: `${Math.round(performance.now() - start)}ms`
			}
		}, 404);
	}
	const resolved = resolveCommand(commands, segments);
	if ("error" in resolved) {
		const parent = resolved.path ? `${name} ${resolved.path}` : name;
		const suggestion = suggest(resolved.error, resolved.commands.keys());
		const didYouMean = suggestion ? ` Did you mean '${suggestion}'?` : "";
		return jsonResponse({
			ok: false,
			error: {
				code: "COMMAND_NOT_FOUND",
				message: `'${resolved.error}' is not a command for '${parent}'.${didYouMean}`
			},
			meta: {
				command: resolved.error,
				duration: `${Math.round(performance.now() - start)}ms`
			}
		}, 404);
	}
	if ("help" in resolved) return jsonResponse({
		ok: false,
		error: {
			code: "COMMAND_NOT_FOUND",
			message: `'${resolved.path}' is a command group. Specify a subcommand.`
		},
		meta: {
			command: resolved.path,
			duration: `${Math.round(performance.now() - start)}ms`
		}
	}, 404);
	if ("fetchGateway" in resolved) return resolved.fetchGateway.fetch(req);
	const { command, path, rest } = resolved;
	const groupMiddlewares = "middlewares" in resolved ? resolved.middlewares : [];
	return executeCommand(path, command, rest, inputOptions, req, start, {
		...options,
		groupMiddlewares
	});
}
/** @internal Executes a resolved command for the fetch handler and returns a JSON Response. */
async function executeCommand(path, command, rest, inputOptions, request, start, options) {
	function jsonResponse(body, status) {
		return new Response(stringify(body), {
			status,
			headers: { "content-type": "application/json" }
		});
	}
	const allMiddleware = [
		...options.middlewares ?? [],
		...options.groupMiddlewares ?? [],
		...command.middleware ?? []
	];
	let globals = {};
	let commandInputOptions = inputOptions;
	if (options.globals) {
		const globalKeys = new Set(Object.keys(options.globals.schema.shape));
		const rawGlobals = {};
		commandInputOptions = {};
		for (const [key, value] of Object.entries(inputOptions)) if (globalKeys.has(key)) rawGlobals[key] = value;
		else commandInputOptions[key] = value;
		try {
			globals = options.globals.schema.parse(rawGlobals);
		} catch (error) {
			return jsonResponse({
				ok: false,
				error: {
					code: "VALIDATION_ERROR",
					message: (error?.issues ?? error?.error?.issues ?? []).map((i) => i.message).join("; ") || "Validation failed"
				},
				meta: {
					command: path,
					duration: `${Math.round(performance.now() - start)}ms`
				}
			}, 400);
		}
	}
	const result = await execute(command, {
		agent: true,
		argv: rest,
		env: options.envSchema,
		format: "json",
		formatExplicit: true,
		globals,
		inputOptions: commandInputOptions,
		middlewares: allMiddleware,
		name: options.name ?? path,
		parseMode: "split",
		path,
		request,
		vars: options.vars,
		version: options.version
	});
	const duration = `${Math.round(performance.now() - start)}ms`;
	if ("stream" in result) {
		const iterator = result.stream;
		const encoder = new TextEncoder();
		const meta = (cta) => ({
			command: path,
			duration: `${Math.round(performance.now() - start)}ms`,
			...cta ? { cta } : void 0
		});
		const errorRecord = (err) => ({
			type: "error",
			ok: false,
			error: {
				code: err.code,
				message: err.message,
				...err.retryable !== void 0 ? { retryable: err.retryable } : void 0
			},
			meta: meta(formatCtaBlock(options.name ?? path, err.cta))
		});
		const stream = new ReadableStream({
			async cancel() {
				await iterator.return(void 0);
			},
			async pull(controller) {
				try {
					const { value, done } = await iterator.next();
					if (done) {
						if (isSentinel(value) && value[sentinel] === "error") {
							controller.enqueue(encoder.encode(stringify(errorRecord(value)) + "\n"));
							controller.close();
							return;
						}
						const cta = isSentinel(value) && value[sentinel] === "ok" ? formatCtaBlock(options.name ?? path, value.cta) : void 0;
						controller.enqueue(encoder.encode(stringify({
							type: "done",
							ok: true,
							meta: meta(cta)
						}) + "\n"));
						controller.close();
						return;
					}
					if (isSentinel(value) && value[sentinel] === "error") {
						controller.enqueue(encoder.encode(stringify(errorRecord(value)) + "\n"));
						await iterator.return(void 0);
						controller.close();
						return;
					}
					controller.enqueue(encoder.encode(stringify({
						type: "chunk",
						data: value
					}) + "\n"));
				} catch (error) {
					controller.enqueue(encoder.encode(stringify({
						type: "error",
						ok: false,
						error: {
							code: error instanceof IncurError ? error.code : "UNKNOWN",
							message: error instanceof Error ? error.message : String(error),
							...error instanceof IncurError ? { retryable: error.retryable } : void 0
						},
						meta: meta()
					}) + "\n"));
					controller.close();
				}
			}
		});
		return new Response(stream, {
			status: 200,
			headers: { "content-type": "application/x-ndjson" }
		});
	}
	if (!result.ok) {
		const cta = formatCtaBlock(options.name ?? path, result.cta);
		return jsonResponse({
			ok: false,
			error: {
				code: result.error.code,
				message: result.error.message,
				...result.error.retryable !== void 0 ? { retryable: result.error.retryable } : void 0,
				...result.error.fieldErrors ? { fieldErrors: result.error.fieldErrors } : void 0
			},
			meta: {
				command: path,
				duration,
				...cta ? { cta } : void 0
			}
		}, result.error.code === "VALIDATION_ERROR" ? 400 : 500);
	}
	const cta = formatCtaBlock(options.name ?? path, result.cta);
	return jsonResponse({
		ok: true,
		data: result.data,
		meta: {
			command: path,
			duration,
			...cta ? { cta } : void 0
		}
	}, 200);
}
/** @internal Formats a validation error for TTY with usage hint. */
function formatHumanValidationError(cli, path, command, error, envSource, configFlag) {
	const lines = [];
	for (const fe of error.fieldErrors) {
		const line = (() => {
			const target = formatValidationTarget(command, fe.path);
			if (fe.missing) return `Error: missing required ${target.kind} ${target.label}`;
			if (target.kind === "environment variable") return `Error: invalid value for environment variable ${target.label}: ${fe.message}`;
			return `Error: invalid value for ${target.label}: ${fe.message}`;
		})();
		lines.push(line);
	}
	lines.push("See below for usage.");
	lines.push("");
	lines.push(formatCommand(path === cli ? cli : `${cli} ${path}`, {
		alias: command.alias,
		configFlag,
		description: command.description,
		args: command.args,
		env: command.env,
		envSource,
		hint: command.hint,
		options: command.options,
		examples: formatExamples(command.examples),
		usage: command.usage
	}));
	return lines.join("\n");
}
/** @internal Formats a field path as an option flag, env name, or positional placeholder. */
function formatValidationTarget(command, path) {
	const [head, ...tail] = path.split(".");
	if (!head) return {
		kind: "argument",
		label: "input"
	};
	if (command.options?.shape[head]) {
		const suffix = tail.length > 0 ? `.${tail.join(".")}` : "";
		return {
			kind: "option",
			label: `--${toKebab(head)}${suffix}`
		};
	}
	if (command.env?.shape[head]) return {
		kind: "environment variable",
		label: `${head}${tail.length > 0 ? `.${tail.join(".")}` : ""}`
	};
	return {
		kind: "argument",
		label: `<${path}>`
	};
}
/** @internal Resolves a command from the tree by walking tokens until a leaf is found. */
function resolveCommand(commands, tokens) {
	const [first, ...rest] = tokens;
	if (!first || !commands.has(first)) return {
		error: first ?? "(none)",
		path: "",
		commands,
		rest
	};
	let entry = resolveAlias(commands, commands.get(first));
	const path = [first];
	let remaining = rest;
	let inheritedOutputPolicy;
	const collectedMiddlewares = [];
	if (isFetchGateway(entry)) {
		const outputPolicy = entry.outputPolicy ?? inheritedOutputPolicy;
		return {
			fetchGateway: entry,
			middlewares: collectedMiddlewares,
			path: path.join(" "),
			rest: remaining,
			...outputPolicy ? { outputPolicy } : void 0
		};
	}
	while (isGroup(entry)) {
		if (entry.outputPolicy) inheritedOutputPolicy = entry.outputPolicy;
		if (entry.middlewares) collectedMiddlewares.push(...entry.middlewares);
		const next = remaining[0];
		if (!next) return {
			help: true,
			path: path.join(" "),
			description: entry.description,
			commands: entry.commands
		};
		const rawChild = entry.commands.get(next);
		if (!rawChild) return {
			error: next,
			path: path.join(" "),
			commands: entry.commands,
			rest: remaining.slice(1)
		};
		let child = resolveAlias(entry.commands, rawChild);
		path.push(next);
		remaining = remaining.slice(1);
		entry = child;
		if (isFetchGateway(entry)) {
			const outputPolicy = entry.outputPolicy ?? inheritedOutputPolicy;
			return {
				fetchGateway: entry,
				middlewares: collectedMiddlewares,
				path: path.join(" "),
				rest: remaining,
				...outputPolicy ? { outputPolicy } : void 0
			};
		}
	}
	const outputPolicy = entry.outputPolicy ?? inheritedOutputPolicy;
	return {
		command: entry,
		middlewares: collectedMiddlewares,
		path: path.join(" "),
		rest: remaining,
		...outputPolicy ? { outputPolicy } : void 0
	};
}
/** @internal Extracts built-in flags from argv. */
var validFormats = /* @__PURE__ */ new Set([
	"toon",
	"json",
	"yaml",
	"md",
	"jsonl"
]);
function extractBuiltinFlags(argv, options = {}) {
	let fullOutput = false;
	let llms = false;
	let llmsFull = false;
	let mcp = false;
	let help = false;
	let update = false;
	let updateCheck = false;
	let version = false;
	let schema = false;
	let format = "toon";
	let formatExplicit = false;
	let configPath;
	let configDisabled = false;
	let filterOutput;
	let tokenLimit;
	let tokenOffset;
	let tokenCount = false;
	const rest = [];
	const cfgFlag = options.configFlag ? `--${options.configFlag}` : void 0;
	const cfgFlagEq = options.configFlag ? `--${options.configFlag}=` : void 0;
	const noCfgFlag = options.configFlag ? `--no-${options.configFlag}` : void 0;
	for (let i = 0; i < argv.length; i++) {
		const token = argv[i];
		if (token === "--full-output") fullOutput = true;
		else if (token === "--llms") llms = true;
		else if (token === "--llms-full") llmsFull = true;
		else if (token === "--mcp") mcp = true;
		else if (token === "--help" || token === "-h") help = true;
		else if (token === "--update") update = true;
		else if (token === "--incur-update-check") updateCheck = true;
		else if (token === "--version" && (argv[i + 1] === void 0 || argv[i + 1].startsWith("-"))) version = true;
		else if (token === "--schema") schema = true;
		else if (token === "--json") {
			format = "json";
			formatExplicit = true;
		} else if (token === "--format" && argv[i + 1]) {
			if (!validFormats.has(argv[i + 1])) throw new ParseError({ message: `Invalid format: "${argv[i + 1]}". Expected one of: ${[...validFormats].join(", ")}` });
			format = argv[i + 1];
			formatExplicit = true;
			i++;
		} else if (cfgFlag && token === cfgFlag) {
			const value = argv[i + 1];
			if (value === void 0) throw new ParseError({ message: `Missing value for flag: ${cfgFlag}` });
			configPath = value;
			configDisabled = false;
			i++;
		} else if (cfgFlagEq && token.startsWith(cfgFlagEq)) {
			const value = token.slice(cfgFlagEq.length);
			if (value.length === 0) throw new ParseError({ message: `Missing value for flag: ${cfgFlag}` });
			configPath = value;
			configDisabled = false;
		} else if (noCfgFlag && token === noCfgFlag) {
			configPath = void 0;
			configDisabled = true;
		} else if (token === "--filter-output" && argv[i + 1]) {
			filterOutput = argv[i + 1];
			i++;
		} else if (token === "--token-limit" && argv[i + 1]) {
			const n = Number(argv[i + 1]);
			if (!Number.isFinite(n) || argv[i + 1].trim() === "") throw new ParseError({ message: `Invalid value for --token-limit: "${argv[i + 1]}"` });
			tokenLimit = n;
			i++;
		} else if (token === "--token-offset" && argv[i + 1]) {
			const n = Number(argv[i + 1]);
			if (!Number.isFinite(n) || argv[i + 1].trim() === "") throw new ParseError({ message: `Invalid value for --token-offset: "${argv[i + 1]}"` });
			tokenOffset = n;
			i++;
		} else if (token === "--token-count") tokenCount = true;
		else rest.push(token);
	}
	return {
		fullOutput,
		format,
		formatExplicit,
		configPath,
		configDisabled,
		filterOutput,
		tokenLimit,
		tokenOffset,
		tokenCount,
		llms,
		llmsFull,
		mcp,
		help,
		update,
		updateCheck,
		version,
		schema,
		rest
	};
}
/** @internal Loads config-backed option defaults for the active command. */
async function loadCommandOptionDefaults(cli, path, options = {}) {
	if (options.configDisabled) return void 0;
	const { loader } = options;
	let targetPath;
	if (options.configPath) targetPath = resolveConfigPath(options.configPath);
	else targetPath = await findFirstExisting(options.files ?? [`${cli}.json`]);
	let parsed;
	if (loader) {
		const result = await loader(targetPath);
		if (result === void 0) return void 0;
		if (!isRecord(result)) throw new ParseError({ message: "Config loader must return a plain object or undefined" });
		parsed = result;
	} else {
		if (!targetPath) return void 0;
		const result = await readJsonConfig(targetPath, !!options.configPath);
		if (!result) return void 0;
		parsed = result;
	}
	return extractCommandSection(parsed, cli, path);
}
/** @internal Resolves a config file path, expanding `~` to home dir. */
function resolveConfigPath(filePath) {
	if (filePath.startsWith("~/") || filePath === "~") return path$1.join(os$1.homedir(), filePath.slice(1));
	return path$1.resolve(process.cwd(), filePath);
}
/** @internal Returns the first readable file from a list of paths, or `undefined`. */
async function findFirstExisting(paths) {
	for (const p of paths) {
		const resolved = resolveConfigPath(p);
		try {
			await fs$1.access(resolved, fs$1.constants.R_OK);
			return resolved;
		} catch {}
	}
}
/** @internal Reads and parses a JSON config file. */
async function readJsonConfig(targetPath, explicit) {
	let raw;
	try {
		raw = await fs$1.readFile(targetPath, "utf8");
	} catch (error) {
		if (error.code === "ENOENT") {
			if (explicit) throw new ParseError({ message: `Config file not found: ${targetPath}` });
			return;
		}
		throw error;
	}
	let parsed;
	try {
		parsed = JSON.parse(raw);
	} catch (error) {
		throw new ParseError({
			message: `Invalid JSON config file: ${targetPath}`,
			cause: error instanceof Error ? error : void 0
		});
	}
	if (!isRecord(parsed)) throw new ParseError({ message: `Invalid config file: expected a top-level object in ${targetPath}` });
	return parsed;
}
/** @internal Walks the nested config tree to extract option defaults for a command path. */
function extractCommandSection(parsed, cli, path) {
	const segments = path === cli ? [] : path.split(" ");
	let node = parsed;
	for (const seg of segments) {
		if (!isRecord(node)) return void 0;
		const commands = node.commands;
		if (!isRecord(commands)) return void 0;
		node = commands[seg];
		if (node === void 0) return void 0;
	}
	if (!isRecord(node)) throw new ParseError({ message: `Invalid config section for '${path}': expected an object` });
	const options = node.options;
	if (options === void 0) return void 0;
	if (!isRecord(options)) throw new ParseError({ message: `Invalid config 'options' for '${path}': expected an object` });
	return Object.keys(options).length > 0 ? options : void 0;
}
/** @internal Collects immediate child commands/groups for help output. */
function collectHelpCommands(commands) {
	const result = [];
	for (const [name, entry] of commands) {
		if (isAlias(entry)) continue;
		result.push({
			name,
			description: entry.description
		});
	}
	return result.sort((a, b) => a.name.localeCompare(b.name));
}
/** @internal Finds the index of a builtin command token in the filtered argv. Returns -1 if not found. */
function builtinIdx(filtered, cliName, builtin) {
	if (findBuiltin(filtered[0])?.name === builtin) return 0;
	if (filtered[0] === cliName && findBuiltin(filtered[1])?.name === builtin) return 1;
	return -1;
}
/** @internal Formats group-level help for a built-in command (e.g. `cli skills`). */
function formatBuiltinHelp(cli, builtin) {
	return formatRoot(`${cli} ${builtin.name}`, {
		aliases: builtin.aliases,
		description: builtin.description,
		commands: builtin.subcommands?.map((s) => ({
			name: s.name,
			description: s.description
		}))
	});
}
/** @internal Formats subcommand-level help for a built-in command (e.g. `cli skills add --help`). */
function formatBuiltinSubcommandHelp(cli, builtin, subName) {
	const sub = findBuiltinSubcommand(builtin, subName);
	return formatCommand(`${cli} ${builtin.name} ${subName}`, {
		alias: sub?.alias,
		aliases: sub?.aliases,
		description: sub?.description,
		hideGlobalOptions: true,
		options: sub?.options
	});
}
async function runMcpDoctor(name, commands, options) {
	const warnings = [];
	const errors = [];
	const input = new PassThrough();
	const output = new PassThrough();
	const chunks = [];
	output.on("data", (chunk) => chunks.push(chunk.toString()));
	let serveError;
	const done = serve(options.mcp?.name ?? name, options.version ?? "0.0.0", commands, {
		input,
		output,
		middlewares: options.middlewares,
		env: options.envSchema,
		vars: options.vars,
		version: options.version,
		...options.mcp?.instructions ? { instructions: options.mcp.instructions } : void 0,
		...options.mcp?.title ? { title: options.mcp.title } : void 0,
		tools: {
			...options.mcp?.tools,
			discovery: "direct"
		}
	}).catch((error) => {
		serveError = error;
	});
	let serveFinished = false;
	done.finally(() => {
		serveFinished = true;
	});
	input.write(`${stringify({
		jsonrpc: "2.0",
		id: 1,
		method: "initialize",
		params: {
			protocolVersion: "2024-11-05",
			capabilities: {},
			clientInfo: {
				name: "incur-doctor",
				version: "1.0.0"
			}
		}
	})}\n`);
	input.write(`${stringify({
		jsonrpc: "2.0",
		id: 2,
		method: "tools/list",
		params: {}
	})}\n`);
	await waitForMcpDoctorResponses(chunks, () => serveFinished);
	input.end();
	await done;
	if (serveError) return {
		ok: false,
		toolCount: 0,
		tools: [],
		warnings,
		errors: [{
			code: "MCP_SERVER_FAILED",
			message: errorMessage(serveError)
		}]
	};
	let responses;
	try {
		responses = parseMcpDoctorResponses(chunks);
	} catch (error) {
		return {
			ok: false,
			toolCount: 0,
			tools: [],
			warnings,
			errors: [{
				code: "MCP_RESPONSE_PARSE_FAILED",
				message: errorMessage(error)
			}]
		};
	}
	const initialize = responses.find((response) => response.id === 1);
	if (!initialize) errors.push({
		code: "MCP_INITIALIZE_MISSING",
		message: "Missing initialize response."
	});
	else if (initialize.error) errors.push({
		code: "MCP_INITIALIZE_FAILED",
		message: mcpErrorMessage(initialize.error)
	});
	const toolsList = responses.find((response) => response.id === 2);
	let tools = [];
	if (!toolsList) errors.push({
		code: "MCP_TOOLS_LIST_MISSING",
		message: "Missing tools/list response."
	});
	else if (toolsList.error) errors.push({
		code: "MCP_TOOLS_LIST_FAILED",
		message: mcpErrorMessage(toolsList.error)
	});
	else if (!isRecord(toolsList.result) || !Array.isArray(toolsList.result.tools)) errors.push({
		code: "MCP_TOOLS_LIST_INVALID",
		message: "tools/list did not return a tools array."
	});
	else tools = toolsList.result.tools.filter(isRecord).map((tool) => ({
		name: typeof tool.name === "string" ? tool.name : "",
		...typeof tool.description === "string" ? { description: tool.description } : void 0
	})).filter((tool) => tool.name);
	if (errors.length === 0 && tools.length === 0) warnings.push("No MCP tools exposed.");
	return {
		ok: errors.length === 0,
		toolCount: tools.length,
		tools,
		warnings,
		errors
	};
}
async function waitForMcpDoctorResponses(chunks, finished) {
	const started = Date.now();
	while (!finished() && (chunks.join("").match(/\n/g)?.length ?? 0) < 2) {
		if (Date.now() - started >= 1e3) return;
		await new Promise((resolve) => setTimeout(resolve, 5));
	}
}
function parseMcpDoctorResponses(chunks) {
	const responses = [];
	for (const line of chunks.join("").split(/\r?\n/)) {
		const trimmed = line.trim();
		if (!trimmed) continue;
		const parsed = JSON.parse(trimmed);
		if (!isRecord(parsed)) throw new Error("Expected JSON-RPC response object.");
		responses.push(parsed);
	}
	return responses;
}
function errorMessage(error) {
	return error instanceof Error ? error.message : String(error);
}
function mcpErrorMessage(error) {
	if (isRecord(error) && typeof error.message === "string") return error.message;
	return stringify(error);
}
/** @internal Formats help text for a fetch gateway command. */
function formatFetchHelp(name, description) {
	const lines = [];
	if (description) lines.push(`${name} — ${description}`);
	else lines.push(name);
	lines.push("");
	lines.push(`Usage: ${name} <path> [options]`);
	lines.push("");
	lines.push("Path segments are joined into the request URL path.");
	lines.push("");
	lines.push("Options:");
	lines.push("  -X, --method <METHOD>     HTTP method (default: GET, POST if body present)");
	lines.push("  -H, --header \"Key: Val\"   Set a request header (repeatable)");
	lines.push("  -d, --data <json>          Request body (implies POST)");
	lines.push("      --body <json>          Request body (implies POST)");
	lines.push("  --<key> <value>            Query string parameter");
	return lines.join("\n");
}
function isFetchSource(value) {
	if (typeof value === "function") return true;
	if (typeof value !== "object" || value === null) return false;
	const source = value;
	return typeof source.fetch === "function" && source.url instanceof URL;
}
function isMcpSourceDefinition(value) {
	if (typeof value !== "object" || value === null || !("mcp" in value)) return false;
	const source = value.mcp;
	if (typeof source === "string" || source instanceof URL) return true;
	return typeof source === "object" && source !== null && "url" in source;
}
function resolveFetch(source) {
	if (typeof source === "function") return source;
	return source.fetch;
}
function fetchBaseUrl(source) {
	return typeof source === "function" ? void 0 : source.url;
}
/** @internal Type guard for command groups. */
function isGroup(entry) {
	return "_group" in entry;
}
/** @internal Type guard for fetch gateways. */
function isFetchGateway(entry) {
	return "_fetch" in entry;
}
/** @internal Type guard for alias entries. */
function isAlias(entry) {
	return "_alias" in entry;
}
/** @internal Follows an alias entry to its canonical target. Returns the entry unchanged if not an alias. */
function resolveAlias(commands, entry) {
	if (isAlias(entry)) return commands.get(entry.target);
	return entry;
}
/** @internal Validates command options against CLI-level global options. */
function assertNoGlobalOptionConflicts(path, entry, globals) {
	if (!globals || isFetchGateway(entry) || isAlias(entry)) return;
	if (isGroup(entry)) {
		for (const [name, child] of entry.commands) assertNoGlobalOptionConflicts(`${path} ${name}`, child, globals);
		return;
	}
	if (entry.options) {
		const globalKeys = Object.keys(globals.schema.shape);
		const optionKeys = Object.keys(entry.options.shape);
		for (const key of optionKeys) if (globalKeys.includes(key)) throw new Error(`Command '${path}' option '${key}' conflicts with a global option. Choose a different name.`);
	}
	if (globals.alias && entry.alias) {
		const globalAliasValues = new Set(Object.values(globals.alias));
		for (const [name, short] of Object.entries(entry.alias)) if (short && globalAliasValues.has(short)) throw new Error(`Command '${path}' alias '-${short}' for '${name}' conflicts with a global alias. Choose a different alias.`);
	}
}
/** @internal Maps CLI instances to their command maps. */
var toCommands = /* @__PURE__ */ new WeakMap();
/** @internal Maps CLI instances to their middleware arrays. */
var toMiddlewares = /* @__PURE__ */ new WeakMap();
/** @internal Maps root CLI instances to their command definitions. */
var toRootDefinition = /* @__PURE__ */ new WeakMap();
/** @internal Maps CLI instances to their root options schema. */
var toRootOptions = /* @__PURE__ */ new WeakMap();
/** @internal Maps CLI instances to whether config file loading is enabled. */
var toConfigEnabled = /* @__PURE__ */ new WeakMap();
/** @internal Maps CLI instances to their output policy. */
var toOutputPolicy = /* @__PURE__ */ new WeakMap();
/** @internal Maps CLI instances to their globals schema and alias map. */
var toGlobals = /* @__PURE__ */ new WeakMap();
/** @internal Maps root CLI instances to their command aliases. */
var toRootAliases = /* @__PURE__ */ new WeakMap();
/** @internal Sentinel symbol for `ok()` and `error()` return values. */
var sentinel = Symbol.for("incur.sentinel");
/** @internal Formats an error for human-readable TTY output. */
function formatHumanError(error) {
	let out = `${error.code === "UNKNOWN" || error.code === "COMMAND_NOT_FOUND" ? "Error" : `Error (${error.code})`}: ${error.message}`;
	if (error.fieldErrors) for (const fe of error.fieldErrors) out += `\n  ${fe.path}: ${fe.message}`;
	return out;
}
/** @internal Formats a CTA block for human-readable TTY output. */
function formatHumanCta(cta) {
	const lines = ["", cta.description];
	const maxLen = Math.max(...cta.commands.map((c) => c.command.length));
	for (const c of cta.commands) {
		const desc = c.description ? `  ${"".padEnd(maxLen - c.command.length)}# ${c.description}` : "";
		lines.push(`  ${c.command}${desc}`);
	}
	return lines.join("\n");
}
/** @internal Merges framework-generated CTA blocks while preserving the first description. */
function mergeFormattedCtas(...blocks) {
	const defined = blocks.filter((block) => block !== void 0);
	if (defined.length === 0) return void 0;
	return {
		description: defined[0].description,
		commands: defined.flatMap((block) => block.commands)
	};
}
/** @internal Type guard for sentinel results. */
function hasRequiredArgs(args) {
	return Object.values(args.shape).some((field) => field._zod.optout !== "optional");
}
function isSentinel(value) {
	return typeof value === "object" && value !== null && sentinel in value;
}
/** @internal Handles streaming output from an async generator `run` handler. */
async function handleStreaming(generator, ctx) {
	const useJsonl = ctx.format === "jsonl";
	if (useJsonl || !ctx.formatExplicit && ctx.format === "toon") try {
		let returnValue;
		while (true) {
			const { value, done } = await generator.next();
			if (done) {
				returnValue = value;
				break;
			}
			if (isSentinel(value)) {
				const tagged = value;
				if (tagged[sentinel] === "error") {
					if (useJsonl) ctx.writeln(JSON.stringify({
						type: "error",
						ok: false,
						error: {
							code: tagged.code,
							message: tagged.message,
							...tagged.retryable !== void 0 ? { retryable: tagged.retryable } : void 0
						}
					}));
					else ctx.writeln(formatHumanError({
						code: tagged.code,
						message: tagged.message
					}));
					ctx.exit(tagged.exitCode ?? 1);
					return;
				}
			}
			if (useJsonl) ctx.writeln(stringify({
				type: "chunk",
				data: value
			}));
			else if (ctx.renderOutput) ctx.writeln(ctx.truncate(format(value, ctx.format)).text);
		}
		if (isSentinel(returnValue) && returnValue[sentinel] === "error") {
			const err = returnValue;
			if (useJsonl) ctx.writeln(JSON.stringify({
				type: "error",
				ok: false,
				error: {
					code: err.code,
					message: err.message,
					...err.retryable !== void 0 ? { retryable: err.retryable } : void 0
				}
			}));
			else ctx.writeln(formatHumanError({
				code: err.code,
				message: err.message
			}));
			ctx.exit(err.exitCode ?? 1);
			return;
		}
		const cta = isSentinel(returnValue) && returnValue[sentinel] === "ok" ? formatCtaBlock(ctx.name, returnValue.cta) : void 0;
		if (useJsonl) ctx.writeln(JSON.stringify({
			type: "done",
			ok: true,
			meta: {
				command: ctx.path,
				duration: `${Math.round(performance.now() - ctx.start)}ms`,
				...cta ? { cta } : void 0
			}
		}));
		else if (cta) ctx.writeln(formatHumanCta(cta));
	} catch (error) {
		if (useJsonl) ctx.writeln(JSON.stringify({
			type: "error",
			ok: false,
			error: {
				code: error instanceof IncurError ? error.code : "UNKNOWN",
				message: error instanceof Error ? error.message : String(error),
				...error instanceof IncurError ? { retryable: error.retryable } : void 0
			}
		}));
		else ctx.writeln(formatHumanError({
			code: "UNKNOWN",
			message: error instanceof Error ? error.message : String(error)
		}));
		ctx.exit(error instanceof IncurError ? error.exitCode ?? 1 : 1);
	}
	else {
		const chunks = [];
		try {
			let returnValue;
			while (true) {
				const { value, done } = await generator.next();
				if (done) {
					returnValue = value;
					break;
				}
				if (isSentinel(value)) {
					const tagged = value;
					if (tagged[sentinel] === "error") {
						ctx.write({
							ok: false,
							error: {
								code: tagged.code,
								message: tagged.message,
								...tagged.retryable !== void 0 ? { retryable: tagged.retryable } : void 0
							},
							meta: {
								command: ctx.path,
								duration: `${Math.round(performance.now() - ctx.start)}ms`
							}
						});
						ctx.exit(tagged.exitCode ?? 1);
						return;
					}
				}
				chunks.push(value);
			}
			if (isSentinel(returnValue) && returnValue[sentinel] === "error") {
				const err = returnValue;
				ctx.write({
					ok: false,
					error: {
						code: err.code,
						message: err.message,
						...err.retryable !== void 0 ? { retryable: err.retryable } : void 0
					},
					meta: {
						command: ctx.path,
						duration: `${Math.round(performance.now() - ctx.start)}ms`
					}
				});
				ctx.exit(err.exitCode ?? 1);
				return;
			}
			const cta = isSentinel(returnValue) && returnValue[sentinel] === "ok" ? formatCtaBlock(ctx.name, returnValue.cta) : void 0;
			ctx.write({
				ok: true,
				data: chunks,
				meta: {
					command: ctx.path,
					duration: `${Math.round(performance.now() - ctx.start)}ms`,
					...cta ? { cta } : void 0
				}
			});
		} catch (error) {
			ctx.write({
				ok: false,
				error: {
					code: error instanceof IncurError ? error.code : "UNKNOWN",
					message: error instanceof Error ? error.message : String(error),
					...error instanceof IncurError ? { retryable: error.retryable } : void 0
				},
				meta: {
					command: ctx.path,
					duration: `${Math.round(performance.now() - ctx.start)}ms`
				}
			});
			ctx.exit(error instanceof IncurError ? error.exitCode ?? 1 : 1);
		}
	}
}
/** @internal Builds the `--llms` index manifest (name + description only) from the command tree. */
function buildIndexManifest(commands, prefix = [], globalsSchema) {
	return {
		version: "incur.v1",
		commands: collectIndexCommands(commands, prefix).sort((a, b) => a.name.localeCompare(b.name)),
		...globalsSchema ? { globals: toJsonSchema(globalsSchema) } : void 0
	};
}
/** @internal Recursively collects leaf commands with name + description only. */
function collectIndexCommands(commands, prefix) {
	const result = [];
	for (const [name, entry] of commands) {
		if (isAlias(entry)) continue;
		const path = [...prefix, name];
		if (isGroup(entry)) result.push(...collectIndexCommands(entry.commands, path));
		else {
			const cmd = { name: path.join(" ") };
			if (isFetchGateway(entry)) {
				if (entry.description) cmd.description = entry.description;
			} else if (entry.description) cmd.description = entry.description;
			result.push(cmd);
		}
	}
	return result;
}
/** @internal Builds the `--llms` manifest from the command tree. */
function buildManifest(commands, prefix = [], globalsSchema) {
	return {
		version: "incur.v1",
		commands: collectCommands(commands, prefix).sort((a, b) => a.name.localeCompare(b.name)),
		...globalsSchema ? { globals: toJsonSchema(globalsSchema) } : void 0
	};
}
/** @internal Recursively collects leaf commands with their full paths. */
function collectCommands(commands, prefix) {
	const result = [];
	for (const [name, entry] of commands) {
		if (isAlias(entry)) continue;
		const path = [...prefix, name];
		if (isFetchGateway(entry)) {
			const cmd = { name: path.join(" ") };
			if (entry.description) cmd.description = entry.description;
			result.push(cmd);
		} else if (isGroup(entry)) result.push(...collectCommands(entry.commands, path));
		else {
			const cmd = { name: path.join(" ") };
			if (entry.description) cmd.description = entry.description;
			const inputSchema = buildInputSchema(entry.args, entry.env, entry.options);
			const outputSchema = entry.output ? toJsonSchema(entry.output) : void 0;
			if (inputSchema || outputSchema) {
				cmd.schema = {};
				if (inputSchema?.args) cmd.schema.args = inputSchema.args;
				if (inputSchema?.env) cmd.schema.env = inputSchema.env;
				if (inputSchema?.options) cmd.schema.options = inputSchema.options;
				if (outputSchema) cmd.schema.output = outputSchema;
			}
			const examples = formatExamples(entry.examples);
			if (examples) {
				const cmdName = path.join(" ");
				cmd.examples = examples.map((e) => ({
					...e,
					command: e.command ? `${cmdName} ${e.command}` : cmdName
				}));
			}
			result.push(cmd);
		}
	}
	return result;
}
/** @internal Recursively collects leaf commands as `Skill.CommandInfo` for `--llms --format md`. */
function collectSkillCommands(commands, prefix, groups, rootCommand) {
	const result = [];
	if (rootCommand) {
		const cmd = {};
		if (rootCommand.description) cmd.description = rootCommand.description;
		if (rootCommand.args) cmd.args = rootCommand.args;
		if (rootCommand.env) cmd.env = rootCommand.env;
		if (rootCommand.hint) cmd.hint = rootCommand.hint;
		if (isDestructive(rootCommand)) cmd.hint = appendDestructiveHint(cmd.hint);
		if (rootCommand.options) cmd.options = rootCommand.options;
		if (rootCommand.output) cmd.output = rootCommand.output;
		const examples = formatExamples(rootCommand.examples);
		if (examples) cmd.examples = examples;
		result.push(cmd);
	}
	for (const [name, entry] of commands) {
		if (isAlias(entry)) continue;
		const path = [...prefix, name];
		if (isFetchGateway(entry)) {
			const cmd = { name: path.join(" ") };
			if (entry.description) cmd.description = entry.description;
			cmd.hint = "Fetch gateway. Pass path segments and curl-style flags (-X, -H, -d, --key value).";
			result.push(cmd);
		} else if (isGroup(entry)) {
			if (entry.description) groups.set(path.join(" "), entry.description);
			result.push(...collectSkillCommands(entry.commands, path, groups));
		} else {
			const cmd = { name: path.join(" ") };
			if (entry.description) cmd.description = entry.description;
			if (entry.args) cmd.args = entry.args;
			if (entry.env) cmd.env = entry.env;
			if (entry.hint) cmd.hint = entry.hint;
			if (isDestructive(entry)) cmd.hint = appendDestructiveHint(cmd.hint);
			if (entry.options) cmd.options = entry.options;
			if (entry.output) cmd.output = entry.output;
			const examples = formatExamples(entry.examples);
			if (examples) {
				const cmdName = path.join(" ");
				cmd.examples = examples.map((e) => ({
					...e,
					command: e.command ? `${cmdName} ${e.command}` : cmdName
				}));
			}
			result.push(cmd);
		}
	}
	return result.sort((a, b) => (a.name ?? "").localeCompare(b.name ?? ""));
}
function isDestructive(command) {
	return command.destructive === true || command.mcp !== false && command.mcp?.annotations?.destructiveHint === true;
}
function appendDestructiveHint(hint) {
	if (!hint) return destructiveCommandHint;
	if (hint.includes(destructiveCommandHint)) return hint;
	return `${hint} ${destructiveCommandHint}`;
}
/** @internal Formats examples into `{ command, description }` objects. `command` is the args/options suffix only. */
function formatExamples(examples) {
	if (!examples || examples.length === 0) return void 0;
	return examples.map((ex) => {
		const parts = [];
		if (ex.args) for (const value of Object.values(ex.args)) parts.push(String(value));
		if (ex.options) for (const [key, value] of Object.entries(ex.options)) parts.push(`--${key} ${value}`);
		const result = { command: parts.join(" ") };
		if (ex.description) result.description = ex.description;
		return result;
	});
}
/** @internal Parses YAML frontmatter from generated skill Markdown. */
function parseSkillFrontmatter(content) {
	const match = content.match(/^---\r?\n([\s\S]*?)\r?\n---/);
	if (!match) return {};
	const meta = loadSync().parse(match[1]);
	if (!meta || typeof meta !== "object") return {};
	return meta;
}
/** @internal Builds separate args, env, and options JSON Schemas. */
function buildInputSchema(args, env, options) {
	if (!args && !env && !options) return void 0;
	const result = {};
	if (args) result.args = toJsonSchema(args);
	if (env) result.env = toJsonSchema(env);
	if (options) result.options = toJsonSchema(options);
	return result;
}
/** @internal Scans argv for deprecated flags and writes warnings to stderr. */
function emitDeprecationWarnings(argv, optionsSchema, alias) {
	if (!optionsSchema) return;
	const shape = optionsSchema.shape;
	const deprecatedFlags = /* @__PURE__ */ new Set();
	const deprecatedShorts = /* @__PURE__ */ new Map();
	for (const key of Object.keys(shape)) if ((shape[key]?.meta?.())?.deprecated) {
		const kebab = key.replace(/[A-Z]/g, (c) => `-${c.toLowerCase()}`);
		deprecatedFlags.add(kebab);
		if (alias?.[key]) deprecatedShorts.set(alias[key], kebab);
	}
	if (deprecatedFlags.size === 0) return;
	for (const token of argv) if (token.startsWith("--")) {
		const stripped = token.split("=")[0].slice(2);
		const raw = !deprecatedFlags.has(stripped) && stripped.startsWith("no-") ? stripped.slice(3) : stripped;
		if (deprecatedFlags.has(raw)) process.stderr.write(`Warning: --${raw} is deprecated\n`);
	} else if (token.startsWith("-") && token.length >= 2) {
		for (const ch of token.slice(1)) if (deprecatedShorts.has(ch)) process.stderr.write(`Warning: --${deprecatedShorts.get(ch)} is deprecated\n`);
	}
}
/** @internal Resolves the display name from `process.argv[1]` basename. Returns the basename if it matches `name` or one of the `aliases`, otherwise falls back to `name`. */
function resolveDisplayName(name, aliases) {
	const bin = process.argv[1];
	if (!bin) return name;
	const basename = path$1.basename(bin);
	if (basename === name) return name;
	if (aliases?.includes(basename)) return basename;
	return name;
}
//#endregion
//#region ../../node_modules/.pnpm/ws@8.18.3/node_modules/ws/lib/constants.js
var require_constants = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var BINARY_TYPES = [
		"nodebuffer",
		"arraybuffer",
		"fragments"
	];
	var hasBlob = typeof Blob !== "undefined";
	if (hasBlob) BINARY_TYPES.push("blob");
	module.exports = {
		BINARY_TYPES,
		EMPTY_BUFFER: Buffer.alloc(0),
		GUID: "258EAFA5-E914-47DA-95CA-C5AB0DC85B11",
		hasBlob,
		kForOnEventAttribute: Symbol("kIsForOnEventAttribute"),
		kListener: Symbol("kListener"),
		kStatusCode: Symbol("status-code"),
		kWebSocket: Symbol("websocket"),
		NOOP: () => {}
	};
}));
//#endregion
//#region ../../node_modules/.pnpm/ws@8.18.3/node_modules/ws/lib/buffer-util.js
var require_buffer_util = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var { EMPTY_BUFFER } = require_constants();
	var FastBuffer = Buffer[Symbol.species];
	/**
	* Merges an array of buffers into a new buffer.
	*
	* @param {Buffer[]} list The array of buffers to concat
	* @param {Number} totalLength The total length of buffers in the list
	* @return {Buffer} The resulting buffer
	* @public
	*/
	function concat(list, totalLength) {
		if (list.length === 0) return EMPTY_BUFFER;
		if (list.length === 1) return list[0];
		const target = Buffer.allocUnsafe(totalLength);
		let offset = 0;
		for (let i = 0; i < list.length; i++) {
			const buf = list[i];
			target.set(buf, offset);
			offset += buf.length;
		}
		if (offset < totalLength) return new FastBuffer(target.buffer, target.byteOffset, offset);
		return target;
	}
	/**
	* Masks a buffer using the given mask.
	*
	* @param {Buffer} source The buffer to mask
	* @param {Buffer} mask The mask to use
	* @param {Buffer} output The buffer where to store the result
	* @param {Number} offset The offset at which to start writing
	* @param {Number} length The number of bytes to mask.
	* @public
	*/
	function _mask(source, mask, output, offset, length) {
		for (let i = 0; i < length; i++) output[offset + i] = source[i] ^ mask[i & 3];
	}
	/**
	* Unmasks a buffer using the given mask.
	*
	* @param {Buffer} buffer The buffer to unmask
	* @param {Buffer} mask The mask to use
	* @public
	*/
	function _unmask(buffer, mask) {
		for (let i = 0; i < buffer.length; i++) buffer[i] ^= mask[i & 3];
	}
	/**
	* Converts a buffer to an `ArrayBuffer`.
	*
	* @param {Buffer} buf The buffer to convert
	* @return {ArrayBuffer} Converted buffer
	* @public
	*/
	function toArrayBuffer(buf) {
		if (buf.length === buf.buffer.byteLength) return buf.buffer;
		return buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.length);
	}
	/**
	* Converts `data` to a `Buffer`.
	*
	* @param {*} data The data to convert
	* @return {Buffer} The buffer
	* @throws {TypeError}
	* @public
	*/
	function toBuffer(data) {
		toBuffer.readOnly = true;
		if (Buffer.isBuffer(data)) return data;
		let buf;
		if (data instanceof ArrayBuffer) buf = new FastBuffer(data);
		else if (ArrayBuffer.isView(data)) buf = new FastBuffer(data.buffer, data.byteOffset, data.byteLength);
		else {
			buf = Buffer.from(data);
			toBuffer.readOnly = false;
		}
		return buf;
	}
	module.exports = {
		concat,
		mask: _mask,
		toArrayBuffer,
		toBuffer,
		unmask: _unmask
	};
	/* istanbul ignore else  */
	if (!process.env.WS_NO_BUFFER_UTIL) try {
		const bufferUtil = __require("bufferutil");
		module.exports.mask = function(source, mask, output, offset, length) {
			if (length < 48) _mask(source, mask, output, offset, length);
			else bufferUtil.mask(source, mask, output, offset, length);
		};
		module.exports.unmask = function(buffer, mask) {
			if (buffer.length < 32) _unmask(buffer, mask);
			else bufferUtil.unmask(buffer, mask);
		};
	} catch (e) {}
}));
//#endregion
//#region ../../node_modules/.pnpm/ws@8.18.3/node_modules/ws/lib/limiter.js
var require_limiter = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var kDone = Symbol("kDone");
	var kRun = Symbol("kRun");
	/**
	* A very simple job queue with adjustable concurrency. Adapted from
	* https://github.com/STRML/async-limiter
	*/
	var Limiter = class {
		/**
		* Creates a new `Limiter`.
		*
		* @param {Number} [concurrency=Infinity] The maximum number of jobs allowed
		*     to run concurrently
		*/
		constructor(concurrency) {
			this[kDone] = () => {
				this.pending--;
				this[kRun]();
			};
			this.concurrency = concurrency || Infinity;
			this.jobs = [];
			this.pending = 0;
		}
		/**
		* Adds a job to the queue.
		*
		* @param {Function} job The job to run
		* @public
		*/
		add(job) {
			this.jobs.push(job);
			this[kRun]();
		}
		/**
		* Removes a job from the queue and runs it if possible.
		*
		* @private
		*/
		[kRun]() {
			if (this.pending === this.concurrency) return;
			if (this.jobs.length) {
				const job = this.jobs.shift();
				this.pending++;
				job(this[kDone]);
			}
		}
	};
	module.exports = Limiter;
}));
//#endregion
//#region ../../node_modules/.pnpm/ws@8.18.3/node_modules/ws/lib/permessage-deflate.js
var require_permessage_deflate = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var zlib = __require("zlib");
	var bufferUtil = require_buffer_util();
	var Limiter = require_limiter();
	var { kStatusCode } = require_constants();
	var FastBuffer = Buffer[Symbol.species];
	var TRAILER = Buffer.from([
		0,
		0,
		255,
		255
	]);
	var kPerMessageDeflate = Symbol("permessage-deflate");
	var kTotalLength = Symbol("total-length");
	var kCallback = Symbol("callback");
	var kBuffers = Symbol("buffers");
	var kError = Symbol("error");
	var zlibLimiter;
	/**
	* permessage-deflate implementation.
	*/
	var PerMessageDeflate = class {
		/**
		* Creates a PerMessageDeflate instance.
		*
		* @param {Object} [options] Configuration options
		* @param {(Boolean|Number)} [options.clientMaxWindowBits] Advertise support
		*     for, or request, a custom client window size
		* @param {Boolean} [options.clientNoContextTakeover=false] Advertise/
		*     acknowledge disabling of client context takeover
		* @param {Number} [options.concurrencyLimit=10] The number of concurrent
		*     calls to zlib
		* @param {(Boolean|Number)} [options.serverMaxWindowBits] Request/confirm the
		*     use of a custom server window size
		* @param {Boolean} [options.serverNoContextTakeover=false] Request/accept
		*     disabling of server context takeover
		* @param {Number} [options.threshold=1024] Size (in bytes) below which
		*     messages should not be compressed if context takeover is disabled
		* @param {Object} [options.zlibDeflateOptions] Options to pass to zlib on
		*     deflate
		* @param {Object} [options.zlibInflateOptions] Options to pass to zlib on
		*     inflate
		* @param {Boolean} [isServer=false] Create the instance in either server or
		*     client mode
		* @param {Number} [maxPayload=0] The maximum allowed message length
		*/
		constructor(options, isServer, maxPayload) {
			this._maxPayload = maxPayload | 0;
			this._options = options || {};
			this._threshold = this._options.threshold !== void 0 ? this._options.threshold : 1024;
			this._isServer = !!isServer;
			this._deflate = null;
			this._inflate = null;
			this.params = null;
			if (!zlibLimiter) zlibLimiter = new Limiter(this._options.concurrencyLimit !== void 0 ? this._options.concurrencyLimit : 10);
		}
		/**
		* @type {String}
		*/
		static get extensionName() {
			return "permessage-deflate";
		}
		/**
		* Create an extension negotiation offer.
		*
		* @return {Object} Extension parameters
		* @public
		*/
		offer() {
			const params = {};
			if (this._options.serverNoContextTakeover) params.server_no_context_takeover = true;
			if (this._options.clientNoContextTakeover) params.client_no_context_takeover = true;
			if (this._options.serverMaxWindowBits) params.server_max_window_bits = this._options.serverMaxWindowBits;
			if (this._options.clientMaxWindowBits) params.client_max_window_bits = this._options.clientMaxWindowBits;
			else if (this._options.clientMaxWindowBits == null) params.client_max_window_bits = true;
			return params;
		}
		/**
		* Accept an extension negotiation offer/response.
		*
		* @param {Array} configurations The extension negotiation offers/reponse
		* @return {Object} Accepted configuration
		* @public
		*/
		accept(configurations) {
			configurations = this.normalizeParams(configurations);
			this.params = this._isServer ? this.acceptAsServer(configurations) : this.acceptAsClient(configurations);
			return this.params;
		}
		/**
		* Releases all resources used by the extension.
		*
		* @public
		*/
		cleanup() {
			if (this._inflate) {
				this._inflate.close();
				this._inflate = null;
			}
			if (this._deflate) {
				const callback = this._deflate[kCallback];
				this._deflate.close();
				this._deflate = null;
				if (callback) callback(/* @__PURE__ */ new Error("The deflate stream was closed while data was being processed"));
			}
		}
		/**
		*  Accept an extension negotiation offer.
		*
		* @param {Array} offers The extension negotiation offers
		* @return {Object} Accepted configuration
		* @private
		*/
		acceptAsServer(offers) {
			const opts = this._options;
			const accepted = offers.find((params) => {
				if (opts.serverNoContextTakeover === false && params.server_no_context_takeover || params.server_max_window_bits && (opts.serverMaxWindowBits === false || typeof opts.serverMaxWindowBits === "number" && opts.serverMaxWindowBits > params.server_max_window_bits) || typeof opts.clientMaxWindowBits === "number" && !params.client_max_window_bits) return false;
				return true;
			});
			if (!accepted) throw new Error("None of the extension offers can be accepted");
			if (opts.serverNoContextTakeover) accepted.server_no_context_takeover = true;
			if (opts.clientNoContextTakeover) accepted.client_no_context_takeover = true;
			if (typeof opts.serverMaxWindowBits === "number") accepted.server_max_window_bits = opts.serverMaxWindowBits;
			if (typeof opts.clientMaxWindowBits === "number") accepted.client_max_window_bits = opts.clientMaxWindowBits;
			else if (accepted.client_max_window_bits === true || opts.clientMaxWindowBits === false) delete accepted.client_max_window_bits;
			return accepted;
		}
		/**
		* Accept the extension negotiation response.
		*
		* @param {Array} response The extension negotiation response
		* @return {Object} Accepted configuration
		* @private
		*/
		acceptAsClient(response) {
			const params = response[0];
			if (this._options.clientNoContextTakeover === false && params.client_no_context_takeover) throw new Error("Unexpected parameter \"client_no_context_takeover\"");
			if (!params.client_max_window_bits) {
				if (typeof this._options.clientMaxWindowBits === "number") params.client_max_window_bits = this._options.clientMaxWindowBits;
			} else if (this._options.clientMaxWindowBits === false || typeof this._options.clientMaxWindowBits === "number" && params.client_max_window_bits > this._options.clientMaxWindowBits) throw new Error("Unexpected or invalid parameter \"client_max_window_bits\"");
			return params;
		}
		/**
		* Normalize parameters.
		*
		* @param {Array} configurations The extension negotiation offers/reponse
		* @return {Array} The offers/response with normalized parameters
		* @private
		*/
		normalizeParams(configurations) {
			configurations.forEach((params) => {
				Object.keys(params).forEach((key) => {
					let value = params[key];
					if (value.length > 1) throw new Error(`Parameter "${key}" must have only a single value`);
					value = value[0];
					if (key === "client_max_window_bits") {
						if (value !== true) {
							const num = +value;
							if (!Number.isInteger(num) || num < 8 || num > 15) throw new TypeError(`Invalid value for parameter "${key}": ${value}`);
							value = num;
						} else if (!this._isServer) throw new TypeError(`Invalid value for parameter "${key}": ${value}`);
					} else if (key === "server_max_window_bits") {
						const num = +value;
						if (!Number.isInteger(num) || num < 8 || num > 15) throw new TypeError(`Invalid value for parameter "${key}": ${value}`);
						value = num;
					} else if (key === "client_no_context_takeover" || key === "server_no_context_takeover") {
						if (value !== true) throw new TypeError(`Invalid value for parameter "${key}": ${value}`);
					} else throw new Error(`Unknown parameter "${key}"`);
					params[key] = value;
				});
			});
			return configurations;
		}
		/**
		* Decompress data. Concurrency limited.
		*
		* @param {Buffer} data Compressed data
		* @param {Boolean} fin Specifies whether or not this is the last fragment
		* @param {Function} callback Callback
		* @public
		*/
		decompress(data, fin, callback) {
			zlibLimiter.add((done) => {
				this._decompress(data, fin, (err, result) => {
					done();
					callback(err, result);
				});
			});
		}
		/**
		* Compress data. Concurrency limited.
		*
		* @param {(Buffer|String)} data Data to compress
		* @param {Boolean} fin Specifies whether or not this is the last fragment
		* @param {Function} callback Callback
		* @public
		*/
		compress(data, fin, callback) {
			zlibLimiter.add((done) => {
				this._compress(data, fin, (err, result) => {
					done();
					callback(err, result);
				});
			});
		}
		/**
		* Decompress data.
		*
		* @param {Buffer} data Compressed data
		* @param {Boolean} fin Specifies whether or not this is the last fragment
		* @param {Function} callback Callback
		* @private
		*/
		_decompress(data, fin, callback) {
			const endpoint = this._isServer ? "client" : "server";
			if (!this._inflate) {
				const key = `${endpoint}_max_window_bits`;
				const windowBits = typeof this.params[key] !== "number" ? zlib.Z_DEFAULT_WINDOWBITS : this.params[key];
				this._inflate = zlib.createInflateRaw({
					...this._options.zlibInflateOptions,
					windowBits
				});
				this._inflate[kPerMessageDeflate] = this;
				this._inflate[kTotalLength] = 0;
				this._inflate[kBuffers] = [];
				this._inflate.on("error", inflateOnError);
				this._inflate.on("data", inflateOnData);
			}
			this._inflate[kCallback] = callback;
			this._inflate.write(data);
			if (fin) this._inflate.write(TRAILER);
			this._inflate.flush(() => {
				const err = this._inflate[kError];
				if (err) {
					this._inflate.close();
					this._inflate = null;
					callback(err);
					return;
				}
				const data = bufferUtil.concat(this._inflate[kBuffers], this._inflate[kTotalLength]);
				if (this._inflate._readableState.endEmitted) {
					this._inflate.close();
					this._inflate = null;
				} else {
					this._inflate[kTotalLength] = 0;
					this._inflate[kBuffers] = [];
					if (fin && this.params[`${endpoint}_no_context_takeover`]) this._inflate.reset();
				}
				callback(null, data);
			});
		}
		/**
		* Compress data.
		*
		* @param {(Buffer|String)} data Data to compress
		* @param {Boolean} fin Specifies whether or not this is the last fragment
		* @param {Function} callback Callback
		* @private
		*/
		_compress(data, fin, callback) {
			const endpoint = this._isServer ? "server" : "client";
			if (!this._deflate) {
				const key = `${endpoint}_max_window_bits`;
				const windowBits = typeof this.params[key] !== "number" ? zlib.Z_DEFAULT_WINDOWBITS : this.params[key];
				this._deflate = zlib.createDeflateRaw({
					...this._options.zlibDeflateOptions,
					windowBits
				});
				this._deflate[kTotalLength] = 0;
				this._deflate[kBuffers] = [];
				this._deflate.on("data", deflateOnData);
			}
			this._deflate[kCallback] = callback;
			this._deflate.write(data);
			this._deflate.flush(zlib.Z_SYNC_FLUSH, () => {
				if (!this._deflate) return;
				let data = bufferUtil.concat(this._deflate[kBuffers], this._deflate[kTotalLength]);
				if (fin) data = new FastBuffer(data.buffer, data.byteOffset, data.length - 4);
				this._deflate[kCallback] = null;
				this._deflate[kTotalLength] = 0;
				this._deflate[kBuffers] = [];
				if (fin && this.params[`${endpoint}_no_context_takeover`]) this._deflate.reset();
				callback(null, data);
			});
		}
	};
	module.exports = PerMessageDeflate;
	/**
	* The listener of the `zlib.DeflateRaw` stream `'data'` event.
	*
	* @param {Buffer} chunk A chunk of data
	* @private
	*/
	function deflateOnData(chunk) {
		this[kBuffers].push(chunk);
		this[kTotalLength] += chunk.length;
	}
	/**
	* The listener of the `zlib.InflateRaw` stream `'data'` event.
	*
	* @param {Buffer} chunk A chunk of data
	* @private
	*/
	function inflateOnData(chunk) {
		this[kTotalLength] += chunk.length;
		if (this[kPerMessageDeflate]._maxPayload < 1 || this[kTotalLength] <= this[kPerMessageDeflate]._maxPayload) {
			this[kBuffers].push(chunk);
			return;
		}
		this[kError] = /* @__PURE__ */ new RangeError("Max payload size exceeded");
		this[kError].code = "WS_ERR_UNSUPPORTED_MESSAGE_LENGTH";
		this[kError][kStatusCode] = 1009;
		this.removeListener("data", inflateOnData);
		this.reset();
	}
	/**
	* The listener of the `zlib.InflateRaw` stream `'error'` event.
	*
	* @param {Error} err The emitted error
	* @private
	*/
	function inflateOnError(err) {
		this[kPerMessageDeflate]._inflate = null;
		if (this[kError]) {
			this[kCallback](this[kError]);
			return;
		}
		err[kStatusCode] = 1007;
		this[kCallback](err);
	}
}));
//#endregion
//#region ../../node_modules/.pnpm/ws@8.18.3/node_modules/ws/lib/validation.js
var require_validation = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var { isUtf8 } = __require("buffer");
	var { hasBlob } = require_constants();
	var tokenChars = [
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		1,
		0,
		1,
		1,
		1,
		1,
		1,
		0,
		0,
		1,
		1,
		0,
		1,
		1,
		0,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		0,
		0,
		0,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		0,
		1,
		0,
		1,
		0
	];
	/**
	* Checks if a status code is allowed in a close frame.
	*
	* @param {Number} code The status code
	* @return {Boolean} `true` if the status code is valid, else `false`
	* @public
	*/
	function isValidStatusCode(code) {
		return code >= 1e3 && code <= 1014 && code !== 1004 && code !== 1005 && code !== 1006 || code >= 3e3 && code <= 4999;
	}
	/**
	* Checks if a given buffer contains only correct UTF-8.
	* Ported from https://www.cl.cam.ac.uk/%7Emgk25/ucs/utf8_check.c by
	* Markus Kuhn.
	*
	* @param {Buffer} buf The buffer to check
	* @return {Boolean} `true` if `buf` contains only correct UTF-8, else `false`
	* @public
	*/
	function _isValidUTF8(buf) {
		const len = buf.length;
		let i = 0;
		while (i < len) if ((buf[i] & 128) === 0) i++;
		else if ((buf[i] & 224) === 192) {
			if (i + 1 === len || (buf[i + 1] & 192) !== 128 || (buf[i] & 254) === 192) return false;
			i += 2;
		} else if ((buf[i] & 240) === 224) {
			if (i + 2 >= len || (buf[i + 1] & 192) !== 128 || (buf[i + 2] & 192) !== 128 || buf[i] === 224 && (buf[i + 1] & 224) === 128 || buf[i] === 237 && (buf[i + 1] & 224) === 160) return false;
			i += 3;
		} else if ((buf[i] & 248) === 240) {
			if (i + 3 >= len || (buf[i + 1] & 192) !== 128 || (buf[i + 2] & 192) !== 128 || (buf[i + 3] & 192) !== 128 || buf[i] === 240 && (buf[i + 1] & 240) === 128 || buf[i] === 244 && buf[i + 1] > 143 || buf[i] > 244) return false;
			i += 4;
		} else return false;
		return true;
	}
	/**
	* Determines whether a value is a `Blob`.
	*
	* @param {*} value The value to be tested
	* @return {Boolean} `true` if `value` is a `Blob`, else `false`
	* @private
	*/
	function isBlob(value) {
		return hasBlob && typeof value === "object" && typeof value.arrayBuffer === "function" && typeof value.type === "string" && typeof value.stream === "function" && (value[Symbol.toStringTag] === "Blob" || value[Symbol.toStringTag] === "File");
	}
	module.exports = {
		isBlob,
		isValidStatusCode,
		isValidUTF8: _isValidUTF8,
		tokenChars
	};
	if (isUtf8) module.exports.isValidUTF8 = function(buf) {
		return buf.length < 24 ? _isValidUTF8(buf) : isUtf8(buf);
	};
	else if (!process.env.WS_NO_UTF_8_VALIDATE) try {
		const isValidUTF8 = __require("utf-8-validate");
		module.exports.isValidUTF8 = function(buf) {
			return buf.length < 32 ? _isValidUTF8(buf) : isValidUTF8(buf);
		};
	} catch (e) {}
}));
//#endregion
//#region ../../node_modules/.pnpm/ws@8.18.3/node_modules/ws/lib/receiver.js
var require_receiver = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var { Writable } = __require("stream");
	var PerMessageDeflate = require_permessage_deflate();
	var { BINARY_TYPES, EMPTY_BUFFER, kStatusCode, kWebSocket } = require_constants();
	var { concat, toArrayBuffer, unmask } = require_buffer_util();
	var { isValidStatusCode, isValidUTF8 } = require_validation();
	var FastBuffer = Buffer[Symbol.species];
	var GET_INFO = 0;
	var GET_PAYLOAD_LENGTH_16 = 1;
	var GET_PAYLOAD_LENGTH_64 = 2;
	var GET_MASK = 3;
	var GET_DATA = 4;
	var INFLATING = 5;
	var DEFER_EVENT = 6;
	/**
	* HyBi Receiver implementation.
	*
	* @extends Writable
	*/
	var Receiver = class extends Writable {
		/**
		* Creates a Receiver instance.
		*
		* @param {Object} [options] Options object
		* @param {Boolean} [options.allowSynchronousEvents=true] Specifies whether
		*     any of the `'message'`, `'ping'`, and `'pong'` events can be emitted
		*     multiple times in the same tick
		* @param {String} [options.binaryType=nodebuffer] The type for binary data
		* @param {Object} [options.extensions] An object containing the negotiated
		*     extensions
		* @param {Boolean} [options.isServer=false] Specifies whether to operate in
		*     client or server mode
		* @param {Number} [options.maxPayload=0] The maximum allowed message length
		* @param {Boolean} [options.skipUTF8Validation=false] Specifies whether or
		*     not to skip UTF-8 validation for text and close messages
		*/
		constructor(options = {}) {
			super();
			this._allowSynchronousEvents = options.allowSynchronousEvents !== void 0 ? options.allowSynchronousEvents : true;
			this._binaryType = options.binaryType || BINARY_TYPES[0];
			this._extensions = options.extensions || {};
			this._isServer = !!options.isServer;
			this._maxPayload = options.maxPayload | 0;
			this._skipUTF8Validation = !!options.skipUTF8Validation;
			this[kWebSocket] = void 0;
			this._bufferedBytes = 0;
			this._buffers = [];
			this._compressed = false;
			this._payloadLength = 0;
			this._mask = void 0;
			this._fragmented = 0;
			this._masked = false;
			this._fin = false;
			this._opcode = 0;
			this._totalPayloadLength = 0;
			this._messageLength = 0;
			this._fragments = [];
			this._errored = false;
			this._loop = false;
			this._state = GET_INFO;
		}
		/**
		* Implements `Writable.prototype._write()`.
		*
		* @param {Buffer} chunk The chunk of data to write
		* @param {String} encoding The character encoding of `chunk`
		* @param {Function} cb Callback
		* @private
		*/
		_write(chunk, encoding, cb) {
			if (this._opcode === 8 && this._state == GET_INFO) return cb();
			this._bufferedBytes += chunk.length;
			this._buffers.push(chunk);
			this.startLoop(cb);
		}
		/**
		* Consumes `n` bytes from the buffered data.
		*
		* @param {Number} n The number of bytes to consume
		* @return {Buffer} The consumed bytes
		* @private
		*/
		consume(n) {
			this._bufferedBytes -= n;
			if (n === this._buffers[0].length) return this._buffers.shift();
			if (n < this._buffers[0].length) {
				const buf = this._buffers[0];
				this._buffers[0] = new FastBuffer(buf.buffer, buf.byteOffset + n, buf.length - n);
				return new FastBuffer(buf.buffer, buf.byteOffset, n);
			}
			const dst = Buffer.allocUnsafe(n);
			do {
				const buf = this._buffers[0];
				const offset = dst.length - n;
				if (n >= buf.length) dst.set(this._buffers.shift(), offset);
				else {
					dst.set(new Uint8Array(buf.buffer, buf.byteOffset, n), offset);
					this._buffers[0] = new FastBuffer(buf.buffer, buf.byteOffset + n, buf.length - n);
				}
				n -= buf.length;
			} while (n > 0);
			return dst;
		}
		/**
		* Starts the parsing loop.
		*
		* @param {Function} cb Callback
		* @private
		*/
		startLoop(cb) {
			this._loop = true;
			do
				switch (this._state) {
					case GET_INFO:
						this.getInfo(cb);
						break;
					case GET_PAYLOAD_LENGTH_16:
						this.getPayloadLength16(cb);
						break;
					case GET_PAYLOAD_LENGTH_64:
						this.getPayloadLength64(cb);
						break;
					case GET_MASK:
						this.getMask();
						break;
					case GET_DATA:
						this.getData(cb);
						break;
					case INFLATING:
					case DEFER_EVENT:
						this._loop = false;
						return;
				}
			while (this._loop);
			if (!this._errored) cb();
		}
		/**
		* Reads the first two bytes of a frame.
		*
		* @param {Function} cb Callback
		* @private
		*/
		getInfo(cb) {
			if (this._bufferedBytes < 2) {
				this._loop = false;
				return;
			}
			const buf = this.consume(2);
			if ((buf[0] & 48) !== 0) {
				cb(this.createError(RangeError, "RSV2 and RSV3 must be clear", true, 1002, "WS_ERR_UNEXPECTED_RSV_2_3"));
				return;
			}
			const compressed = (buf[0] & 64) === 64;
			if (compressed && !this._extensions[PerMessageDeflate.extensionName]) {
				cb(this.createError(RangeError, "RSV1 must be clear", true, 1002, "WS_ERR_UNEXPECTED_RSV_1"));
				return;
			}
			this._fin = (buf[0] & 128) === 128;
			this._opcode = buf[0] & 15;
			this._payloadLength = buf[1] & 127;
			if (this._opcode === 0) {
				if (compressed) {
					cb(this.createError(RangeError, "RSV1 must be clear", true, 1002, "WS_ERR_UNEXPECTED_RSV_1"));
					return;
				}
				if (!this._fragmented) {
					cb(this.createError(RangeError, "invalid opcode 0", true, 1002, "WS_ERR_INVALID_OPCODE"));
					return;
				}
				this._opcode = this._fragmented;
			} else if (this._opcode === 1 || this._opcode === 2) {
				if (this._fragmented) {
					cb(this.createError(RangeError, `invalid opcode ${this._opcode}`, true, 1002, "WS_ERR_INVALID_OPCODE"));
					return;
				}
				this._compressed = compressed;
			} else if (this._opcode > 7 && this._opcode < 11) {
				if (!this._fin) {
					cb(this.createError(RangeError, "FIN must be set", true, 1002, "WS_ERR_EXPECTED_FIN"));
					return;
				}
				if (compressed) {
					cb(this.createError(RangeError, "RSV1 must be clear", true, 1002, "WS_ERR_UNEXPECTED_RSV_1"));
					return;
				}
				if (this._payloadLength > 125 || this._opcode === 8 && this._payloadLength === 1) {
					cb(this.createError(RangeError, `invalid payload length ${this._payloadLength}`, true, 1002, "WS_ERR_INVALID_CONTROL_PAYLOAD_LENGTH"));
					return;
				}
			} else {
				cb(this.createError(RangeError, `invalid opcode ${this._opcode}`, true, 1002, "WS_ERR_INVALID_OPCODE"));
				return;
			}
			if (!this._fin && !this._fragmented) this._fragmented = this._opcode;
			this._masked = (buf[1] & 128) === 128;
			if (this._isServer) {
				if (!this._masked) {
					cb(this.createError(RangeError, "MASK must be set", true, 1002, "WS_ERR_EXPECTED_MASK"));
					return;
				}
			} else if (this._masked) {
				cb(this.createError(RangeError, "MASK must be clear", true, 1002, "WS_ERR_UNEXPECTED_MASK"));
				return;
			}
			if (this._payloadLength === 126) this._state = GET_PAYLOAD_LENGTH_16;
			else if (this._payloadLength === 127) this._state = GET_PAYLOAD_LENGTH_64;
			else this.haveLength(cb);
		}
		/**
		* Gets extended payload length (7+16).
		*
		* @param {Function} cb Callback
		* @private
		*/
		getPayloadLength16(cb) {
			if (this._bufferedBytes < 2) {
				this._loop = false;
				return;
			}
			this._payloadLength = this.consume(2).readUInt16BE(0);
			this.haveLength(cb);
		}
		/**
		* Gets extended payload length (7+64).
		*
		* @param {Function} cb Callback
		* @private
		*/
		getPayloadLength64(cb) {
			if (this._bufferedBytes < 8) {
				this._loop = false;
				return;
			}
			const buf = this.consume(8);
			const num = buf.readUInt32BE(0);
			if (num > Math.pow(2, 21) - 1) {
				cb(this.createError(RangeError, "Unsupported WebSocket frame: payload length > 2^53 - 1", false, 1009, "WS_ERR_UNSUPPORTED_DATA_PAYLOAD_LENGTH"));
				return;
			}
			this._payloadLength = num * Math.pow(2, 32) + buf.readUInt32BE(4);
			this.haveLength(cb);
		}
		/**
		* Payload length has been read.
		*
		* @param {Function} cb Callback
		* @private
		*/
		haveLength(cb) {
			if (this._payloadLength && this._opcode < 8) {
				this._totalPayloadLength += this._payloadLength;
				if (this._totalPayloadLength > this._maxPayload && this._maxPayload > 0) {
					cb(this.createError(RangeError, "Max payload size exceeded", false, 1009, "WS_ERR_UNSUPPORTED_MESSAGE_LENGTH"));
					return;
				}
			}
			if (this._masked) this._state = GET_MASK;
			else this._state = GET_DATA;
		}
		/**
		* Reads mask bytes.
		*
		* @private
		*/
		getMask() {
			if (this._bufferedBytes < 4) {
				this._loop = false;
				return;
			}
			this._mask = this.consume(4);
			this._state = GET_DATA;
		}
		/**
		* Reads data bytes.
		*
		* @param {Function} cb Callback
		* @private
		*/
		getData(cb) {
			let data = EMPTY_BUFFER;
			if (this._payloadLength) {
				if (this._bufferedBytes < this._payloadLength) {
					this._loop = false;
					return;
				}
				data = this.consume(this._payloadLength);
				if (this._masked && (this._mask[0] | this._mask[1] | this._mask[2] | this._mask[3]) !== 0) unmask(data, this._mask);
			}
			if (this._opcode > 7) {
				this.controlMessage(data, cb);
				return;
			}
			if (this._compressed) {
				this._state = INFLATING;
				this.decompress(data, cb);
				return;
			}
			if (data.length) {
				this._messageLength = this._totalPayloadLength;
				this._fragments.push(data);
			}
			this.dataMessage(cb);
		}
		/**
		* Decompresses data.
		*
		* @param {Buffer} data Compressed data
		* @param {Function} cb Callback
		* @private
		*/
		decompress(data, cb) {
			this._extensions[PerMessageDeflate.extensionName].decompress(data, this._fin, (err, buf) => {
				if (err) return cb(err);
				if (buf.length) {
					this._messageLength += buf.length;
					if (this._messageLength > this._maxPayload && this._maxPayload > 0) {
						cb(this.createError(RangeError, "Max payload size exceeded", false, 1009, "WS_ERR_UNSUPPORTED_MESSAGE_LENGTH"));
						return;
					}
					this._fragments.push(buf);
				}
				this.dataMessage(cb);
				if (this._state === GET_INFO) this.startLoop(cb);
			});
		}
		/**
		* Handles a data message.
		*
		* @param {Function} cb Callback
		* @private
		*/
		dataMessage(cb) {
			if (!this._fin) {
				this._state = GET_INFO;
				return;
			}
			const messageLength = this._messageLength;
			const fragments = this._fragments;
			this._totalPayloadLength = 0;
			this._messageLength = 0;
			this._fragmented = 0;
			this._fragments = [];
			if (this._opcode === 2) {
				let data;
				if (this._binaryType === "nodebuffer") data = concat(fragments, messageLength);
				else if (this._binaryType === "arraybuffer") data = toArrayBuffer(concat(fragments, messageLength));
				else if (this._binaryType === "blob") data = new Blob(fragments);
				else data = fragments;
				if (this._allowSynchronousEvents) {
					this.emit("message", data, true);
					this._state = GET_INFO;
				} else {
					this._state = DEFER_EVENT;
					setImmediate(() => {
						this.emit("message", data, true);
						this._state = GET_INFO;
						this.startLoop(cb);
					});
				}
			} else {
				const buf = concat(fragments, messageLength);
				if (!this._skipUTF8Validation && !isValidUTF8(buf)) {
					cb(this.createError(Error, "invalid UTF-8 sequence", true, 1007, "WS_ERR_INVALID_UTF8"));
					return;
				}
				if (this._state === INFLATING || this._allowSynchronousEvents) {
					this.emit("message", buf, false);
					this._state = GET_INFO;
				} else {
					this._state = DEFER_EVENT;
					setImmediate(() => {
						this.emit("message", buf, false);
						this._state = GET_INFO;
						this.startLoop(cb);
					});
				}
			}
		}
		/**
		* Handles a control message.
		*
		* @param {Buffer} data Data to handle
		* @return {(Error|RangeError|undefined)} A possible error
		* @private
		*/
		controlMessage(data, cb) {
			if (this._opcode === 8) {
				if (data.length === 0) {
					this._loop = false;
					this.emit("conclude", 1005, EMPTY_BUFFER);
					this.end();
				} else {
					const code = data.readUInt16BE(0);
					if (!isValidStatusCode(code)) {
						cb(this.createError(RangeError, `invalid status code ${code}`, true, 1002, "WS_ERR_INVALID_CLOSE_CODE"));
						return;
					}
					const buf = new FastBuffer(data.buffer, data.byteOffset + 2, data.length - 2);
					if (!this._skipUTF8Validation && !isValidUTF8(buf)) {
						cb(this.createError(Error, "invalid UTF-8 sequence", true, 1007, "WS_ERR_INVALID_UTF8"));
						return;
					}
					this._loop = false;
					this.emit("conclude", code, buf);
					this.end();
				}
				this._state = GET_INFO;
				return;
			}
			if (this._allowSynchronousEvents) {
				this.emit(this._opcode === 9 ? "ping" : "pong", data);
				this._state = GET_INFO;
			} else {
				this._state = DEFER_EVENT;
				setImmediate(() => {
					this.emit(this._opcode === 9 ? "ping" : "pong", data);
					this._state = GET_INFO;
					this.startLoop(cb);
				});
			}
		}
		/**
		* Builds an error object.
		*
		* @param {function(new:Error|RangeError)} ErrorCtor The error constructor
		* @param {String} message The error message
		* @param {Boolean} prefix Specifies whether or not to add a default prefix to
		*     `message`
		* @param {Number} statusCode The status code
		* @param {String} errorCode The exposed error code
		* @return {(Error|RangeError)} The error
		* @private
		*/
		createError(ErrorCtor, message, prefix, statusCode, errorCode) {
			this._loop = false;
			this._errored = true;
			const err = new ErrorCtor(prefix ? `Invalid WebSocket frame: ${message}` : message);
			Error.captureStackTrace(err, this.createError);
			err.code = errorCode;
			err[kStatusCode] = statusCode;
			return err;
		}
	};
	module.exports = Receiver;
}));
//#endregion
//#region ../../node_modules/.pnpm/ws@8.18.3/node_modules/ws/lib/sender.js
var require_sender = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var { Duplex: Duplex$3 } = __require("stream");
	var { randomFillSync } = __require("crypto");
	var PerMessageDeflate = require_permessage_deflate();
	var { EMPTY_BUFFER, kWebSocket, NOOP } = require_constants();
	var { isBlob, isValidStatusCode } = require_validation();
	var { mask: applyMask, toBuffer } = require_buffer_util();
	var kByteLength = Symbol("kByteLength");
	var maskBuffer = Buffer.alloc(4);
	var RANDOM_POOL_SIZE = 8 * 1024;
	var randomPool;
	var randomPoolPointer = RANDOM_POOL_SIZE;
	var DEFAULT = 0;
	var DEFLATING = 1;
	var GET_BLOB_DATA = 2;
	module.exports = class Sender {
		/**
		* Creates a Sender instance.
		*
		* @param {Duplex} socket The connection socket
		* @param {Object} [extensions] An object containing the negotiated extensions
		* @param {Function} [generateMask] The function used to generate the masking
		*     key
		*/
		constructor(socket, extensions, generateMask) {
			this._extensions = extensions || {};
			if (generateMask) {
				this._generateMask = generateMask;
				this._maskBuffer = Buffer.alloc(4);
			}
			this._socket = socket;
			this._firstFragment = true;
			this._compress = false;
			this._bufferedBytes = 0;
			this._queue = [];
			this._state = DEFAULT;
			this.onerror = NOOP;
			this[kWebSocket] = void 0;
		}
		/**
		* Frames a piece of data according to the HyBi WebSocket protocol.
		*
		* @param {(Buffer|String)} data The data to frame
		* @param {Object} options Options object
		* @param {Boolean} [options.fin=false] Specifies whether or not to set the
		*     FIN bit
		* @param {Function} [options.generateMask] The function used to generate the
		*     masking key
		* @param {Boolean} [options.mask=false] Specifies whether or not to mask
		*     `data`
		* @param {Buffer} [options.maskBuffer] The buffer used to store the masking
		*     key
		* @param {Number} options.opcode The opcode
		* @param {Boolean} [options.readOnly=false] Specifies whether `data` can be
		*     modified
		* @param {Boolean} [options.rsv1=false] Specifies whether or not to set the
		*     RSV1 bit
		* @return {(Buffer|String)[]} The framed data
		* @public
		*/
		static frame(data, options) {
			let mask;
			let merge = false;
			let offset = 2;
			let skipMasking = false;
			if (options.mask) {
				mask = options.maskBuffer || maskBuffer;
				if (options.generateMask) options.generateMask(mask);
				else {
					if (randomPoolPointer === RANDOM_POOL_SIZE) {
						/* istanbul ignore else  */
						if (randomPool === void 0) randomPool = Buffer.alloc(RANDOM_POOL_SIZE);
						randomFillSync(randomPool, 0, RANDOM_POOL_SIZE);
						randomPoolPointer = 0;
					}
					mask[0] = randomPool[randomPoolPointer++];
					mask[1] = randomPool[randomPoolPointer++];
					mask[2] = randomPool[randomPoolPointer++];
					mask[3] = randomPool[randomPoolPointer++];
				}
				skipMasking = (mask[0] | mask[1] | mask[2] | mask[3]) === 0;
				offset = 6;
			}
			let dataLength;
			if (typeof data === "string") if ((!options.mask || skipMasking) && options[kByteLength] !== void 0) dataLength = options[kByteLength];
			else {
				data = Buffer.from(data);
				dataLength = data.length;
			}
			else {
				dataLength = data.length;
				merge = options.mask && options.readOnly && !skipMasking;
			}
			let payloadLength = dataLength;
			if (dataLength >= 65536) {
				offset += 8;
				payloadLength = 127;
			} else if (dataLength > 125) {
				offset += 2;
				payloadLength = 126;
			}
			const target = Buffer.allocUnsafe(merge ? dataLength + offset : offset);
			target[0] = options.fin ? options.opcode | 128 : options.opcode;
			if (options.rsv1) target[0] |= 64;
			target[1] = payloadLength;
			if (payloadLength === 126) target.writeUInt16BE(dataLength, 2);
			else if (payloadLength === 127) {
				target[2] = target[3] = 0;
				target.writeUIntBE(dataLength, 4, 6);
			}
			if (!options.mask) return [target, data];
			target[1] |= 128;
			target[offset - 4] = mask[0];
			target[offset - 3] = mask[1];
			target[offset - 2] = mask[2];
			target[offset - 1] = mask[3];
			if (skipMasking) return [target, data];
			if (merge) {
				applyMask(data, mask, target, offset, dataLength);
				return [target];
			}
			applyMask(data, mask, data, 0, dataLength);
			return [target, data];
		}
		/**
		* Sends a close message to the other peer.
		*
		* @param {Number} [code] The status code component of the body
		* @param {(String|Buffer)} [data] The message component of the body
		* @param {Boolean} [mask=false] Specifies whether or not to mask the message
		* @param {Function} [cb] Callback
		* @public
		*/
		close(code, data, mask, cb) {
			let buf;
			if (code === void 0) buf = EMPTY_BUFFER;
			else if (typeof code !== "number" || !isValidStatusCode(code)) throw new TypeError("First argument must be a valid error code number");
			else if (data === void 0 || !data.length) {
				buf = Buffer.allocUnsafe(2);
				buf.writeUInt16BE(code, 0);
			} else {
				const length = Buffer.byteLength(data);
				if (length > 123) throw new RangeError("The message must not be greater than 123 bytes");
				buf = Buffer.allocUnsafe(2 + length);
				buf.writeUInt16BE(code, 0);
				if (typeof data === "string") buf.write(data, 2);
				else buf.set(data, 2);
			}
			const options = {
				[kByteLength]: buf.length,
				fin: true,
				generateMask: this._generateMask,
				mask,
				maskBuffer: this._maskBuffer,
				opcode: 8,
				readOnly: false,
				rsv1: false
			};
			if (this._state !== DEFAULT) this.enqueue([
				this.dispatch,
				buf,
				false,
				options,
				cb
			]);
			else this.sendFrame(Sender.frame(buf, options), cb);
		}
		/**
		* Sends a ping message to the other peer.
		*
		* @param {*} data The message to send
		* @param {Boolean} [mask=false] Specifies whether or not to mask `data`
		* @param {Function} [cb] Callback
		* @public
		*/
		ping(data, mask, cb) {
			let byteLength;
			let readOnly;
			if (typeof data === "string") {
				byteLength = Buffer.byteLength(data);
				readOnly = false;
			} else if (isBlob(data)) {
				byteLength = data.size;
				readOnly = false;
			} else {
				data = toBuffer(data);
				byteLength = data.length;
				readOnly = toBuffer.readOnly;
			}
			if (byteLength > 125) throw new RangeError("The data size must not be greater than 125 bytes");
			const options = {
				[kByteLength]: byteLength,
				fin: true,
				generateMask: this._generateMask,
				mask,
				maskBuffer: this._maskBuffer,
				opcode: 9,
				readOnly,
				rsv1: false
			};
			if (isBlob(data)) if (this._state !== DEFAULT) this.enqueue([
				this.getBlobData,
				data,
				false,
				options,
				cb
			]);
			else this.getBlobData(data, false, options, cb);
			else if (this._state !== DEFAULT) this.enqueue([
				this.dispatch,
				data,
				false,
				options,
				cb
			]);
			else this.sendFrame(Sender.frame(data, options), cb);
		}
		/**
		* Sends a pong message to the other peer.
		*
		* @param {*} data The message to send
		* @param {Boolean} [mask=false] Specifies whether or not to mask `data`
		* @param {Function} [cb] Callback
		* @public
		*/
		pong(data, mask, cb) {
			let byteLength;
			let readOnly;
			if (typeof data === "string") {
				byteLength = Buffer.byteLength(data);
				readOnly = false;
			} else if (isBlob(data)) {
				byteLength = data.size;
				readOnly = false;
			} else {
				data = toBuffer(data);
				byteLength = data.length;
				readOnly = toBuffer.readOnly;
			}
			if (byteLength > 125) throw new RangeError("The data size must not be greater than 125 bytes");
			const options = {
				[kByteLength]: byteLength,
				fin: true,
				generateMask: this._generateMask,
				mask,
				maskBuffer: this._maskBuffer,
				opcode: 10,
				readOnly,
				rsv1: false
			};
			if (isBlob(data)) if (this._state !== DEFAULT) this.enqueue([
				this.getBlobData,
				data,
				false,
				options,
				cb
			]);
			else this.getBlobData(data, false, options, cb);
			else if (this._state !== DEFAULT) this.enqueue([
				this.dispatch,
				data,
				false,
				options,
				cb
			]);
			else this.sendFrame(Sender.frame(data, options), cb);
		}
		/**
		* Sends a data message to the other peer.
		*
		* @param {*} data The message to send
		* @param {Object} options Options object
		* @param {Boolean} [options.binary=false] Specifies whether `data` is binary
		*     or text
		* @param {Boolean} [options.compress=false] Specifies whether or not to
		*     compress `data`
		* @param {Boolean} [options.fin=false] Specifies whether the fragment is the
		*     last one
		* @param {Boolean} [options.mask=false] Specifies whether or not to mask
		*     `data`
		* @param {Function} [cb] Callback
		* @public
		*/
		send(data, options, cb) {
			const perMessageDeflate = this._extensions[PerMessageDeflate.extensionName];
			let opcode = options.binary ? 2 : 1;
			let rsv1 = options.compress;
			let byteLength;
			let readOnly;
			if (typeof data === "string") {
				byteLength = Buffer.byteLength(data);
				readOnly = false;
			} else if (isBlob(data)) {
				byteLength = data.size;
				readOnly = false;
			} else {
				data = toBuffer(data);
				byteLength = data.length;
				readOnly = toBuffer.readOnly;
			}
			if (this._firstFragment) {
				this._firstFragment = false;
				if (rsv1 && perMessageDeflate && perMessageDeflate.params[perMessageDeflate._isServer ? "server_no_context_takeover" : "client_no_context_takeover"]) rsv1 = byteLength >= perMessageDeflate._threshold;
				this._compress = rsv1;
			} else {
				rsv1 = false;
				opcode = 0;
			}
			if (options.fin) this._firstFragment = true;
			const opts = {
				[kByteLength]: byteLength,
				fin: options.fin,
				generateMask: this._generateMask,
				mask: options.mask,
				maskBuffer: this._maskBuffer,
				opcode,
				readOnly,
				rsv1
			};
			if (isBlob(data)) if (this._state !== DEFAULT) this.enqueue([
				this.getBlobData,
				data,
				this._compress,
				opts,
				cb
			]);
			else this.getBlobData(data, this._compress, opts, cb);
			else if (this._state !== DEFAULT) this.enqueue([
				this.dispatch,
				data,
				this._compress,
				opts,
				cb
			]);
			else this.dispatch(data, this._compress, opts, cb);
		}
		/**
		* Gets the contents of a blob as binary data.
		*
		* @param {Blob} blob The blob
		* @param {Boolean} [compress=false] Specifies whether or not to compress
		*     the data
		* @param {Object} options Options object
		* @param {Boolean} [options.fin=false] Specifies whether or not to set the
		*     FIN bit
		* @param {Function} [options.generateMask] The function used to generate the
		*     masking key
		* @param {Boolean} [options.mask=false] Specifies whether or not to mask
		*     `data`
		* @param {Buffer} [options.maskBuffer] The buffer used to store the masking
		*     key
		* @param {Number} options.opcode The opcode
		* @param {Boolean} [options.readOnly=false] Specifies whether `data` can be
		*     modified
		* @param {Boolean} [options.rsv1=false] Specifies whether or not to set the
		*     RSV1 bit
		* @param {Function} [cb] Callback
		* @private
		*/
		getBlobData(blob, compress, options, cb) {
			this._bufferedBytes += options[kByteLength];
			this._state = GET_BLOB_DATA;
			blob.arrayBuffer().then((arrayBuffer) => {
				if (this._socket.destroyed) {
					const err = /* @__PURE__ */ new Error("The socket was closed while the blob was being read");
					process.nextTick(callCallbacks, this, err, cb);
					return;
				}
				this._bufferedBytes -= options[kByteLength];
				const data = toBuffer(arrayBuffer);
				if (!compress) {
					this._state = DEFAULT;
					this.sendFrame(Sender.frame(data, options), cb);
					this.dequeue();
				} else this.dispatch(data, compress, options, cb);
			}).catch((err) => {
				process.nextTick(onError, this, err, cb);
			});
		}
		/**
		* Dispatches a message.
		*
		* @param {(Buffer|String)} data The message to send
		* @param {Boolean} [compress=false] Specifies whether or not to compress
		*     `data`
		* @param {Object} options Options object
		* @param {Boolean} [options.fin=false] Specifies whether or not to set the
		*     FIN bit
		* @param {Function} [options.generateMask] The function used to generate the
		*     masking key
		* @param {Boolean} [options.mask=false] Specifies whether or not to mask
		*     `data`
		* @param {Buffer} [options.maskBuffer] The buffer used to store the masking
		*     key
		* @param {Number} options.opcode The opcode
		* @param {Boolean} [options.readOnly=false] Specifies whether `data` can be
		*     modified
		* @param {Boolean} [options.rsv1=false] Specifies whether or not to set the
		*     RSV1 bit
		* @param {Function} [cb] Callback
		* @private
		*/
		dispatch(data, compress, options, cb) {
			if (!compress) {
				this.sendFrame(Sender.frame(data, options), cb);
				return;
			}
			const perMessageDeflate = this._extensions[PerMessageDeflate.extensionName];
			this._bufferedBytes += options[kByteLength];
			this._state = DEFLATING;
			perMessageDeflate.compress(data, options.fin, (_, buf) => {
				if (this._socket.destroyed) {
					const err = /* @__PURE__ */ new Error("The socket was closed while data was being compressed");
					callCallbacks(this, err, cb);
					return;
				}
				this._bufferedBytes -= options[kByteLength];
				this._state = DEFAULT;
				options.readOnly = false;
				this.sendFrame(Sender.frame(buf, options), cb);
				this.dequeue();
			});
		}
		/**
		* Executes queued send operations.
		*
		* @private
		*/
		dequeue() {
			while (this._state === DEFAULT && this._queue.length) {
				const params = this._queue.shift();
				this._bufferedBytes -= params[3][kByteLength];
				Reflect.apply(params[0], this, params.slice(1));
			}
		}
		/**
		* Enqueues a send operation.
		*
		* @param {Array} params Send operation parameters.
		* @private
		*/
		enqueue(params) {
			this._bufferedBytes += params[3][kByteLength];
			this._queue.push(params);
		}
		/**
		* Sends a frame.
		*
		* @param {(Buffer | String)[]} list The frame to send
		* @param {Function} [cb] Callback
		* @private
		*/
		sendFrame(list, cb) {
			if (list.length === 2) {
				this._socket.cork();
				this._socket.write(list[0]);
				this._socket.write(list[1], cb);
				this._socket.uncork();
			} else this._socket.write(list[0], cb);
		}
	};
	/**
	* Calls queued callbacks with an error.
	*
	* @param {Sender} sender The `Sender` instance
	* @param {Error} err The error to call the callbacks with
	* @param {Function} [cb] The first callback
	* @private
	*/
	function callCallbacks(sender, err, cb) {
		if (typeof cb === "function") cb(err);
		for (let i = 0; i < sender._queue.length; i++) {
			const params = sender._queue[i];
			const callback = params[params.length - 1];
			if (typeof callback === "function") callback(err);
		}
	}
	/**
	* Handles a `Sender` error.
	*
	* @param {Sender} sender The `Sender` instance
	* @param {Error} err The error
	* @param {Function} [cb] The first pending callback
	* @private
	*/
	function onError(sender, err, cb) {
		callCallbacks(sender, err, cb);
		sender.onerror(err);
	}
}));
//#endregion
//#region ../../node_modules/.pnpm/ws@8.18.3/node_modules/ws/lib/event-target.js
var require_event_target = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var { kForOnEventAttribute, kListener } = require_constants();
	var kCode = Symbol("kCode");
	var kData = Symbol("kData");
	var kError = Symbol("kError");
	var kMessage = Symbol("kMessage");
	var kReason = Symbol("kReason");
	var kTarget = Symbol("kTarget");
	var kType = Symbol("kType");
	var kWasClean = Symbol("kWasClean");
	/**
	* Class representing an event.
	*/
	var Event = class {
		/**
		* Create a new `Event`.
		*
		* @param {String} type The name of the event
		* @throws {TypeError} If the `type` argument is not specified
		*/
		constructor(type) {
			this[kTarget] = null;
			this[kType] = type;
		}
		/**
		* @type {*}
		*/
		get target() {
			return this[kTarget];
		}
		/**
		* @type {String}
		*/
		get type() {
			return this[kType];
		}
	};
	Object.defineProperty(Event.prototype, "target", { enumerable: true });
	Object.defineProperty(Event.prototype, "type", { enumerable: true });
	/**
	* Class representing a close event.
	*
	* @extends Event
	*/
	var CloseEvent = class extends Event {
		/**
		* Create a new `CloseEvent`.
		*
		* @param {String} type The name of the event
		* @param {Object} [options] A dictionary object that allows for setting
		*     attributes via object members of the same name
		* @param {Number} [options.code=0] The status code explaining why the
		*     connection was closed
		* @param {String} [options.reason=''] A human-readable string explaining why
		*     the connection was closed
		* @param {Boolean} [options.wasClean=false] Indicates whether or not the
		*     connection was cleanly closed
		*/
		constructor(type, options = {}) {
			super(type);
			this[kCode] = options.code === void 0 ? 0 : options.code;
			this[kReason] = options.reason === void 0 ? "" : options.reason;
			this[kWasClean] = options.wasClean === void 0 ? false : options.wasClean;
		}
		/**
		* @type {Number}
		*/
		get code() {
			return this[kCode];
		}
		/**
		* @type {String}
		*/
		get reason() {
			return this[kReason];
		}
		/**
		* @type {Boolean}
		*/
		get wasClean() {
			return this[kWasClean];
		}
	};
	Object.defineProperty(CloseEvent.prototype, "code", { enumerable: true });
	Object.defineProperty(CloseEvent.prototype, "reason", { enumerable: true });
	Object.defineProperty(CloseEvent.prototype, "wasClean", { enumerable: true });
	/**
	* Class representing an error event.
	*
	* @extends Event
	*/
	var ErrorEvent = class extends Event {
		/**
		* Create a new `ErrorEvent`.
		*
		* @param {String} type The name of the event
		* @param {Object} [options] A dictionary object that allows for setting
		*     attributes via object members of the same name
		* @param {*} [options.error=null] The error that generated this event
		* @param {String} [options.message=''] The error message
		*/
		constructor(type, options = {}) {
			super(type);
			this[kError] = options.error === void 0 ? null : options.error;
			this[kMessage] = options.message === void 0 ? "" : options.message;
		}
		/**
		* @type {*}
		*/
		get error() {
			return this[kError];
		}
		/**
		* @type {String}
		*/
		get message() {
			return this[kMessage];
		}
	};
	Object.defineProperty(ErrorEvent.prototype, "error", { enumerable: true });
	Object.defineProperty(ErrorEvent.prototype, "message", { enumerable: true });
	/**
	* Class representing a message event.
	*
	* @extends Event
	*/
	var MessageEvent = class extends Event {
		/**
		* Create a new `MessageEvent`.
		*
		* @param {String} type The name of the event
		* @param {Object} [options] A dictionary object that allows for setting
		*     attributes via object members of the same name
		* @param {*} [options.data=null] The message content
		*/
		constructor(type, options = {}) {
			super(type);
			this[kData] = options.data === void 0 ? null : options.data;
		}
		/**
		* @type {*}
		*/
		get data() {
			return this[kData];
		}
	};
	Object.defineProperty(MessageEvent.prototype, "data", { enumerable: true });
	module.exports = {
		CloseEvent,
		ErrorEvent,
		Event,
		EventTarget: {
			/**
			* Register an event listener.
			*
			* @param {String} type A string representing the event type to listen for
			* @param {(Function|Object)} handler The listener to add
			* @param {Object} [options] An options object specifies characteristics about
			*     the event listener
			* @param {Boolean} [options.once=false] A `Boolean` indicating that the
			*     listener should be invoked at most once after being added. If `true`,
			*     the listener would be automatically removed when invoked.
			* @public
			*/
			addEventListener(type, handler, options = {}) {
				for (const listener of this.listeners(type)) if (!options[kForOnEventAttribute] && listener[kListener] === handler && !listener[kForOnEventAttribute]) return;
				let wrapper;
				if (type === "message") wrapper = function onMessage(data, isBinary) {
					const event = new MessageEvent("message", { data: isBinary ? data : data.toString() });
					event[kTarget] = this;
					callListener(handler, this, event);
				};
				else if (type === "close") wrapper = function onClose(code, message) {
					const event = new CloseEvent("close", {
						code,
						reason: message.toString(),
						wasClean: this._closeFrameReceived && this._closeFrameSent
					});
					event[kTarget] = this;
					callListener(handler, this, event);
				};
				else if (type === "error") wrapper = function onError(error) {
					const event = new ErrorEvent("error", {
						error,
						message: error.message
					});
					event[kTarget] = this;
					callListener(handler, this, event);
				};
				else if (type === "open") wrapper = function onOpen() {
					const event = new Event("open");
					event[kTarget] = this;
					callListener(handler, this, event);
				};
				else return;
				wrapper[kForOnEventAttribute] = !!options[kForOnEventAttribute];
				wrapper[kListener] = handler;
				if (options.once) this.once(type, wrapper);
				else this.on(type, wrapper);
			},
			/**
			* Remove an event listener.
			*
			* @param {String} type A string representing the event type to remove
			* @param {(Function|Object)} handler The listener to remove
			* @public
			*/
			removeEventListener(type, handler) {
				for (const listener of this.listeners(type)) if (listener[kListener] === handler && !listener[kForOnEventAttribute]) {
					this.removeListener(type, listener);
					break;
				}
			}
		},
		MessageEvent
	};
	/**
	* Call an event listener
	*
	* @param {(Function|Object)} listener The listener to call
	* @param {*} thisArg The value to use as `this`` when calling the listener
	* @param {Event} event The event to pass to the listener
	* @private
	*/
	function callListener(listener, thisArg, event) {
		if (typeof listener === "object" && listener.handleEvent) listener.handleEvent.call(listener, event);
		else listener.call(thisArg, event);
	}
}));
//#endregion
//#region ../../node_modules/.pnpm/ws@8.18.3/node_modules/ws/lib/extension.js
var require_extension = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var { tokenChars } = require_validation();
	/**
	* Adds an offer to the map of extension offers or a parameter to the map of
	* parameters.
	*
	* @param {Object} dest The map of extension offers or parameters
	* @param {String} name The extension or parameter name
	* @param {(Object|Boolean|String)} elem The extension parameters or the
	*     parameter value
	* @private
	*/
	function push(dest, name, elem) {
		if (dest[name] === void 0) dest[name] = [elem];
		else dest[name].push(elem);
	}
	/**
	* Parses the `Sec-WebSocket-Extensions` header into an object.
	*
	* @param {String} header The field value of the header
	* @return {Object} The parsed object
	* @public
	*/
	function parse(header) {
		const offers = Object.create(null);
		let params = Object.create(null);
		let mustUnescape = false;
		let isEscaping = false;
		let inQuotes = false;
		let extensionName;
		let paramName;
		let start = -1;
		let code = -1;
		let end = -1;
		let i = 0;
		for (; i < header.length; i++) {
			code = header.charCodeAt(i);
			if (extensionName === void 0) if (end === -1 && tokenChars[code] === 1) {
				if (start === -1) start = i;
			} else if (i !== 0 && (code === 32 || code === 9)) {
				if (end === -1 && start !== -1) end = i;
			} else if (code === 59 || code === 44) {
				if (start === -1) throw new SyntaxError(`Unexpected character at index ${i}`);
				if (end === -1) end = i;
				const name = header.slice(start, end);
				if (code === 44) {
					push(offers, name, params);
					params = Object.create(null);
				} else extensionName = name;
				start = end = -1;
			} else throw new SyntaxError(`Unexpected character at index ${i}`);
			else if (paramName === void 0) if (end === -1 && tokenChars[code] === 1) {
				if (start === -1) start = i;
			} else if (code === 32 || code === 9) {
				if (end === -1 && start !== -1) end = i;
			} else if (code === 59 || code === 44) {
				if (start === -1) throw new SyntaxError(`Unexpected character at index ${i}`);
				if (end === -1) end = i;
				push(params, header.slice(start, end), true);
				if (code === 44) {
					push(offers, extensionName, params);
					params = Object.create(null);
					extensionName = void 0;
				}
				start = end = -1;
			} else if (code === 61 && start !== -1 && end === -1) {
				paramName = header.slice(start, i);
				start = end = -1;
			} else throw new SyntaxError(`Unexpected character at index ${i}`);
			else if (isEscaping) {
				if (tokenChars[code] !== 1) throw new SyntaxError(`Unexpected character at index ${i}`);
				if (start === -1) start = i;
				else if (!mustUnescape) mustUnescape = true;
				isEscaping = false;
			} else if (inQuotes) if (tokenChars[code] === 1) {
				if (start === -1) start = i;
			} else if (code === 34 && start !== -1) {
				inQuotes = false;
				end = i;
			} else if (code === 92) isEscaping = true;
			else throw new SyntaxError(`Unexpected character at index ${i}`);
			else if (code === 34 && header.charCodeAt(i - 1) === 61) inQuotes = true;
			else if (end === -1 && tokenChars[code] === 1) {
				if (start === -1) start = i;
			} else if (start !== -1 && (code === 32 || code === 9)) {
				if (end === -1) end = i;
			} else if (code === 59 || code === 44) {
				if (start === -1) throw new SyntaxError(`Unexpected character at index ${i}`);
				if (end === -1) end = i;
				let value = header.slice(start, end);
				if (mustUnescape) {
					value = value.replace(/\\/g, "");
					mustUnescape = false;
				}
				push(params, paramName, value);
				if (code === 44) {
					push(offers, extensionName, params);
					params = Object.create(null);
					extensionName = void 0;
				}
				paramName = void 0;
				start = end = -1;
			} else throw new SyntaxError(`Unexpected character at index ${i}`);
		}
		if (start === -1 || inQuotes || code === 32 || code === 9) throw new SyntaxError("Unexpected end of input");
		if (end === -1) end = i;
		const token = header.slice(start, end);
		if (extensionName === void 0) push(offers, token, params);
		else {
			if (paramName === void 0) push(params, token, true);
			else if (mustUnescape) push(params, paramName, token.replace(/\\/g, ""));
			else push(params, paramName, token);
			push(offers, extensionName, params);
		}
		return offers;
	}
	/**
	* Builds the `Sec-WebSocket-Extensions` header field value.
	*
	* @param {Object} extensions The map of extensions and parameters to format
	* @return {String} A string representing the given object
	* @public
	*/
	function format(extensions) {
		return Object.keys(extensions).map((extension) => {
			let configurations = extensions[extension];
			if (!Array.isArray(configurations)) configurations = [configurations];
			return configurations.map((params) => {
				return [extension].concat(Object.keys(params).map((k) => {
					let values = params[k];
					if (!Array.isArray(values)) values = [values];
					return values.map((v) => v === true ? k : `${k}=${v}`).join("; ");
				})).join("; ");
			}).join(", ");
		}).join(", ");
	}
	module.exports = {
		format,
		parse
	};
}));
//#endregion
//#region ../../node_modules/.pnpm/ws@8.18.3/node_modules/ws/lib/websocket.js
var require_websocket = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var EventEmitter$2 = __require("events");
	var https = __require("https");
	var http$1 = __require("http");
	var net = __require("net");
	var tls = __require("tls");
	var { randomBytes: randomBytes$1, createHash: createHash$2 } = __require("crypto");
	var { Duplex: Duplex$2, Readable: Readable$1 } = __require("stream");
	var { URL: URL$1 } = __require("url");
	var PerMessageDeflate = require_permessage_deflate();
	var Receiver = require_receiver();
	var Sender = require_sender();
	var { isBlob } = require_validation();
	var { BINARY_TYPES, EMPTY_BUFFER, GUID, kForOnEventAttribute, kListener, kStatusCode, kWebSocket, NOOP } = require_constants();
	var { EventTarget: { addEventListener, removeEventListener } } = require_event_target();
	var { format, parse } = require_extension();
	var { toBuffer } = require_buffer_util();
	var closeTimeout = 30 * 1e3;
	var kAborted = Symbol("kAborted");
	var protocolVersions = [8, 13];
	var readyStates = [
		"CONNECTING",
		"OPEN",
		"CLOSING",
		"CLOSED"
	];
	var subprotocolRegex = /^[!#$%&'*+\-.0-9A-Z^_`|a-z~]+$/;
	/**
	* Class representing a WebSocket.
	*
	* @extends EventEmitter
	*/
	var WebSocket = class WebSocket extends EventEmitter$2 {
		/**
		* Create a new `WebSocket`.
		*
		* @param {(String|URL)} address The URL to which to connect
		* @param {(String|String[])} [protocols] The subprotocols
		* @param {Object} [options] Connection options
		*/
		constructor(address, protocols, options) {
			super();
			this._binaryType = BINARY_TYPES[0];
			this._closeCode = 1006;
			this._closeFrameReceived = false;
			this._closeFrameSent = false;
			this._closeMessage = EMPTY_BUFFER;
			this._closeTimer = null;
			this._errorEmitted = false;
			this._extensions = {};
			this._paused = false;
			this._protocol = "";
			this._readyState = WebSocket.CONNECTING;
			this._receiver = null;
			this._sender = null;
			this._socket = null;
			if (address !== null) {
				this._bufferedAmount = 0;
				this._isServer = false;
				this._redirects = 0;
				if (protocols === void 0) protocols = [];
				else if (!Array.isArray(protocols)) if (typeof protocols === "object" && protocols !== null) {
					options = protocols;
					protocols = [];
				} else protocols = [protocols];
				initAsClient(this, address, protocols, options);
			} else {
				this._autoPong = options.autoPong;
				this._isServer = true;
			}
		}
		/**
		* For historical reasons, the custom "nodebuffer" type is used by the default
		* instead of "blob".
		*
		* @type {String}
		*/
		get binaryType() {
			return this._binaryType;
		}
		set binaryType(type) {
			if (!BINARY_TYPES.includes(type)) return;
			this._binaryType = type;
			if (this._receiver) this._receiver._binaryType = type;
		}
		/**
		* @type {Number}
		*/
		get bufferedAmount() {
			if (!this._socket) return this._bufferedAmount;
			return this._socket._writableState.length + this._sender._bufferedBytes;
		}
		/**
		* @type {String}
		*/
		get extensions() {
			return Object.keys(this._extensions).join();
		}
		/**
		* @type {Boolean}
		*/
		get isPaused() {
			return this._paused;
		}
		/**
		* @type {Function}
		*/
		/* istanbul ignore next */
		get onclose() {
			return null;
		}
		/**
		* @type {Function}
		*/
		/* istanbul ignore next */
		get onerror() {
			return null;
		}
		/**
		* @type {Function}
		*/
		/* istanbul ignore next */
		get onopen() {
			return null;
		}
		/**
		* @type {Function}
		*/
		/* istanbul ignore next */
		get onmessage() {
			return null;
		}
		/**
		* @type {String}
		*/
		get protocol() {
			return this._protocol;
		}
		/**
		* @type {Number}
		*/
		get readyState() {
			return this._readyState;
		}
		/**
		* @type {String}
		*/
		get url() {
			return this._url;
		}
		/**
		* Set up the socket and the internal resources.
		*
		* @param {Duplex} socket The network socket between the server and client
		* @param {Buffer} head The first packet of the upgraded stream
		* @param {Object} options Options object
		* @param {Boolean} [options.allowSynchronousEvents=false] Specifies whether
		*     any of the `'message'`, `'ping'`, and `'pong'` events can be emitted
		*     multiple times in the same tick
		* @param {Function} [options.generateMask] The function used to generate the
		*     masking key
		* @param {Number} [options.maxPayload=0] The maximum allowed message size
		* @param {Boolean} [options.skipUTF8Validation=false] Specifies whether or
		*     not to skip UTF-8 validation for text and close messages
		* @private
		*/
		setSocket(socket, head, options) {
			const receiver = new Receiver({
				allowSynchronousEvents: options.allowSynchronousEvents,
				binaryType: this.binaryType,
				extensions: this._extensions,
				isServer: this._isServer,
				maxPayload: options.maxPayload,
				skipUTF8Validation: options.skipUTF8Validation
			});
			const sender = new Sender(socket, this._extensions, options.generateMask);
			this._receiver = receiver;
			this._sender = sender;
			this._socket = socket;
			receiver[kWebSocket] = this;
			sender[kWebSocket] = this;
			socket[kWebSocket] = this;
			receiver.on("conclude", receiverOnConclude);
			receiver.on("drain", receiverOnDrain);
			receiver.on("error", receiverOnError);
			receiver.on("message", receiverOnMessage);
			receiver.on("ping", receiverOnPing);
			receiver.on("pong", receiverOnPong);
			sender.onerror = senderOnError;
			if (socket.setTimeout) socket.setTimeout(0);
			if (socket.setNoDelay) socket.setNoDelay();
			if (head.length > 0) socket.unshift(head);
			socket.on("close", socketOnClose);
			socket.on("data", socketOnData);
			socket.on("end", socketOnEnd);
			socket.on("error", socketOnError);
			this._readyState = WebSocket.OPEN;
			this.emit("open");
		}
		/**
		* Emit the `'close'` event.
		*
		* @private
		*/
		emitClose() {
			if (!this._socket) {
				this._readyState = WebSocket.CLOSED;
				this.emit("close", this._closeCode, this._closeMessage);
				return;
			}
			if (this._extensions[PerMessageDeflate.extensionName]) this._extensions[PerMessageDeflate.extensionName].cleanup();
			this._receiver.removeAllListeners();
			this._readyState = WebSocket.CLOSED;
			this.emit("close", this._closeCode, this._closeMessage);
		}
		/**
		* Start a closing handshake.
		*
		*          +----------+   +-----------+   +----------+
		*     - - -|ws.close()|-->|close frame|-->|ws.close()|- - -
		*    |     +----------+   +-----------+   +----------+     |
		*          +----------+   +-----------+         |
		* CLOSING  |ws.close()|<--|close frame|<--+-----+       CLOSING
		*          +----------+   +-----------+   |
		*    |           |                        |   +---+        |
		*                +------------------------+-->|fin| - - - -
		*    |         +---+                      |   +---+
		*     - - - - -|fin|<---------------------+
		*              +---+
		*
		* @param {Number} [code] Status code explaining why the connection is closing
		* @param {(String|Buffer)} [data] The reason why the connection is
		*     closing
		* @public
		*/
		close(code, data) {
			if (this.readyState === WebSocket.CLOSED) return;
			if (this.readyState === WebSocket.CONNECTING) {
				abortHandshake(this, this._req, "WebSocket was closed before the connection was established");
				return;
			}
			if (this.readyState === WebSocket.CLOSING) {
				if (this._closeFrameSent && (this._closeFrameReceived || this._receiver._writableState.errorEmitted)) this._socket.end();
				return;
			}
			this._readyState = WebSocket.CLOSING;
			this._sender.close(code, data, !this._isServer, (err) => {
				if (err) return;
				this._closeFrameSent = true;
				if (this._closeFrameReceived || this._receiver._writableState.errorEmitted) this._socket.end();
			});
			setCloseTimer(this);
		}
		/**
		* Pause the socket.
		*
		* @public
		*/
		pause() {
			if (this.readyState === WebSocket.CONNECTING || this.readyState === WebSocket.CLOSED) return;
			this._paused = true;
			this._socket.pause();
		}
		/**
		* Send a ping.
		*
		* @param {*} [data] The data to send
		* @param {Boolean} [mask] Indicates whether or not to mask `data`
		* @param {Function} [cb] Callback which is executed when the ping is sent
		* @public
		*/
		ping(data, mask, cb) {
			if (this.readyState === WebSocket.CONNECTING) throw new Error("WebSocket is not open: readyState 0 (CONNECTING)");
			if (typeof data === "function") {
				cb = data;
				data = mask = void 0;
			} else if (typeof mask === "function") {
				cb = mask;
				mask = void 0;
			}
			if (typeof data === "number") data = data.toString();
			if (this.readyState !== WebSocket.OPEN) {
				sendAfterClose(this, data, cb);
				return;
			}
			if (mask === void 0) mask = !this._isServer;
			this._sender.ping(data || EMPTY_BUFFER, mask, cb);
		}
		/**
		* Send a pong.
		*
		* @param {*} [data] The data to send
		* @param {Boolean} [mask] Indicates whether or not to mask `data`
		* @param {Function} [cb] Callback which is executed when the pong is sent
		* @public
		*/
		pong(data, mask, cb) {
			if (this.readyState === WebSocket.CONNECTING) throw new Error("WebSocket is not open: readyState 0 (CONNECTING)");
			if (typeof data === "function") {
				cb = data;
				data = mask = void 0;
			} else if (typeof mask === "function") {
				cb = mask;
				mask = void 0;
			}
			if (typeof data === "number") data = data.toString();
			if (this.readyState !== WebSocket.OPEN) {
				sendAfterClose(this, data, cb);
				return;
			}
			if (mask === void 0) mask = !this._isServer;
			this._sender.pong(data || EMPTY_BUFFER, mask, cb);
		}
		/**
		* Resume the socket.
		*
		* @public
		*/
		resume() {
			if (this.readyState === WebSocket.CONNECTING || this.readyState === WebSocket.CLOSED) return;
			this._paused = false;
			if (!this._receiver._writableState.needDrain) this._socket.resume();
		}
		/**
		* Send a data message.
		*
		* @param {*} data The message to send
		* @param {Object} [options] Options object
		* @param {Boolean} [options.binary] Specifies whether `data` is binary or
		*     text
		* @param {Boolean} [options.compress] Specifies whether or not to compress
		*     `data`
		* @param {Boolean} [options.fin=true] Specifies whether the fragment is the
		*     last one
		* @param {Boolean} [options.mask] Specifies whether or not to mask `data`
		* @param {Function} [cb] Callback which is executed when data is written out
		* @public
		*/
		send(data, options, cb) {
			if (this.readyState === WebSocket.CONNECTING) throw new Error("WebSocket is not open: readyState 0 (CONNECTING)");
			if (typeof options === "function") {
				cb = options;
				options = {};
			}
			if (typeof data === "number") data = data.toString();
			if (this.readyState !== WebSocket.OPEN) {
				sendAfterClose(this, data, cb);
				return;
			}
			const opts = {
				binary: typeof data !== "string",
				mask: !this._isServer,
				compress: true,
				fin: true,
				...options
			};
			if (!this._extensions[PerMessageDeflate.extensionName]) opts.compress = false;
			this._sender.send(data || EMPTY_BUFFER, opts, cb);
		}
		/**
		* Forcibly close the connection.
		*
		* @public
		*/
		terminate() {
			if (this.readyState === WebSocket.CLOSED) return;
			if (this.readyState === WebSocket.CONNECTING) {
				abortHandshake(this, this._req, "WebSocket was closed before the connection was established");
				return;
			}
			if (this._socket) {
				this._readyState = WebSocket.CLOSING;
				this._socket.destroy();
			}
		}
	};
	/**
	* @constant {Number} CONNECTING
	* @memberof WebSocket
	*/
	Object.defineProperty(WebSocket, "CONNECTING", {
		enumerable: true,
		value: readyStates.indexOf("CONNECTING")
	});
	/**
	* @constant {Number} CONNECTING
	* @memberof WebSocket.prototype
	*/
	Object.defineProperty(WebSocket.prototype, "CONNECTING", {
		enumerable: true,
		value: readyStates.indexOf("CONNECTING")
	});
	/**
	* @constant {Number} OPEN
	* @memberof WebSocket
	*/
	Object.defineProperty(WebSocket, "OPEN", {
		enumerable: true,
		value: readyStates.indexOf("OPEN")
	});
	/**
	* @constant {Number} OPEN
	* @memberof WebSocket.prototype
	*/
	Object.defineProperty(WebSocket.prototype, "OPEN", {
		enumerable: true,
		value: readyStates.indexOf("OPEN")
	});
	/**
	* @constant {Number} CLOSING
	* @memberof WebSocket
	*/
	Object.defineProperty(WebSocket, "CLOSING", {
		enumerable: true,
		value: readyStates.indexOf("CLOSING")
	});
	/**
	* @constant {Number} CLOSING
	* @memberof WebSocket.prototype
	*/
	Object.defineProperty(WebSocket.prototype, "CLOSING", {
		enumerable: true,
		value: readyStates.indexOf("CLOSING")
	});
	/**
	* @constant {Number} CLOSED
	* @memberof WebSocket
	*/
	Object.defineProperty(WebSocket, "CLOSED", {
		enumerable: true,
		value: readyStates.indexOf("CLOSED")
	});
	/**
	* @constant {Number} CLOSED
	* @memberof WebSocket.prototype
	*/
	Object.defineProperty(WebSocket.prototype, "CLOSED", {
		enumerable: true,
		value: readyStates.indexOf("CLOSED")
	});
	[
		"binaryType",
		"bufferedAmount",
		"extensions",
		"isPaused",
		"protocol",
		"readyState",
		"url"
	].forEach((property) => {
		Object.defineProperty(WebSocket.prototype, property, { enumerable: true });
	});
	[
		"open",
		"error",
		"close",
		"message"
	].forEach((method) => {
		Object.defineProperty(WebSocket.prototype, `on${method}`, {
			enumerable: true,
			get() {
				for (const listener of this.listeners(method)) if (listener[kForOnEventAttribute]) return listener[kListener];
				return null;
			},
			set(handler) {
				for (const listener of this.listeners(method)) if (listener[kForOnEventAttribute]) {
					this.removeListener(method, listener);
					break;
				}
				if (typeof handler !== "function") return;
				this.addEventListener(method, handler, { [kForOnEventAttribute]: true });
			}
		});
	});
	WebSocket.prototype.addEventListener = addEventListener;
	WebSocket.prototype.removeEventListener = removeEventListener;
	module.exports = WebSocket;
	/**
	* Initialize a WebSocket client.
	*
	* @param {WebSocket} websocket The client to initialize
	* @param {(String|URL)} address The URL to which to connect
	* @param {Array} protocols The subprotocols
	* @param {Object} [options] Connection options
	* @param {Boolean} [options.allowSynchronousEvents=true] Specifies whether any
	*     of the `'message'`, `'ping'`, and `'pong'` events can be emitted multiple
	*     times in the same tick
	* @param {Boolean} [options.autoPong=true] Specifies whether or not to
	*     automatically send a pong in response to a ping
	* @param {Function} [options.finishRequest] A function which can be used to
	*     customize the headers of each http request before it is sent
	* @param {Boolean} [options.followRedirects=false] Whether or not to follow
	*     redirects
	* @param {Function} [options.generateMask] The function used to generate the
	*     masking key
	* @param {Number} [options.handshakeTimeout] Timeout in milliseconds for the
	*     handshake request
	* @param {Number} [options.maxPayload=104857600] The maximum allowed message
	*     size
	* @param {Number} [options.maxRedirects=10] The maximum number of redirects
	*     allowed
	* @param {String} [options.origin] Value of the `Origin` or
	*     `Sec-WebSocket-Origin` header
	* @param {(Boolean|Object)} [options.perMessageDeflate=true] Enable/disable
	*     permessage-deflate
	* @param {Number} [options.protocolVersion=13] Value of the
	*     `Sec-WebSocket-Version` header
	* @param {Boolean} [options.skipUTF8Validation=false] Specifies whether or
	*     not to skip UTF-8 validation for text and close messages
	* @private
	*/
	function initAsClient(websocket, address, protocols, options) {
		const opts = {
			allowSynchronousEvents: true,
			autoPong: true,
			protocolVersion: protocolVersions[1],
			maxPayload: 100 * 1024 * 1024,
			skipUTF8Validation: false,
			perMessageDeflate: true,
			followRedirects: false,
			maxRedirects: 10,
			...options,
			socketPath: void 0,
			hostname: void 0,
			protocol: void 0,
			timeout: void 0,
			method: "GET",
			host: void 0,
			path: void 0,
			port: void 0
		};
		websocket._autoPong = opts.autoPong;
		if (!protocolVersions.includes(opts.protocolVersion)) throw new RangeError(`Unsupported protocol version: ${opts.protocolVersion} (supported versions: ${protocolVersions.join(", ")})`);
		let parsedUrl;
		if (address instanceof URL$1) parsedUrl = address;
		else try {
			parsedUrl = new URL$1(address);
		} catch (e) {
			throw new SyntaxError(`Invalid URL: ${address}`);
		}
		if (parsedUrl.protocol === "http:") parsedUrl.protocol = "ws:";
		else if (parsedUrl.protocol === "https:") parsedUrl.protocol = "wss:";
		websocket._url = parsedUrl.href;
		const isSecure = parsedUrl.protocol === "wss:";
		const isIpcUrl = parsedUrl.protocol === "ws+unix:";
		let invalidUrlMessage;
		if (parsedUrl.protocol !== "ws:" && !isSecure && !isIpcUrl) invalidUrlMessage = "The URL's protocol must be one of \"ws:\", \"wss:\", \"http:\", \"https:\", or \"ws+unix:\"";
		else if (isIpcUrl && !parsedUrl.pathname) invalidUrlMessage = "The URL's pathname is empty";
		else if (parsedUrl.hash) invalidUrlMessage = "The URL contains a fragment identifier";
		if (invalidUrlMessage) {
			const err = new SyntaxError(invalidUrlMessage);
			if (websocket._redirects === 0) throw err;
			else {
				emitErrorAndClose(websocket, err);
				return;
			}
		}
		const defaultPort = isSecure ? 443 : 80;
		const key = randomBytes$1(16).toString("base64");
		const request = isSecure ? https.request : http$1.request;
		const protocolSet = /* @__PURE__ */ new Set();
		let perMessageDeflate;
		opts.createConnection = opts.createConnection || (isSecure ? tlsConnect : netConnect);
		opts.defaultPort = opts.defaultPort || defaultPort;
		opts.port = parsedUrl.port || defaultPort;
		opts.host = parsedUrl.hostname.startsWith("[") ? parsedUrl.hostname.slice(1, -1) : parsedUrl.hostname;
		opts.headers = {
			...opts.headers,
			"Sec-WebSocket-Version": opts.protocolVersion,
			"Sec-WebSocket-Key": key,
			Connection: "Upgrade",
			Upgrade: "websocket"
		};
		opts.path = parsedUrl.pathname + parsedUrl.search;
		opts.timeout = opts.handshakeTimeout;
		if (opts.perMessageDeflate) {
			perMessageDeflate = new PerMessageDeflate(opts.perMessageDeflate !== true ? opts.perMessageDeflate : {}, false, opts.maxPayload);
			opts.headers["Sec-WebSocket-Extensions"] = format({ [PerMessageDeflate.extensionName]: perMessageDeflate.offer() });
		}
		if (protocols.length) {
			for (const protocol of protocols) {
				if (typeof protocol !== "string" || !subprotocolRegex.test(protocol) || protocolSet.has(protocol)) throw new SyntaxError("An invalid or duplicated subprotocol was specified");
				protocolSet.add(protocol);
			}
			opts.headers["Sec-WebSocket-Protocol"] = protocols.join(",");
		}
		if (opts.origin) if (opts.protocolVersion < 13) opts.headers["Sec-WebSocket-Origin"] = opts.origin;
		else opts.headers.Origin = opts.origin;
		if (parsedUrl.username || parsedUrl.password) opts.auth = `${parsedUrl.username}:${parsedUrl.password}`;
		if (isIpcUrl) {
			const parts = opts.path.split(":");
			opts.socketPath = parts[0];
			opts.path = parts[1];
		}
		let req;
		if (opts.followRedirects) {
			if (websocket._redirects === 0) {
				websocket._originalIpc = isIpcUrl;
				websocket._originalSecure = isSecure;
				websocket._originalHostOrSocketPath = isIpcUrl ? opts.socketPath : parsedUrl.host;
				const headers = options && options.headers;
				options = {
					...options,
					headers: {}
				};
				if (headers) for (const [key, value] of Object.entries(headers)) options.headers[key.toLowerCase()] = value;
			} else if (websocket.listenerCount("redirect") === 0) {
				const isSameHost = isIpcUrl ? websocket._originalIpc ? opts.socketPath === websocket._originalHostOrSocketPath : false : websocket._originalIpc ? false : parsedUrl.host === websocket._originalHostOrSocketPath;
				if (!isSameHost || websocket._originalSecure && !isSecure) {
					delete opts.headers.authorization;
					delete opts.headers.cookie;
					if (!isSameHost) delete opts.headers.host;
					opts.auth = void 0;
				}
			}
			if (opts.auth && !options.headers.authorization) options.headers.authorization = "Basic " + Buffer.from(opts.auth).toString("base64");
			req = websocket._req = request(opts);
			if (websocket._redirects) websocket.emit("redirect", websocket.url, req);
		} else req = websocket._req = request(opts);
		if (opts.timeout) req.on("timeout", () => {
			abortHandshake(websocket, req, "Opening handshake has timed out");
		});
		req.on("error", (err) => {
			if (req === null || req[kAborted]) return;
			req = websocket._req = null;
			emitErrorAndClose(websocket, err);
		});
		req.on("response", (res) => {
			const location = res.headers.location;
			const statusCode = res.statusCode;
			if (location && opts.followRedirects && statusCode >= 300 && statusCode < 400) {
				if (++websocket._redirects > opts.maxRedirects) {
					abortHandshake(websocket, req, "Maximum redirects exceeded");
					return;
				}
				req.abort();
				let addr;
				try {
					addr = new URL$1(location, address);
				} catch (e) {
					emitErrorAndClose(websocket, /* @__PURE__ */ new SyntaxError(`Invalid URL: ${location}`));
					return;
				}
				initAsClient(websocket, addr, protocols, options);
			} else if (!websocket.emit("unexpected-response", req, res)) abortHandshake(websocket, req, `Unexpected server response: ${res.statusCode}`);
		});
		req.on("upgrade", (res, socket, head) => {
			websocket.emit("upgrade", res);
			if (websocket.readyState !== WebSocket.CONNECTING) return;
			req = websocket._req = null;
			const upgrade = res.headers.upgrade;
			if (upgrade === void 0 || upgrade.toLowerCase() !== "websocket") {
				abortHandshake(websocket, socket, "Invalid Upgrade header");
				return;
			}
			const digest = createHash$2("sha1").update(key + GUID).digest("base64");
			if (res.headers["sec-websocket-accept"] !== digest) {
				abortHandshake(websocket, socket, "Invalid Sec-WebSocket-Accept header");
				return;
			}
			const serverProt = res.headers["sec-websocket-protocol"];
			let protError;
			if (serverProt !== void 0) {
				if (!protocolSet.size) protError = "Server sent a subprotocol but none was requested";
				else if (!protocolSet.has(serverProt)) protError = "Server sent an invalid subprotocol";
			} else if (protocolSet.size) protError = "Server sent no subprotocol";
			if (protError) {
				abortHandshake(websocket, socket, protError);
				return;
			}
			if (serverProt) websocket._protocol = serverProt;
			const secWebSocketExtensions = res.headers["sec-websocket-extensions"];
			if (secWebSocketExtensions !== void 0) {
				if (!perMessageDeflate) {
					abortHandshake(websocket, socket, "Server sent a Sec-WebSocket-Extensions header but no extension was requested");
					return;
				}
				let extensions;
				try {
					extensions = parse(secWebSocketExtensions);
				} catch (err) {
					abortHandshake(websocket, socket, "Invalid Sec-WebSocket-Extensions header");
					return;
				}
				const extensionNames = Object.keys(extensions);
				if (extensionNames.length !== 1 || extensionNames[0] !== PerMessageDeflate.extensionName) {
					abortHandshake(websocket, socket, "Server indicated an extension that was not requested");
					return;
				}
				try {
					perMessageDeflate.accept(extensions[PerMessageDeflate.extensionName]);
				} catch (err) {
					abortHandshake(websocket, socket, "Invalid Sec-WebSocket-Extensions header");
					return;
				}
				websocket._extensions[PerMessageDeflate.extensionName] = perMessageDeflate;
			}
			websocket.setSocket(socket, head, {
				allowSynchronousEvents: opts.allowSynchronousEvents,
				generateMask: opts.generateMask,
				maxPayload: opts.maxPayload,
				skipUTF8Validation: opts.skipUTF8Validation
			});
		});
		if (opts.finishRequest) opts.finishRequest(req, websocket);
		else req.end();
	}
	/**
	* Emit the `'error'` and `'close'` events.
	*
	* @param {WebSocket} websocket The WebSocket instance
	* @param {Error} The error to emit
	* @private
	*/
	function emitErrorAndClose(websocket, err) {
		websocket._readyState = WebSocket.CLOSING;
		websocket._errorEmitted = true;
		websocket.emit("error", err);
		websocket.emitClose();
	}
	/**
	* Create a `net.Socket` and initiate a connection.
	*
	* @param {Object} options Connection options
	* @return {net.Socket} The newly created socket used to start the connection
	* @private
	*/
	function netConnect(options) {
		options.path = options.socketPath;
		return net.connect(options);
	}
	/**
	* Create a `tls.TLSSocket` and initiate a connection.
	*
	* @param {Object} options Connection options
	* @return {tls.TLSSocket} The newly created socket used to start the connection
	* @private
	*/
	function tlsConnect(options) {
		options.path = void 0;
		if (!options.servername && options.servername !== "") options.servername = net.isIP(options.host) ? "" : options.host;
		return tls.connect(options);
	}
	/**
	* Abort the handshake and emit an error.
	*
	* @param {WebSocket} websocket The WebSocket instance
	* @param {(http.ClientRequest|net.Socket|tls.Socket)} stream The request to
	*     abort or the socket to destroy
	* @param {String} message The error message
	* @private
	*/
	function abortHandshake(websocket, stream, message) {
		websocket._readyState = WebSocket.CLOSING;
		const err = new Error(message);
		Error.captureStackTrace(err, abortHandshake);
		if (stream.setHeader) {
			stream[kAborted] = true;
			stream.abort();
			if (stream.socket && !stream.socket.destroyed) stream.socket.destroy();
			process.nextTick(emitErrorAndClose, websocket, err);
		} else {
			stream.destroy(err);
			stream.once("error", websocket.emit.bind(websocket, "error"));
			stream.once("close", websocket.emitClose.bind(websocket));
		}
	}
	/**
	* Handle cases where the `ping()`, `pong()`, or `send()` methods are called
	* when the `readyState` attribute is `CLOSING` or `CLOSED`.
	*
	* @param {WebSocket} websocket The WebSocket instance
	* @param {*} [data] The data to send
	* @param {Function} [cb] Callback
	* @private
	*/
	function sendAfterClose(websocket, data, cb) {
		if (data) {
			const length = isBlob(data) ? data.size : toBuffer(data).length;
			if (websocket._socket) websocket._sender._bufferedBytes += length;
			else websocket._bufferedAmount += length;
		}
		if (cb) {
			const err = /* @__PURE__ */ new Error(`WebSocket is not open: readyState ${websocket.readyState} (${readyStates[websocket.readyState]})`);
			process.nextTick(cb, err);
		}
	}
	/**
	* The listener of the `Receiver` `'conclude'` event.
	*
	* @param {Number} code The status code
	* @param {Buffer} reason The reason for closing
	* @private
	*/
	function receiverOnConclude(code, reason) {
		const websocket = this[kWebSocket];
		websocket._closeFrameReceived = true;
		websocket._closeMessage = reason;
		websocket._closeCode = code;
		if (websocket._socket[kWebSocket] === void 0) return;
		websocket._socket.removeListener("data", socketOnData);
		process.nextTick(resume, websocket._socket);
		if (code === 1005) websocket.close();
		else websocket.close(code, reason);
	}
	/**
	* The listener of the `Receiver` `'drain'` event.
	*
	* @private
	*/
	function receiverOnDrain() {
		const websocket = this[kWebSocket];
		if (!websocket.isPaused) websocket._socket.resume();
	}
	/**
	* The listener of the `Receiver` `'error'` event.
	*
	* @param {(RangeError|Error)} err The emitted error
	* @private
	*/
	function receiverOnError(err) {
		const websocket = this[kWebSocket];
		if (websocket._socket[kWebSocket] !== void 0) {
			websocket._socket.removeListener("data", socketOnData);
			process.nextTick(resume, websocket._socket);
			websocket.close(err[kStatusCode]);
		}
		if (!websocket._errorEmitted) {
			websocket._errorEmitted = true;
			websocket.emit("error", err);
		}
	}
	/**
	* The listener of the `Receiver` `'finish'` event.
	*
	* @private
	*/
	function receiverOnFinish() {
		this[kWebSocket].emitClose();
	}
	/**
	* The listener of the `Receiver` `'message'` event.
	*
	* @param {Buffer|ArrayBuffer|Buffer[])} data The message
	* @param {Boolean} isBinary Specifies whether the message is binary or not
	* @private
	*/
	function receiverOnMessage(data, isBinary) {
		this[kWebSocket].emit("message", data, isBinary);
	}
	/**
	* The listener of the `Receiver` `'ping'` event.
	*
	* @param {Buffer} data The data included in the ping frame
	* @private
	*/
	function receiverOnPing(data) {
		const websocket = this[kWebSocket];
		if (websocket._autoPong) websocket.pong(data, !this._isServer, NOOP);
		websocket.emit("ping", data);
	}
	/**
	* The listener of the `Receiver` `'pong'` event.
	*
	* @param {Buffer} data The data included in the pong frame
	* @private
	*/
	function receiverOnPong(data) {
		this[kWebSocket].emit("pong", data);
	}
	/**
	* Resume a readable stream
	*
	* @param {Readable} stream The readable stream
	* @private
	*/
	function resume(stream) {
		stream.resume();
	}
	/**
	* The `Sender` error event handler.
	*
	* @param {Error} The error
	* @private
	*/
	function senderOnError(err) {
		const websocket = this[kWebSocket];
		if (websocket.readyState === WebSocket.CLOSED) return;
		if (websocket.readyState === WebSocket.OPEN) {
			websocket._readyState = WebSocket.CLOSING;
			setCloseTimer(websocket);
		}
		this._socket.end();
		if (!websocket._errorEmitted) {
			websocket._errorEmitted = true;
			websocket.emit("error", err);
		}
	}
	/**
	* Set a timer to destroy the underlying raw socket of a WebSocket.
	*
	* @param {WebSocket} websocket The WebSocket instance
	* @private
	*/
	function setCloseTimer(websocket) {
		websocket._closeTimer = setTimeout(websocket._socket.destroy.bind(websocket._socket), closeTimeout);
	}
	/**
	* The listener of the socket `'close'` event.
	*
	* @private
	*/
	function socketOnClose() {
		const websocket = this[kWebSocket];
		this.removeListener("close", socketOnClose);
		this.removeListener("data", socketOnData);
		this.removeListener("end", socketOnEnd);
		websocket._readyState = WebSocket.CLOSING;
		let chunk;
		if (!this._readableState.endEmitted && !websocket._closeFrameReceived && !websocket._receiver._writableState.errorEmitted && (chunk = websocket._socket.read()) !== null) websocket._receiver.write(chunk);
		websocket._receiver.end();
		this[kWebSocket] = void 0;
		clearTimeout(websocket._closeTimer);
		if (websocket._receiver._writableState.finished || websocket._receiver._writableState.errorEmitted) websocket.emitClose();
		else {
			websocket._receiver.on("error", receiverOnFinish);
			websocket._receiver.on("finish", receiverOnFinish);
		}
	}
	/**
	* The listener of the socket `'data'` event.
	*
	* @param {Buffer} chunk A chunk of data
	* @private
	*/
	function socketOnData(chunk) {
		if (!this[kWebSocket]._receiver.write(chunk)) this.pause();
	}
	/**
	* The listener of the socket `'end'` event.
	*
	* @private
	*/
	function socketOnEnd() {
		const websocket = this[kWebSocket];
		websocket._readyState = WebSocket.CLOSING;
		websocket._receiver.end();
		this.end();
	}
	/**
	* The listener of the socket `'error'` event.
	*
	* @private
	*/
	function socketOnError() {
		const websocket = this[kWebSocket];
		this.removeListener("error", socketOnError);
		this.on("error", NOOP);
		if (websocket) {
			websocket._readyState = WebSocket.CLOSING;
			this.destroy();
		}
	}
}));
//#endregion
//#region ../../node_modules/.pnpm/ws@8.18.3/node_modules/ws/lib/stream.js
var require_stream = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	require_websocket();
	var { Duplex: Duplex$1 } = __require("stream");
	/**
	* Emits the `'close'` event on a stream.
	*
	* @param {Duplex} stream The stream.
	* @private
	*/
	function emitClose(stream) {
		stream.emit("close");
	}
	/**
	* The listener of the `'end'` event.
	*
	* @private
	*/
	function duplexOnEnd() {
		if (!this.destroyed && this._writableState.finished) this.destroy();
	}
	/**
	* The listener of the `'error'` event.
	*
	* @param {Error} err The error
	* @private
	*/
	function duplexOnError(err) {
		this.removeListener("error", duplexOnError);
		this.destroy();
		if (this.listenerCount("error") === 0) this.emit("error", err);
	}
	/**
	* Wraps a `WebSocket` in a duplex stream.
	*
	* @param {WebSocket} ws The `WebSocket` to wrap
	* @param {Object} [options] The options for the `Duplex` constructor
	* @return {Duplex} The duplex stream
	* @public
	*/
	function createWebSocketStream(ws, options) {
		let terminateOnDestroy = true;
		const duplex = new Duplex$1({
			...options,
			autoDestroy: false,
			emitClose: false,
			objectMode: false,
			writableObjectMode: false
		});
		ws.on("message", function message(msg, isBinary) {
			const data = !isBinary && duplex._readableState.objectMode ? msg.toString() : msg;
			if (!duplex.push(data)) ws.pause();
		});
		ws.once("error", function error(err) {
			if (duplex.destroyed) return;
			terminateOnDestroy = false;
			duplex.destroy(err);
		});
		ws.once("close", function close() {
			if (duplex.destroyed) return;
			duplex.push(null);
		});
		duplex._destroy = function(err, callback) {
			if (ws.readyState === ws.CLOSED) {
				callback(err);
				process.nextTick(emitClose, duplex);
				return;
			}
			let called = false;
			ws.once("error", function error(err) {
				called = true;
				callback(err);
			});
			ws.once("close", function close() {
				if (!called) callback(err);
				process.nextTick(emitClose, duplex);
			});
			if (terminateOnDestroy) ws.terminate();
		};
		duplex._final = function(callback) {
			if (ws.readyState === ws.CONNECTING) {
				ws.once("open", function open() {
					duplex._final(callback);
				});
				return;
			}
			if (ws._socket === null) return;
			if (ws._socket._writableState.finished) {
				callback();
				if (duplex._readableState.endEmitted) duplex.destroy();
			} else {
				ws._socket.once("finish", function finish() {
					callback();
				});
				ws.close();
			}
		};
		duplex._read = function() {
			if (ws.isPaused) ws.resume();
		};
		duplex._write = function(chunk, encoding, callback) {
			if (ws.readyState === ws.CONNECTING) {
				ws.once("open", function open() {
					duplex._write(chunk, encoding, callback);
				});
				return;
			}
			ws.send(chunk, callback);
		};
		duplex.on("end", duplexOnEnd);
		duplex.on("error", duplexOnError);
		return duplex;
	}
	module.exports = createWebSocketStream;
}));
//#endregion
//#region ../../node_modules/.pnpm/ws@8.18.3/node_modules/ws/lib/subprotocol.js
var require_subprotocol = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var { tokenChars } = require_validation();
	/**
	* Parses the `Sec-WebSocket-Protocol` header into a set of subprotocol names.
	*
	* @param {String} header The field value of the header
	* @return {Set} The subprotocol names
	* @public
	*/
	function parse(header) {
		const protocols = /* @__PURE__ */ new Set();
		let start = -1;
		let end = -1;
		let i = 0;
		for (; i < header.length; i++) {
			const code = header.charCodeAt(i);
			if (end === -1 && tokenChars[code] === 1) {
				if (start === -1) start = i;
			} else if (i !== 0 && (code === 32 || code === 9)) {
				if (end === -1 && start !== -1) end = i;
			} else if (code === 44) {
				if (start === -1) throw new SyntaxError(`Unexpected character at index ${i}`);
				if (end === -1) end = i;
				const protocol = header.slice(start, end);
				if (protocols.has(protocol)) throw new SyntaxError(`The "${protocol}" subprotocol is duplicated`);
				protocols.add(protocol);
				start = end = -1;
			} else throw new SyntaxError(`Unexpected character at index ${i}`);
		}
		if (start === -1 || end !== -1) throw new SyntaxError("Unexpected end of input");
		const protocol = header.slice(start, i);
		if (protocols.has(protocol)) throw new SyntaxError(`The "${protocol}" subprotocol is duplicated`);
		protocols.add(protocol);
		return protocols;
	}
	module.exports = { parse };
}));
//#endregion
//#region ../../node_modules/.pnpm/ws@8.18.3/node_modules/ws/lib/websocket-server.js
var require_websocket_server = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var EventEmitter$1 = __require("events");
	var http = __require("http");
	var { Duplex } = __require("stream");
	var { createHash: createHash$1 } = __require("crypto");
	var extension = require_extension();
	var PerMessageDeflate = require_permessage_deflate();
	var subprotocol = require_subprotocol();
	var WebSocket = require_websocket();
	var { GUID, kWebSocket } = require_constants();
	var keyRegex = /^[+/0-9A-Za-z]{22}==$/;
	var RUNNING = 0;
	var CLOSING = 1;
	var CLOSED = 2;
	/**
	* Class representing a WebSocket server.
	*
	* @extends EventEmitter
	*/
	var WebSocketServer = class extends EventEmitter$1 {
		/**
		* Create a `WebSocketServer` instance.
		*
		* @param {Object} options Configuration options
		* @param {Boolean} [options.allowSynchronousEvents=true] Specifies whether
		*     any of the `'message'`, `'ping'`, and `'pong'` events can be emitted
		*     multiple times in the same tick
		* @param {Boolean} [options.autoPong=true] Specifies whether or not to
		*     automatically send a pong in response to a ping
		* @param {Number} [options.backlog=511] The maximum length of the queue of
		*     pending connections
		* @param {Boolean} [options.clientTracking=true] Specifies whether or not to
		*     track clients
		* @param {Function} [options.handleProtocols] A hook to handle protocols
		* @param {String} [options.host] The hostname where to bind the server
		* @param {Number} [options.maxPayload=104857600] The maximum allowed message
		*     size
		* @param {Boolean} [options.noServer=false] Enable no server mode
		* @param {String} [options.path] Accept only connections matching this path
		* @param {(Boolean|Object)} [options.perMessageDeflate=false] Enable/disable
		*     permessage-deflate
		* @param {Number} [options.port] The port where to bind the server
		* @param {(http.Server|https.Server)} [options.server] A pre-created HTTP/S
		*     server to use
		* @param {Boolean} [options.skipUTF8Validation=false] Specifies whether or
		*     not to skip UTF-8 validation for text and close messages
		* @param {Function} [options.verifyClient] A hook to reject connections
		* @param {Function} [options.WebSocket=WebSocket] Specifies the `WebSocket`
		*     class to use. It must be the `WebSocket` class or class that extends it
		* @param {Function} [callback] A listener for the `listening` event
		*/
		constructor(options, callback) {
			super();
			options = {
				allowSynchronousEvents: true,
				autoPong: true,
				maxPayload: 100 * 1024 * 1024,
				skipUTF8Validation: false,
				perMessageDeflate: false,
				handleProtocols: null,
				clientTracking: true,
				verifyClient: null,
				noServer: false,
				backlog: null,
				server: null,
				host: null,
				path: null,
				port: null,
				WebSocket,
				...options
			};
			if (options.port == null && !options.server && !options.noServer || options.port != null && (options.server || options.noServer) || options.server && options.noServer) throw new TypeError("One and only one of the \"port\", \"server\", or \"noServer\" options must be specified");
			if (options.port != null) {
				this._server = http.createServer((req, res) => {
					const body = http.STATUS_CODES[426];
					res.writeHead(426, {
						"Content-Length": body.length,
						"Content-Type": "text/plain"
					});
					res.end(body);
				});
				this._server.listen(options.port, options.host, options.backlog, callback);
			} else if (options.server) this._server = options.server;
			if (this._server) {
				const emitConnection = this.emit.bind(this, "connection");
				this._removeListeners = addListeners(this._server, {
					listening: this.emit.bind(this, "listening"),
					error: this.emit.bind(this, "error"),
					upgrade: (req, socket, head) => {
						this.handleUpgrade(req, socket, head, emitConnection);
					}
				});
			}
			if (options.perMessageDeflate === true) options.perMessageDeflate = {};
			if (options.clientTracking) {
				this.clients = /* @__PURE__ */ new Set();
				this._shouldEmitClose = false;
			}
			this.options = options;
			this._state = RUNNING;
		}
		/**
		* Returns the bound address, the address family name, and port of the server
		* as reported by the operating system if listening on an IP socket.
		* If the server is listening on a pipe or UNIX domain socket, the name is
		* returned as a string.
		*
		* @return {(Object|String|null)} The address of the server
		* @public
		*/
		address() {
			if (this.options.noServer) throw new Error("The server is operating in \"noServer\" mode");
			if (!this._server) return null;
			return this._server.address();
		}
		/**
		* Stop the server from accepting new connections and emit the `'close'` event
		* when all existing connections are closed.
		*
		* @param {Function} [cb] A one-time listener for the `'close'` event
		* @public
		*/
		close(cb) {
			if (this._state === CLOSED) {
				if (cb) this.once("close", () => {
					cb(/* @__PURE__ */ new Error("The server is not running"));
				});
				process.nextTick(emitClose, this);
				return;
			}
			if (cb) this.once("close", cb);
			if (this._state === CLOSING) return;
			this._state = CLOSING;
			if (this.options.noServer || this.options.server) {
				if (this._server) {
					this._removeListeners();
					this._removeListeners = this._server = null;
				}
				if (this.clients) if (!this.clients.size) process.nextTick(emitClose, this);
				else this._shouldEmitClose = true;
				else process.nextTick(emitClose, this);
			} else {
				const server = this._server;
				this._removeListeners();
				this._removeListeners = this._server = null;
				server.close(() => {
					emitClose(this);
				});
			}
		}
		/**
		* See if a given request should be handled by this server instance.
		*
		* @param {http.IncomingMessage} req Request object to inspect
		* @return {Boolean} `true` if the request is valid, else `false`
		* @public
		*/
		shouldHandle(req) {
			if (this.options.path) {
				const index = req.url.indexOf("?");
				if ((index !== -1 ? req.url.slice(0, index) : req.url) !== this.options.path) return false;
			}
			return true;
		}
		/**
		* Handle a HTTP Upgrade request.
		*
		* @param {http.IncomingMessage} req The request object
		* @param {Duplex} socket The network socket between the server and client
		* @param {Buffer} head The first packet of the upgraded stream
		* @param {Function} cb Callback
		* @public
		*/
		handleUpgrade(req, socket, head, cb) {
			socket.on("error", socketOnError);
			const key = req.headers["sec-websocket-key"];
			const upgrade = req.headers.upgrade;
			const version = +req.headers["sec-websocket-version"];
			if (req.method !== "GET") {
				abortHandshakeOrEmitwsClientError(this, req, socket, 405, "Invalid HTTP method");
				return;
			}
			if (upgrade === void 0 || upgrade.toLowerCase() !== "websocket") {
				abortHandshakeOrEmitwsClientError(this, req, socket, 400, "Invalid Upgrade header");
				return;
			}
			if (key === void 0 || !keyRegex.test(key)) {
				abortHandshakeOrEmitwsClientError(this, req, socket, 400, "Missing or invalid Sec-WebSocket-Key header");
				return;
			}
			if (version !== 13 && version !== 8) {
				abortHandshakeOrEmitwsClientError(this, req, socket, 400, "Missing or invalid Sec-WebSocket-Version header", { "Sec-WebSocket-Version": "13, 8" });
				return;
			}
			if (!this.shouldHandle(req)) {
				abortHandshake(socket, 400);
				return;
			}
			const secWebSocketProtocol = req.headers["sec-websocket-protocol"];
			let protocols = /* @__PURE__ */ new Set();
			if (secWebSocketProtocol !== void 0) try {
				protocols = subprotocol.parse(secWebSocketProtocol);
			} catch (err) {
				abortHandshakeOrEmitwsClientError(this, req, socket, 400, "Invalid Sec-WebSocket-Protocol header");
				return;
			}
			const secWebSocketExtensions = req.headers["sec-websocket-extensions"];
			const extensions = {};
			if (this.options.perMessageDeflate && secWebSocketExtensions !== void 0) {
				const perMessageDeflate = new PerMessageDeflate(this.options.perMessageDeflate, true, this.options.maxPayload);
				try {
					const offers = extension.parse(secWebSocketExtensions);
					if (offers[PerMessageDeflate.extensionName]) {
						perMessageDeflate.accept(offers[PerMessageDeflate.extensionName]);
						extensions[PerMessageDeflate.extensionName] = perMessageDeflate;
					}
				} catch (err) {
					abortHandshakeOrEmitwsClientError(this, req, socket, 400, "Invalid or unacceptable Sec-WebSocket-Extensions header");
					return;
				}
			}
			if (this.options.verifyClient) {
				const info = {
					origin: req.headers[`${version === 8 ? "sec-websocket-origin" : "origin"}`],
					secure: !!(req.socket.authorized || req.socket.encrypted),
					req
				};
				if (this.options.verifyClient.length === 2) {
					this.options.verifyClient(info, (verified, code, message, headers) => {
						if (!verified) return abortHandshake(socket, code || 401, message, headers);
						this.completeUpgrade(extensions, key, protocols, req, socket, head, cb);
					});
					return;
				}
				if (!this.options.verifyClient(info)) return abortHandshake(socket, 401);
			}
			this.completeUpgrade(extensions, key, protocols, req, socket, head, cb);
		}
		/**
		* Upgrade the connection to WebSocket.
		*
		* @param {Object} extensions The accepted extensions
		* @param {String} key The value of the `Sec-WebSocket-Key` header
		* @param {Set} protocols The subprotocols
		* @param {http.IncomingMessage} req The request object
		* @param {Duplex} socket The network socket between the server and client
		* @param {Buffer} head The first packet of the upgraded stream
		* @param {Function} cb Callback
		* @throws {Error} If called more than once with the same socket
		* @private
		*/
		completeUpgrade(extensions, key, protocols, req, socket, head, cb) {
			if (!socket.readable || !socket.writable) return socket.destroy();
			if (socket[kWebSocket]) throw new Error("server.handleUpgrade() was called more than once with the same socket, possibly due to a misconfiguration");
			if (this._state > RUNNING) return abortHandshake(socket, 503);
			const headers = [
				"HTTP/1.1 101 Switching Protocols",
				"Upgrade: websocket",
				"Connection: Upgrade",
				`Sec-WebSocket-Accept: ${createHash$1("sha1").update(key + GUID).digest("base64")}`
			];
			const ws = new this.options.WebSocket(null, void 0, this.options);
			if (protocols.size) {
				const protocol = this.options.handleProtocols ? this.options.handleProtocols(protocols, req) : protocols.values().next().value;
				if (protocol) {
					headers.push(`Sec-WebSocket-Protocol: ${protocol}`);
					ws._protocol = protocol;
				}
			}
			if (extensions[PerMessageDeflate.extensionName]) {
				const params = extensions[PerMessageDeflate.extensionName].params;
				const value = extension.format({ [PerMessageDeflate.extensionName]: [params] });
				headers.push(`Sec-WebSocket-Extensions: ${value}`);
				ws._extensions = extensions;
			}
			this.emit("headers", headers, req);
			socket.write(headers.concat("\r\n").join("\r\n"));
			socket.removeListener("error", socketOnError);
			ws.setSocket(socket, head, {
				allowSynchronousEvents: this.options.allowSynchronousEvents,
				maxPayload: this.options.maxPayload,
				skipUTF8Validation: this.options.skipUTF8Validation
			});
			if (this.clients) {
				this.clients.add(ws);
				ws.on("close", () => {
					this.clients.delete(ws);
					if (this._shouldEmitClose && !this.clients.size) process.nextTick(emitClose, this);
				});
			}
			cb(ws, req);
		}
	};
	module.exports = WebSocketServer;
	/**
	* Add event listeners on an `EventEmitter` using a map of <event, listener>
	* pairs.
	*
	* @param {EventEmitter} server The event emitter
	* @param {Object.<String, Function>} map The listeners to add
	* @return {Function} A function that will remove the added listeners when
	*     called
	* @private
	*/
	function addListeners(server, map) {
		for (const event of Object.keys(map)) server.on(event, map[event]);
		return function removeListeners() {
			for (const event of Object.keys(map)) server.removeListener(event, map[event]);
		};
	}
	/**
	* Emit a `'close'` event on an `EventEmitter`.
	*
	* @param {EventEmitter} server The event emitter
	* @private
	*/
	function emitClose(server) {
		server._state = CLOSED;
		server.emit("close");
	}
	/**
	* Handle socket errors.
	*
	* @private
	*/
	function socketOnError() {
		this.destroy();
	}
	/**
	* Close the connection when preconditions are not fulfilled.
	*
	* @param {Duplex} socket The socket of the upgrade request
	* @param {Number} code The HTTP response status code
	* @param {String} [message] The HTTP response body
	* @param {Object} [headers] Additional HTTP response headers
	* @private
	*/
	function abortHandshake(socket, code, message, headers) {
		message = message || http.STATUS_CODES[code];
		headers = {
			Connection: "close",
			"Content-Type": "text/html",
			"Content-Length": Buffer.byteLength(message),
			...headers
		};
		socket.once("finish", socket.destroy);
		socket.end(`HTTP/1.1 ${code} ${http.STATUS_CODES[code]}\r\n` + Object.keys(headers).map((h) => `${h}: ${headers[h]}`).join("\r\n") + "\r\n\r\n" + message);
	}
	/**
	* Emit a `'wsClientError'` event on a `WebSocketServer` if there is at least
	* one listener for it, otherwise call `abortHandshake()`.
	*
	* @param {WebSocketServer} server The WebSocket server
	* @param {http.IncomingMessage} req The request object
	* @param {Duplex} socket The socket of the upgrade request
	* @param {Number} code The HTTP response status code
	* @param {String} message The HTTP response body
	* @param {Object} [headers] The HTTP response headers
	* @private
	*/
	function abortHandshakeOrEmitwsClientError(server, req, socket, code, message, headers) {
		if (server.listenerCount("wsClientError")) {
			const err = new Error(message);
			Error.captureStackTrace(err, abortHandshakeOrEmitwsClientError);
			server.emit("wsClientError", err, socket, req);
		} else abortHandshake(socket, code, message, headers);
	}
}));
require_stream();
require_receiver();
require_sender();
require_websocket();
var import_websocket_server = /* @__PURE__ */ __toESM(require_websocket_server(), 1);
//#endregion
//#region ../../node_modules/.pnpm/hono@4.12.32/node_modules/hono/dist/compose.js
var compose = (middleware, onError, onNotFound) => {
	return (context, next) => {
		let index = -1;
		return dispatch(0);
		async function dispatch(i) {
			if (i <= index) throw new Error("next() called multiple times");
			index = i;
			let res;
			let isError = false;
			let handler;
			if (middleware[i]) {
				handler = middleware[i][0][0];
				context.req.routeIndex = i;
			} else handler = i === middleware.length && next || void 0;
			if (handler) try {
				res = await handler(context, () => dispatch(i + 1));
			} catch (err) {
				if (err instanceof Error && onError) {
					context.error = err;
					res = await onError(err, context);
					isError = true;
				} else throw err;
			}
			else if (context.finalized === false && onNotFound) res = await onNotFound(context);
			if (res && (context.finalized === false || isError)) context.res = res;
			return context;
		}
	};
};
//#endregion
//#region ../../node_modules/.pnpm/hono@4.12.32/node_modules/hono/dist/request/constants.js
var GET_MATCH_RESULT = /* @__PURE__ */ Symbol();
//#endregion
//#region ../../node_modules/.pnpm/hono@4.12.32/node_modules/hono/dist/utils/buffer.js
var bufferToFormData = (arrayBuffer, contentType) => {
	return new Response(arrayBuffer, { headers: { "Content-Type": contentType.replace(/^[^;]+/, (mediaType) => mediaType.toLowerCase()) } }).formData();
};
//#endregion
//#region ../../node_modules/.pnpm/hono@4.12.32/node_modules/hono/dist/utils/body.js
var isRawRequest = (request) => "headers" in request;
var parseBody = async (request, options = /* @__PURE__ */ Object.create(null)) => {
	const { all = false, dot = false } = options;
	const mediaType = (isRawRequest(request) ? request.headers : request.raw.headers).get("Content-Type")?.split(";")[0].trim().toLowerCase();
	if (mediaType === "multipart/form-data" || mediaType === "application/x-www-form-urlencoded") return parseFormData(request, {
		all,
		dot
	});
	return {};
};
async function parseFormData(request, options) {
	if (!isRawRequest(request) && request.bodyCache.formData) return convertFormDataToBodyData(await request.bodyCache.formData, options);
	const headers = isRawRequest(request) ? request.headers : request.raw.headers;
	const formDataPromise = bufferToFormData(await request.arrayBuffer(), headers.get("Content-Type") || "");
	if (!isRawRequest(request)) request.bodyCache.formData = formDataPromise;
	const formData = await formDataPromise;
	if (formData) return convertFormDataToBodyData(formData, options);
	return {};
}
function convertFormDataToBodyData(formData, options) {
	const form = /* @__PURE__ */ Object.create(null);
	formData.forEach((value, key) => {
		if (!(options.all || key.endsWith("[]"))) form[key] = value;
		else handleParsingAllValues(form, key, value);
	});
	if (options.dot) Object.entries(form).forEach(([key, value]) => {
		if (key.includes(".")) {
			handleParsingNestedValues(form, key, value);
			delete form[key];
		}
	});
	return form;
}
var handleParsingAllValues = (form, key, value) => {
	if (form[key] !== void 0) if (Array.isArray(form[key])) form[key].push(value);
	else form[key] = [form[key], value];
	else if (!key.endsWith("[]")) form[key] = value;
	else form[key] = [value];
};
var handleParsingNestedValues = (form, key, value) => {
	if (/(?:^|\.)__proto__\./.test(key)) return;
	let nestedForm = form;
	const keys = key.split(".");
	keys.forEach((key2, index) => {
		if (index === keys.length - 1) nestedForm[key2] = value;
		else {
			if (!nestedForm[key2] || typeof nestedForm[key2] !== "object" || Array.isArray(nestedForm[key2]) || nestedForm[key2] instanceof File) nestedForm[key2] = /* @__PURE__ */ Object.create(null);
			nestedForm = nestedForm[key2];
		}
	});
};
//#endregion
//#region ../../node_modules/.pnpm/hono@4.12.32/node_modules/hono/dist/utils/url.js
var splitPath = (path) => {
	const paths = path.split("/");
	if (paths[0] === "") paths.shift();
	return paths;
};
var splitRoutingPath = (routePath) => {
	const { groups, path } = extractGroupsFromPath(routePath);
	return replaceGroupMarks(splitPath(path), groups);
};
var extractGroupsFromPath = (path) => {
	const groups = [];
	path = path.replace(/\{[^}]+\}/g, (match, index) => {
		const mark = `@${index}`;
		groups.push([mark, match]);
		return mark;
	});
	return {
		groups,
		path
	};
};
var replaceGroupMarks = (paths, groups) => {
	for (let i = groups.length - 1; i >= 0; i--) {
		const [mark] = groups[i];
		for (let j = paths.length - 1; j >= 0; j--) if (paths[j].includes(mark)) {
			paths[j] = paths[j].replace(mark, groups[i][1]);
			break;
		}
	}
	return paths;
};
var patternCache = {};
var getPattern = (label, next) => {
	if (label === "*") return "*";
	const match = label.match(/^\:([^\{\}]+)(?:\{(.+)\})?$/);
	if (match) {
		const cacheKey = `${label}#${next}`;
		if (!patternCache[cacheKey]) if (match[2]) patternCache[cacheKey] = next && next[0] !== ":" && next[0] !== "*" ? [
			cacheKey,
			match[1],
			new RegExp(`^${match[2]}(?=/${next})`)
		] : [
			label,
			match[1],
			new RegExp(`^${match[2]}$`)
		];
		else patternCache[cacheKey] = [
			label,
			match[1],
			true
		];
		return patternCache[cacheKey];
	}
	return null;
};
var tryDecode = (str, decoder) => {
	try {
		return decoder(str);
	} catch {
		return str.replace(/(?:%[0-9A-Fa-f]{2})+/g, (match) => {
			try {
				return decoder(match);
			} catch {
				return match;
			}
		});
	}
};
var tryDecodeURI = (str) => tryDecode(str, decodeURI);
var getPath = (request) => {
	const url = request.url;
	const start = url.indexOf("/", url.indexOf(":") + 4);
	let i = start;
	for (; i < url.length; i++) {
		const charCode = url.charCodeAt(i);
		if (charCode === 37) {
			const queryIndex = url.indexOf("?", i);
			const hashIndex = url.indexOf("#", i);
			const end = queryIndex === -1 ? hashIndex === -1 ? void 0 : hashIndex : hashIndex === -1 ? queryIndex : Math.min(queryIndex, hashIndex);
			const path = url.slice(start, end);
			return tryDecodeURI(path.includes("%25") ? path.replace(/%25/g, "%2525") : path);
		} else if (charCode === 63 || charCode === 35) break;
	}
	return url.slice(start, i);
};
var getPathNoStrict = (request) => {
	const result = getPath(request);
	return result.length > 1 && result.at(-1) === "/" ? result.slice(0, -1) : result;
};
var mergePath = (base, sub, ...rest) => {
	if (rest.length) sub = mergePath(sub, ...rest);
	return `${base?.[0] === "/" ? "" : "/"}${base}${sub === "/" ? "" : `${base?.at(-1) === "/" ? "" : "/"}${sub?.[0] === "/" ? sub.slice(1) : sub}`}`;
};
var checkOptionalParameter = (path) => {
	if (path.charCodeAt(path.length - 1) !== 63 || !path.includes(":")) return null;
	const segments = path.split("/");
	const results = [];
	let basePath = "";
	segments.forEach((segment) => {
		if (segment !== "" && !/\:/.test(segment)) basePath += "/" + segment;
		else if (/\:/.test(segment)) if (/\?/.test(segment)) {
			if (results.length === 0 && basePath === "") results.push("/");
			else results.push(basePath);
			const optionalSegment = segment.replace("?", "");
			basePath += "/" + optionalSegment;
			results.push(basePath);
		} else basePath += "/" + segment;
	});
	return results.filter((v, i, a) => a.indexOf(v) === i);
};
var _decodeURI = (value) => {
	if (!/[%+]/.test(value)) return value;
	if (value.indexOf("+") !== -1) value = value.replace(/\+/g, " ");
	return value.indexOf("%") !== -1 ? tryDecode(value, decodeURIComponent_) : value;
};
var _getQueryParam = (url, key, multiple) => {
	let encoded;
	if (!multiple && key && !/[%+]/.test(key)) {
		let keyIndex2 = url.indexOf("?", 8);
		if (keyIndex2 === -1) return;
		if (!url.startsWith(key, keyIndex2 + 1)) keyIndex2 = url.indexOf(`&${key}`, keyIndex2 + 1);
		while (keyIndex2 !== -1) {
			const trailingKeyCode = url.charCodeAt(keyIndex2 + key.length + 1);
			if (trailingKeyCode === 61) {
				const valueIndex = keyIndex2 + key.length + 2;
				const endIndex = url.indexOf("&", valueIndex);
				return _decodeURI(url.slice(valueIndex, endIndex === -1 ? void 0 : endIndex));
			} else if (trailingKeyCode == 38 || isNaN(trailingKeyCode)) return "";
			keyIndex2 = url.indexOf(`&${key}`, keyIndex2 + 1);
		}
		encoded = /[%+]/.test(url);
		if (!encoded) return;
	}
	const results = /* @__PURE__ */ Object.create(null);
	encoded ??= /[%+]/.test(url);
	let keyIndex = url.indexOf("?", 8);
	while (keyIndex !== -1) {
		const nextKeyIndex = url.indexOf("&", keyIndex + 1);
		let valueIndex = url.indexOf("=", keyIndex);
		if (valueIndex > nextKeyIndex && nextKeyIndex !== -1) valueIndex = -1;
		let name = url.slice(keyIndex + 1, valueIndex === -1 ? nextKeyIndex === -1 ? void 0 : nextKeyIndex : valueIndex);
		if (encoded) name = _decodeURI(name);
		keyIndex = nextKeyIndex;
		if (name === "") continue;
		let value;
		if (valueIndex === -1) value = "";
		else {
			value = url.slice(valueIndex + 1, nextKeyIndex === -1 ? void 0 : nextKeyIndex);
			if (encoded) value = _decodeURI(value);
		}
		if (multiple) {
			if (!(results[name] && Array.isArray(results[name]))) results[name] = [];
			results[name].push(value);
		} else results[name] ??= value;
	}
	return key ? results[key] : results;
};
var getQueryParam = _getQueryParam;
var getQueryParams = (url, key) => {
	return _getQueryParam(url, key, true);
};
var decodeURIComponent_ = decodeURIComponent;
//#endregion
//#region ../../node_modules/.pnpm/hono@4.12.32/node_modules/hono/dist/request.js
var tryDecodeURIComponent = (str) => tryDecode(str, decodeURIComponent_);
var HonoRequest = class {
	/**
	* `.raw` can get the raw Request object.
	*
	* @see {@link https://hono.dev/docs/api/request#raw}
	*
	* @example
	* ```ts
	* // For Cloudflare Workers
	* app.post('/', async (c) => {
	*   const metadata = c.req.raw.cf?.hostMetadata?
	*   ...
	* })
	* ```
	*/
	raw;
	#validatedData;
	#matchResult;
	routeIndex = 0;
	/**
	* `.path` can get the pathname of the request.
	*
	* @see {@link https://hono.dev/docs/api/request#path}
	*
	* @example
	* ```ts
	* app.get('/about/me', (c) => {
	*   const pathname = c.req.path // `/about/me`
	* })
	* ```
	*/
	path;
	bodyCache = {};
	constructor(request, path = "/", matchResult = [[]]) {
		this.raw = request;
		this.path = path;
		this.#matchResult = matchResult;
		this.#validatedData = {};
	}
	param(key) {
		return key ? this.#getDecodedParam(key) : this.#getAllDecodedParams();
	}
	#getDecodedParam(key) {
		const paramKey = this.#matchResult[0][this.routeIndex][1][key];
		const param = this.#getParamValue(paramKey);
		return param && /\%/.test(param) ? tryDecodeURIComponent(param) : param;
	}
	#getAllDecodedParams() {
		const decoded = {};
		const keys = Object.keys(this.#matchResult[0][this.routeIndex][1]);
		for (const key of keys) {
			const value = this.#getParamValue(this.#matchResult[0][this.routeIndex][1][key]);
			if (value !== void 0) decoded[key] = /\%/.test(value) ? tryDecodeURIComponent(value) : value;
		}
		return decoded;
	}
	#getParamValue(paramKey) {
		return this.#matchResult[1] ? this.#matchResult[1][paramKey] : paramKey;
	}
	query(key) {
		return getQueryParam(this.url, key);
	}
	queries(key) {
		return getQueryParams(this.url, key);
	}
	header(name) {
		if (name) return this.raw.headers.get(name) ?? void 0;
		const headerData = /* @__PURE__ */ Object.create(null);
		this.raw.headers.forEach((value, key) => {
			headerData[key] = value;
		});
		return headerData;
	}
	async parseBody(options) {
		return parseBody(this, options);
	}
	#cachedBody = (key) => {
		const { bodyCache, raw } = this;
		const cachedBody = bodyCache[key];
		if (cachedBody) return cachedBody;
		const anyCachedKey = Object.keys(bodyCache)[0];
		if (anyCachedKey) return bodyCache[anyCachedKey].then((body) => {
			if (anyCachedKey === "json") body = JSON.stringify(body);
			return new Response(body)[key]();
		});
		return bodyCache[key] = raw[key]();
	};
	/**
	* `.json()` can parse Request body of type `application/json`
	*
	* @see {@link https://hono.dev/docs/api/request#json}
	*
	* @example
	* ```ts
	* app.post('/entry', async (c) => {
	*   const body = await c.req.json()
	* })
	* ```
	*/
	json() {
		return this.#cachedBody("text").then((text) => JSON.parse(text));
	}
	/**
	* `.text()` can parse Request body of type `text/plain`
	*
	* @see {@link https://hono.dev/docs/api/request#text}
	*
	* @example
	* ```ts
	* app.post('/entry', async (c) => {
	*   const body = await c.req.text()
	* })
	* ```
	*/
	text() {
		return this.#cachedBody("text");
	}
	/**
	* `.arrayBuffer()` parse Request body as an `ArrayBuffer`
	*
	* @see {@link https://hono.dev/docs/api/request#arraybuffer}
	*
	* @example
	* ```ts
	* app.post('/entry', async (c) => {
	*   const body = await c.req.arrayBuffer()
	* })
	* ```
	*/
	arrayBuffer() {
		return this.#cachedBody("arrayBuffer");
	}
	/**
	* `.bytes()` parses the request body as a `Uint8Array`.
	*
	* @see {@link https://hono.dev/docs/api/request#bytes}
	*
	* @example
	* ```ts
	* app.post('/entry', async (c) => {
	*   const body = await c.req.bytes()
	* })
	* ```
	*/
	bytes() {
		return this.#cachedBody("arrayBuffer").then((buffer) => new Uint8Array(buffer));
	}
	/**
	* Parses the request body as a `Blob`.
	* @example
	* ```ts
	* app.post('/entry', async (c) => {
	*   const body = await c.req.blob();
	* });
	* ```
	* @see https://hono.dev/docs/api/request#blob
	*/
	blob() {
		return this.#cachedBody("blob");
	}
	/**
	* Parses the request body as `FormData`.
	* @example
	* ```ts
	* app.post('/entry', async (c) => {
	*   const body = await c.req.formData();
	* });
	* ```
	* @see https://hono.dev/docs/api/request#formdata
	*/
	formData() {
		return this.#cachedBody("formData");
	}
	/**
	* Adds validated data to the request.
	*
	* @param target - The target of the validation.
	* @param data - The validated data to add.
	*/
	addValidatedData(target, data) {
		this.#validatedData[target] = data;
	}
	valid(target) {
		return this.#validatedData[target];
	}
	/**
	* `.url()` can get the request url strings.
	*
	* @see {@link https://hono.dev/docs/api/request#url}
	*
	* @example
	* ```ts
	* app.get('/about/me', (c) => {
	*   const url = c.req.url // `http://localhost:8787/about/me`
	*   ...
	* })
	* ```
	*/
	get url() {
		return this.raw.url;
	}
	/**
	* `.method()` can get the method name of the request.
	*
	* @see {@link https://hono.dev/docs/api/request#method}
	*
	* @example
	* ```ts
	* app.get('/about/me', (c) => {
	*   const method = c.req.method // `GET`
	* })
	* ```
	*/
	get method() {
		return this.raw.method;
	}
	get [GET_MATCH_RESULT]() {
		return this.#matchResult;
	}
	/**
	* `.matchedRoutes()` can return a matched route in the handler
	*
	* @deprecated
	*
	* Use matchedRoutes helper defined in "hono/route" instead.
	*
	* @see {@link https://hono.dev/docs/api/request#matchedroutes}
	*
	* @example
	* ```ts
	* app.use('*', async function logger(c, next) {
	*   await next()
	*   c.req.matchedRoutes.forEach(({ handler, method, path }, i) => {
	*     const name = handler.name || (handler.length < 2 ? '[handler]' : '[middleware]')
	*     console.log(
	*       method,
	*       ' ',
	*       path,
	*       ' '.repeat(Math.max(10 - path.length, 0)),
	*       name,
	*       i === c.req.routeIndex ? '<- respond from here' : ''
	*     )
	*   })
	* })
	* ```
	*/
	get matchedRoutes() {
		return this.#matchResult[0].map(([[, route]]) => route);
	}
	/**
	* `routePath()` can retrieve the path registered within the handler
	*
	* @deprecated
	*
	* Use routePath helper defined in "hono/route" instead.
	*
	* @see {@link https://hono.dev/docs/api/request#routepath}
	*
	* @example
	* ```ts
	* app.get('/posts/:id', (c) => {
	*   return c.json({ path: c.req.routePath })
	* })
	* ```
	*/
	get routePath() {
		return this.#matchResult[0].map(([[, route]]) => route)[this.routeIndex].path;
	}
};
//#endregion
//#region ../../node_modules/.pnpm/hono@4.12.32/node_modules/hono/dist/utils/html.js
var HtmlEscapedCallbackPhase = {
	Stringify: 1,
	BeforeStream: 2,
	Stream: 3
};
var raw = (value, callbacks) => {
	const escapedString = new String(value);
	escapedString.isEscaped = true;
	escapedString.callbacks = callbacks;
	return escapedString;
};
var resolveCallback = async (str, phase, preserveCallbacks, context, buffer) => {
	if (typeof str === "object" && !(str instanceof String)) {
		if (!(str instanceof Promise)) str = str.toString();
		if (str instanceof Promise) str = await str;
	}
	const callbacks = str.callbacks;
	if (!callbacks?.length) return Promise.resolve(str);
	if (buffer) buffer[0] += str;
	else buffer = [str];
	const resStr = Promise.all(callbacks.map((c) => c({
		phase,
		buffer,
		context
	}))).then((res) => Promise.all(res.filter(Boolean).map((str2) => resolveCallback(str2, phase, false, context, buffer))).then(() => buffer[0]));
	if (preserveCallbacks) return raw(await resStr, callbacks);
	else return resStr;
};
//#endregion
//#region ../../node_modules/.pnpm/hono@4.12.32/node_modules/hono/dist/context.js
var TEXT_PLAIN = "text/plain; charset=UTF-8";
var setDefaultContentType = (contentType, headers) => {
	return {
		"Content-Type": contentType,
		...headers
	};
};
var createResponseInstance = (body, init) => new Response(body, init);
var Context = class {
	#rawRequest;
	#req;
	/**
	* `.env` can get bindings (environment variables, secrets, KV namespaces, D1 database, R2 bucket etc.) in Cloudflare Workers.
	*
	* @see {@link https://hono.dev/docs/api/context#env}
	*
	* @example
	* ```ts
	* // Environment object for Cloudflare Workers
	* app.get('*', async c => {
	*   const counter = c.env.COUNTER
	* })
	* ```
	*/
	env = {};
	#var;
	finalized = false;
	/**
	* `.error` can get the error object from the middleware if the Handler throws an error.
	*
	* @see {@link https://hono.dev/docs/api/context#error}
	*
	* @example
	* ```ts
	* app.use('*', async (c, next) => {
	*   await next()
	*   if (c.error) {
	*     // do something...
	*   }
	* })
	* ```
	*/
	error;
	#status;
	#executionCtx;
	#res;
	#layout;
	#renderer;
	#notFoundHandler;
	#preparedHeaders;
	#matchResult;
	#path;
	/**
	* Creates an instance of the Context class.
	*
	* @param req - The Request object.
	* @param options - Optional configuration options for the context.
	*/
	constructor(req, options) {
		this.#rawRequest = req;
		if (options) {
			this.#executionCtx = options.executionCtx;
			this.env = options.env;
			this.#notFoundHandler = options.notFoundHandler;
			this.#path = options.path;
			this.#matchResult = options.matchResult;
		}
	}
	/**
	* `.req` is the instance of {@link HonoRequest}.
	*/
	get req() {
		this.#req ??= new HonoRequest(this.#rawRequest, this.#path, this.#matchResult);
		return this.#req;
	}
	/**
	* @see {@link https://hono.dev/docs/api/context#event}
	* The FetchEvent associated with the current request.
	*
	* @throws Will throw an error if the context does not have a FetchEvent.
	*/
	get event() {
		if (this.#executionCtx && "respondWith" in this.#executionCtx) return this.#executionCtx;
		else throw Error("This context has no FetchEvent");
	}
	/**
	* @see {@link https://hono.dev/docs/api/context#executionctx}
	* The ExecutionContext associated with the current request.
	*
	* @throws Will throw an error if the context does not have an ExecutionContext.
	*/
	get executionCtx() {
		if (this.#executionCtx) return this.#executionCtx;
		else throw Error("This context has no ExecutionContext");
	}
	/**
	* @see {@link https://hono.dev/docs/api/context#res}
	* The Response object for the current request.
	*/
	get res() {
		return this.#res ||= createResponseInstance(null, { headers: this.#preparedHeaders ??= new Headers() });
	}
	/**
	* Sets the Response object for the current request.
	*
	* @param _res - The Response object to set.
	*/
	set res(_res) {
		if (this.#res && _res) {
			_res = createResponseInstance(_res.body, _res);
			for (const [k, v] of this.#res.headers.entries()) {
				if (k === "content-type") continue;
				if (k === "set-cookie") {
					const cookies = this.#res.headers.getSetCookie();
					_res.headers.delete("set-cookie");
					for (const cookie of cookies) _res.headers.append("set-cookie", cookie);
				} else _res.headers.set(k, v);
			}
		}
		this.#res = _res;
		this.finalized = true;
	}
	/**
	* `.render()` can create a response within a layout.
	*
	* @see {@link https://hono.dev/docs/api/context#render-setrenderer}
	*
	* @example
	* ```ts
	* app.get('/', (c) => {
	*   return c.render('Hello!')
	* })
	* ```
	*/
	render = (...args) => {
		this.#renderer ??= (content) => this.html(content);
		return this.#renderer(...args);
	};
	/**
	* Sets the layout for the response.
	*
	* @param layout - The layout to set.
	* @returns The layout function.
	*/
	setLayout = (layout) => this.#layout = layout;
	/**
	* Gets the current layout for the response.
	*
	* @returns The current layout function.
	*/
	getLayout = () => this.#layout;
	/**
	* `.setRenderer()` can set the layout in the custom middleware.
	*
	* @see {@link https://hono.dev/docs/api/context#render-setrenderer}
	*
	* @example
	* ```tsx
	* app.use('*', async (c, next) => {
	*   c.setRenderer((content) => {
	*     return c.html(
	*       <html>
	*         <body>
	*           <p>{content}</p>
	*         </body>
	*       </html>
	*     )
	*   })
	*   await next()
	* })
	* ```
	*/
	setRenderer = (renderer) => {
		this.#renderer = renderer;
	};
	/**
	* `.header()` can set headers.
	*
	* @see {@link https://hono.dev/docs/api/context#header}
	*
	* @example
	* ```ts
	* app.get('/welcome', (c) => {
	*   // Set headers
	*   c.header('X-Message', 'Hello!')
	*   c.header('Content-Type', 'text/plain')
	*
	*   return c.body('Thank you for coming')
	* })
	* ```
	*/
	header = (name, value, options) => {
		if (this.finalized) this.#res = createResponseInstance(this.#res.body, this.#res);
		const headers = this.#res ? this.#res.headers : this.#preparedHeaders ??= new Headers();
		if (value === void 0) headers.delete(name);
		else if (options?.append) headers.append(name, value);
		else headers.set(name, value);
	};
	status = (status) => {
		this.#status = status;
	};
	/**
	* `.set()` can set the value specified by the key.
	*
	* @see {@link https://hono.dev/docs/api/context#set-get}
	*
	* @example
	* ```ts
	* app.use('*', async (c, next) => {
	*   c.set('message', 'Hono is hot!!')
	*   await next()
	* })
	* ```
	*/
	set = (key, value) => {
		this.#var ??= /* @__PURE__ */ new Map();
		this.#var.set(key, value);
	};
	/**
	* `.get()` can use the value specified by the key.
	*
	* @see {@link https://hono.dev/docs/api/context#set-get}
	*
	* @example
	* ```ts
	* app.get('/', (c) => {
	*   const message = c.get('message')
	*   return c.text(`The message is "${message}"`)
	* })
	* ```
	*/
	get = (key) => {
		return this.#var ? this.#var.get(key) : void 0;
	};
	/**
	* `.var` can access the value of a variable.
	*
	* @see {@link https://hono.dev/docs/api/context#var}
	*
	* @example
	* ```ts
	* const result = c.var.client.oneMethod()
	* ```
	*/
	get var() {
		if (!this.#var) return {};
		return Object.fromEntries(this.#var);
	}
	#newResponse(data, arg, headers) {
		const responseHeaders = this.#res ? new Headers(this.#res.headers) : this.#preparedHeaders ?? new Headers();
		if (typeof arg === "object" && "headers" in arg) {
			const argHeaders = arg.headers instanceof Headers ? arg.headers : new Headers(arg.headers);
			for (const [key, value] of argHeaders) if (key.toLowerCase() === "set-cookie") responseHeaders.append(key, value);
			else responseHeaders.set(key, value);
		}
		if (headers) for (const [k, v] of Object.entries(headers)) if (typeof v === "string") responseHeaders.set(k, v);
		else {
			responseHeaders.delete(k);
			for (const v2 of v) responseHeaders.append(k, v2);
		}
		return createResponseInstance(data, {
			status: typeof arg === "number" ? arg : arg?.status ?? this.#status,
			headers: responseHeaders
		});
	}
	newResponse = (...args) => this.#newResponse(...args);
	/**
	* `.body()` can return the HTTP response.
	* You can set headers with `.header()` and set HTTP status code with `.status`.
	* This can also be set in `.text()`, `.json()` and so on.
	*
	* @see {@link https://hono.dev/docs/api/context#body}
	*
	* @example
	* ```ts
	* app.get('/welcome', (c) => {
	*   // Set headers
	*   c.header('X-Message', 'Hello!')
	*   c.header('Content-Type', 'text/plain')
	*   // Set HTTP status code
	*   c.status(201)
	*
	*   // Return the response body
	*   return c.body('Thank you for coming')
	* })
	* ```
	*/
	body = (data, arg, headers) => this.#newResponse(data, arg, headers);
	/**
	* `.text()` can render text as `Content-Type:text/plain`.
	*
	* @see {@link https://hono.dev/docs/api/context#text}
	*
	* @example
	* ```ts
	* app.get('/say', (c) => {
	*   return c.text('Hello!')
	* })
	* ```
	*/
	text = (text, arg, headers) => {
		return !this.#preparedHeaders && !this.#status && !arg && !headers && !this.finalized ? new Response(text) : this.#newResponse(text, arg, setDefaultContentType(TEXT_PLAIN, headers));
	};
	/**
	* `.json()` can render JSON as `Content-Type:application/json`.
	*
	* @see {@link https://hono.dev/docs/api/context#json}
	*
	* @example
	* ```ts
	* app.get('/api', (c) => {
	*   return c.json({ message: 'Hello!' })
	* })
	* ```
	*/
	json = (object, arg, headers) => {
		return this.#newResponse(JSON.stringify(object), arg, setDefaultContentType("application/json", headers));
	};
	html = (html, arg, headers) => {
		const res = (html2) => this.#newResponse(html2, arg, setDefaultContentType("text/html; charset=UTF-8", headers));
		return typeof html === "object" ? resolveCallback(html, HtmlEscapedCallbackPhase.Stringify, false, {}).then(res) : res(html);
	};
	/**
	* `.redirect()` can Redirect, default status code is 302.
	*
	* @see {@link https://hono.dev/docs/api/context#redirect}
	*
	* @example
	* ```ts
	* app.get('/redirect', (c) => {
	*   return c.redirect('/')
	* })
	* app.get('/redirect-permanently', (c) => {
	*   return c.redirect('/', 301)
	* })
	* ```
	*/
	redirect = (location, status) => {
		const locationString = String(location);
		this.header("Location", !/[^\x00-\xFF]/.test(locationString) ? locationString : encodeURI(locationString));
		return this.newResponse(null, status ?? 302);
	};
	/**
	* `.notFound()` can return the Not Found Response.
	*
	* @see {@link https://hono.dev/docs/api/context#notfound}
	*
	* @example
	* ```ts
	* app.get('/notfound', (c) => {
	*   return c.notFound()
	* })
	* ```
	*/
	notFound = () => {
		this.#notFoundHandler ??= () => createResponseInstance();
		return this.#notFoundHandler(this);
	};
};
//#endregion
//#region ../../node_modules/.pnpm/hono@4.12.32/node_modules/hono/dist/router.js
var METHODS = [
	"get",
	"post",
	"put",
	"delete",
	"options",
	"patch"
];
var MESSAGE_MATCHER_IS_ALREADY_BUILT = "Can not add a route since the matcher is already built.";
var UnsupportedPathError = class extends Error {};
//#endregion
//#region ../../node_modules/.pnpm/hono@4.12.32/node_modules/hono/dist/utils/constants.js
var COMPOSED_HANDLER = "__COMPOSED_HANDLER";
//#endregion
//#region ../../node_modules/.pnpm/hono@4.12.32/node_modules/hono/dist/hono-base.js
var notFoundHandler = (c) => {
	return c.text("404 Not Found", 404);
};
var errorHandler = (err, c) => {
	if ("getResponse" in err) {
		const res = err.getResponse();
		return c.newResponse(res.body, res);
	}
	console.error(err);
	return c.text("Internal Server Error", 500);
};
var Hono$1 = class _Hono {
	get;
	post;
	put;
	delete;
	options;
	patch;
	all;
	on;
	use;
	router;
	getPath;
	_basePath = "/";
	#path = "/";
	routes = [];
	constructor(options = {}) {
		[...METHODS, "all"].forEach((method) => {
			this[method] = (args1, ...args) => {
				if (typeof args1 === "string") this.#path = args1;
				else this.#addRoute(method, this.#path, args1);
				args.forEach((handler) => {
					this.#addRoute(method, this.#path, handler);
				});
				return this;
			};
		});
		this.on = (method, path, ...handlers) => {
			for (const p of [path].flat()) {
				this.#path = p;
				for (const m of [method].flat()) handlers.map((handler) => {
					this.#addRoute(m.toUpperCase(), this.#path, handler);
				});
			}
			return this;
		};
		this.use = (arg1, ...handlers) => {
			if (typeof arg1 === "string") this.#path = arg1;
			else {
				this.#path = "*";
				handlers.unshift(arg1);
			}
			handlers.forEach((handler) => {
				this.#addRoute("ALL", this.#path, handler);
			});
			return this;
		};
		const { strict, ...optionsWithoutStrict } = options;
		Object.assign(this, optionsWithoutStrict);
		this.getPath = strict ?? true ? options.getPath ?? getPath : getPathNoStrict;
	}
	#clone() {
		const clone = new _Hono({
			router: this.router,
			getPath: this.getPath
		});
		clone.errorHandler = this.errorHandler;
		clone.#notFoundHandler = this.#notFoundHandler;
		clone.routes = this.routes;
		return clone;
	}
	#notFoundHandler = notFoundHandler;
	errorHandler = errorHandler;
	/**
	* `.route()` allows grouping other Hono instance in routes.
	*
	* @see {@link https://hono.dev/docs/api/routing#grouping}
	*
	* @param {string} path - base Path
	* @param {Hono} app - other Hono instance
	* @returns {Hono} routed Hono instance
	*
	* @example
	* ```ts
	* const app = new Hono()
	* const app2 = new Hono()
	*
	* app2.get("/user", (c) => c.text("user"))
	* app.route("/api", app2) // GET /api/user
	* ```
	*/
	route(path, app) {
		const subApp = this.basePath(path);
		app.routes.map((r) => {
			let handler;
			if (app.errorHandler === errorHandler) handler = r.handler;
			else {
				handler = async (c, next) => (await compose([], app.errorHandler)(c, () => r.handler(c, next))).res;
				handler[COMPOSED_HANDLER] = r.handler;
			}
			subApp.#addRoute(r.method, r.path, handler, r.basePath);
		});
		return this;
	}
	/**
	* `.basePath()` allows base paths to be specified.
	*
	* @see {@link https://hono.dev/docs/api/routing#base-path}
	*
	* @param {string} path - base Path
	* @returns {Hono} changed Hono instance
	*
	* @example
	* ```ts
	* const api = new Hono().basePath('/api')
	* ```
	*/
	basePath(path) {
		const subApp = this.#clone();
		subApp._basePath = mergePath(this._basePath, path);
		return subApp;
	}
	/**
	* `.onError()` handles an error and returns a customized Response.
	*
	* @see {@link https://hono.dev/docs/api/hono#error-handling}
	*
	* @param {ErrorHandler} handler - request Handler for error
	* @returns {Hono} changed Hono instance
	*
	* @example
	* ```ts
	* app.onError((err, c) => {
	*   console.error(`${err}`)
	*   return c.text('Custom Error Message', 500)
	* })
	* ```
	*/
	onError = (handler) => {
		this.errorHandler = handler;
		return this;
	};
	/**
	* `.notFound()` allows you to customize a Not Found Response.
	*
	* @see {@link https://hono.dev/docs/api/hono#not-found}
	*
	* @param {NotFoundHandler} handler - request handler for not-found
	* @returns {Hono} changed Hono instance
	*
	* @example
	* ```ts
	* app.notFound((c) => {
	*   return c.text('Custom 404 Message', 404)
	* })
	* ```
	*/
	notFound = (handler) => {
		this.#notFoundHandler = handler;
		return this;
	};
	/**
	* `.mount()` allows you to mount applications built with other frameworks into your Hono application.
	*
	* @see {@link https://hono.dev/docs/api/hono#mount}
	*
	* @param {string} path - base Path
	* @param {Function} applicationHandler - other Request Handler
	* @param {MountOptions} [options] - options of `.mount()`
	* @returns {Hono} mounted Hono instance
	*
	* @example
	* ```ts
	* import { Router as IttyRouter } from 'itty-router'
	* import { Hono } from 'hono'
	* // Create itty-router application
	* const ittyRouter = IttyRouter()
	* // GET /itty-router/hello
	* ittyRouter.get('/hello', () => new Response('Hello from itty-router'))
	*
	* const app = new Hono()
	* app.mount('/itty-router', ittyRouter.handle)
	* ```
	*
	* @example
	* ```ts
	* const app = new Hono()
	* // Send the request to another application without modification.
	* app.mount('/app', anotherApp, {
	*   replaceRequest: (req) => req,
	* })
	* ```
	*/
	mount(path, applicationHandler, options) {
		let replaceRequest;
		let optionHandler;
		if (options) if (typeof options === "function") optionHandler = options;
		else {
			optionHandler = options.optionHandler;
			if (options.replaceRequest === false) replaceRequest = (request) => request;
			else replaceRequest = options.replaceRequest;
		}
		const getOptions = optionHandler ? (c) => {
			const options2 = optionHandler(c);
			return Array.isArray(options2) ? options2 : [options2];
		} : (c) => {
			let executionContext = void 0;
			try {
				executionContext = c.executionCtx;
			} catch {}
			return [c.env, executionContext];
		};
		replaceRequest ||= (() => {
			const mergedPath = mergePath(this._basePath, path);
			const pathPrefixLength = mergedPath === "/" ? 0 : mergedPath.length;
			return (request) => {
				const url = new URL(request.url);
				url.pathname = this.getPath(request).slice(pathPrefixLength) || "/";
				return new Request(url, request);
			};
		})();
		const handler = async (c, next) => {
			const res = await applicationHandler(replaceRequest(c.req.raw), ...getOptions(c));
			if (res) return res;
			await next();
		};
		this.#addRoute("ALL", mergePath(path, "*"), handler);
		return this;
	}
	#addRoute(method, path, handler, baseRoutePath) {
		method = method.toUpperCase();
		path = mergePath(this._basePath, path);
		const r = {
			basePath: baseRoutePath !== void 0 ? mergePath(this._basePath, baseRoutePath) : this._basePath,
			path,
			method,
			handler
		};
		this.router.add(method, path, [handler, r]);
		this.routes.push(r);
	}
	#handleError(err, c) {
		if (err instanceof Error) return this.errorHandler(err, c);
		throw err;
	}
	#dispatch(request, executionCtx, env, method) {
		if (method === "HEAD") return (async () => new Response(null, await this.#dispatch(request, executionCtx, env, "GET")))();
		const path = this.getPath(request, { env });
		const matchResult = this.router.match(method, path);
		const c = new Context(request, {
			path,
			matchResult,
			env,
			executionCtx,
			notFoundHandler: this.#notFoundHandler
		});
		if (matchResult[0].length === 1) {
			let res;
			try {
				res = matchResult[0][0][0][0](c, async () => {
					c.res = await this.#notFoundHandler(c);
				});
			} catch (err) {
				return this.#handleError(err, c);
			}
			return res instanceof Promise ? res.then((resolved) => resolved || (c.finalized ? c.res : this.#notFoundHandler(c))).catch((err) => this.#handleError(err, c)) : res ?? this.#notFoundHandler(c);
		}
		const composed = compose(matchResult[0], this.errorHandler, this.#notFoundHandler);
		return (async () => {
			try {
				const context = await composed(c);
				if (!context.finalized) throw new Error("Context is not finalized. Did you forget to return a Response object or `await next()`?");
				return context.res;
			} catch (err) {
				return this.#handleError(err, c);
			}
		})();
	}
	/**
	* `.fetch()` will be entry point of your app.
	*
	* @see {@link https://hono.dev/docs/api/hono#fetch}
	*
	* @param {Request} request - request Object of request
	* @param {Env} Env - env Object
	* @param {ExecutionContext} - context of execution
	* @returns {Response | Promise<Response>} response of request
	*
	*/
	fetch = (request, ...rest) => {
		return this.#dispatch(request, rest[1], rest[0], request.method);
	};
	/**
	* `.request()` is a useful method for testing.
	* You can pass a URL or pathname to send a GET request.
	* app will return a Response object.
	* ```ts
	* test('GET /hello is ok', async () => {
	*   const res = await app.request('/hello')
	*   expect(res.status).toBe(200)
	* })
	* ```
	* @see https://hono.dev/docs/api/hono#request
	*/
	request = (input, requestInit, Env, executionCtx) => {
		if (input instanceof Request) return this.fetch(requestInit ? new Request(input, requestInit) : input, Env, executionCtx);
		input = input.toString();
		return this.fetch(new Request(/^https?:\/\//.test(input) ? input : `http://localhost${mergePath("/", input)}`, requestInit), Env, executionCtx);
	};
	/**
	* `.fire()` automatically adds a global fetch event listener.
	* This can be useful for environments that adhere to the Service Worker API, such as non-ES module Cloudflare Workers.
	* @deprecated
	* Use `fire` from `hono/service-worker` instead.
	* ```ts
	* import { Hono } from 'hono'
	* import { fire } from 'hono/service-worker'
	*
	* const app = new Hono()
	* // ...
	* fire(app)
	* ```
	* @see https://hono.dev/docs/api/hono#fire
	* @see https://developer.mozilla.org/en-US/docs/Web/API/Service_Worker_API
	* @see https://developers.cloudflare.com/workers/reference/migrate-to-module-workers/
	*/
	fire = () => {
		addEventListener("fetch", (event) => {
			event.respondWith(this.#dispatch(event.request, event, void 0, event.request.method));
		});
	};
};
//#endregion
//#region ../../node_modules/.pnpm/hono@4.12.32/node_modules/hono/dist/router/reg-exp-router/matcher.js
var emptyParam = [];
function match(method, path) {
	const matchers = this.buildAllMatchers();
	const match2 = ((method2, path2) => {
		const matcher = matchers[method2] || matchers["ALL"];
		const staticMatch = matcher[2][path2];
		if (staticMatch) return staticMatch;
		const match3 = path2.match(matcher[0]);
		if (!match3) return [[], emptyParam];
		const index = match3.indexOf("", 1);
		return [matcher[1][index], match3];
	});
	this.match = match2;
	return match2(method, path);
}
//#endregion
//#region ../../node_modules/.pnpm/hono@4.12.32/node_modules/hono/dist/router/reg-exp-router/node.js
var LABEL_REG_EXP_STR = "[^/]+";
var ONLY_WILDCARD_REG_EXP_STR = ".*";
var TAIL_WILDCARD_REG_EXP_STR = "(?:|/.*)";
var PATH_ERROR = /* @__PURE__ */ Symbol();
var regExpMetaChars = /* @__PURE__ */ new Set(".\\+*[^]$()");
function compareKey(a, b) {
	if (a.length === 1) return b.length === 1 ? a < b ? -1 : 1 : -1;
	if (b.length === 1) return 1;
	if (a === ONLY_WILDCARD_REG_EXP_STR || a === TAIL_WILDCARD_REG_EXP_STR) return 1;
	else if (b === ONLY_WILDCARD_REG_EXP_STR || b === TAIL_WILDCARD_REG_EXP_STR) return -1;
	if (a === LABEL_REG_EXP_STR) return 1;
	else if (b === LABEL_REG_EXP_STR) return -1;
	return a.length === b.length ? a < b ? -1 : 1 : b.length - a.length;
}
var Node$1 = class _Node {
	#index;
	#varIndex;
	#children = /* @__PURE__ */ Object.create(null);
	insert(tokens, index, paramMap, context, pathErrorCheckOnly) {
		if (tokens.length === 0) {
			if (this.#index !== void 0) throw PATH_ERROR;
			if (pathErrorCheckOnly) return;
			this.#index = index;
			return;
		}
		const [token, ...restTokens] = tokens;
		const pattern = token === "*" ? restTokens.length === 0 ? [
			"",
			"",
			ONLY_WILDCARD_REG_EXP_STR
		] : [
			"",
			"",
			LABEL_REG_EXP_STR
		] : token === "/*" ? [
			"",
			"",
			TAIL_WILDCARD_REG_EXP_STR
		] : token.match(/^\:([^\{\}]+)(?:\{(.+)\})?$/);
		let node;
		if (pattern) {
			const name = pattern[1];
			let regexpStr = pattern[2] || LABEL_REG_EXP_STR;
			if (name && pattern[2]) {
				if (regexpStr === ".*") throw PATH_ERROR;
				regexpStr = regexpStr.replace(/^\((?!\?:)(?=[^)]+\)$)/, "(?:");
				if (/\((?!\?:)/.test(regexpStr)) throw PATH_ERROR;
			}
			node = this.#children[regexpStr];
			if (!node) {
				if (Object.keys(this.#children).some((k) => k !== ONLY_WILDCARD_REG_EXP_STR && k !== TAIL_WILDCARD_REG_EXP_STR)) throw PATH_ERROR;
				if (pathErrorCheckOnly) return;
				node = this.#children[regexpStr] = new _Node();
				if (name !== "") node.#varIndex = context.varIndex++;
			}
			if (!pathErrorCheckOnly && name !== "") paramMap.push([name, node.#varIndex]);
		} else {
			node = this.#children[token];
			if (!node) {
				if (Object.keys(this.#children).some((k) => k.length > 1 && k !== ONLY_WILDCARD_REG_EXP_STR && k !== TAIL_WILDCARD_REG_EXP_STR)) throw PATH_ERROR;
				if (pathErrorCheckOnly) return;
				node = this.#children[token] = new _Node();
			}
		}
		node.insert(restTokens, index, paramMap, context, pathErrorCheckOnly);
	}
	buildRegExpStr() {
		const strList = Object.keys(this.#children).sort(compareKey).map((k) => {
			const c = this.#children[k];
			return (typeof c.#varIndex === "number" ? `(${k})@${c.#varIndex}` : regExpMetaChars.has(k) ? `\\${k}` : k) + c.buildRegExpStr();
		});
		if (typeof this.#index === "number") strList.unshift(`#${this.#index}`);
		if (strList.length === 0) return "";
		if (strList.length === 1) return strList[0];
		return "(?:" + strList.join("|") + ")";
	}
};
//#endregion
//#region ../../node_modules/.pnpm/hono@4.12.32/node_modules/hono/dist/router/reg-exp-router/trie.js
var Trie = class {
	#context = { varIndex: 0 };
	#root = new Node$1();
	insert(path, index, pathErrorCheckOnly) {
		const paramAssoc = [];
		const groups = [];
		for (let i = 0;;) {
			let replaced = false;
			path = path.replace(/\{[^}]+\}/g, (m) => {
				const mark = `@\\${i}`;
				groups[i] = [mark, m];
				i++;
				replaced = true;
				return mark;
			});
			if (!replaced) break;
		}
		const tokens = path.match(/(?::[^\/]+)|(?:\/\*$)|./g) || [];
		for (let i = groups.length - 1; i >= 0; i--) {
			const [mark] = groups[i];
			for (let j = tokens.length - 1; j >= 0; j--) if (tokens[j].indexOf(mark) !== -1) {
				tokens[j] = tokens[j].replace(mark, groups[i][1]);
				break;
			}
		}
		this.#root.insert(tokens, index, paramAssoc, this.#context, pathErrorCheckOnly);
		return paramAssoc;
	}
	buildRegExp() {
		let regexp = this.#root.buildRegExpStr();
		if (regexp === "") return [
			/^$/,
			[],
			[]
		];
		let captureIndex = 0;
		const indexReplacementMap = [];
		const paramReplacementMap = [];
		regexp = regexp.replace(/#(\d+)|@(\d+)|\.\*\$/g, (_, handlerIndex, paramIndex) => {
			if (handlerIndex !== void 0) {
				indexReplacementMap[++captureIndex] = Number(handlerIndex);
				return "$()";
			}
			if (paramIndex !== void 0) {
				paramReplacementMap[Number(paramIndex)] = ++captureIndex;
				return "";
			}
			return "";
		});
		return [
			new RegExp(`^${regexp}`),
			indexReplacementMap,
			paramReplacementMap
		];
	}
};
//#endregion
//#region ../../node_modules/.pnpm/hono@4.12.32/node_modules/hono/dist/router/reg-exp-router/router.js
var nullMatcher = [
	/^$/,
	[],
	/* @__PURE__ */ Object.create(null)
];
var wildcardRegExpCache = /* @__PURE__ */ Object.create(null);
function buildWildcardRegExp(path) {
	return wildcardRegExpCache[path] ??= new RegExp(path === "*" ? "" : `^${path.replace(/\/\*$|([.\\+*[^\]$()])/g, (_, metaChar) => metaChar ? `\\${metaChar}` : "(?:|/.*)")}$`);
}
function clearWildcardRegExpCache() {
	wildcardRegExpCache = /* @__PURE__ */ Object.create(null);
}
function buildMatcherFromPreprocessedRoutes(routes) {
	const trie = new Trie();
	const handlerData = [];
	if (routes.length === 0) return nullMatcher;
	const routesWithStaticPathFlag = routes.map((route) => [!/\*|\/:/.test(route[0]), ...route]).sort(([isStaticA, pathA], [isStaticB, pathB]) => isStaticA ? 1 : isStaticB ? -1 : pathA.length - pathB.length);
	const staticMap = /* @__PURE__ */ Object.create(null);
	for (let i = 0, j = -1, len = routesWithStaticPathFlag.length; i < len; i++) {
		const [pathErrorCheckOnly, path, handlers] = routesWithStaticPathFlag[i];
		if (pathErrorCheckOnly) staticMap[path] = [handlers.map(([h]) => [h, /* @__PURE__ */ Object.create(null)]), emptyParam];
		else j++;
		let paramAssoc;
		try {
			paramAssoc = trie.insert(path, j, pathErrorCheckOnly);
		} catch (e) {
			throw e === PATH_ERROR ? new UnsupportedPathError(path) : e;
		}
		if (pathErrorCheckOnly) continue;
		handlerData[j] = handlers.map(([h, paramCount]) => {
			const paramIndexMap = /* @__PURE__ */ Object.create(null);
			paramCount -= 1;
			for (; paramCount >= 0; paramCount--) {
				const [key, value] = paramAssoc[paramCount];
				paramIndexMap[key] = value;
			}
			return [h, paramIndexMap];
		});
	}
	const [regexp, indexReplacementMap, paramReplacementMap] = trie.buildRegExp();
	for (let i = 0, len = handlerData.length; i < len; i++) for (let j = 0, len2 = handlerData[i].length; j < len2; j++) {
		const map = handlerData[i][j]?.[1];
		if (!map) continue;
		const keys = Object.keys(map);
		for (let k = 0, len3 = keys.length; k < len3; k++) map[keys[k]] = paramReplacementMap[map[keys[k]]];
	}
	const handlerMap = [];
	for (const i in indexReplacementMap) handlerMap[i] = handlerData[indexReplacementMap[i]];
	return [
		regexp,
		handlerMap,
		staticMap
	];
}
function findMiddleware(middleware, path) {
	if (!middleware) return;
	for (const k of Object.keys(middleware).sort((a, b) => b.length - a.length)) if (buildWildcardRegExp(k).test(path)) return [...middleware[k]];
}
var RegExpRouter = class {
	name = "RegExpRouter";
	#middleware;
	#routes;
	constructor() {
		this.#middleware = { ["ALL"]: /* @__PURE__ */ Object.create(null) };
		this.#routes = { ["ALL"]: /* @__PURE__ */ Object.create(null) };
	}
	add(method, path, handler) {
		const middleware = this.#middleware;
		const routes = this.#routes;
		if (!middleware || !routes) throw new Error(MESSAGE_MATCHER_IS_ALREADY_BUILT);
		if (!middleware[method]) [middleware, routes].forEach((handlerMap) => {
			handlerMap[method] = /* @__PURE__ */ Object.create(null);
			Object.keys(handlerMap["ALL"]).forEach((p) => {
				handlerMap[method][p] = [...handlerMap["ALL"][p]];
			});
		});
		if (path === "/*") path = "*";
		const paramCount = (path.match(/\/:/g) || []).length;
		if (/\*$/.test(path)) {
			const re = buildWildcardRegExp(path);
			if (method === "ALL") Object.keys(middleware).forEach((m) => {
				middleware[m][path] ||= findMiddleware(middleware[m], path) || findMiddleware(middleware["ALL"], path) || [];
			});
			else middleware[method][path] ||= findMiddleware(middleware[method], path) || findMiddleware(middleware["ALL"], path) || [];
			Object.keys(middleware).forEach((m) => {
				if (method === "ALL" || method === m) Object.keys(middleware[m]).forEach((p) => {
					re.test(p) && middleware[m][p].push([handler, paramCount]);
				});
			});
			Object.keys(routes).forEach((m) => {
				if (method === "ALL" || method === m) Object.keys(routes[m]).forEach((p) => re.test(p) && routes[m][p].push([handler, paramCount]));
			});
			return;
		}
		const paths = checkOptionalParameter(path) || [path];
		for (let i = 0, len = paths.length; i < len; i++) {
			const path2 = paths[i];
			Object.keys(routes).forEach((m) => {
				if (method === "ALL" || method === m) {
					routes[m][path2] ||= [...findMiddleware(middleware[m], path2) || findMiddleware(middleware["ALL"], path2) || []];
					routes[m][path2].push([handler, paramCount - len + i + 1]);
				}
			});
		}
	}
	match = match;
	buildAllMatchers() {
		const matchers = /* @__PURE__ */ Object.create(null);
		Object.keys(this.#routes).concat(Object.keys(this.#middleware)).forEach((method) => {
			matchers[method] ||= this.#buildMatcher(method);
		});
		this.#middleware = this.#routes = void 0;
		clearWildcardRegExpCache();
		return matchers;
	}
	#buildMatcher(method) {
		const routes = [];
		let hasOwnRoute = method === "ALL";
		[this.#middleware, this.#routes].forEach((r) => {
			const ownRoute = r[method] ? Object.keys(r[method]).map((path) => [path, r[method][path]]) : [];
			if (ownRoute.length !== 0) {
				hasOwnRoute ||= true;
				routes.push(...ownRoute);
			} else if (method !== "ALL") routes.push(...Object.keys(r["ALL"]).map((path) => [path, r["ALL"][path]]));
		});
		if (!hasOwnRoute) return null;
		else return buildMatcherFromPreprocessedRoutes(routes);
	}
};
//#endregion
//#region ../../node_modules/.pnpm/hono@4.12.32/node_modules/hono/dist/router/smart-router/router.js
var SmartRouter = class {
	name = "SmartRouter";
	#routers = [];
	#routes = [];
	constructor(init) {
		this.#routers = init.routers;
	}
	add(method, path, handler) {
		if (!this.#routes) throw new Error(MESSAGE_MATCHER_IS_ALREADY_BUILT);
		this.#routes.push([
			method,
			path,
			handler
		]);
	}
	match(method, path) {
		if (!this.#routes) throw new Error("Fatal error");
		const routers = this.#routers;
		const routes = this.#routes;
		const len = routers.length;
		let i = 0;
		let res;
		for (; i < len; i++) {
			const router = routers[i];
			try {
				for (let i2 = 0, len2 = routes.length; i2 < len2; i2++) router.add(...routes[i2]);
				res = router.match(method, path);
			} catch (e) {
				if (e instanceof UnsupportedPathError) continue;
				throw e;
			}
			this.match = router.match.bind(router);
			this.#routers = [router];
			this.#routes = void 0;
			break;
		}
		if (i === len) throw new Error("Fatal error");
		this.name = `SmartRouter + ${this.activeRouter.name}`;
		return res;
	}
	get activeRouter() {
		if (this.#routes || this.#routers.length !== 1) throw new Error("No active router has been determined yet.");
		return this.#routers[0];
	}
};
//#endregion
//#region ../../node_modules/.pnpm/hono@4.12.32/node_modules/hono/dist/router/trie-router/node.js
var emptyParams = /* @__PURE__ */ Object.create(null);
var hasChildren = (children) => {
	for (const _ in children) return true;
	return false;
};
var Node = class _Node {
	#methods;
	#children;
	#patterns;
	#order = 0;
	#params = emptyParams;
	constructor(method, handler, children) {
		this.#children = children || /* @__PURE__ */ Object.create(null);
		this.#methods = [];
		if (method && handler) {
			const m = /* @__PURE__ */ Object.create(null);
			m[method] = {
				handler,
				possibleKeys: [],
				score: 0
			};
			this.#methods = [m];
		}
		this.#patterns = [];
	}
	insert(method, path, handler) {
		this.#order = ++this.#order;
		let curNode = this;
		const parts = splitRoutingPath(path);
		const possibleKeys = [];
		for (let i = 0, len = parts.length; i < len; i++) {
			const p = parts[i];
			const nextP = parts[i + 1];
			const pattern = getPattern(p, nextP);
			const key = Array.isArray(pattern) ? pattern[0] : p;
			if (key in curNode.#children) {
				curNode = curNode.#children[key];
				if (pattern) possibleKeys.push(pattern[1]);
				continue;
			}
			curNode.#children[key] = new _Node();
			if (pattern) {
				curNode.#patterns.push(pattern);
				possibleKeys.push(pattern[1]);
			}
			curNode = curNode.#children[key];
		}
		curNode.#methods.push({ [method]: {
			handler,
			possibleKeys: possibleKeys.filter((v, i, a) => a.indexOf(v) === i),
			score: this.#order
		} });
		return curNode;
	}
	#pushHandlerSets(handlerSets, node, method, nodeParams, params) {
		for (let i = 0, len = node.#methods.length; i < len; i++) {
			const m = node.#methods[i];
			const handlerSet = m[method] || m["ALL"];
			const processedSet = {};
			if (handlerSet !== void 0) {
				handlerSet.params = /* @__PURE__ */ Object.create(null);
				handlerSets.push(handlerSet);
				if (nodeParams !== emptyParams || params && params !== emptyParams) for (let i2 = 0, len2 = handlerSet.possibleKeys.length; i2 < len2; i2++) {
					const key = handlerSet.possibleKeys[i2];
					const processed = processedSet[handlerSet.score];
					handlerSet.params[key] = params?.[key] && !processed ? params[key] : nodeParams[key] ?? params?.[key];
					processedSet[handlerSet.score] = true;
				}
			}
		}
	}
	search(method, path) {
		const handlerSets = [];
		this.#params = emptyParams;
		let curNodes = [this];
		const parts = splitPath(path);
		const curNodesQueue = [];
		const len = parts.length;
		let partOffsets = null;
		for (let i = 0; i < len; i++) {
			const part = parts[i];
			const isLast = i === len - 1;
			const tempNodes = [];
			for (let j = 0, len2 = curNodes.length; j < len2; j++) {
				const node = curNodes[j];
				const nextNode = node.#children[part];
				if (nextNode) {
					nextNode.#params = node.#params;
					if (isLast) {
						if (nextNode.#children["*"]) this.#pushHandlerSets(handlerSets, nextNode.#children["*"], method, node.#params);
						this.#pushHandlerSets(handlerSets, nextNode, method, node.#params);
					} else tempNodes.push(nextNode);
				}
				for (let k = 0, len3 = node.#patterns.length; k < len3; k++) {
					const pattern = node.#patterns[k];
					const params = node.#params === emptyParams ? {} : { ...node.#params };
					if (pattern === "*") {
						const astNode = node.#children["*"];
						if (astNode) {
							this.#pushHandlerSets(handlerSets, astNode, method, node.#params);
							astNode.#params = params;
							tempNodes.push(astNode);
						}
						continue;
					}
					const [key, name, matcher] = pattern;
					if (!part && !(matcher instanceof RegExp)) continue;
					const child = node.#children[key];
					if (matcher instanceof RegExp) {
						if (partOffsets === null) {
							partOffsets = new Array(len);
							let offset = path[0] === "/" ? 1 : 0;
							for (let p = 0; p < len; p++) {
								partOffsets[p] = offset;
								offset += parts[p].length + 1;
							}
						}
						const restPathString = path.substring(partOffsets[i]);
						const m = matcher.exec(restPathString);
						if (m) {
							params[name] = m[0];
							this.#pushHandlerSets(handlerSets, child, method, node.#params, params);
							if (m[0].length === restPathString.length && child.#children["*"]) this.#pushHandlerSets(handlerSets, child.#children["*"], method, node.#params, params);
							if (hasChildren(child.#children)) {
								child.#params = params;
								const componentCount = m[0].match(/\//)?.length ?? 0;
								(curNodesQueue[componentCount] ||= []).push(child);
							}
							continue;
						}
					}
					if (matcher === true || matcher.test(part)) {
						params[name] = part;
						if (isLast) {
							this.#pushHandlerSets(handlerSets, child, method, params, node.#params);
							if (child.#children["*"]) this.#pushHandlerSets(handlerSets, child.#children["*"], method, params, node.#params);
						} else {
							child.#params = params;
							tempNodes.push(child);
						}
					}
				}
			}
			const shifted = curNodesQueue.shift();
			curNodes = shifted ? tempNodes.concat(shifted) : tempNodes;
		}
		if (handlerSets.length > 1) handlerSets.sort((a, b) => {
			return a.score - b.score;
		});
		return [handlerSets.map(({ handler, params }) => [handler, params])];
	}
};
//#endregion
//#region ../../node_modules/.pnpm/hono@4.12.32/node_modules/hono/dist/router/trie-router/router.js
var TrieRouter = class {
	name = "TrieRouter";
	#node;
	constructor() {
		this.#node = new Node();
	}
	add(method, path, handler) {
		const results = checkOptionalParameter(path);
		if (results) {
			for (let i = 0, len = results.length; i < len; i++) this.#node.insert(method, results[i], handler);
			return;
		}
		this.#node.insert(method, path, handler);
	}
	match(method, path) {
		return this.#node.search(method, path);
	}
};
//#endregion
//#region ../../node_modules/.pnpm/hono@4.12.32/node_modules/hono/dist/hono.js
var Hono = class extends Hono$1 {
	/**
	* Creates an instance of the Hono class.
	*
	* @param options - Optional configuration options for the Hono instance.
	*/
	constructor(options = {}) {
		super(options);
		this.router = options.router ?? new SmartRouter({ routers: [new RegExpRouter(), new TrieRouter()] });
	}
};
//#endregion
//#region ../douzed/src/capture-store.ts
/**
* #CaptureStore — persists sessions, exchanges, and annotation spans, and is the last gate
* before anything touches disk (AC-CAP-005, TR-6). Uses node:sqlite so douzed ships with no
* native dependency to compile.
*/
var CaptureStore = class {
	db;
	constructor(filename) {
		this.db = new DatabaseSync(filename);
		this.db.exec(`
      PRAGMA journal_mode = WAL;
      CREATE TABLE IF NOT EXISTS sessions (
        id TEXT PRIMARY KEY, name TEXT NOT NULL, origins TEXT NOT NULL,
        started_at INTEGER NOT NULL, stopped_at INTEGER, debugger_enabled INTEGER NOT NULL DEFAULT 0
      );
      CREATE TABLE IF NOT EXISTS exchanges (
        id TEXT PRIMARY KEY, session_id TEXT NOT NULL, position INTEGER NOT NULL, doc TEXT NOT NULL
      );
      CREATE TABLE IF NOT EXISTS annotations (
        id TEXT PRIMARY KEY, session_id TEXT NOT NULL, note TEXT NOT NULL,
        start_position INTEGER NOT NULL, end_position INTEGER NOT NULL
      );
      CREATE INDEX IF NOT EXISTS exchanges_session ON exchanges(session_id, position);
    `);
	}
	/**
	* The extension owns session identity — it allocates the id and stamps every exchange with it,
	* so the daemon must adopt that id rather than minting its own. HAR import has no upstream id
	* and gets a fresh one.
	*/
	startSession(input) {
		const session = CaptureSession.parse({
			id: input.id ?? randomUUID(),
			name: input.name,
			origins: input.origins,
			started_at: Date.now(),
			debugger_enabled: input.debugger_enabled ?? false
		});
		this.db.prepare("INSERT OR REPLACE INTO sessions (id,name,origins,started_at,debugger_enabled) VALUES (?,?,?,?,?)").run(session.id, session.name, JSON.stringify(session.origins), session.started_at, session.debugger_enabled ? 1 : 0);
		return session;
	}
	stopSession(id) {
		this.db.prepare("UPDATE sessions SET stopped_at = ? WHERE id = ?").run(Date.now(), id);
		return { retained: this.countExchanges(id) };
	}
	/**
	* Redaction is re-applied here even though the extension already ran it, because douzed also
	* ingests HAR files and must not depend on an upstream having been careful (AC-CAP-006.1).
	*/
	appendExchange(input) {
		const exchange = Exchange.parse({
			...input,
			url: redactUrl(input.url),
			request_headers: redactHeaders(input.request_headers ?? {}),
			response_headers: redactHeaders(input.response_headers ?? {}),
			request_body: redactBody(input.request_body),
			response_body: redactBody(input.response_body)
		});
		const leaked = findSurvivingSecrets({
			url: exchange.url,
			request_headers: exchange.request_headers,
			response_headers: exchange.response_headers,
			request_body: exchange.request_body,
			response_body: exchange.response_body
		});
		if (leaked.length > 0) throw new Error(`refusing to persist exchange ${exchange.id}: credential at ${leaked.join(", ")}`);
		this.db.prepare("INSERT OR REPLACE INTO exchanges (id,session_id,position,doc) VALUES (?,?,?,?)").run(exchange.id, exchange.session_id, exchange.position, JSON.stringify(exchange));
		return exchange;
	}
	/**
	* AC-CAP-007.2 — a span covers everything captured since the previous note. When nothing has
	* been captured since, the span is EMPTY (end < start) rather than claiming the next exchange
	* that has not happened yet — that one arrives after the note, so the note cannot describe it.
	*/
	annotate(sessionId, note) {
		const previous = this.db.prepare("SELECT MAX(end_position) AS last FROM annotations WHERE session_id = ?").get(sessionId);
		const start = previous?.last === null || previous?.last === void 0 ? 0 : previous.last + 1;
		const highest = this.db.prepare("SELECT MAX(position) AS max FROM exchanges WHERE session_id = ?").get(sessionId);
		const end = highest?.max === null || highest?.max === void 0 ? start - 1 : highest.max;
		const span = AnnotationSpan.parse({
			id: randomUUID(),
			session_id: sessionId,
			note,
			start_position: start,
			end_position: end
		});
		this.db.prepare("INSERT INTO annotations (id,session_id,note,start_position,end_position) VALUES (?,?,?,?,?)").run(span.id, span.session_id, span.note, span.start_position, span.end_position);
		return span;
	}
	countExchanges(sessionId) {
		return this.db.prepare("SELECT COUNT(*) AS n FROM exchanges WHERE session_id = ?").get(sessionId).n;
	}
	nextPosition(sessionId) {
		return this.countExchanges(sessionId);
	}
	exchanges(sessionId) {
		return this.db.prepare("SELECT doc FROM exchanges WHERE session_id = ? ORDER BY position").all(sessionId).map((row) => JSON.parse(row.doc));
	}
	annotations(sessionId) {
		return this.db.prepare("SELECT id,session_id,note,start_position,end_position FROM annotations WHERE session_id = ? ORDER BY start_position").all(sessionId);
	}
	sessions() {
		return this.db.prepare("SELECT * FROM sessions ORDER BY started_at DESC").all().map((row) => CaptureSession.parse({
			...row,
			origins: JSON.parse(row["origins"]),
			debugger_enabled: Boolean(row["debugger_enabled"]),
			stopped_at: row["stopped_at"] ?? void 0
		}));
	}
	session(id) {
		return this.sessions().find((s) => s.id === id) ?? null;
	}
	/** Idempotent: a signal handler and an explicit `daemon.close()` can both land on the same store. */
	close() {
		if (this.closed) return;
		this.closed = true;
		this.db.close();
	}
	closed = false;
};
//#endregion
//#region ../../node_modules/.pnpm/readdirp@5.0.0/node_modules/readdirp/index.js
var EntryTypes = {
	FILE_TYPE: "files",
	DIR_TYPE: "directories",
	FILE_DIR_TYPE: "files_directories",
	EVERYTHING_TYPE: "all"
};
var defaultOptions = {
	root: ".",
	fileFilter: (_entryInfo) => true,
	directoryFilter: (_entryInfo) => true,
	type: EntryTypes.FILE_TYPE,
	lstat: false,
	depth: 2147483648,
	alwaysStat: false,
	highWaterMark: 4096
};
Object.freeze(defaultOptions);
var RECURSIVE_ERROR_CODE = "READDIRP_RECURSIVE_ERROR";
var NORMAL_FLOW_ERRORS = /* @__PURE__ */ new Set([
	"ENOENT",
	"EPERM",
	"EACCES",
	"ELOOP",
	RECURSIVE_ERROR_CODE
]);
var ALL_TYPES = [
	EntryTypes.DIR_TYPE,
	EntryTypes.EVERYTHING_TYPE,
	EntryTypes.FILE_DIR_TYPE,
	EntryTypes.FILE_TYPE
];
var DIR_TYPES = /* @__PURE__ */ new Set([
	EntryTypes.DIR_TYPE,
	EntryTypes.EVERYTHING_TYPE,
	EntryTypes.FILE_DIR_TYPE
]);
var FILE_TYPES = /* @__PURE__ */ new Set([
	EntryTypes.EVERYTHING_TYPE,
	EntryTypes.FILE_DIR_TYPE,
	EntryTypes.FILE_TYPE
]);
var isNormalFlowError = (error) => NORMAL_FLOW_ERRORS.has(error.code);
var wantBigintFsStats = process.platform === "win32";
var emptyFn = (_entryInfo) => true;
var normalizeFilter = (filter) => {
	if (filter === void 0) return emptyFn;
	if (typeof filter === "function") return filter;
	if (typeof filter === "string") {
		const fl = filter.trim();
		return (entry) => entry.basename === fl;
	}
	if (Array.isArray(filter)) {
		const trItems = filter.map((item) => item.trim());
		return (entry) => trItems.some((f) => entry.basename === f);
	}
	return emptyFn;
};
/** Readable readdir stream, emitting new files as they're being listed. */
var ReaddirpStream = class extends Readable {
	parents;
	reading;
	parent;
	_stat;
	_maxDepth;
	_wantsDir;
	_wantsFile;
	_wantsEverything;
	_root;
	_isDirent;
	_statsProp;
	_rdOptions;
	_fileFilter;
	_directoryFilter;
	constructor(options = {}) {
		super({
			objectMode: true,
			autoDestroy: true,
			highWaterMark: options.highWaterMark
		});
		const opts = {
			...defaultOptions,
			...options
		};
		const { root, type } = opts;
		this._fileFilter = normalizeFilter(opts.fileFilter);
		this._directoryFilter = normalizeFilter(opts.directoryFilter);
		const statMethod = opts.lstat ? lstat : stat$1;
		if (wantBigintFsStats) this._stat = (path) => statMethod(path, { bigint: true });
		else this._stat = statMethod;
		this._maxDepth = opts.depth != null && Number.isSafeInteger(opts.depth) ? opts.depth : defaultOptions.depth;
		this._wantsDir = type ? DIR_TYPES.has(type) : false;
		this._wantsFile = type ? FILE_TYPES.has(type) : false;
		this._wantsEverything = type === EntryTypes.EVERYTHING_TYPE;
		this._root = resolve(root);
		this._isDirent = !opts.alwaysStat;
		this._statsProp = this._isDirent ? "dirent" : "stats";
		this._rdOptions = {
			encoding: "utf8",
			withFileTypes: this._isDirent
		};
		this.parents = [this._exploreDir(root, 1)];
		this.reading = false;
		this.parent = void 0;
	}
	async _read(batch) {
		if (this.reading) return;
		this.reading = true;
		try {
			while (!this.destroyed && batch > 0) {
				const par = this.parent;
				const fil = par && par.files;
				if (fil && fil.length > 0) {
					const { path, depth } = par;
					const slice = fil.splice(0, batch).map((dirent) => this._formatEntry(dirent, path));
					const awaited = await Promise.all(slice);
					for (const entry of awaited) {
						if (!entry) continue;
						if (this.destroyed) return;
						const entryType = await this._getEntryType(entry);
						if (entryType === "directory" && this._directoryFilter(entry)) {
							if (depth <= this._maxDepth) this.parents.push(this._exploreDir(entry.fullPath, depth + 1));
							if (this._wantsDir) {
								this.push(entry);
								batch--;
							}
						} else if ((entryType === "file" || this._includeAsFile(entry)) && this._fileFilter(entry)) {
							if (this._wantsFile) {
								this.push(entry);
								batch--;
							}
						}
					}
				} else {
					const parent = this.parents.pop();
					if (!parent) {
						this.push(null);
						break;
					}
					this.parent = await parent;
					if (this.destroyed) return;
				}
			}
		} catch (error) {
			this.destroy(error);
		} finally {
			this.reading = false;
		}
	}
	async _exploreDir(path, depth) {
		let files;
		try {
			files = await readdir(path, this._rdOptions);
		} catch (error) {
			this._onError(error);
		}
		return {
			files,
			depth,
			path
		};
	}
	async _formatEntry(dirent, path) {
		let entry;
		const basename = this._isDirent ? dirent.name : dirent;
		try {
			const fullPath = resolve(join(path, basename));
			entry = {
				path: relative(this._root, fullPath),
				fullPath,
				basename
			};
			entry[this._statsProp] = this._isDirent ? dirent : await this._stat(fullPath);
		} catch (err) {
			this._onError(err);
			return;
		}
		return entry;
	}
	_onError(err) {
		if (isNormalFlowError(err) && !this.destroyed) this.emit("warn", err);
		else this.destroy(err);
	}
	async _getEntryType(entry) {
		if (!entry && this._statsProp in entry) return "";
		const stats = entry[this._statsProp];
		if (stats.isFile()) return "file";
		if (stats.isDirectory()) return "directory";
		if (stats && stats.isSymbolicLink()) {
			const full = entry.fullPath;
			try {
				const entryRealPath = await realpath(full);
				const entryRealPathStats = await lstat(entryRealPath);
				if (entryRealPathStats.isFile()) return "file";
				if (entryRealPathStats.isDirectory()) {
					const len = entryRealPath.length;
					if (full.startsWith(entryRealPath) && full.substr(len, 1) === sep) {
						const recursiveError = /* @__PURE__ */ new Error(`Circular symlink detected: "${full}" points to "${entryRealPath}"`);
						recursiveError.code = RECURSIVE_ERROR_CODE;
						return this._onError(recursiveError);
					}
					return "directory";
				}
			} catch (error) {
				this._onError(error);
				return "";
			}
		}
	}
	_includeAsFile(entry) {
		const stats = entry && entry[this._statsProp];
		return stats && this._wantsEverything && !stats.isDirectory();
	}
};
/**
* Streaming version: Reads all files and directories in given root recursively.
* Consumes ~constant small amount of RAM.
* @param root Root directory
* @param options Options to specify root (start directory), filters and recursion depth
*/
function readdirp(root, options = {}) {
	let type = options.entryType || options.type;
	if (type === "both") type = EntryTypes.FILE_DIR_TYPE;
	if (type) options.type = type;
	if (!root) throw new Error("readdirp: root argument is required. Usage: readdirp(root, options)");
	else if (typeof root !== "string") throw new TypeError("readdirp: root argument must be a string. Usage: readdirp(root, options)");
	else if (type && !ALL_TYPES.includes(type)) throw new Error(`readdirp: Invalid type passed. Use one of ${ALL_TYPES.join(", ")}`);
	options.root = root;
	return new ReaddirpStream(options);
}
//#endregion
//#region ../../node_modules/.pnpm/chokidar@5.0.0/node_modules/chokidar/handler.js
var STR_DATA = "data";
var STR_CLOSE = "close";
var EMPTY_FN = () => {};
var pl = process.platform;
var isWindows = pl === "win32";
var isMacos = pl === "darwin";
var isLinux = pl === "linux";
var isFreeBSD = pl === "freebsd";
var isIBMi = type() === "OS400";
var EVENTS = {
	ALL: "all",
	READY: "ready",
	ADD: "add",
	CHANGE: "change",
	ADD_DIR: "addDir",
	UNLINK: "unlink",
	UNLINK_DIR: "unlinkDir",
	RAW: "raw",
	ERROR: "error"
};
var EV = EVENTS;
var THROTTLE_MODE_WATCH = "watch";
var statMethods = {
	lstat,
	stat: stat$1
};
var KEY_LISTENERS = "listeners";
var KEY_ERR = "errHandlers";
var KEY_RAW = "rawEmitters";
var HANDLER_KEYS = [
	KEY_LISTENERS,
	KEY_ERR,
	KEY_RAW
];
var binaryExtensions = /* @__PURE__ */ new Set([
	"3dm",
	"3ds",
	"3g2",
	"3gp",
	"7z",
	"a",
	"aac",
	"adp",
	"afdesign",
	"afphoto",
	"afpub",
	"ai",
	"aif",
	"aiff",
	"alz",
	"ape",
	"apk",
	"appimage",
	"ar",
	"arj",
	"asf",
	"au",
	"avi",
	"bak",
	"baml",
	"bh",
	"bin",
	"bk",
	"bmp",
	"btif",
	"bz2",
	"bzip2",
	"cab",
	"caf",
	"cgm",
	"class",
	"cmx",
	"cpio",
	"cr2",
	"cur",
	"dat",
	"dcm",
	"deb",
	"dex",
	"djvu",
	"dll",
	"dmg",
	"dng",
	"doc",
	"docm",
	"docx",
	"dot",
	"dotm",
	"dra",
	"DS_Store",
	"dsk",
	"dts",
	"dtshd",
	"dvb",
	"dwg",
	"dxf",
	"ecelp4800",
	"ecelp7470",
	"ecelp9600",
	"egg",
	"eol",
	"eot",
	"epub",
	"exe",
	"f4v",
	"fbs",
	"fh",
	"fla",
	"flac",
	"flatpak",
	"fli",
	"flv",
	"fpx",
	"fst",
	"fvt",
	"g3",
	"gh",
	"gif",
	"graffle",
	"gz",
	"gzip",
	"h261",
	"h263",
	"h264",
	"icns",
	"ico",
	"ief",
	"img",
	"ipa",
	"iso",
	"jar",
	"jpeg",
	"jpg",
	"jpgv",
	"jpm",
	"jxr",
	"key",
	"ktx",
	"lha",
	"lib",
	"lvp",
	"lz",
	"lzh",
	"lzma",
	"lzo",
	"m3u",
	"m4a",
	"m4v",
	"mar",
	"mdi",
	"mht",
	"mid",
	"midi",
	"mj2",
	"mka",
	"mkv",
	"mmr",
	"mng",
	"mobi",
	"mov",
	"movie",
	"mp3",
	"mp4",
	"mp4a",
	"mpeg",
	"mpg",
	"mpga",
	"mxu",
	"nef",
	"npx",
	"numbers",
	"nupkg",
	"o",
	"odp",
	"ods",
	"odt",
	"oga",
	"ogg",
	"ogv",
	"otf",
	"ott",
	"pages",
	"pbm",
	"pcx",
	"pdb",
	"pdf",
	"pea",
	"pgm",
	"pic",
	"png",
	"pnm",
	"pot",
	"potm",
	"potx",
	"ppa",
	"ppam",
	"ppm",
	"pps",
	"ppsm",
	"ppsx",
	"ppt",
	"pptm",
	"pptx",
	"psd",
	"pya",
	"pyc",
	"pyo",
	"pyv",
	"qt",
	"rar",
	"ras",
	"raw",
	"resources",
	"rgb",
	"rip",
	"rlc",
	"rmf",
	"rmvb",
	"rpm",
	"rtf",
	"rz",
	"s3m",
	"s7z",
	"scpt",
	"sgi",
	"shar",
	"snap",
	"sil",
	"sketch",
	"slk",
	"smv",
	"snk",
	"so",
	"stl",
	"suo",
	"sub",
	"swf",
	"tar",
	"tbz",
	"tbz2",
	"tga",
	"tgz",
	"thmx",
	"tif",
	"tiff",
	"tlz",
	"ttc",
	"ttf",
	"txz",
	"udf",
	"uvh",
	"uvi",
	"uvm",
	"uvp",
	"uvs",
	"uvu",
	"viv",
	"vob",
	"war",
	"wav",
	"wax",
	"wbmp",
	"wdp",
	"weba",
	"webm",
	"webp",
	"whl",
	"wim",
	"wm",
	"wma",
	"wmv",
	"wmx",
	"woff",
	"woff2",
	"wrm",
	"wvx",
	"xbm",
	"xif",
	"xla",
	"xlam",
	"xls",
	"xlsb",
	"xlsm",
	"xlsx",
	"xlt",
	"xltm",
	"xltx",
	"xm",
	"xmind",
	"xpi",
	"xpm",
	"xwd",
	"xz",
	"z",
	"zip",
	"zipx"
]);
var isBinaryPath = (filePath) => binaryExtensions.has(path$1.extname(filePath).slice(1).toLowerCase());
var foreach = (val, fn) => {
	if (val instanceof Set) val.forEach(fn);
	else fn(val);
};
var addAndConvert = (main, prop, item) => {
	let container = main[prop];
	if (!(container instanceof Set)) main[prop] = container = /* @__PURE__ */ new Set([container]);
	container.add(item);
};
var clearItem = (cont) => (key) => {
	const set = cont[key];
	if (set instanceof Set) set.clear();
	else delete cont[key];
};
var delFromSet = (main, prop, item) => {
	const container = main[prop];
	if (container instanceof Set) container.delete(item);
	else if (container === item) delete main[prop];
};
var isEmptySet = (val) => val instanceof Set ? val.size === 0 : !val;
var FsWatchInstances = /* @__PURE__ */ new Map();
/**
* Instantiates the fs_watch interface
* @param path to be watched
* @param options to be passed to fs_watch
* @param listener main event handler
* @param errHandler emits info about errors
* @param emitRaw emits raw event data
* @returns {NativeFsWatcher}
*/
function createFsWatchInstance(path, options, listener, errHandler, emitRaw) {
	const handleEvent = (rawEvent, evPath) => {
		listener(path);
		emitRaw(rawEvent, evPath, { watchedPath: path });
		if (evPath && path !== evPath) fsWatchBroadcast(path$1.resolve(path, evPath), KEY_LISTENERS, path$1.join(path, evPath));
	};
	try {
		return watch(path, { persistent: options.persistent }, handleEvent);
	} catch (error) {
		errHandler(error);
		return;
	}
}
/**
* Helper for passing fs_watch event data to a collection of listeners
* @param fullPath absolute path bound to fs_watch instance
*/
var fsWatchBroadcast = (fullPath, listenerType, val1, val2, val3) => {
	const cont = FsWatchInstances.get(fullPath);
	if (!cont) return;
	foreach(cont[listenerType], (listener) => {
		listener(val1, val2, val3);
	});
};
/**
* Instantiates the fs_watch interface or binds listeners
* to an existing one covering the same file system entry
* @param path
* @param fullPath absolute path
* @param options to be passed to fs_watch
* @param handlers container for event listener functions
*/
var setFsWatchListener = (path, fullPath, options, handlers) => {
	const { listener, errHandler, rawEmitter } = handlers;
	let cont = FsWatchInstances.get(fullPath);
	let watcher;
	if (!options.persistent) {
		watcher = createFsWatchInstance(path, options, listener, errHandler, rawEmitter);
		if (!watcher) return;
		return watcher.close.bind(watcher);
	}
	if (cont) {
		addAndConvert(cont, KEY_LISTENERS, listener);
		addAndConvert(cont, KEY_ERR, errHandler);
		addAndConvert(cont, KEY_RAW, rawEmitter);
	} else {
		watcher = createFsWatchInstance(path, options, fsWatchBroadcast.bind(null, fullPath, KEY_LISTENERS), errHandler, fsWatchBroadcast.bind(null, fullPath, KEY_RAW));
		if (!watcher) return;
		watcher.on(EV.ERROR, async (error) => {
			const broadcastErr = fsWatchBroadcast.bind(null, fullPath, KEY_ERR);
			if (cont) cont.watcherUnusable = true;
			if (isWindows && error.code === "EPERM") try {
				await (await open(path, "r")).close();
				broadcastErr(error);
			} catch (err) {}
			else broadcastErr(error);
		});
		cont = {
			listeners: listener,
			errHandlers: errHandler,
			rawEmitters: rawEmitter,
			watcher
		};
		FsWatchInstances.set(fullPath, cont);
	}
	return () => {
		delFromSet(cont, KEY_LISTENERS, listener);
		delFromSet(cont, KEY_ERR, errHandler);
		delFromSet(cont, KEY_RAW, rawEmitter);
		if (isEmptySet(cont.listeners)) {
			cont.watcher.close();
			FsWatchInstances.delete(fullPath);
			HANDLER_KEYS.forEach(clearItem(cont));
			cont.watcher = void 0;
			Object.freeze(cont);
		}
	};
};
var FsWatchFileInstances = /* @__PURE__ */ new Map();
/**
* Instantiates the fs_watchFile interface or binds listeners
* to an existing one covering the same file system entry
* @param path to be watched
* @param fullPath absolute path
* @param options options to be passed to fs_watchFile
* @param handlers container for event listener functions
* @returns closer
*/
var setFsWatchFileListener = (path, fullPath, options, handlers) => {
	const { listener, rawEmitter } = handlers;
	let cont = FsWatchFileInstances.get(fullPath);
	const copts = cont && cont.options;
	if (copts && (copts.persistent < options.persistent || copts.interval > options.interval)) {
		unwatchFile(fullPath);
		cont = void 0;
	}
	if (cont) {
		addAndConvert(cont, KEY_LISTENERS, listener);
		addAndConvert(cont, KEY_RAW, rawEmitter);
	} else {
		cont = {
			listeners: listener,
			rawEmitters: rawEmitter,
			options,
			watcher: watchFile(fullPath, options, (curr, prev) => {
				foreach(cont.rawEmitters, (rawEmitter) => {
					rawEmitter(EV.CHANGE, fullPath, {
						curr,
						prev
					});
				});
				const currmtime = curr.mtimeMs;
				if (curr.size !== prev.size || currmtime > prev.mtimeMs || currmtime === 0) foreach(cont.listeners, (listener) => listener(path, curr));
			})
		};
		FsWatchFileInstances.set(fullPath, cont);
	}
	return () => {
		delFromSet(cont, KEY_LISTENERS, listener);
		delFromSet(cont, KEY_RAW, rawEmitter);
		if (isEmptySet(cont.listeners)) {
			FsWatchFileInstances.delete(fullPath);
			unwatchFile(fullPath);
			cont.options = cont.watcher = void 0;
			Object.freeze(cont);
		}
	};
};
/**
* @mixin
*/
var NodeFsHandler = class {
	fsw;
	_boundHandleError;
	constructor(fsW) {
		this.fsw = fsW;
		this._boundHandleError = (error) => fsW._handleError(error);
	}
	/**
	* Watch file for changes with fs_watchFile or fs_watch.
	* @param path to file or dir
	* @param listener on fs change
	* @returns closer for the watcher instance
	*/
	_watchWithNodeFs(path, listener) {
		const opts = this.fsw.options;
		const directory = path$1.dirname(path);
		const basename = path$1.basename(path);
		this.fsw._getWatchedDir(directory).add(basename);
		const absolutePath = path$1.resolve(path);
		const options = { persistent: opts.persistent };
		if (!listener) listener = EMPTY_FN;
		let closer;
		if (opts.usePolling) {
			options.interval = opts.interval !== opts.binaryInterval && isBinaryPath(basename) ? opts.binaryInterval : opts.interval;
			closer = setFsWatchFileListener(path, absolutePath, options, {
				listener,
				rawEmitter: this.fsw._emitRaw
			});
		} else closer = setFsWatchListener(path, absolutePath, options, {
			listener,
			errHandler: this._boundHandleError,
			rawEmitter: this.fsw._emitRaw
		});
		return closer;
	}
	/**
	* Watch a file and emit add event if warranted.
	* @returns closer for the watcher instance
	*/
	_handleFile(file, stats, initialAdd) {
		if (this.fsw.closed) return;
		const dirname = path$1.dirname(file);
		const basename = path$1.basename(file);
		const parent = this.fsw._getWatchedDir(dirname);
		let prevStats = stats;
		if (parent.has(basename)) return;
		const listener = async (path, newStats) => {
			if (!this.fsw._throttle(THROTTLE_MODE_WATCH, file, 5)) return;
			if (!newStats || newStats.mtimeMs === 0) try {
				const newStats = await stat$1(file);
				if (this.fsw.closed) return;
				const at = newStats.atimeMs;
				const mt = newStats.mtimeMs;
				if (!at || at <= mt || mt !== prevStats.mtimeMs) this.fsw._emit(EV.CHANGE, file, newStats);
				if ((isMacos || isLinux || isFreeBSD) && prevStats.ino !== newStats.ino) {
					this.fsw._closeFile(path);
					prevStats = newStats;
					const closer = this._watchWithNodeFs(file, listener);
					if (closer) this.fsw._addPathCloser(path, closer);
				} else prevStats = newStats;
			} catch (error) {
				this.fsw._remove(dirname, basename);
			}
			else if (parent.has(basename)) {
				const at = newStats.atimeMs;
				const mt = newStats.mtimeMs;
				if (!at || at <= mt || mt !== prevStats.mtimeMs) this.fsw._emit(EV.CHANGE, file, newStats);
				prevStats = newStats;
			}
		};
		const closer = this._watchWithNodeFs(file, listener);
		if (!(initialAdd && this.fsw.options.ignoreInitial) && this.fsw._isntIgnored(file)) {
			if (!this.fsw._throttle(EV.ADD, file, 0)) return;
			this.fsw._emit(EV.ADD, file, stats);
		}
		return closer;
	}
	/**
	* Handle symlinks encountered while reading a dir.
	* @param entry returned by readdirp
	* @param directory path of dir being read
	* @param path of this item
	* @param item basename of this item
	* @returns true if no more processing is needed for this entry.
	*/
	async _handleSymlink(entry, directory, path, item) {
		if (this.fsw.closed) return;
		const full = entry.fullPath;
		const dir = this.fsw._getWatchedDir(directory);
		if (!this.fsw.options.followSymlinks) {
			this.fsw._incrReadyCount();
			let linkPath;
			try {
				linkPath = await realpath(path);
			} catch (e) {
				this.fsw._emitReady();
				return true;
			}
			if (this.fsw.closed) return;
			if (dir.has(item)) {
				if (this.fsw._symlinkPaths.get(full) !== linkPath) {
					this.fsw._symlinkPaths.set(full, linkPath);
					this.fsw._emit(EV.CHANGE, path, entry.stats);
				}
			} else {
				dir.add(item);
				this.fsw._symlinkPaths.set(full, linkPath);
				this.fsw._emit(EV.ADD, path, entry.stats);
			}
			this.fsw._emitReady();
			return true;
		}
		if (this.fsw._symlinkPaths.has(full)) return true;
		this.fsw._symlinkPaths.set(full, true);
	}
	_handleRead(directory, initialAdd, wh, target, dir, depth, throttler) {
		directory = path$1.join(directory, "");
		const throttleKey = target ? `${directory}:${target}` : directory;
		throttler = this.fsw._throttle("readdir", throttleKey, 1e3);
		if (!throttler) return;
		const previous = this.fsw._getWatchedDir(wh.path);
		const current = /* @__PURE__ */ new Set();
		let stream = this.fsw._readdirp(directory, {
			fileFilter: (entry) => wh.filterPath(entry),
			directoryFilter: (entry) => wh.filterDir(entry)
		});
		if (!stream) return;
		stream.on(STR_DATA, async (entry) => {
			if (this.fsw.closed) {
				stream = void 0;
				return;
			}
			const item = entry.path;
			let path = path$1.join(directory, item);
			current.add(item);
			if (entry.stats.isSymbolicLink() && await this._handleSymlink(entry, directory, path, item)) return;
			if (this.fsw.closed) {
				stream = void 0;
				return;
			}
			if (item === target || !target && !previous.has(item)) {
				this.fsw._incrReadyCount();
				path = path$1.join(dir, path$1.relative(dir, path));
				this._addToNodeFs(path, initialAdd, wh, depth + 1);
			}
		}).on(EV.ERROR, this._boundHandleError);
		return new Promise((resolve, reject) => {
			if (!stream) return reject();
			stream.once("end", () => {
				if (this.fsw.closed) {
					stream = void 0;
					return;
				}
				const wasThrottled = throttler ? throttler.clear() : false;
				resolve(void 0);
				previous.getChildren().filter((item) => {
					return item !== directory && !current.has(item);
				}).forEach((item) => {
					this.fsw._remove(directory, item);
				});
				stream = void 0;
				if (wasThrottled) this._handleRead(directory, false, wh, target, dir, depth, throttler);
			});
		});
	}
	/**
	* Read directory to add / remove files from `@watched` list and re-read it on change.
	* @param dir fs path
	* @param stats
	* @param initialAdd
	* @param depth relative to user-supplied path
	* @param target child path targeted for watch
	* @param wh Common watch helpers for this path
	* @param realpath
	* @returns closer for the watcher instance.
	*/
	async _handleDir(dir, stats, initialAdd, depth, target, wh, realpath) {
		const parentDir = this.fsw._getWatchedDir(path$1.dirname(dir));
		const tracked = parentDir.has(path$1.basename(dir));
		if (!(initialAdd && this.fsw.options.ignoreInitial) && !target && !tracked) this.fsw._emit(EV.ADD_DIR, dir, stats);
		parentDir.add(path$1.basename(dir));
		this.fsw._getWatchedDir(dir);
		let throttler;
		let closer;
		const oDepth = this.fsw.options.depth;
		if ((oDepth == null || depth <= oDepth) && !this.fsw._symlinkPaths.has(realpath)) {
			if (!target) {
				await this._handleRead(dir, initialAdd, wh, target, dir, depth, throttler);
				if (this.fsw.closed) return;
			}
			closer = this._watchWithNodeFs(dir, (dirPath, stats) => {
				if (stats && stats.mtimeMs === 0) return;
				this._handleRead(dirPath, false, wh, target, dir, depth, throttler);
			});
		}
		return closer;
	}
	/**
	* Handle added file, directory, or glob pattern.
	* Delegates call to _handleFile / _handleDir after checks.
	* @param path to file or ir
	* @param initialAdd was the file added at watch instantiation?
	* @param priorWh depth relative to user-supplied path
	* @param depth Child path actually targeted for watch
	* @param target Child path actually targeted for watch
	*/
	async _addToNodeFs(path, initialAdd, priorWh, depth, target) {
		const ready = this.fsw._emitReady;
		if (this.fsw._isIgnored(path) || this.fsw.closed) {
			ready();
			return false;
		}
		const wh = this.fsw._getWatchHelpers(path);
		if (priorWh) {
			wh.filterPath = (entry) => priorWh.filterPath(entry);
			wh.filterDir = (entry) => priorWh.filterDir(entry);
		}
		try {
			const stats = await statMethods[wh.statMethod](wh.watchPath);
			if (this.fsw.closed) return;
			if (this.fsw._isIgnored(wh.watchPath, stats)) {
				ready();
				return false;
			}
			const follow = this.fsw.options.followSymlinks;
			let closer;
			if (stats.isDirectory()) {
				const absPath = path$1.resolve(path);
				const targetPath = follow ? await realpath(path) : path;
				if (this.fsw.closed) return;
				closer = await this._handleDir(wh.watchPath, stats, initialAdd, depth, target, wh, targetPath);
				if (this.fsw.closed) return;
				if (absPath !== targetPath && targetPath !== void 0) this.fsw._symlinkPaths.set(absPath, targetPath);
			} else if (stats.isSymbolicLink()) {
				const targetPath = follow ? await realpath(path) : path;
				if (this.fsw.closed) return;
				const parent = path$1.dirname(wh.watchPath);
				this.fsw._getWatchedDir(parent).add(wh.watchPath);
				this.fsw._emit(EV.ADD, wh.watchPath, stats);
				closer = await this._handleDir(parent, stats, initialAdd, depth, path, wh, targetPath);
				if (this.fsw.closed) return;
				if (targetPath !== void 0) this.fsw._symlinkPaths.set(path$1.resolve(path), targetPath);
			} else closer = this._handleFile(wh.watchPath, stats, initialAdd);
			ready();
			if (closer) this.fsw._addPathCloser(path, closer);
			return false;
		} catch (error) {
			if (this.fsw._handleError(error)) {
				ready();
				return path;
			}
		}
	}
};
//#endregion
//#region ../../node_modules/.pnpm/chokidar@5.0.0/node_modules/chokidar/index.js
/*! chokidar - MIT License (c) 2012 Paul Miller (paulmillr.com) */
var SLASH = "/";
var SLASH_SLASH = "//";
var ONE_DOT = ".";
var TWO_DOTS = "..";
var STRING_TYPE = "string";
var BACK_SLASH_RE = /\\/g;
var DOUBLE_SLASH_RE = /\/\//g;
var DOT_RE = /\..*\.(sw[px])$|~$|\.subl.*\.tmp/;
var REPLACER_RE = /^\.[/\\]/;
function arrify(item) {
	return Array.isArray(item) ? item : [item];
}
var isMatcherObject = (matcher) => typeof matcher === "object" && matcher !== null && !(matcher instanceof RegExp);
function createPattern(matcher) {
	if (typeof matcher === "function") return matcher;
	if (typeof matcher === "string") return (string) => matcher === string;
	if (matcher instanceof RegExp) return (string) => matcher.test(string);
	if (typeof matcher === "object" && matcher !== null) return (string) => {
		if (matcher.path === string) return true;
		if (matcher.recursive) {
			const relative = path$1.relative(matcher.path, string);
			if (!relative) return false;
			return !relative.startsWith("..") && !path$1.isAbsolute(relative);
		}
		return false;
	};
	return () => false;
}
function normalizePath(path) {
	if (typeof path !== "string") throw new Error("string expected");
	path = path$1.normalize(path);
	path = path.replace(/\\/g, "/");
	let prepend = false;
	if (path.startsWith("//")) prepend = true;
	path = path.replace(DOUBLE_SLASH_RE, "/");
	if (prepend) path = "/" + path;
	return path;
}
function matchPatterns(patterns, testString, stats) {
	const path = normalizePath(testString);
	for (let index = 0; index < patterns.length; index++) {
		const pattern = patterns[index];
		if (pattern(path, stats)) return true;
	}
	return false;
}
function anymatch(matchers, testString) {
	if (matchers == null) throw new TypeError("anymatch: specify first argument");
	const patterns = arrify(matchers).map((matcher) => createPattern(matcher));
	if (testString == null) return (testString, stats) => {
		return matchPatterns(patterns, testString, stats);
	};
	return matchPatterns(patterns, testString);
}
var unifyPaths = (paths_) => {
	const paths = arrify(paths_).flat();
	if (!paths.every((p) => typeof p === STRING_TYPE)) throw new TypeError(`Non-string provided as watch path: ${paths}`);
	return paths.map(normalizePathToUnix);
};
var toUnix = (string) => {
	let str = string.replace(BACK_SLASH_RE, SLASH);
	let prepend = false;
	if (str.startsWith(SLASH_SLASH)) prepend = true;
	str = str.replace(DOUBLE_SLASH_RE, SLASH);
	if (prepend) str = SLASH + str;
	return str;
};
var normalizePathToUnix = (path) => toUnix(path$1.normalize(toUnix(path)));
var normalizeIgnored = (cwd = "") => (path) => {
	if (typeof path === "string") return normalizePathToUnix(path$1.isAbsolute(path) ? path : path$1.join(cwd, path));
	else return path;
};
var getAbsolutePath = (path, cwd) => {
	if (path$1.isAbsolute(path)) return path;
	return path$1.join(cwd, path);
};
var EMPTY_SET = Object.freeze(/* @__PURE__ */ new Set());
/**
* Directory entry.
*/
var DirEntry = class {
	path;
	_removeWatcher;
	items;
	constructor(dir, removeWatcher) {
		this.path = dir;
		this._removeWatcher = removeWatcher;
		this.items = /* @__PURE__ */ new Set();
	}
	add(item) {
		const { items } = this;
		if (!items) return;
		if (item !== ONE_DOT && item !== TWO_DOTS) items.add(item);
	}
	async remove(item) {
		const { items } = this;
		if (!items) return;
		items.delete(item);
		if (items.size > 0) return;
		const dir = this.path;
		try {
			await readdir(dir);
		} catch (err) {
			if (this._removeWatcher) this._removeWatcher(path$1.dirname(dir), path$1.basename(dir));
		}
	}
	has(item) {
		const { items } = this;
		if (!items) return;
		return items.has(item);
	}
	getChildren() {
		const { items } = this;
		if (!items) return [];
		return [...items.values()];
	}
	dispose() {
		this.items.clear();
		this.path = "";
		this._removeWatcher = EMPTY_FN;
		this.items = EMPTY_SET;
		Object.freeze(this);
	}
};
var STAT_METHOD_F = "stat";
var STAT_METHOD_L = "lstat";
var WatchHelper = class {
	fsw;
	path;
	watchPath;
	fullWatchPath;
	dirParts;
	followSymlinks;
	statMethod;
	constructor(path, follow, fsw) {
		this.fsw = fsw;
		const watchPath = path;
		this.path = path = path.replace(REPLACER_RE, "");
		this.watchPath = watchPath;
		this.fullWatchPath = path$1.resolve(watchPath);
		this.dirParts = [];
		this.dirParts.forEach((parts) => {
			if (parts.length > 1) parts.pop();
		});
		this.followSymlinks = follow;
		this.statMethod = follow ? STAT_METHOD_F : STAT_METHOD_L;
	}
	entryPath(entry) {
		return path$1.join(this.watchPath, path$1.relative(this.watchPath, entry.fullPath));
	}
	filterPath(entry) {
		const { stats } = entry;
		if (stats && stats.isSymbolicLink()) return this.filterDir(entry);
		const resolvedPath = this.entryPath(entry);
		return this.fsw._isntIgnored(resolvedPath, stats) && this.fsw._hasReadPermissions(stats);
	}
	filterDir(entry) {
		return this.fsw._isntIgnored(this.entryPath(entry), entry.stats);
	}
};
/**
* Watches files & directories for changes. Emitted events:
* `add`, `addDir`, `change`, `unlink`, `unlinkDir`, `all`, `error`
*
*     new FSWatcher()
*       .add(directories)
*       .on('add', path => log('File', path, 'was added'))
*/
var FSWatcher = class extends EventEmitter {
	closed;
	options;
	_closers;
	_ignoredPaths;
	_throttled;
	_streams;
	_symlinkPaths;
	_watched;
	_pendingWrites;
	_pendingUnlinks;
	_readyCount;
	_emitReady;
	_closePromise;
	_userIgnored;
	_readyEmitted;
	_emitRaw;
	_boundRemove;
	_nodeFsHandler;
	constructor(_opts = {}) {
		super();
		this.closed = false;
		this._closers = /* @__PURE__ */ new Map();
		this._ignoredPaths = /* @__PURE__ */ new Set();
		this._throttled = /* @__PURE__ */ new Map();
		this._streams = /* @__PURE__ */ new Set();
		this._symlinkPaths = /* @__PURE__ */ new Map();
		this._watched = /* @__PURE__ */ new Map();
		this._pendingWrites = /* @__PURE__ */ new Map();
		this._pendingUnlinks = /* @__PURE__ */ new Map();
		this._readyCount = 0;
		this._readyEmitted = false;
		const awf = _opts.awaitWriteFinish;
		const DEF_AWF = {
			stabilityThreshold: 2e3,
			pollInterval: 100
		};
		const opts = {
			persistent: true,
			ignoreInitial: false,
			ignorePermissionErrors: false,
			interval: 100,
			binaryInterval: 300,
			followSymlinks: true,
			usePolling: false,
			atomic: true,
			..._opts,
			ignored: _opts.ignored ? arrify(_opts.ignored) : arrify([]),
			awaitWriteFinish: awf === true ? DEF_AWF : typeof awf === "object" ? {
				...DEF_AWF,
				...awf
			} : false
		};
		if (isIBMi) opts.usePolling = true;
		if (opts.atomic === void 0) opts.atomic = !opts.usePolling;
		const envPoll = process.env.CHOKIDAR_USEPOLLING;
		if (envPoll !== void 0) {
			const envLower = envPoll.toLowerCase();
			if (envLower === "false" || envLower === "0") opts.usePolling = false;
			else if (envLower === "true" || envLower === "1") opts.usePolling = true;
			else opts.usePolling = !!envLower;
		}
		const envInterval = process.env.CHOKIDAR_INTERVAL;
		if (envInterval) opts.interval = Number.parseInt(envInterval, 10);
		let readyCalls = 0;
		this._emitReady = () => {
			readyCalls++;
			if (readyCalls >= this._readyCount) {
				this._emitReady = EMPTY_FN;
				this._readyEmitted = true;
				process.nextTick(() => this.emit(EVENTS.READY));
			}
		};
		this._emitRaw = (...args) => this.emit(EVENTS.RAW, ...args);
		this._boundRemove = this._remove.bind(this);
		this.options = opts;
		this._nodeFsHandler = new NodeFsHandler(this);
		Object.freeze(opts);
	}
	_addIgnoredPath(matcher) {
		if (isMatcherObject(matcher)) {
			for (const ignored of this._ignoredPaths) if (isMatcherObject(ignored) && ignored.path === matcher.path && ignored.recursive === matcher.recursive) return;
		}
		this._ignoredPaths.add(matcher);
	}
	_removeIgnoredPath(matcher) {
		this._ignoredPaths.delete(matcher);
		if (typeof matcher === "string") {
			for (const ignored of this._ignoredPaths) if (isMatcherObject(ignored) && ignored.path === matcher) this._ignoredPaths.delete(ignored);
		}
	}
	/**
	* Adds paths to be watched on an existing FSWatcher instance.
	* @param paths_ file or file list. Other arguments are unused
	*/
	add(paths_, _origAdd, _internal) {
		const { cwd } = this.options;
		this.closed = false;
		this._closePromise = void 0;
		let paths = unifyPaths(paths_);
		if (cwd) paths = paths.map((path) => {
			return getAbsolutePath(path, cwd);
		});
		paths.forEach((path) => {
			this._removeIgnoredPath(path);
		});
		this._userIgnored = void 0;
		if (!this._readyCount) this._readyCount = 0;
		this._readyCount += paths.length;
		Promise.all(paths.map(async (path) => {
			const res = await this._nodeFsHandler._addToNodeFs(path, !_internal, void 0, 0, _origAdd);
			if (res) this._emitReady();
			return res;
		})).then((results) => {
			if (this.closed) return;
			results.forEach((item) => {
				if (item) this.add(path$1.dirname(item), path$1.basename(_origAdd || item));
			});
		});
		return this;
	}
	/**
	* Close watchers or start ignoring events from specified paths.
	*/
	unwatch(paths_) {
		if (this.closed) return this;
		const paths = unifyPaths(paths_);
		const { cwd } = this.options;
		paths.forEach((path) => {
			if (!path$1.isAbsolute(path) && !this._closers.has(path)) {
				if (cwd) path = path$1.join(cwd, path);
				path = path$1.resolve(path);
			}
			this._closePath(path);
			this._addIgnoredPath(path);
			if (this._watched.has(path)) this._addIgnoredPath({
				path,
				recursive: true
			});
			this._userIgnored = void 0;
		});
		return this;
	}
	/**
	* Close watchers and remove all listeners from watched paths.
	*/
	close() {
		if (this._closePromise) return this._closePromise;
		this.closed = true;
		this.removeAllListeners();
		const closers = [];
		this._closers.forEach((closerList) => closerList.forEach((closer) => {
			const promise = closer();
			if (promise instanceof Promise) closers.push(promise);
		}));
		this._streams.forEach((stream) => stream.destroy());
		this._userIgnored = void 0;
		this._readyCount = 0;
		this._readyEmitted = false;
		this._watched.forEach((dirent) => dirent.dispose());
		this._closers.clear();
		this._watched.clear();
		this._streams.clear();
		this._symlinkPaths.clear();
		this._throttled.clear();
		this._closePromise = closers.length ? Promise.all(closers).then(() => void 0) : Promise.resolve();
		return this._closePromise;
	}
	/**
	* Expose list of watched paths
	* @returns for chaining
	*/
	getWatched() {
		const watchList = {};
		this._watched.forEach((entry, dir) => {
			const index = (this.options.cwd ? path$1.relative(this.options.cwd, dir) : dir) || ONE_DOT;
			watchList[index] = entry.getChildren().sort();
		});
		return watchList;
	}
	emitWithAll(event, args) {
		this.emit(event, ...args);
		if (event !== EVENTS.ERROR) this.emit(EVENTS.ALL, event, ...args);
	}
	/**
	* Normalize and emit events.
	* Calling _emit DOES NOT MEAN emit() would be called!
	* @param event Type of event
	* @param path File or directory path
	* @param stats arguments to be passed with event
	* @returns the error if defined, otherwise the value of the FSWatcher instance's `closed` flag
	*/
	async _emit(event, path, stats) {
		if (this.closed) return;
		const opts = this.options;
		if (isWindows) path = path$1.normalize(path);
		if (opts.cwd) path = path$1.relative(opts.cwd, path);
		const args = [path];
		if (stats != null) args.push(stats);
		const awf = opts.awaitWriteFinish;
		let pw;
		if (awf && (pw = this._pendingWrites.get(path))) {
			pw.lastChange = /* @__PURE__ */ new Date();
			return this;
		}
		if (opts.atomic) {
			if (event === EVENTS.UNLINK) {
				this._pendingUnlinks.set(path, [event, ...args]);
				setTimeout(() => {
					this._pendingUnlinks.forEach((entry, path) => {
						this.emit(...entry);
						this.emit(EVENTS.ALL, ...entry);
						this._pendingUnlinks.delete(path);
					});
				}, typeof opts.atomic === "number" ? opts.atomic : 100);
				return this;
			}
			if (event === EVENTS.ADD && this._pendingUnlinks.has(path)) {
				event = EVENTS.CHANGE;
				this._pendingUnlinks.delete(path);
			}
		}
		if (awf && (event === EVENTS.ADD || event === EVENTS.CHANGE) && this._readyEmitted) {
			const awfEmit = (err, stats) => {
				if (err) {
					event = EVENTS.ERROR;
					args[0] = err;
					this.emitWithAll(event, args);
				} else if (stats) {
					if (args.length > 1) args[1] = stats;
					else args.push(stats);
					this.emitWithAll(event, args);
				}
			};
			this._awaitWriteFinish(path, awf.stabilityThreshold, event, awfEmit);
			return this;
		}
		if (event === EVENTS.CHANGE) {
			if (!this._throttle(EVENTS.CHANGE, path, 50)) return this;
		}
		if (opts.alwaysStat && stats === void 0 && (event === EVENTS.ADD || event === EVENTS.ADD_DIR || event === EVENTS.CHANGE)) {
			const fullPath = opts.cwd ? path$1.join(opts.cwd, path) : path;
			let stats;
			try {
				stats = await stat$1(fullPath);
			} catch (err) {}
			if (!stats || this.closed) return;
			args.push(stats);
		}
		this.emitWithAll(event, args);
		return this;
	}
	/**
	* Common handler for errors
	* @returns The error if defined, otherwise the value of the FSWatcher instance's `closed` flag
	*/
	_handleError(error) {
		const code = error && error.code;
		if (error && code !== "ENOENT" && code !== "ENOTDIR" && (!this.options.ignorePermissionErrors || code !== "EPERM" && code !== "EACCES")) this.emit(EVENTS.ERROR, error);
		return error || this.closed;
	}
	/**
	* Helper utility for throttling
	* @param actionType type being throttled
	* @param path being acted upon
	* @param timeout duration of time to suppress duplicate actions
	* @returns tracking object or false if action should be suppressed
	*/
	_throttle(actionType, path, timeout) {
		if (!this._throttled.has(actionType)) this._throttled.set(actionType, /* @__PURE__ */ new Map());
		const action = this._throttled.get(actionType);
		if (!action) throw new Error("invalid throttle");
		const actionPath = action.get(path);
		if (actionPath) {
			actionPath.count++;
			return false;
		}
		let timeoutObject;
		const clear = () => {
			const item = action.get(path);
			const count = item ? item.count : 0;
			action.delete(path);
			clearTimeout(timeoutObject);
			if (item) clearTimeout(item.timeoutObject);
			return count;
		};
		timeoutObject = setTimeout(clear, timeout);
		const thr = {
			timeoutObject,
			clear,
			count: 0
		};
		action.set(path, thr);
		return thr;
	}
	_incrReadyCount() {
		return this._readyCount++;
	}
	/**
	* Awaits write operation to finish.
	* Polls a newly created file for size variations. When files size does not change for 'threshold' milliseconds calls callback.
	* @param path being acted upon
	* @param threshold Time in milliseconds a file size must be fixed before acknowledging write OP is finished
	* @param event
	* @param awfEmit Callback to be called when ready for event to be emitted.
	*/
	_awaitWriteFinish(path, threshold, event, awfEmit) {
		const awf = this.options.awaitWriteFinish;
		if (typeof awf !== "object") return;
		const pollInterval = awf.pollInterval;
		let timeoutHandler;
		let fullPath = path;
		if (this.options.cwd && !path$1.isAbsolute(path)) fullPath = path$1.join(this.options.cwd, path);
		const now = /* @__PURE__ */ new Date();
		const writes = this._pendingWrites;
		function awaitWriteFinishFn(prevStat) {
			stat(fullPath, (err, curStat) => {
				if (err || !writes.has(path)) {
					if (err && err.code !== "ENOENT") awfEmit(err);
					return;
				}
				const now = Number(/* @__PURE__ */ new Date());
				if (prevStat && curStat.size !== prevStat.size) writes.get(path).lastChange = now;
				if (now - writes.get(path).lastChange >= threshold) {
					writes.delete(path);
					awfEmit(void 0, curStat);
				} else timeoutHandler = setTimeout(awaitWriteFinishFn, pollInterval, curStat);
			});
		}
		if (!writes.has(path)) {
			writes.set(path, {
				lastChange: now,
				cancelWait: () => {
					writes.delete(path);
					clearTimeout(timeoutHandler);
					return event;
				}
			});
			timeoutHandler = setTimeout(awaitWriteFinishFn, pollInterval);
		}
	}
	/**
	* Determines whether user has asked to ignore this path.
	*/
	_isIgnored(path, stats) {
		if (this.options.atomic && DOT_RE.test(path)) return true;
		if (!this._userIgnored) {
			const { cwd } = this.options;
			const ignored = (this.options.ignored || []).map(normalizeIgnored(cwd));
			const list = [...[...this._ignoredPaths].map(normalizeIgnored(cwd)), ...ignored];
			this._userIgnored = anymatch(list, void 0);
		}
		return this._userIgnored(path, stats);
	}
	_isntIgnored(path, stat) {
		return !this._isIgnored(path, stat);
	}
	/**
	* Provides a set of common helpers and properties relating to symlink handling.
	* @param path file or directory pattern being watched
	*/
	_getWatchHelpers(path) {
		return new WatchHelper(path, this.options.followSymlinks, this);
	}
	/**
	* Provides directory tracking objects
	* @param directory path of the directory
	*/
	_getWatchedDir(directory) {
		const dir = path$1.resolve(directory);
		if (!this._watched.has(dir)) this._watched.set(dir, new DirEntry(dir, this._boundRemove));
		return this._watched.get(dir);
	}
	/**
	* Check for read permissions: https://stackoverflow.com/a/11781404/1358405
	*/
	_hasReadPermissions(stats) {
		if (this.options.ignorePermissionErrors) return true;
		return Boolean(Number(stats.mode) & 256);
	}
	/**
	* Handles emitting unlink events for
	* files and directories, and via recursion, for
	* files and directories within directories that are unlinked
	* @param directory within which the following item is located
	* @param item      base path of item/directory
	*/
	_remove(directory, item, isDirectory) {
		const path = path$1.join(directory, item);
		const fullPath = path$1.resolve(path);
		isDirectory = isDirectory != null ? isDirectory : this._watched.has(path) || this._watched.has(fullPath);
		if (!this._throttle("remove", path, 100)) return;
		if (!isDirectory && this._watched.size === 1) this.add(directory, item, true);
		this._getWatchedDir(path).getChildren().forEach((nested) => this._remove(path, nested));
		const parent = this._getWatchedDir(directory);
		const wasTracked = parent.has(item);
		parent.remove(item);
		if (this._symlinkPaths.has(fullPath)) this._symlinkPaths.delete(fullPath);
		let relPath = path;
		if (this.options.cwd) relPath = path$1.relative(this.options.cwd, path);
		if (this.options.awaitWriteFinish && this._pendingWrites.has(relPath)) {
			if (this._pendingWrites.get(relPath).cancelWait() === EVENTS.ADD) return;
		}
		this._watched.delete(path);
		this._watched.delete(fullPath);
		const eventName = isDirectory ? EVENTS.UNLINK_DIR : EVENTS.UNLINK;
		if (wasTracked && !this._isIgnored(path)) this._emit(eventName, path);
		this._closePath(path);
	}
	/**
	* Closes all watchers for a path
	*/
	_closePath(path) {
		this._closeFile(path);
		const dir = path$1.dirname(path);
		this._getWatchedDir(dir).remove(path$1.basename(path));
	}
	/**
	* Closes only file-specific watchers
	*/
	_closeFile(path) {
		const closers = this._closers.get(path);
		if (!closers) return;
		closers.forEach((closer) => closer());
		this._closers.delete(path);
	}
	_addPathCloser(path, closer) {
		if (!closer) return;
		let list = this._closers.get(path);
		if (!list) {
			list = [];
			this._closers.set(path, list);
		}
		list.push(closer);
	}
	_readdirp(root, opts) {
		if (this.closed) return;
		let stream = readdirp(root, {
			type: EVENTS.ALL,
			alwaysStat: true,
			lstat: true,
			...opts,
			depth: 0
		});
		this._streams.add(stream);
		stream.once(STR_CLOSE, () => {
			stream = void 0;
		});
		stream.once("end", () => {
			if (stream) {
				this._streams.delete(stream);
				stream = void 0;
			}
		});
		return stream;
	}
};
/**
* Instantiates watcher with paths to be tracked.
* @param paths file / directory paths
* @param options opts, such as `atomic`, `awaitWriteFinish`, `ignored`, and others
* @returns an instance of FSWatcher for chaining.
* @example
* const watcher = watch('.').on('all', (event, path) => { console.log(event, path); });
* watch('.', { atomic: true, awaitWriteFinish: true, ignored: (f, stats) => stats?.isFile() && !f.endsWith('.js') })
*/
function watch$1(paths, options = {}) {
	const watcher = new FSWatcher(options);
	watcher.add(paths);
	return watcher;
}
var chokidar_default = {
	watch: watch$1,
	FSWatcher
};
//#endregion
//#region ../douzed/src/registry.ts
/**
* #RecipeRegistry — owns the only mutable shared state in the runtime. Loads enabled recipes,
* validates them, watches the directory, and keeps the last valid version of a recipe whose
* reload failed (AC-RUN-002.3).
*/
var RecipeRegistry = class extends EventEmitter {
	dir;
	fixturesDir;
	/** Last successfully-loaded version per file, so a bad edit cannot take a recipe down. */
	loaded = /* @__PURE__ */ new Map();
	errors = /* @__PURE__ */ new Map();
	/** Fixture validity keyed by path, invalidated by mtime+size. */
	fixtureCache = /* @__PURE__ */ new Map();
	watcher;
	revision = 0;
	constructor(dir, fixturesDir) {
		super();
		this.dir = dir;
		this.fixturesDir = fixturesDir;
	}
	/**
	* Resolves once the watcher is live. On macOS, fsevents delivers nothing for the window
	* between `watch()` and 'ready', so a recipe written in that gap was simply never seen —
	* invisible until some later edit happened to touch the directory again. Awaiting 'ready'
	* closes the window, and the second load picks up whatever landed while it was open.
	*/
	async start() {
		this.loadAll();
		this.watcher = chokidar_default.watch(this.dir, {
			ignoreInitial: true,
			awaitWriteFinish: {
				stabilityThreshold: 250,
				pollInterval: 50
			}
		});
		for (const event of [
			"add",
			"change",
			"unlink"
		]) this.watcher.on(event, (path) => {
			if (!path.endsWith(".yaml") && !path.endsWith(".yml")) return;
			this.loadAll();
		});
		await once(this.watcher, "ready");
		this.loadAll();
	}
	async stop() {
		await this.watcher?.close();
	}
	loadAll() {
		if (!existsSync(this.dir)) return;
		const files = readdirSync(this.dir).filter((f) => f.endsWith(".yaml") || f.endsWith(".yml"));
		const before = JSON.stringify(this.state().tools);
		for (const known of [...this.loaded.keys()]) if (!files.includes(known)) this.loaded.delete(known);
		for (const known of [...this.errors.keys()]) if (!files.includes(known)) this.errors.delete(known);
		for (const file of files) {
			const result = parseRecipe(readFileSync(join(this.dir, file), "utf8"), file);
			if (result.ok && result.recipe) {
				this.loaded.set(file, result.recipe);
				this.errors.delete(file);
				if (result.migrated?.length) this.emit("migrated", {
					recipe: result.recipe.name,
					fields: result.migrated
				});
			} else this.errors.set(file, result.error ?? "unknown error");
		}
		if (JSON.stringify(this.state().tools) !== before) {
			this.revision += 1;
			this.emit("changed", this.state());
		}
	}
	state() {
		const tools = [];
		for (const recipe of this.loaded.values()) {
			if (!recipe.enabled) continue;
			for (const tool of recipe.tools) {
				if (!tool.approved) continue;
				const fixtureIssue = this.validateFixtures(tool);
				const reason = tool.flags.degraded_reason ?? fixtureIssue ?? void 0;
				tools.push({
					qualified_name: `${recipe.name}_${tool.name}`,
					recipe: recipe.name,
					base_url: recipe.target.base_url,
					tool,
					credential_source: recipe.auth.credential_source,
					degraded: tool.flags.degraded || fixtureIssue !== null,
					...reason === void 0 ? {} : { degraded_reason: reason }
				});
			}
		}
		return {
			tools,
			errors: [...this.errors.entries()].map(([recipe, error]) => ({
				recipe,
				error
			})),
			revision: this.revision
		};
	}
	/** All recipes including disabled ones — `doctor` needs these (AC-RUN-001.4). */
	recipes() {
		return [...this.loaded.values()];
	}
	recipe(name) {
		return this.recipes().find((r) => r.name === name) ?? null;
	}
	/**
	* A recipe's `name` need not match its filename, so anything writing a recipe back must ask
	* where it came from — otherwise it creates a second file defining the same recipe name.
	*/
	fileFor(recipeName) {
		for (const [file, recipe] of this.loaded) if (recipe.name === recipeName) return file;
		return null;
	}
	/**
	* AC-RUN-001.5 — a fixture that no longer matches its tool's declared schema degrades the
	* tool rather than removing it, and the failing fixture is named.
	*
	* Cached by (file, mtime, size): `state()` runs on every `/registry` request AND every relay
	* call, and re-reading every fixture from disk each time is real latency against the <150ms
	* per-call target. The mtime key means an edited fixture is still picked up immediately.
	*/
	validateFixtures(tool) {
		for (const fixture of tool.fixtures) {
			const path = join(this.fixturesDir, fixture);
			let stamp;
			try {
				const stats = statSync(path);
				stamp = `${stats.mtimeMs}:${stats.size}`;
			} catch {
				return `fixture "${fixture}" is missing`;
			}
			const cached = this.fixtureCache.get(path);
			if (cached?.stamp === stamp) {
				if (cached.error) return cached.error;
				continue;
			}
			let error = null;
			try {
				JSON.parse(readFileSync(path, "utf8"));
			} catch {
				error = `fixture "${fixture}" is not valid JSON`;
			}
			this.fixtureCache.set(path, {
				stamp,
				error
			});
			if (error) return error;
		}
		return null;
	}
};
//#endregion
//#region ../douzed/src/relay.ts
/**
* #RelayBridge — holds the extension WebSocket, correlates requests to responses, and enforces
* every call guard *before* forwarding. Guards live here rather than in client code so they
* cannot be bypassed by calling douzed directly or from an ejected package.
*/
var RelayBridge = class {
	auditPath;
	socket = null;
	heartbeat;
	pending = /* @__PURE__ */ new Map();
	/** AC-EXE-003.1 — per-tool call timestamps driving the rate limiter. */
	calls = /* @__PURE__ */ new Map();
	/** Serialises queued calls per tool so excess is delayed rather than dropped. */
	queues = /* @__PURE__ */ new Map();
	constructor(auditPath) {
		this.auditPath = auditPath;
	}
	attach(socket) {
		this.socket?.close();
		this.socket = socket;
		clearInterval(this.heartbeat);
		this.heartbeat = setInterval(() => this.send({ type: "ping" }), HEARTBEAT_MS);
		socket.on("close", () => {
			if (this.socket !== socket) return;
			this.socket = null;
			clearInterval(this.heartbeat);
			this.failPending(new DouzeError("extension_disconnected", "The Douze Chrome extension disconnected while this call was in flight. Open Chrome and confirm the Douze extension is enabled, then retry."));
		});
	}
	get connected() {
		return this.socket !== null && this.socket.readyState === 1;
	}
	/** Called by the WS layer when the extension answers a relay.request. */
	settle(response) {
		const entry = this.pending.get(response.id);
		if (!entry) return;
		clearTimeout(entry.timer);
		this.pending.delete(response.id);
		entry.resolve(response);
	}
	failPending(error) {
		for (const [id, entry] of this.pending) {
			clearTimeout(entry.timer);
			this.pending.delete(id);
			entry.reject(error);
		}
	}
	send(message) {
		if (this.socket?.readyState === 1) this.socket.send(JSON.stringify(message));
	}
	/**
	* The single entry point for a tool call. Runs guards, queues under the rate limit, relays,
	* classifies the outcome, and writes an audit entry — in that order.
	*/
	async call(surface, args, options = {}) {
		const started = Date.now();
		const label = surface.qualified_name;
		try {
			this.guard(surface, args);
			const response = await this.enqueue(surface, () => this.dispatch(surface, args, options));
			this.classify(surface, response);
			this.audit(label, args, response.status ?? 0, Date.now() - started);
			return response;
		} catch (error) {
			this.audit(label, args, -1, Date.now() - started, error.message);
			throw error;
		}
	}
	/** Guards that must fire before any network request is issued (AC-EXE-003.2 and .4). */
	guard(surface, args) {
		if (surface.degraded) throw new DouzeError("tool_degraded", `"${surface.qualified_name}" stopped working because ${siteOf(surface.base_url)} changed how it works. Douze did not run it. To fix it, open the site in Chrome, click the Douze button, and record it again.`, {
			tool: surface.qualified_name,
			change: surface.degraded_reason,
			fix: `douze doctor ${surface.recipe}`
		});
		if (surface.tool.side_effect === "destructive" && args["confirm"] !== true) throw new DouzeError("confirm_required", `Tool "${surface.qualified_name}" performs a destructive action. Re-run it with confirm=true to proceed.`, { tool: surface.qualified_name });
		if (!this.connected) throw new DouzeError("extension_disconnected", `The Douze Chrome extension is not connected, so "${surface.qualified_name}" cannot run against ${surface.base_url}. Open Chrome and confirm the Douze extension is enabled.`, {
			tool: surface.qualified_name,
			target: surface.base_url
		});
	}
	/**
	* AC-EXE-003.1 — excess calls queue rather than drop. Each tool has its own chain, so a
	* throttled tool never blocks another.
	*/
	enqueue(surface, run) {
		const limit = surface.tool.rate_limit_per_minute;
		if (!limit) return run();
		const key = surface.qualified_name;
		const chained = (this.queues.get(key) ?? Promise.resolve()).then(async () => {
			const now = Date.now();
			const recent = (this.calls.get(key) ?? []).filter((t) => now - t < 6e4);
			if (recent.length >= limit) {
				const wait = 6e4 - (now - recent[0]);
				await new Promise((r) => setTimeout(r, wait));
			}
			this.calls.set(key, [...(this.calls.get(key) ?? []).filter((t) => Date.now() - t < 6e4), Date.now()]);
			return run();
		});
		this.queues.set(key, chained.catch(() => void 0));
		return chained;
	}
	/** AC-EXE-001.2 — forward to the extension and wait for the correlated response. */
	dispatch(surface, args, options) {
		if (!this.connected) return Promise.reject(new DouzeError("extension_disconnected", `The Douze Chrome extension is not connected, so "${surface.qualified_name}" cannot run against ${surface.base_url}. Open Chrome and confirm the Douze extension is enabled.`, {
			tool: surface.qualified_name,
			target: surface.base_url
		}));
		const request = buildRequest(surface, args, options.timeout_ms);
		return new Promise((resolve, reject) => {
			const timer = setTimeout(() => {
				this.pending.delete(request.id);
				reject(new DouzeError("timeout", `Tool "${surface.qualified_name}" did not return within ${humanDuration(request.timeout_ms)}.`, {
					tool: surface.qualified_name,
					elapsed_ms: request.timeout_ms
				}));
			}, request.timeout_ms);
			this.pending.set(request.id, {
				resolve,
				reject,
				timer
			});
			this.send({
				type: "relay.request",
				request
			});
		});
	}
	/** AC-EXE-002.1 — 401, 403, or a login redirect all mean the same thing to the user. */
	classify(surface, response) {
		if (!(response.status === 401 || response.status === 403 || response.redirected_to_login)) return;
		throw new DouzeError("session_expired", `You have been signed out of ${siteOf(surface.base_url)}. Sign in again in Chrome, then retry.`, {
			tool: surface.qualified_name,
			target: surface.base_url
		});
	}
	/**
	* AC-EXE-003.3 — every invocation leaves a redacted trace. TR-6 names logs explicitly, so the
	* same shape gate applied to fixtures runs here: an agent that pastes a key into a free-text
	* argument must not have it land in the audit log under a harmless name.
	*/
	audit(tool, args, status, duration, error) {
		const params = redactBody(args);
		const leaked = findSurvivingSecrets(params);
		const safe = leaked.length === 0 ? params : { redacted: `${leaked.length} credential-shaped argument(s) withheld` };
		const entry = {
			at: (/* @__PURE__ */ new Date()).toISOString(),
			tool,
			params: safe,
			status,
			duration_ms: duration,
			error
		};
		try {
			appendFileSync(this.auditPath, `${JSON.stringify(entry)}\n`);
		} catch {}
	}
};
/**
* The site as the reader knows it. A scheme is our plumbing, not part of the name anyone would
* say out loud; the port stays, because for a local app it is genuinely part of the address.
*/
var siteOf = (url) => {
	try {
		return new URL(url).host;
	} catch {
		return url;
	}
};
/** "120000ms" is a number the reader has to convert; this is the same fact in their units. */
var humanDuration = (ms) => {
	if (ms < 6e4) {
		const seconds = Math.round(ms / 1e3);
		return seconds === 1 ? "1 second" : `${seconds} seconds`;
	}
	const minutes = Math.round(ms / 6e4);
	return minutes === 1 ? "1 minute" : `${minutes} minutes`;
};
/**
* Turns validated tool arguments into a concrete request: path params are substituted into the
* Endpoint Template, the rest become a query string or a JSON body depending on the method.
*/
function buildRequest(surface, args, timeout_ms = 12e4) {
	const { method, path, headers, graphql } = surface.tool.request;
	const remaining = { ...args };
	delete remaining["confirm"];
	delete remaining["raw"];
	const resolvedPath = path.replace(/\{(\w+)\}/g, (_, name) => {
		const value = remaining[name];
		delete remaining[name];
		return encodeURIComponent(String(value ?? ""));
	});
	const url = new URL(resolvedPath, surface.base_url);
	let body;
	if (graphql) body = {
		operationName: graphql.operation,
		query: graphql.document,
		variables: remaining
	};
	else if (method === "GET" || method === "HEAD") {
		for (const [key, value] of Object.entries(remaining)) if (value !== void 0 && value !== null) url.searchParams.set(key, String(value));
	} else body = remaining;
	return {
		id: randomUUID(),
		origin: new URL(surface.base_url).origin,
		url: url.toString(),
		method,
		headers: {
			...headers,
			...body === void 0 ? {} : { "content-type": "application/json" }
		},
		...body === void 0 ? {} : { body },
		credential_source: surface.credential_source ?? [],
		timeout_ms
	};
}
//#endregion
//#region ../douzed/src/paths.ts
/**
* TR-3 — everything Douze persists lives under one directory the user owns.
* DOUZE_HOME lets the E2E suite run against a scratch root without touching a real install.
*/
var douzeHome = () => process.env["DOUZE_HOME"] ?? join(homedir(), ".douze");
var paths = () => {
	const home = douzeHome();
	return {
		home,
		recipes: join(home, "recipes"),
		fixtures: join(home, "fixtures"),
		captures: join(home, "captures.db"),
		audit: join(home, "audit.jsonl"),
		runtime: join(home, "douzed.json"),
		token: join(home, "token"),
		extension: join(home, "extension")
	};
};
function ensureHome() {
	const p = paths();
	for (const dir of [
		p.home,
		p.recipes,
		p.fixtures
	]) mkdirSync(dir, { recursive: true });
	return p;
}
/**
* AC-EXE-001.1 / AC-CON-001.2 — one token per install, generated on first run. Every loopback
* request carries it, so another local process cannot drive the relay.
*/
function installToken() {
	const p = ensureHome();
	if (existsSync(p.token)) return readFileSync(p.token, "utf8").trim();
	const token = randomBytes(24).toString("base64url");
	writeFileSync(p.token, token, { mode: 384 });
	return token;
}
/** A Chrome extension id: 32 letters, a–p. Both an unpacked and a Web Store id look like this. */
var EXTENSION_ID = /^[a-p]{32}$/;
/** The id inside a `chrome-extension://…` origin, or null when that is not what this is. */
var extensionIdOf = (origin) => {
	const id = origin.startsWith("chrome-extension://") ? origin.slice(19) : "";
	return EXTENSION_ID.test(id) ? id : null;
};
/**
* Trust on first use — which extension may hold the install token.
*
* The Origin check on /pair keeps web pages out, but every other Chrome extension the user has
* installed can send `Origin: chrome-extension://…` too, and one with loopback host access would
* then hold a token that drives the relay on every site the user approved. Douze has no Web Store
* id yet, so an allowlist is not available: the first extension to pair owns this install.
*
* A pin file that is not a well-formed id — a truncated write, a hand edit — counts as no pin.
* Refusing everything would lock the user out of their own daemon over a file nobody knew existed.
*
* DOUZE_EXTENSION_ID forces the answer and is never written back: an unpacked extension's id
* changes with its path, so the e2e suite and anyone reloading a local build need to say which.
*/
function pinnedExtension() {
	const forced = process.env["DOUZE_EXTENSION_ID"];
	if (forced) return forced;
	try {
		const pinned = readFileSync(paths().extension, "utf8").trim();
		return EXTENSION_ID.test(pinned) ? pinned : null;
	} catch {
		return null;
	}
}
/** Called only once pairing has actually succeeded, so a refused attempt never claims the pin. */
function pinExtension(id) {
	writeFileSync(ensureHome().extension, id, { mode: 384 });
}
var readRuntime = () => {
	try {
		return JSON.parse(readFileSync(paths().runtime, "utf8"));
	} catch {
		return null;
	}
};
var writeRuntime = (info) => {
	writeFileSync(ensureHome().runtime, JSON.stringify(info));
};
/** AC-RUN-003.2 — a stale runtime file must not be mistaken for a live daemon. */
function isAlive(info) {
	if (!info) return false;
	try {
		process.kill(info.pid, 0);
		return true;
	} catch {
		return false;
	}
}
//#endregion
//#region ../douzed/src/har-import.ts
var headerMap = (headers = []) => Object.fromEntries(headers.map((h) => [h.name.toLowerCase(), h.value]));
var parseMaybeJson = (text) => {
	if (text === void 0 || text === "") return void 0;
	try {
		return JSON.parse(text);
	} catch {
		return text;
	}
};
/**
* REQ-CAP-006 — a HAR becomes a Capture Session under exactly the same filtering and redaction
* as live capture, so the two paths cannot produce different recipes from the same traffic.
* Redaction itself is applied by CaptureStore.appendExchange (AC-CAP-006.1).
*/
function importHar(store, har, name) {
	const entries = har?.log?.entries ?? [];
	if (entries.length === 0) throw new Error("HAR contains no entries");
	/**
	* The primary origin is whichever produced the most *inferable* requests. Counting raw entries
	* instead would hand the title to a CDN: a HAR with 100 images from cdn.app.com and 20 JSON
	* calls to app.com would pick the CDN and import nothing.
	*/
	const counts = /* @__PURE__ */ new Map();
	for (const entry of entries) {
		let origin;
		try {
			origin = new URL(entry.request.url).origin;
		} catch {
			continue;
		}
		if (isNoiseHost(entry.request.url)) continue;
		if (!isInferableContentType(entry.response.content?.mimeType)) continue;
		counts.set(origin, (counts.get(origin) ?? 0) + 1);
	}
	const primary = [...counts.entries()].sort((a, b) => b[1] - a[1])[0]?.[0];
	if (!primary) throw new Error("HAR contains no importable JSON exchanges");
	const session = store.startSession({
		name,
		origins: [primary]
	});
	let imported = 0;
	let skipped = 0;
	for (const entry of entries) {
		let origin;
		try {
			origin = new URL(entry.request.url).origin;
		} catch {
			skipped += 1;
			continue;
		}
		const contentType = entry.response.content?.mimeType;
		if (!shouldCapture({
			url: entry.request.url,
			origin,
			response_content_type: contentType
		}, [primary])) {
			skipped += 1;
			continue;
		}
		const text = entry.response.content?.text;
		const missing = text === void 0 || text === "" || entry.response.content?.encoding === "base64";
		const exchange = {
			id: randomUUID(),
			session_id: session.id,
			position: store.nextPosition(session.id),
			started_at: Date.parse(entry.startedDateTime ?? "") || Date.now(),
			duration_ms: entry.time ?? 0,
			method: entry.request.method,
			url: entry.request.url,
			origin,
			request_headers: headerMap(entry.request.headers),
			request_body: parseMaybeJson(entry.request.postData?.text),
			status: entry.response.status,
			response_headers: headerMap(entry.response.headers),
			response_body: missing ? void 0 : parseMaybeJson(text),
			response_content_type: contentType ?? "application/json",
			response_size: entry.response.content?.size ?? 0,
			body_missing: missing,
			...missing ? { body_missing_reason: "har_no_content" } : {},
			background: false,
			source: "har"
		};
		store.appendExchange(exchange);
		imported += 1;
	}
	store.stopSession(session.id);
	return {
		session_id: session.id,
		imported,
		skipped
	};
}
//#endregion
//#region ../douzed/src/doctor.ts
var run$1 = promisify(execFile);
/** Infrastructure failed, so this run learned nothing about the target's contract. */
var TransientDriftError = class extends Error {};
/**
* #DriftWatcher — replays read-only fixtures against the live target, classifies the outcome,
* and writes degradation into the recipe so it propagates to every client through the same
* hot-reload path as any other edit (AC-DRF-002.1). It has no client-facing mechanism of its own.
*/
var DriftWatcher = class {
	registry;
	bridge;
	recipesDir;
	fixturesDir;
	options;
	timer;
	constructor(registry, bridge, recipesDir, fixturesDir, options = {}) {
		this.registry = registry;
		this.bridge = bridge;
		this.recipesDir = recipesDir;
		this.fixturesDir = fixturesDir;
		this.options = options;
	}
	/** AC-DRF-001.3 — runs on a schedule and skips silently when the relay is unavailable. */
	schedule() {
		const interval = this.options.intervalMs ?? 360 * 60 * 1e3;
		this.timer = setInterval(() => {
			if (!this.bridge.connected) return;
			for (const recipe of this.registry.recipes()) this.run(recipe.name).catch(() => void 0);
		}, interval);
		this.timer.unref?.();
	}
	stop() {
		clearInterval(this.timer);
	}
	async run(recipeName) {
		const recipe = this.registry.recipe(recipeName);
		if (!recipe) throw new Error(`no recipe "${recipeName}"`);
		const reports = [];
		let mutated = false;
		for (const tool of recipe.tools) {
			if (!tool.approved) continue;
			if (tool.side_effect !== "read") continue;
			let report;
			try {
				report = await this.replay(recipe, tool);
			} catch (error) {
				if (error instanceof TransientDriftError) throw new Error(`doctor run for "${recipe.name}" abandoned: ${error.message}`);
				throw error;
			}
			reports.push(report);
			if (report.status === "breaking" || report.status === "gone") {
				tool.flags.degraded = true;
				tool.flags.degraded_reason = report.detail ?? report.status;
				mutated = true;
			} else if (report.status === "ok" && tool.flags.degraded) {
				tool.flags.degraded = false;
				delete tool.flags.degraded_reason;
				mutated = true;
			} else if (report.status === "schema_widened" && report.added_fields?.length) {
				widenSchema(tool, report.added_fields);
				mutated = true;
			}
		}
		if (mutated) {
			const file = this.registry.fileFor(recipe.name) ?? `${recipe.name}.yaml`;
			writeFileSync(join(this.recipesDir, file), serializeRecipe(Recipe.parse(recipe)));
			await this.commitPatch(file);
		}
		const report = {
			recipe: recipe.name,
			at: (/* @__PURE__ */ new Date()).toISOString(),
			tools: reports,
			patched: mutated
		};
		if (reports.some((r) => r.status === "breaking" || r.status === "gone")) await this.notify(report);
		return report;
	}
	async replay(recipe, tool) {
		const fixture = this.loadFixture(tool);
		if (!fixture) return {
			tool: tool.name,
			status: "gone",
			detail: "no fixture stored to replay"
		};
		const surface = {
			qualified_name: `${recipe.name}_${tool.name}`,
			recipe: recipe.name,
			base_url: recipe.target.base_url,
			tool,
			credential_source: recipe.auth.credential_source,
			degraded: false
		};
		let live;
		try {
			const response = await this.bridge.call(surface, fixture.args ?? {});
			if (response.status === 404 || response.status === 410) return {
				tool: tool.name,
				status: "gone",
				detail: `target returned ${response.status}`
			};
			live = response.body;
		} catch (error) {
			if (error instanceof DouzeError) {
				if (error.code === "session_expired") return {
					tool: tool.name,
					status: "session_expired",
					detail: error.message
				};
				throw new TransientDriftError(error.message);
			}
			return {
				tool: tool.name,
				status: "breaking",
				detail: error.message
			};
		}
		return compare(tool.name, fixture.response, live);
	}
	loadFixture(tool) {
		const name = tool.fixtures[0];
		if (!name) return null;
		const path = join(this.fixturesDir, name);
		if (!existsSync(path)) return null;
		try {
			const raw = JSON.parse(readFileSync(path, "utf8"));
			return "response" in raw ? raw : { response: raw };
		} catch {
			return null;
		}
	}
	/**
	* AC-DRF-003.2 — *offer* to commit. Opt-in only: a background drift run must never move the
	* user's HEAD onto a branch, sweep up their staged work, or race another run in the same repo.
	* When enabled, the original branch is restored and only the recipe file is committed.
	*/
	async commitPatch(file) {
		if (!this.options.commitPatches) return;
		try {
			await run$1("git", ["rev-parse", "--is-inside-work-tree"], { cwd: this.recipesDir });
		} catch {
			return;
		}
		let original;
		try {
			original = (await run$1("git", [
				"rev-parse",
				"--abbrev-ref",
				"HEAD"
			], { cwd: this.recipesDir })).stdout.trim();
		} catch {
			return;
		}
		const branch = `douze/drift-${file.replace(/\.ya?ml$/, "")}`;
		try {
			await run$1("git", [
				"checkout",
				"-B",
				branch
			], { cwd: this.recipesDir });
			await run$1("git", [
				"commit",
				"-m",
				`douze: drift patch for ${file}`,
				"--",
				file
			], { cwd: this.recipesDir });
		} catch {} finally {
			await run$1("git", ["checkout", original], { cwd: this.recipesDir }).catch(() => void 0);
		}
	}
	async notify(report) {
		if (!this.options.webhook) return;
		try {
			await fetch(this.options.webhook, {
				method: "POST",
				headers: { "content-type": "application/json" },
				body: JSON.stringify(report)
			});
		} catch {}
	}
};
/**
* AC-DRF-001.2 — the five-way classification. A field that appeared is a widening; a field that
* vanished or changed type is breaking.
*/
function compare(toolName, expected, live) {
	const missing = [];
	const added = [];
	const retyped = [];
	walk$1(expected, live, "$", missing, added, retyped);
	if (missing.length > 0 || retyped.length > 0) return {
		tool: toolName,
		status: "breaking",
		detail: [missing.length ? `missing ${missing.join(", ")}` : "", retyped.length ? `type changed at ${retyped.join(", ")}` : ""].filter(Boolean).join("; ")
	};
	if (added.length > 0) return {
		tool: toolName,
		status: "schema_widened",
		detail: `new optional ${added.join(", ")}`,
		added_fields: added
	};
	return {
		tool: toolName,
		status: "ok"
	};
}
function walk$1(expected, live, path, missing, added, retyped) {
	if (Array.isArray(expected)) {
		if (!Array.isArray(live)) {
			retyped.push(path);
			return;
		}
		if (expected.length > 0 && live.length > 0) walk$1(expected[0], live[0], `${path}[]`, missing, added, retyped);
		return;
	}
	if (expected !== null && typeof expected === "object") {
		if (live === null || typeof live !== "object" || Array.isArray(live)) {
			retyped.push(path);
			return;
		}
		const liveRecord = live;
		for (const [key, value] of Object.entries(expected)) {
			if (!(key in liveRecord)) {
				missing.push(`${path}.${key}`);
				continue;
			}
			walk$1(value, liveRecord[key], `${path}.${key}`, missing, added, retyped);
		}
		for (const key of Object.keys(liveRecord)) if (!(key in expected)) added.push(`${path}.${key}`);
		return;
	}
	if (expected === null || live === null) {
		if (expected !== live) retyped.push(path);
		return;
	}
	if (typeof expected !== typeof live) retyped.push(path);
}
/**
* AC-DRF-003.1 — adds newly-observed fields as OPTIONAL and changes nothing else. The field
* paths are JSONPaths like `$.data.orders[].priority`, so the property must be inserted at that
* depth; putting the leaf at the root would describe a response the target never sends.
*/
function widenSchema(tool, fields) {
	const root = tool.response.output_schema ?? {};
	for (const field of fields) {
		const segments = field.split(".").slice(1);
		const leaf = segments.pop();
		if (!leaf) continue;
		let node = root;
		for (const segment of segments) {
			const isArray = segment.endsWith("[]");
			const key = isArray ? segment.slice(0, -2) : segment;
			node["type"] ??= "object";
			const properties = node["properties"] ??= {};
			const child = properties[key] ??= {};
			if (isArray) {
				child["type"] = "array";
				node = child["items"] ??= {};
			} else node = child;
		}
		node["type"] ??= "object";
		const properties = node["properties"] ??= {};
		if (!(leaf in properties)) properties[leaf] = { type: "string" };
	}
	root["type"] ??= "object";
	tool.response.output_schema = root;
}
//#endregion
//#region ../douzed/src/server.ts
/** Reported to the extension by /pair so it can tell a stale daemon from a current one. */
var DOUZED_VERSION = "0.1.0";
/**
* douzed — the only always-on Douze process (TR-5, AC-RUN-003.1). It holds the extension
* WebSocket, the recipe registry, the capture store, and the review UI.
*
* ADR-006 still holds: @douze/studio — inference, model calls, the review page — is never
* statically imported here. The review routes `await import()` it, so an ordinary relay call
* never loads the inference engine.
*/
async function startDaemon(options = {}) {
	const paths = ensureHome();
	const existing = readRuntime();
	if (isAlive(existing)) throw new Error(`douzed is already running (pid ${existing.pid}, port ${existing.port})`);
	const token = installToken();
	const store = new CaptureStore(paths.captures);
	const registry = new RecipeRegistry(paths.recipes, paths.fixtures);
	const bridge = new RelayBridge(paths.audit);
	const drift = new DriftWatcher(registry, bridge, paths.recipes, paths.fixtures, { ...process.env["DOUZE_DRIFT_WEBHOOK"] ? { webhook: process.env["DOUZE_DRIFT_WEBHOOK"] } : {} });
	await registry.start();
	drift.schedule();
	let bound = 0;
	const app = new Hono();
	app.use("*", async (c, next) => {
		if (c.req.path === "/health" || c.req.path === "/pair") return next();
		if ((c.req.header("x-douze-token") ?? new URL(c.req.url).searchParams.get("token")) === token) return next();
		if (c.req.path.startsWith("/review/")) {
			const page = await notice("This link has expired.", "Click the Douze button in Chrome and record the site again to get a fresh one.");
			return c.html(page, 401);
		}
		return c.json({ error: "invalid install token" }, 401);
	});
	app.get("/health", (c) => c.json({
		ok: true,
		extension_connected: bridge.connected
	}));
	/**
	* The extension pairs itself here so nobody has to copy a token out of a terminal.
	*
	* Two checks, and both are the security boundary. The Origin check keeps pages out: a malicious
	* page can open a WebSocket to loopback without CORS, so the install token must never become
	* readable by one — a page cannot forge `Origin: chrome-extension://…`, and without an
	* `Access-Control-Allow-Origin` naming its own origin it cannot read the response either.
	*
	* The pin (#pinnedExtension) then keeps *other extensions* out, because they can send that
	* header honestly. First one to pair wins the install; the rest get 403 and a line on stderr.
	*/
	app.on(["GET", "OPTIONS"], "/pair", (c) => {
		const origin = c.req.header("origin") ?? "";
		const id = extensionIdOf(origin);
		if (!id) return c.json({ error: "forbidden" }, 403);
		const pinned = pinnedExtension();
		if (pinned && pinned !== id) {
			process.stderr.write(`douzed: refused pairing from extension ${id} — this install is paired with ${pinned}. Delete ${paths.extension} to pair a different extension.\n`);
			return c.json({ error: "forbidden" }, 403);
		}
		c.header("Access-Control-Allow-Origin", origin);
		c.header("Vary", "Origin");
		if (c.req.method === "OPTIONS") return c.body(null, 204);
		if (!pinned) pinExtension(id);
		return c.json({
			token,
			port: bound,
			version: DOUZED_VERSION
		});
	});
	/** AC-RUN-002 — clients poll or subscribe here; the registry is the single source of truth. */
	app.get("/registry", (c) => c.json(registry.state()));
	app.get("/recipes", (c) => c.json(registry.recipes()));
	app.get("/sessions", (c) => c.json(store.sessions()));
	app.get("/sessions/:id", (c) => {
		const id = c.req.param("id");
		const session = store.session(id);
		if (!session) return c.json({ error: `no session ${id}` }, 404);
		return c.json({
			session,
			exchanges: store.exchanges(id),
			annotations: store.annotations(id)
		});
	});
	/** REQ-DRF-001 — an on-demand Doctor Run; the scheduled one uses the same path. */
	app.post("/doctor/:recipe", async (c) => {
		try {
			return c.json(await drift.run(c.req.param("recipe")));
		} catch (error) {
			return c.json({
				error: "doctor_failed",
				message: error.message
			}, 400);
		}
	});
	app.post("/import/har", async (c) => {
		const { har, name } = await c.req.json();
		return c.json(importHar(store, har, name));
	});
	const reviews = /* @__PURE__ */ new Map();
	const review = async (sessionId) => {
		const session = store.session(sessionId);
		if (!session) return null;
		const exchanges = store.exchanges(sessionId);
		if (exchanges.length === 0) return null;
		const cached = reviews.get(sessionId);
		if (cached && cached.exchanges === exchanges.length) return cached.session;
		const { StudioSession, baseUrlFrom } = await import("./src2.js");
		const built = StudioSession.fromExchanges({
			recipeName: session.name.toLowerCase().replace(/[^a-z0-9-]+/g, "-"),
			baseUrl: baseUrlFrom(exchanges),
			paths: {
				recipes: paths.recipes,
				fixtures: paths.fixtures
			}
		}, {
			exchanges,
			annotations: store.annotations(sessionId)
		});
		reviews.set(sessionId, {
			session: built,
			exchanges: exchanges.length
		});
		return built;
	};
	app.get("/review/:sessionId", async (c) => {
		const sessionId = c.req.param("sessionId");
		if (!await review(sessionId)) return c.html(await notice("Nothing was recorded yet.", "Click the Douze button in Chrome, press Watch this site, use the site for a minute, then press Done."), 404);
		const { reviewPage } = await import("./src2.js");
		return c.html(reviewPage({
			id: sessionId,
			token
		}));
	});
	app.get("/api/review/:sessionId", async (c) => {
		const session = await review(c.req.param("sessionId"));
		if (!session) return c.json({ error: "no_session" }, 404);
		return c.json({
			site: hostnameOf(session.config.baseUrl),
			recipe: session.config.recipeName,
			candidates: session.view()
		});
	});
	app.post("/api/review/:sessionId/enable", async (c) => {
		const session = await review(c.req.param("sessionId"));
		if (!session) return c.json({ error: "no_session" }, 404);
		const raw = (await c.req.text()).trim();
		let names;
		if (raw !== "") try {
			names = JSON.parse(raw).names;
		} catch {
			return c.json({
				error: "bad_request",
				message: "The request body is not valid JSON."
			}, 400);
		}
		if (!Array.isArray(names)) {
			const bulk = session.approveReads();
			return c.json({
				enabled: bulk.approved,
				skipped: bulk.skipped
			});
		}
		const enabled = [];
		const skipped = [];
		for (const name of names) if (knows(session, name)) {
			session.approve(name);
			enabled.push(name);
		} else skipped.push(name);
		return c.json({
			enabled,
			skipped
		});
	});
	app.post("/api/review/:sessionId/disable", async (c) => {
		const session = await review(c.req.param("sessionId"));
		if (!session) return c.json({ error: "no_session" }, 404);
		const { names } = await c.req.json().catch(() => ({}));
		for (const name of names ?? []) if (knows(session, name)) session.unapprove(name);
		return c.json({ ok: true });
	});
	app.post("/api/review/:sessionId/edit", async (c) => {
		const session = await review(c.req.param("sessionId"));
		if (!session) return c.json({ error: "no_session" }, 404);
		const body = await c.req.json();
		if (!body.name || !body.field) return c.json({ error: "name and field are required" }, 400);
		try {
			session.edit(body.name, body.field, body.value);
			session.save();
			return c.json({ ok: true });
		} catch (error) {
			return c.json({ error: error.message }, 400);
		}
	});
	app.post("/api/review/:sessionId/save", async (c) => {
		const session = await review(c.req.param("sessionId"));
		if (!session) return c.json({ error: "no_session" }, 404);
		try {
			const report = session.save();
			const tools = session.candidates.filter((x) => x.tool.approved).map((x) => x.tool.name);
			return c.json({
				path: report.path,
				tools
			});
		} catch (error) {
			return c.json({
				error: "save_failed",
				message: error.message
			}, 400);
		}
	});
	/**
	* What is already set up on the origin the user is looking at — the extension popup's list.
	*
	* The popup reads this cross-origin, so it needs ACAO. Unlike /pair this stays behind the token
	* check, so the header only decides who may *read* an answer the caller already had to
	* authenticate for; a page with no token gets 401 either way.
	*/
	app.get("/api/site-tools", (c) => {
		const origin = c.req.header("origin") ?? "";
		if (origin.startsWith("chrome-extension://")) {
			c.header("Access-Control-Allow-Origin", origin);
			c.header("Vary", "Origin");
		}
		const wanted = originOf(c.req.query("origin") ?? "");
		if (!wanted) return c.json({ tools: [] });
		const tools = registry.state().tools.filter((t) => originOf(t.base_url) === wanted).map((t) => ({
			name: t.qualified_name,
			description: t.tool.description,
			side_effect: t.tool.side_effect
		}));
		return c.json({ tools });
	});
	/** The relay entry point used by `douze --mcp` and the CLI (AC-EXE-001.1). */
	app.post("/relay/:recipe/:tool", async (c) => {
		const qualified = `${c.req.param("recipe")}_${c.req.param("tool")}`;
		const surface = registry.state().tools.find((t) => t.qualified_name === qualified);
		if (!surface) return c.json({
			error: "unknown_tool",
			message: `no tool "${qualified}"`
		}, 404);
		const body = await c.req.json();
		try {
			const response = await bridge.call(surface, body.args ?? {}, { ...body.timeout_ms === void 0 ? {} : { timeout_ms: body.timeout_ms } });
			return c.json(response);
		} catch (error) {
			if (error instanceof DouzeError) return c.json(error.toResult(), 502);
			return c.json({
				error: "relay_failed",
				message: error.message
			}, 500);
		}
	});
	const server = createServer(async (req, res) => {
		if (!isLoopbackHost(req.headers.host)) {
			res.writeHead(403, { "content-type": "application/json" });
			res.end("{\"error\":\"forbidden\"}");
			return;
		}
		const response = await app.fetch(new Request(`http://127.0.0.1${req.url}`, {
			method: req.method,
			headers: req.headers,
			...req.method === "GET" || req.method === "HEAD" ? {} : {
				body: await readBody(req),
				duplex: "half"
			}
		}));
		res.writeHead(response.status, Object.fromEntries(response.headers));
		res.end(Buffer.from(await response.arrayBuffer()));
	});
	const wss = new import_websocket_server.default({
		server,
		path: "/ws"
	});
	wss.on("error", (error) => {
		if (error.code === "EADDRINUSE") return;
		process.stderr.write(`douzed: websocket server — ${error.message}\n`);
	});
	wss.on("connection", (socket, req) => {
		if (new URL(req.url ?? "", "http://127.0.0.1").searchParams.get("token") !== token || !isLoopbackHost(req.headers.host)) {
			socket.close(1008, "invalid install token");
			return;
		}
		bridge.attach(socket);
		socket.send(JSON.stringify({
			type: "welcome",
			heartbeat_ms: 2e4
		}));
		socket.on("message", (raw) => {
			try {
				const parsed = ClientMessage.safeParse(JSON.parse(String(raw)));
				if (!parsed.success) {
					process.stderr.write(`douzed: dropped malformed extension message\n`);
					return;
				}
				handleClientMessage(parsed.data, store, bridge);
			} catch (error) {
				process.stderr.write(`douzed: refused extension message — ${error.message}\n`);
			}
		});
	});
	const requested = options.port ?? (process.env["DOUZE_PORT"] ? Number(process.env["DOUZE_PORT"]) : void 0);
	let port;
	try {
		port = requested === void 0 ? await listenInRange(server) : await listen(server, requested);
	} catch (cause) {
		drift.stop();
		await registry.stop();
		store.close();
		throw cause;
	}
	bound = port;
	writeRuntime({
		pid: process.pid,
		port,
		started_at: Date.now()
	});
	return {
		port,
		registry,
		store,
		bridge,
		drift,
		close: async () => {
			drift.stop();
			await registry.stop();
			for (const client of wss.clients) client.terminate();
			wss.close();
			store.close();
			await new Promise((resolve) => server.close(() => resolve()));
		}
	};
}
function handleClientMessage(message, store, bridge) {
	switch (message.type) {
		case "exchange.session.start":
			store.startSession({
				id: message.session.id,
				name: message.session.name,
				origins: message.session.origins,
				debugger_enabled: message.session.debugger_enabled
			});
			return;
		case "exchange.append":
			store.appendExchange(Exchange.parse(message.exchange));
			return;
		case "exchange.annotate":
			store.annotate(message.span.session_id, message.span.note);
			return;
		case "exchange.session.stop":
			store.stopSession(message.session_id);
			return;
		case "relay.response":
			bridge.settle(RelayResponse.parse(message.response));
			return;
		default: return;
	}
}
/** The dead ends a browser can reach. ADR-006 holds: studio is loaded here, never imported. */
var notice = async (headline, next) => {
	const { noticePage } = await import("./src2.js");
	return noticePage(headline, next);
};
var knows = (session, name) => session.candidates.some((c) => c.tool.name === name);
/** A malformed base_url must not match a malformed query — both become null, never equal. */
var originOf = (url) => {
	try {
		return new URL(url).origin;
	} catch {
		return null;
	}
};
/** The names loopback answers to, with or without a port. Anything else was resolved by a DNS server. */
var isLoopbackHost = (host) => /^(127\.0\.0\.1|localhost|\[::1\])(:\d+)?$/.test(host ?? "");
var hostnameOf = (url) => {
	try {
		return new URL(url).hostname;
	} catch {
		return url;
	}
};
var readBody = (req) => new Promise((resolve, reject) => {
	const chunks = [];
	req.on("data", (c) => chunks.push(c));
	req.on("end", () => resolve(Buffer.concat(chunks)));
	req.on("error", reject);
});
/**
* Walks the range the extension probes, then gives up on being findable rather than on running.
*
* A port held by another douzed ends the walk instead of pushing us one along it: two clients
* starting at the same instant both find nothing, both try 8787, and the loser would otherwise
* bind 8788 and run a second daemon with its own registry. Losing the bind means the winner is
* the daemon, and `hostOrAdopt` re-probes and talks to it.
*
* ponytail: a 250 ms probe, not a handshake. The winner's HTTP handler is attached before it
* binds, so it answers as soon as its loop is free; a slower answer falls through to the next
* port, which is the behaviour we had before. Make it a real handshake only if a duplicate
* daemon ever shows up in the wild.
*/
var listenInRange = async (server) => {
	for (const candidate of PORT_RANGE) {
		const bound = await listen(server, candidate).catch(() => 0);
		if (bound > 0) return bound;
		if (await douzedOn(candidate)) throw new Error(`douzed is already running on port ${candidate}`);
	}
	return listen(server, 0);
};
var douzedOn = async (port) => {
	try {
		return (await fetch(`http://127.0.0.1:${port}/health`, { signal: AbortSignal.timeout(250) })).ok;
	} catch {
		return false;
	}
};
var listen = (server, port) => new Promise((resolve, reject) => {
	const onError = (error) => reject(error);
	server.once("error", onError);
	server.listen(port, "127.0.0.1", () => {
		server.removeListener("error", onError);
		resolve(server.address().port);
	});
});
promisify(execFile);
//#endregion
//#region src/errors.ts
/**
* This one surfaces inside the chat window, to someone who did not install a daemon and
* has no terminal open. It names the one action that fixes it and nothing else — a second option
* they cannot perform is not a fallback, it is a reason to stop reading.
*/
var RELAY_UNREACHABLE_HINT = "Douze's background service isn't running, so nothing can run right now. Quit the app you added Douze to and open it again.";
/** The cause travels in the detail: "ECONNREFUSED 127.0.0.1:8787" is not a sentence for a reader. */
var relayUnreachable = (cause) => new DouzeError("relay_unreachable", RELAY_UNREACHABLE_HINT, cause ? { cause } : {});
var CODES = /* @__PURE__ */ new Set([
	"relay_unreachable",
	"extension_disconnected",
	"session_expired",
	"tool_degraded",
	"confirm_required",
	"rate_limited",
	"timeout"
]);
/**
* Turns whatever douzed returned into a `DouzeError`. An unrecognised body still becomes a
* legible error rather than a stack trace, because the user may only ever see the chat window.
*/
function fromDaemon(body, status, tool) {
	const { error, message, ...detail } = body;
	if (typeof error === "string" && CODES.has(error)) return new DouzeError(error, message ?? error, detail);
	return new DouzeError("relay_unreachable", `The Douze relay rejected the call to "${tool}" (HTTP ${status}): ${message ?? error ?? "no reason given"}.`, {
		tool,
		...detail
	});
}
/**
* The text a client prints. Every branch ends in an instruction the user can act on without a
* terminal, and none of them suggests a retry the runtime would perform itself.
*/
function explain(error) {
	const suffix = FOLLOW_UP[error.code];
	return suffix ? `${error.message} ${suffix}` : error.message;
}
/**
* AC-CON-004.4 is a negative requirement, so it is spelled out here rather than left implicit:
* nothing in this package reissues a failed call or falls back to headless execution.
*/
var FOLLOW_UP = {
	relay_unreachable: "Douze did not retry and did not execute the request any other way.",
	extension_disconnected: "Douze did not retry and did not execute the request without the browser.",
	session_expired: "Douze did not retry, so no further request was sent to the target."
};
//#endregion
//#region src/daemon-client.ts
/**
* Whether a daemon this process needs is one it runs itself.
*
* Process-global because the question is about the process: `status` and `sessions` build their
* own client inside a command handler, and inside `douze --mcp` those must host like every other
* call rather than re-exec a Node that may not exist. A terminal leaves it false, so a one-shot
* command still detaches a daemon that outlives it.
*/
var hostByDefault = false;
var hostDaemonInProcess = () => {
	hostByDefault = true;
};
/**
* The client half of the loopback contract. Everything the CLI and the MCP server know about
* douzed goes through here: the install token, the runtime file, and AC-RUN-003.3 — if douzed
* is not running, start it and proceed once it answers.
*/
var DaemonClient = class {
	options;
	cached = null;
	constructor(options = {}) {
		this.options = options;
	}
	/**
	* AC-RUN-003.4 — resolving the endpoint before every call is what makes recovery after a
	* daemon restart automatic: a dead pid is a daemon to start again, not an error to report.
	*
	* An install configures nothing: with no environment set, the runtime file is read and the
	* daemon started if it is down. `DOUZE_RELAY_URL`/`DOUZE_INSTALL_TOKEN` remain as an override
	* for pointing a client at a daemon it did not start — a second `DOUZE_HOME`, or a test.
	*/
	async resolve() {
		const configured = process.env["DOUZE_RELAY_URL"];
		if (configured) return {
			origin: configured.replace(/\/+$/, ""),
			token: process.env["DOUZE_INSTALL_TOKEN"] ?? installToken()
		};
		if (isAlive(this.cached)) return local(this.cached);
		const running = readRuntime();
		if (isAlive(running)) {
			this.cached = running;
			return local(running);
		}
		if (this.options.autoStart === false) throw relayUnreachable("no running instance");
		this.cached = this.options.host ?? hostByDefault ? await hostOrAdopt() : await startDetached();
		return local(this.cached);
	}
	async request(path, init = {}) {
		const endpoint = await this.resolve();
		let response;
		try {
			response = await fetch(`${endpoint.origin}${path}`, {
				...init,
				headers: {
					"content-type": "application/json",
					"x-douze-token": endpoint.token,
					...init.headers
				}
			});
		} catch (cause) {
			this.cached = null;
			throw relayUnreachable(cause.message);
		}
		const body = await response.json().catch(() => ({}));
		if (!response.ok) {
			const error = new DaemonHttpError(response.status);
			error.body = body;
			throw error;
		}
		return body;
	}
	registry() {
		return this.request("/registry");
	}
	recipes() {
		return this.request("/recipes");
	}
	health() {
		return this.request("/health");
	}
};
var local = (runtime) => ({
	origin: `http://127.0.0.1:${runtime.port}`,
	token: installToken()
});
/** Carries the daemon's `{error, message, ...}` body up to `errors.fromDaemon`. */
var DaemonHttpError = class extends Error {
	status;
	body = void 0;
	constructor(status) {
		super(`douzed returned HTTP ${status}`);
		this.status = status;
		this.name = "DaemonHttpError";
	}
};
/**
* The daemon this process runs itself, if it is the one that got there first. Held so a second
* `resolve()` adopts it instead of binding a second port.
*/
var hosted = null;
/**
* How `douze --mcp` gets a daemon: adopt one if it is already up, otherwise run it here.
*
* Re-exec is not available to the MCP process. Claude Desktop runs it in an Electron
* UtilityProcess, where `process.execPath` is the Claude binary and there is no node to spawn —
* `startDetached` there launches the app, waits out its timeout, and dies without ever answering
* `initialize`. Hosting the daemon in-process needs no node binary and no install step, and works
* the same in every MCP client.
*
* The cost is deliberate: the daemon lives as long as the client that started it. A second client
* adopts this one over loopback, and takes over hosting once this process is gone.
*/
async function hostOrAdopt() {
	if (hosted) return runtimeOf(hosted.port);
	const adopted = await probe();
	if (adopted) return adopted;
	try {
		hosted = await startDaemon();
		return runtimeOf(hosted.port);
	} catch (cause) {
		const winner = await probe();
		if (winner) return winner;
		throw relayUnreachable(cause.message);
	}
}
/** The ports a daemon can be on: whichever one it recorded, then the range it walks. */
async function probe() {
	const recorded = readRuntime();
	const ports = [.../* @__PURE__ */ new Set([...recorded ? [recorded.port] : [], ...PORT_RANGE])];
	for (const port of ports) if (await reachablePort(port)) return runtimeOf(port);
	return null;
}
/**
* A daemon we did not start has a pid we cannot know from a port alone, and `isAlive` is what
* `resolve` caches on. Our own pid stands in: a daemon that goes away is caught by the failed
* request that follows, which drops the cache and resolves again.
*/
var runtimeOf = (port) => {
	const recorded = readRuntime();
	return recorded?.port === port ? recorded : {
		pid: process.pid,
		port,
		started_at: Date.now()
	};
};
var reachablePort = async (port) => {
	try {
		return (await fetch(`http://127.0.0.1:${port}/health`, { signal: AbortSignal.timeout(500) })).ok;
	} catch {
		return false;
	}
};
/**
* A cold auto-start pays for the runtime compiling the daemon entry point, and on a loaded or
* slow machine that is well past 15 s. The old ceiling turned a slow first run into a hard
* failure of `douze status`; the wait is cheap and only ever ends early.
*/
var DAEMON_START_TIMEOUT_MS = Number(process.env["DOUZE_START_TIMEOUT_MS"] ?? 45e3);
/**
* AC-RUN-003.1 — for a terminal, douzed outlives the command that started it, so it is spawned
* detached. `DOUZE_ENTRY` exists because a bundled CLI and a test harness disagree about what
* `argv[1]` is. The MCP process cannot use this path at all (see `hostOrAdopt`).
*/
async function startDetached(timeoutMs = DAEMON_START_TIMEOUT_MS) {
	const entry = process.env["DOUZE_ENTRY"] ?? process.argv[1];
	if (!entry) throw relayUnreachable("cannot locate the douze entry point to start douzed");
	spawn(process.execPath, [
		...process.execArgv,
		entry,
		"start"
	], {
		detached: true,
		stdio: "ignore",
		env: {
			...process.env,
			DOUZE_FOREGROUND: "1"
		}
	}).unref();
	return waitForDaemon(timeoutMs);
}
/** AC-RUN-003.3 — "proceed once the relay is reachable", not once the process exists. */
async function waitForDaemon(timeoutMs = DAEMON_START_TIMEOUT_MS) {
	const deadline = Date.now() + timeoutMs;
	while (Date.now() < deadline) {
		const runtime = readRuntime();
		if (isAlive(runtime) && await reachable(runtime)) return runtime;
		await new Promise((resolve) => setTimeout(resolve, 50));
	}
	throw relayUnreachable(`douzed did not become reachable within ${timeoutMs}ms`);
}
async function reachable(runtime) {
	try {
		return (await fetch(`http://127.0.0.1:${runtime.port}/health`)).ok;
	} catch {
		return false;
	}
}
//#endregion
//#region ../../node_modules/.pnpm/@modelcontextprotocol+server@2.0.0-alpha.4/node_modules/@modelcontextprotocol/server/dist/stdio.mjs
/**
* Server transport for stdio: this communicates with an MCP client by reading from the current process' `stdin` and writing to `stdout`.
*
* This transport is only available in Node.js environments.
*
* @example
* ```ts source="./stdio.examples.ts#StdioServerTransport_basicUsage"
* const server = new McpServer({ name: 'my-server', version: '1.0.0' });
* const transport = new StdioServerTransport();
* await server.connect(transport);
* ```
*/
var StdioServerTransport = class {
	_readBuffer;
	_started = false;
	_closed = false;
	constructor(_stdin = process$1.stdin, _stdout = process$1.stdout, options) {
		this._stdin = _stdin;
		this._stdout = _stdout;
		this._readBuffer = new ReadBuffer({ maxBufferSize: options?.maxBufferSize });
	}
	onclose;
	onerror;
	onmessage;
	_ondata = (chunk) => {
		try {
			this._readBuffer.append(chunk);
			this.processReadBuffer();
		} catch (error) {
			this.onerror?.(error);
			this.close().catch(() => {});
		}
	};
	_onerror = (error) => {
		this.onerror?.(error);
	};
	_onstdouterror = (error) => {
		this.onerror?.(error);
		this.close().catch(() => {});
	};
	/**
	* Starts listening for messages on `stdin`.
	*/
	async start() {
		if (this._started) throw new Error("StdioServerTransport already started! If using Server class, note that connect() calls start() automatically.");
		this._started = true;
		this._stdin.on("data", this._ondata);
		this._stdin.on("error", this._onerror);
		this._stdout.on("error", this._onstdouterror);
	}
	processReadBuffer() {
		while (true) try {
			const message = this._readBuffer.readMessage();
			if (message === null) break;
			this.onmessage?.(message);
		} catch (error) {
			this.onerror?.(error);
		}
	}
	async close() {
		if (this._closed) return;
		this._closed = true;
		this._stdin.off("data", this._ondata);
		this._stdin.off("error", this._onerror);
		this._stdout.off("error", this._onstdouterror);
		if (this._stdin.listenerCount("data") === 0) this._stdin.pause();
		this._readBuffer.clear();
		this.onclose?.();
	}
	send(message) {
		if (this._closed) return Promise.reject(/* @__PURE__ */ new Error("StdioServerTransport is closed"));
		return new Promise((resolve, reject) => {
			const json = serializeMessage(message);
			let settled = false;
			const onError = (error) => {
				if (settled) return;
				settled = true;
				this._stdout.off("error", onError);
				this._stdout.off("drain", onDrain);
				reject(error);
			};
			const onDrain = () => {
				if (settled) return;
				settled = true;
				this._stdout.off("error", onError);
				this._stdout.off("drain", onDrain);
				resolve();
			};
			this._stdout.once("error", onError);
			if (this._stdout.write(json)) {
				if (settled) return;
				settled = true;
				this._stdout.off("error", onError);
				resolve();
			} else if (!settled) this._stdout.once("drain", onDrain);
		});
	}
};
//#endregion
//#region src/shape.ts
/**
* REQ-RUN-004 — result shaping. A tool result is trimmed to the recipe's Primary Payload Path
* and capped before it leaves the client, so a chat context is not spent on response envelopes.
*/
/** AC-RUN-004.2 — the cap on a trimmed result, measured as UTF-8 JSON bytes. */
var MAX_RESULT_BYTES = 32 * 1024;
function shapeResult(body, options = {}) {
	const path = options.primary_payload_path;
	let data = body;
	let note;
	if (!options.raw && path) {
		const picked = selectPath(body, path);
		if (picked === MISSING) note = `primary_payload_path "${path}" did not resolve; returning the full body.`;
		else data = picked;
	}
	const encoded = Buffer.byteLength(json(data), "utf8");
	if (encoded <= 32768) return note === void 0 ? { data } : {
		data,
		note
	};
	const returned = cutToBytes(json(data), MAX_RESULT_BYTES);
	return {
		data: returned,
		truncated: {
			message: `Result truncated to ${MAX_RESULT_BYTES} bytes; the untrimmed result was ${encoded} bytes.`,
			untrimmed_bytes: encoded,
			returned_bytes: Buffer.byteLength(returned, "utf8")
		},
		...note === void 0 ? {} : { note }
	};
}
var json = (value) => typeof value === "string" ? value : JSON.stringify(value) ?? "null";
/** Distinguishes "the path selected `undefined`" from "the path does not exist". */
var MISSING = Symbol("missing");
/**
* The subset of JSONPath recipes actually record: a rooted dot/bracket path such as
* `$.data.orders[0].id`. Filters and wildcards are deliberately unsupported — inference never
* emits them, and a fuller evaluator would be code with no caller.
*/
function selectPath(value, path) {
	let current = value;
	for (const segment of segments(path)) {
		if (current === null || current === void 0) return MISSING;
		if (Array.isArray(current)) {
			const index = Number(segment);
			if (!Number.isInteger(index) || index < 0 || index >= current.length) return MISSING;
			current = current[index];
			continue;
		}
		if (typeof current !== "object") return MISSING;
		const record = current;
		if (!(segment in record)) return MISSING;
		current = record[segment];
	}
	return current;
}
function segments(path) {
	return path.replace(/^\$\.?/, "").replace(/\[(\d+)\]/g, ".$1").replace(/\['([^']*)'\]/g, ".$1").split(".").filter((s) => s.length > 0);
}
/**
* Cuts a string to at most `limit` BYTES without splitting a UTF-8 sequence.
*
* `Buffer.subarray(0, limit).toString('utf8')` looks right and is not: a split multi-byte
* sequence decodes to a 3-byte U+FFFD, so an emoji straddling the boundary comes back one or two
* bytes OVER the cap AC-RUN-004.2 exists to enforce — and mojibake with it. A continuation byte
* is 0b10xxxxxx, so walking back to the last lead byte finds the real boundary.
*/
function cutToBytes(value, limit) {
	const buffer = Buffer.from(value, "utf8");
	if (buffer.length <= limit) return value;
	let end = limit;
	while (end > 0 && (buffer[end] & 192) === 128) end -= 1;
	return buffer.subarray(0, end).toString("utf8");
}
//#endregion
//#region src/relay-client.ts
/** AC-CON-003.1 — the interval at which a still-running call reports progress. */
var PROGRESS_INTERVAL_MS = 6e4;
/**
* #RelayClient — builds the call, waits it out, and shapes the answer. It owns none of the
* guards: rate limiting, destructive confirmation, and degradation all live in douzed so they
* cannot be bypassed by calling the daemon directly (blueprint 3.3).
*/
var RelayClient = class {
	daemon;
	constructor(daemon) {
		this.daemon = daemon;
	}
	async call(surface, args, options = {}) {
		const ceiling = options.ceilingMs ?? Number(process.env["DOUZE_CALL_CEILING_MS"] ?? 3e5);
		const started = Date.now();
		const ticker = options.onProgress ? setInterval(() => void options.onProgress?.(Date.now() - started), PROGRESS_INTERVAL_MS) : void 0;
		try {
			const response = await withCeiling(this.post(surface, args, ceiling), ceiling, () => new DouzeError("timeout", `Tool "${surface.qualified_name}" was cancelled after ${Math.round((Date.now() - started) / 1e3)}s without returning; the configured ceiling is ${Math.round(ceiling / 1e3)}s.`, {
				tool: surface.qualified_name,
				elapsed_ms: Date.now() - started,
				ceiling_ms: ceiling
			}));
			return {
				status: response.status ?? 0,
				duration_ms: response.duration_ms,
				...shapeResult(response.body, {
					primary_payload_path: surface.tool.response.primary_payload_path,
					raw: args["raw"] === true
				})
			};
		} finally {
			clearInterval(ticker);
		}
	}
	async post(surface, args, ceiling) {
		try {
			return await this.daemon.request(`/relay/${encodeURIComponent(surface.recipe)}/${encodeURIComponent(surface.tool.name)}`, {
				method: "POST",
				body: JSON.stringify({
					args,
					timeout_ms: ceiling
				})
			});
		} catch (error) {
			if (error instanceof DaemonHttpError) throw fromDaemon(error.body, error.status, surface.qualified_name);
			throw error;
		}
	}
};
function withCeiling(work, ms, onTimeout) {
	let timer;
	return Promise.race([work.finally(() => clearTimeout(timer)), new Promise((_, reject) => {
		timer = setTimeout(() => reject(onTimeout()), ms);
	})]);
}
//#endregion
//#region src/mcp.ts
/**
* How often the registry is polled for a new revision. The watcher settles in 250 ms, so a
* 2-second poll keeps a disk edit inside the 5 seconds AC-RUN-002.1 allows end to end.
*
* ponytail: polling, not a subscription. One idle GET every 2s on loopback against a daemon
* that already holds the state in memory. Swap for an SSE endpoint on douzed if the poll ever
* shows up in a profile.
*/
var POLL_MS = Number(process.env["DOUZE_REGISTRY_POLL_MS"] ?? 2e3);
/**
* How long the handshake waits for the first tool list before going ahead without it. Long
* enough for a daemon this process has to start itself (a few hundred milliseconds), short
* enough that a client never sees a server that looks dead.
*/
var FIRST_REFRESH_MS = 3e3;
var sleep = (ms) => new Promise((resolve) => {
	setTimeout(resolve, ms).unref?.();
});
/**
* `douze --mcp`.
*
* incur's own `Mcp.serve` materialises the tool list once at connect time and never exposes the
* `McpServer`, so a recipe approved after launch would be invisible until restart — the exact
* thing ADR-005 exists to avoid. This is the wrapper that decision anticipated: incur still owns
* the command tree (`Cli.toCommands`), the tool projection (`Mcp.collectTools`) and the execution
* pipeline (`Mcp.callTool`); only registration is ours, because only registration needs to change
* while a client is connected.
*
* Discovery is `direct`: every tool is a literal entry in `tools/list` under its
* `<recipe>_<tool>` name (AC-RUN-001.2). incur's default is `progressive` — four static tools
* plus a searchable catalog — which would also survive a surface change without any
* notification, but it hides the real names from `tools/list` and routes every call through a
* read/write gate. Douze's surface is narrow enough that the literal list is worth more than the
* token saving, and `notifications/tools/list_changed` covers the churn (AC-RUN-002.2).
*/
async function serveMcp(options) {
	const { builder, daemon } = options;
	const name = options.name ?? "douze";
	const version = options.version ?? "0.1.0";
	const server = new McpServer({
		name,
		title: "Douze",
		version
	}, { instructions: "Tools recorded from your own authenticated dashboards. Each tool is named <recipe>_<tool> and executes inside your signed-in browser. Tool names and descriptions change while this server runs; re-read tools/list after a notifications/tools/list_changed." });
	const registered = /* @__PURE__ */ new Map();
	const sync = () => {
		const tools = collectTools(builder.commands, []);
		const present = /* @__PURE__ */ new Set();
		for (const tool of tools) {
			present.add(tool.name);
			const fingerprint = JSON.stringify([
				tool.description,
				tool.inputSchema,
				tool.annotations
			]);
			const existing = registered.get(tool.name);
			if (existing?.fingerprint === fingerprint) continue;
			const config = toolConfig(tool);
			if (existing) {
				existing.handle.update(config);
				existing.fingerprint = fingerprint;
				continue;
			}
			const handle = server.registerTool(tool.name, config, (...callArgs) => {
				const hasInput = Object.keys(tool.inputSchema.properties ?? {}).length > 0;
				const params = hasInput ? callArgs[0] : {};
				const extra = hasInput ? callArgs[1] : callArgs[0];
				return call(tool.name, params, extra);
			});
			registered.set(tool.name, {
				handle,
				fingerprint
			});
		}
		for (const [toolName, entry] of registered) {
			if (present.has(toolName)) continue;
			entry.handle.remove();
			registered.delete(toolName);
		}
	};
	/**
	* Resolved fresh on every call rather than closed over: after a hot reload the command behind
	* a name may carry a new schema, and a stale closure would validate against the old one.
	*/
	const call = async (toolName, params, extra) => {
		const tool = collectTools(builder.commands, []).find((t) => t.name === toolName);
		if (!tool) return {
			content: [{
				type: "text",
				text: `Tool "${toolName}" no longer exists.`
			}],
			isError: true
		};
		const stop = startProgress(toolName, extra);
		try {
			return await callTool(tool, params, {
				name,
				version,
				extra
			});
		} finally {
			stop();
		}
	};
	const refresh = async () => {
		const state = await daemon.registry();
		const result = builder.apply(state);
		if (result.changed) sync();
		return result.changed;
	};
	sync();
	const poll = setInterval(() => {
		refresh().catch(() => void 0);
	}, options.pollMs ?? POLL_MS);
	poll.unref?.();
	const first = refresh().catch((error) => {
		process.stderr.write(`douze: no tools yet — ${error.message}\n`);
		return false;
	});
	await Promise.race([first, sleep(options.firstRefreshMs ?? FIRST_REFRESH_MS)]);
	const transport = new StdioServerTransport(options.input, options.output);
	await server.connect(transport);
	return {
		server,
		refresh,
		close: async () => {
			clearInterval(poll);
			await server.close();
		}
	};
}
/**
* AC-CON-003.1 — a relayed call waits on a human's browser, so silence past a minute reads as a
* hang. A tick every 60 seconds keeps the client's own timer alive until the call resolves.
*/
function startProgress(toolName, extra) {
	const token = extra?.mcpReq?._meta?.progressToken ?? extra?._meta?.progressToken;
	const notify = extra?.mcpReq?.notify?.bind(extra.mcpReq) ?? extra?.sendNotification;
	if (token === void 0 || !notify) return () => void 0;
	const started = Date.now();
	let progress = 0;
	const timer = setInterval(() => {
		const elapsed = Math.round((Date.now() - started) / 1e3);
		notify({
			method: "notifications/progress",
			params: {
				progressToken: token,
				progress: ++progress,
				message: `${toolName} is still running in your browser (${elapsed}s elapsed).`
			}
		});
	}, PROGRESS_INTERVAL_MS);
	return () => clearInterval(timer);
}
function toolConfig(tool) {
	const shape = {
		...tool.command.args?.shape,
		...tool.command.options?.shape
	};
	return {
		...tool.description ? { description: tool.description } : {},
		...Object.keys(shape).length > 0 ? { inputSchema: object(shape) } : {},
		...tool.outputSchema ? { outputSchema: fromJsonSchema(tool.outputSchema) } : {},
		...tool.annotations ? { annotations: tool.annotations } : {}
	};
}
//#endregion
//#region src/schema-to-zod.ts
/**
* AC-RUN-001.1 — recipes store JSON Schema; incur wants Zod. `Openapi.toZod` is incur's own
* converter, the same one it uses for OpenAPI parameters and remote MCP `inputSchema`s, so a
* schema that survives this conversion is one incur can both parse on the CLI and re-emit as
* MCP JSON Schema unchanged. incur accepts no raw JSON Schema anywhere, so this runs at load.
*/
function toZodObject(schema) {
	const converted = toZod(isObjectSchema(schema) ? schema : {
		type: "object",
		properties: {}
	});
	if (converted instanceof ZodObject) return converted;
	return object({});
}
function isObjectSchema(schema) {
	if (schema === null || typeof schema !== "object") return false;
	const record = schema;
	return record["type"] === "object" || "properties" in record;
}
/**
* AC-RUN-004.1 — `raw` is a runtime concern rather than a recipe one, so every tool grows it
* here instead of every recipe carrying it. Left `.optional()` rather than `.default(false)`
* because incur derives the MCP schema from the parsed *output* type, where a default makes the
* field required — and an agent should not have to pass `raw` to make a normal call.
*/
var RAW_OPTION = boolean().optional().describe("Return the untrimmed response body instead of the recipe's primary payload path.");
//#endregion
//#region src/surface.ts
/**
* Command names the runtime owns. A recipe called `start` would otherwise silently replace
* `douze start`, which is a worse outcome than refusing to mount it.
*/
var RESERVED_GROUPS = /* @__PURE__ */ new Set([
	"bundle",
	"completions",
	"doctor",
	"eject",
	"import",
	"mcp",
	"sessions",
	"skills",
	"start",
	"status",
	"stop"
]);
/**
* #ToolSurfaceBuilder — turns a `RegistryState` into a live incur command tree.
*
* One tree serves both surfaces (ADR-007): incur exposes a leaf as `douze <recipe> <tool>` on
* the CLI and joins the same path with `_` for MCP, so `<recipe>_<tool>` needs no separate
* naming pass and two recipes defining `list` stay distinct with neither renamed (AC-RUN-001.3).
*
* `.command()` is a runtime call over a Map incur keeps live, and a mounted sub-Cli's Map is
* held by reference, so rebuilding a recipe's tools after a hot reload is a mutation rather
* than a restart (ADR-005).
*/
var ToolSurfaceBuilder = class {
	root;
	relay;
	fixturesDir;
	groups = /* @__PURE__ */ new Map();
	rootCommands;
	revision = -1;
	constructor(root, relay, fixturesDir = paths().fixtures) {
		this.root = root;
		this.relay = relay;
		this.fixturesDir = fixturesDir;
		this.rootCommands = liveCommands(root);
	}
	/** The live command map incur reads at MCP collect time and at CLI dispatch time. */
	get commands() {
		return this.rootCommands;
	}
	/** AC-RUN-001.1 — one command per approved tool, JSON Schema converted to Zod at load time. */
	apply(state) {
		if (state.revision === this.revision) return {
			changed: false,
			errors: state.errors,
			skipped: []
		};
		this.revision = state.revision;
		const byRecipe = /* @__PURE__ */ new Map();
		const skipped = [];
		for (const tool of state.tools) {
			if (RESERVED_GROUPS.has(tool.recipe)) {
				if (!skipped.includes(tool.recipe)) skipped.push(tool.recipe);
				continue;
			}
			const bucket = byRecipe.get(tool.recipe);
			if (bucket) bucket.push(tool);
			else byRecipe.set(tool.recipe, [tool]);
		}
		for (const [recipe] of this.groups) if (!byRecipe.has(recipe)) {
			this.groups.delete(recipe);
			this.rootCommands.delete(recipe);
		}
		for (const [recipe, tools] of byRecipe) {
			const group = this.group(recipe);
			const commands = liveCommands(group);
			const wanted = new Set(tools.map((t) => t.tool.name));
			for (const name of [...commands.keys()]) if (!wanted.has(name)) commands.delete(name);
			for (const tool of tools) group.command(tool.tool.name, this.define(tool));
		}
		return {
			changed: true,
			errors: state.errors,
			skipped
		};
	}
	group(recipe) {
		const existing = this.groups.get(recipe);
		if (existing) return existing;
		const group = create(recipe, { description: `Tools recorded from the ${recipe} target` });
		this.groups.set(recipe, group);
		this.root.command(group);
		return group;
	}
	define(surface) {
		const { tool } = surface;
		const options = toZodObject(tool.request.input_schema).extend({ raw: RAW_OPTION });
		const readOnly = tool.side_effect === "read";
		return {
			description: describe(surface),
			options,
			examples: examples(surface, this.fixturesDir),
			mcp: { annotations: {
				readOnlyHint: readOnly,
				destructiveHint: tool.side_effect === "destructive",
				idempotentHint: readOnly,
				openWorldHint: true
			} },
			run: async (c) => {
				try {
					return await this.relay.call(surface, c.options);
				} catch (error) {
					if (error instanceof DouzeError) return c.error({
						code: error.code,
						message: explain(error),
						retryable: false
					});
					throw error;
				}
			}
		};
	}
};
/**
* A chat client selects on the description alone (ADR-008), so the side effect and the
* degradation reason belong in the text rather than only in annotations a client may ignore.
*/
function describe(surface) {
	const parts = [surface.tool.description];
	if (surface.tool.side_effect === "destructive") parts.push("Destructive: requires confirm=true.");
	if (surface.degraded) parts.push(`Currently degraded and will refuse to run: ${surface.degraded_reason ?? "contract drift"}.`);
	return parts.join(" ");
}
/**
* AC-CON-002.4 — `douze skills add` is incur's built-in generator; it renders whatever
* `examples` a command carries. Drawing the values from the tool's own recorded fixture is what
* makes the generated skill a worked example rather than a schema restatement.
*/
function examples(surface, fixturesDir) {
	const fixture = surface.tool.fixtures[0];
	if (!fixture) return [];
	let sample;
	try {
		sample = JSON.parse(readFileSync(join(fixturesDir, fixture), "utf8"));
	} catch {
		return [];
	}
	const schema = surface.tool.request.input_schema;
	const options = {};
	for (const name of schema.required ?? []) options[name] = sampleValue(name, schema.properties?.[name], sample);
	return [{
		options,
		description: `Recorded against ${surface.base_url} (fixture ${fixture})`
	}];
}
function sampleValue(name, property, sample) {
	const found = findValue(sample, name);
	if (found !== void 0) return found;
	if (property?.enum?.length) return property.enum[0];
	if (name === "confirm") return true;
	switch (property?.type) {
		case "number":
		case "integer": return 1;
		case "boolean": return true;
		case "array": return [];
		default: return `<${name}>`;
	}
}
/** Shallow-ish search for a key in the fixture, so `{data:{id:7}}` still yields an `id` example. */
function findValue(value, key, depth = 3) {
	if (depth < 0 || value === null || typeof value !== "object") return void 0;
	if (Array.isArray(value)) return findValue(value[0], key, depth - 1);
	const record = value;
	if (key in record && isScalar(record[key])) return record[key];
	for (const nested of Object.values(record)) {
		const found = findValue(nested, key, depth - 1);
		if (found !== void 0) return found;
	}
}
var isScalar = (value) => typeof value === "string" || typeof value === "number" || typeof value === "boolean";
/** incur keeps a Cli's command tree in a live Map; mutating it is how a hot reload lands. */
function liveCommands(cli) {
	const commands = toCommands.get(cli);
	if (!commands) throw new Error("incur did not expose a command map for this Cli");
	return commands;
}
//#endregion
//#region src/commands/daemon.ts
/**
* Daemon lifecycle and read-only inspection. These are the only commands that must work with no
* recipes, no extension, and no browser, so they are registered before any recipe group.
*/
function register$2(cli) {
	cli.command("start", {
		description: "Start the Douze relay daemon (douzed)",
		options: object({ port: number().int().optional().describe("Port for the relay to bind") }),
		mcp: false,
		async run(c) {
			if (process.env["DOUZE_FOREGROUND"] === "1") return runForeground(c.options.port, c.error);
			const running = readRuntime();
			if (isAlive(running)) return {
				started: false,
				pid: running.pid,
				port: running.port
			};
			if (c.options.port !== void 0) process.env["DOUZE_PORT"] = String(c.options.port);
			const runtime = await startDetached();
			return {
				started: true,
				pid: runtime.pid,
				port: runtime.port
			};
		}
	});
	cli.command("stop", {
		description: "Stop the Douze relay daemon",
		mcp: false,
		run(c) {
			const running = readRuntime();
			if (!isAlive(running)) return c.error({
				code: "NOT_RUNNING",
				message: "douzed is not running.",
				exitCode: 1
			});
			process.kill(running.pid, "SIGTERM");
			return {
				stopped: true,
				pid: running.pid
			};
		}
	});
	cli.command("status", {
		description: "Report daemon, extension, and tool-surface state",
		mcp: { annotations: { readOnlyHint: true } },
		async run() {
			const daemon = new DaemonClient();
			const [health, registry] = await Promise.all([daemon.health(), daemon.registry()]);
			const running = readRuntime();
			return {
				running: isAlive(running),
				pid: running?.pid,
				port: running?.port,
				...running && running.port !== DEFAULT_PORT ? { port_warning: PORT_RANGE.includes(running.port) ? `Something else is using ${DEFAULT_PORT}, so Douze took ${running.port}. The Chrome extension still finds it.` : `Douze is on port ${running.port}, which the Chrome extension does not check. Free up one of ${PORT_RANGE.join(", ")} and restart Douze, or the extension will report it as not running.` } : {},
				extension_connected: health.extension_connected,
				revision: registry.revision,
				tools: registry.tools.length,
				degraded: registry.tools.filter((t) => t.degraded).map((t) => t.qualified_name),
				errors: registry.errors
			};
		}
	});
	cli.command("sessions", {
		description: "List recorded capture sessions",
		mcp: { annotations: { readOnlyHint: true } },
		run: () => new DaemonClient().request("/sessions")
	});
	cli.command("import", {
		description: "Import a HAR file as a capture session",
		args: object({ file: string().describe("Path to a .har file") }),
		options: object({ name: string().describe("Name for the created session") }),
		mcp: false,
		async run(c) {
			const path = resolve(c.args.file);
			let har;
			try {
				har = JSON.parse(readFileSync(path, "utf8"));
			} catch (cause) {
				return c.error({
					code: "BAD_HAR",
					message: `Could not read ${path}: ${cause.message}`,
					exitCode: 1
				});
			}
			return new DaemonClient().request("/import/har", {
				method: "POST",
				body: JSON.stringify({
					har,
					name: c.options.name
				})
			});
		}
	});
}
/** The daemon process itself: start, write the runtime file, and stay up until signalled. */
async function runForeground(port, error) {
	let daemon;
	try {
		daemon = await startDaemon(port === void 0 ? {} : { port });
	} catch (cause) {
		return error({
			code: "ALREADY_RUNNING",
			message: cause.message,
			exitCode: 1
		});
	}
	for (const signal of ["SIGTERM", "SIGINT"]) process.on(signal, () => {
		daemon.close().then(() => process.exit(0));
	});
	await new Promise(() => void 0);
	throw new Error("unreachable");
}
//#endregion
//#region src/zip.ts
function zip(entries) {
	const local = [];
	const central = [];
	let offset = 0;
	for (const entry of entries) {
		const name = Buffer.from(entry.path.replace(/\\/g, "/"), "utf8");
		const crc = crc32(entry.data);
		const size = entry.data.length;
		const header = Buffer.alloc(30);
		header.writeUInt32LE(67324752, 0);
		header.writeUInt16LE(20, 4);
		header.writeUInt16LE(0, 6);
		header.writeUInt16LE(0, 8);
		header.writeUInt16LE(0, 10);
		header.writeUInt16LE(33, 12);
		header.writeUInt32LE(crc, 14);
		header.writeUInt32LE(size, 18);
		header.writeUInt32LE(size, 22);
		header.writeUInt16LE(name.length, 26);
		header.writeUInt16LE(0, 28);
		local.push(header, name, entry.data);
		const record = Buffer.alloc(46);
		record.writeUInt32LE(33639248, 0);
		record.writeUInt16LE(20, 4);
		record.writeUInt16LE(20, 6);
		record.writeUInt16LE(0, 8);
		record.writeUInt16LE(0, 10);
		record.writeUInt16LE(0, 12);
		record.writeUInt16LE(33, 14);
		record.writeUInt32LE(crc, 16);
		record.writeUInt32LE(size, 20);
		record.writeUInt32LE(size, 24);
		record.writeUInt16LE(name.length, 28);
		record.writeUInt16LE(0, 30);
		record.writeUInt16LE(0, 32);
		record.writeUInt16LE(0, 34);
		record.writeUInt16LE(0, 36);
		record.writeUInt32LE(33188 << 16 >>> 0, 38);
		record.writeUInt32LE(offset, 42);
		central.push(record, name);
		offset += header.length + name.length + size;
	}
	const directory = Buffer.concat(central);
	const end = Buffer.alloc(22);
	end.writeUInt32LE(101010256, 0);
	end.writeUInt16LE(0, 4);
	end.writeUInt16LE(0, 6);
	end.writeUInt16LE(entries.length, 8);
	end.writeUInt16LE(entries.length, 10);
	end.writeUInt32LE(directory.length, 12);
	end.writeUInt32LE(offset, 16);
	end.writeUInt16LE(0, 20);
	return Buffer.concat([
		...local,
		directory,
		end
	]);
}
var TABLE = (() => {
	const table = /* @__PURE__ */ new Uint32Array(256);
	for (let i = 0; i < 256; i++) {
		let value = i;
		for (let bit = 0; bit < 8; bit++) value = value & 1 ? 3988292384 ^ value >>> 1 : value >>> 1;
		table[i] = value >>> 0;
	}
	return table;
})();
function crc32(data) {
	let crc = 4294967295;
	for (const byte of data) crc = TABLE[(crc ^ byte) & 255] ^ crc >>> 8;
	return (crc ^ 4294967295) >>> 0;
}
//#endregion
//#region src/commands/bundle.ts
var VERSION$1 = "0.1.0";
/**
* ADR-008 — `.mcpb` is the primary install path, because Claude Desktop's only alternative is
* hand-edited JSON. AC-CON-001.4 is what makes this a one-time act: the bundle carries no tool
* definitions at all, so a recipe approved next month appears without a rebuild.
*/
function register$1(cli) {
	cli.command("bundle", {
		description: "Emit a .mcpb bundle installable by double-click in Claude Desktop",
		options: object({
			out: string().default("Douze.mcpb").describe("Path to write the bundle to"),
			dist: string().optional().describe("Directory holding the built MCP server (defaults to this package's dist)")
		}),
		mcp: false,
		run(c) {
			const dist = resolve(c.options.dist ?? defaultDist());
			if (!existsSync(join(dist, "index.js"))) return c.error({
				code: "NOT_BUILT",
				message: `No built MCP server at ${dist}/index.js. Run \`pnpm bundle\` from the repo root, which builds and emits Douze.mcpb in one step.`,
				exitCode: 1
			});
			const entries = [{
				path: "manifest.json",
				data: Buffer.from(JSON.stringify(manifest(), null, 2), "utf8")
			}];
			for (const file of walk(dist)) entries.push({
				path: join("server", relative(dist, file)),
				data: readFileSync(file)
			});
			const out = resolve(c.options.out);
			writeFileSync(out, zip(entries));
			return {
				bundle: out,
				files: entries.length,
				bytes: statSync(out).size
			};
		}
	});
}
/**
* There is no `user_config`, and that is the point: installing is a double-click and nothing
* else. The server finds its own way to the background service — `DaemonClient.resolve` reads
* the runtime file and starts the service if it is down, and `installToken()` reads or creates
* the token — so there is nothing left for a person to type into a settings form.
*
* AC-CON-001.3 — `type: node` runs on the Node that ships inside Claude Desktop, so nothing
* extra is installed.
*/
function manifest() {
	return {
		manifest_version: "0.2",
		name: "douze",
		display_name: "Douze",
		version: VERSION$1,
		description: "Use the websites you are already signed into as tools, without handing over your password.",
		author: { name: "Douze" },
		server: {
			type: "node",
			entry_point: "server/index.js",
			mcp_config: {
				command: "node",
				args: ["${__dirname}/server/index.js", "--mcp"]
			}
		},
		compatibility: {
			claude_desktop: ">=0.10.0",
			platforms: [
				"darwin",
				"win32",
				"linux"
			],
			runtimes: { node: ">=22" }
		}
	};
}
var defaultDist = () => join(dirname(dirname(fileURLToPath(import.meta.url))), "dist");
function walk(dir) {
	const found = [];
	for (const entry of readdirSync(dir, { withFileTypes: true })) {
		const path = join(dir, entry.name);
		if (entry.isDirectory()) found.push(...walk(path));
		else if (!entry.name.endsWith(".map")) found.push(path);
	}
	return found;
}
//#endregion
//#region src/commands/mcp-add.ts
/**
* REQ-CON-002 — one command registers Douze with an MCP client. Any MCP client: the daemon, the
* extension and the recipes know nothing about who is calling, so the only Claude-specific thing
* left was where the registration is written.
*
* incur ships an `mcp add`, but it shells out to `npx add-mcp`, which writes `command: "douze"` —
* a binary a consumer never installs, since Douze ships as a zip and not on npm. It also reports
* agent names scraped from that tool's stdout, so neither AC-CON-002.1 (report the scope written)
* nor AC-CON-002.3 (reserved names) survives the indirection. Registration is written here.
*/
/** AC-CON-002.3 — names Claude Code has taken for itself. Comparison is case-insensitive. */
var RESERVED_SERVER_NAMES = [
	"workspace",
	"claude-in-chrome",
	"computer-use",
	"Claude Preview",
	"Claude Browser"
];
var AGENTS = [
	"claude-code",
	"claude-desktop",
	"cursor",
	"vscode",
	"windsurf"
];
var isAgent = (value) => AGENTS.includes(value);
/**
* AC-CON-002.3 — reserved means rejected-and-suffixed, not rejected-and-failed: the user asked
* for a registration, and refusing one over a name would be a worse answer than renaming it.
*/
function resolveServerName(requested) {
	const taken = new Set(RESERVED_SERVER_NAMES.map((n) => n.toLowerCase()));
	if (!taken.has(requested.toLowerCase())) return requested;
	let candidate = `${requested}-douze`;
	let suffix = 2;
	while (taken.has(candidate.toLowerCase())) candidate = `${requested}-douze-${suffix++}`;
	return candidate;
}
/** Where an app of this name keeps its per-user configuration on this platform. */
var appConfigDir = (app) => {
	if (process.platform === "darwin") return join(homedir(), "Library", "Application Support", app);
	if (process.platform === "win32") return join(process.env["APPDATA"] ?? join(homedir(), "AppData", "Roaming"), app);
	return join(homedir(), ".config", app);
};
/**
* Where each client reads stdio servers from. A scope an agent does not have returns null rather
* than a nearby file: writing a global registration for someone who asked for a project one is a
* worse answer than saying the scope does not exist.
*/
var TARGETS = {
	"claude-code": (scope, cwd) => {
		if (scope === "project") return {
			path: join(cwd, ".mcp.json"),
			container: ["mcpServers"]
		};
		if (scope === "local") return {
			path: join(homedir(), ".claude.json"),
			container: [
				"projects",
				cwd,
				"mcpServers"
			]
		};
		return {
			path: join(homedir(), ".claude.json"),
			container: ["mcpServers"]
		};
	},
	"claude-desktop": (scope) => scope === "user" ? {
		path: join(appConfigDir("Claude"), "claude_desktop_config.json"),
		container: ["mcpServers"]
	} : null,
	cursor: (scope, cwd) => {
		if (scope === "project") return {
			path: join(cwd, ".cursor", "mcp.json"),
			container: ["mcpServers"]
		};
		return scope === "user" ? {
			path: join(homedir(), ".cursor", "mcp.json"),
			container: ["mcpServers"]
		} : null;
	},
	vscode: (scope, cwd) => {
		if (scope === "project") return {
			path: join(cwd, ".vscode", "mcp.json"),
			container: ["servers"]
		};
		return scope === "user" ? {
			path: join(appConfigDir("Code"), "User", "mcp.json"),
			container: ["servers"]
		} : null;
	},
	windsurf: (scope) => scope === "user" ? {
		path: join(homedir(), ".codeium", "windsurf", "mcp_config.json"),
		container: ["mcpServers"]
	} : null
};
function configTarget(agent, scope, cwd) {
	const target = TARGETS[agent](scope, cwd);
	if (!target) throw new Error(`${agent} has no ${scope} scope; use --scope user.`);
	return target;
}
/**
* How a client should launch us: this Node, running this entry point, both absolute.
*
* Not `node`: GUI clients spawn servers with a login shell's PATH nowhere in sight, so a bare
* `node` may not resolve. Not `douze` either — there is no such binary on a consumer's machine.
* `argv[1]` is the file the user just ran, which is the unzipped `index.js` we want written down.
*/
function launcher(command) {
	if (command) return {
		command,
		args: ["--mcp"]
	};
	const entry = process.env["DOUZE_ENTRY"] ?? process.argv[1];
	if (!entry) throw new Error("cannot locate the douze entry point to register");
	return {
		command: process.execPath,
		args: [resolve(entry), "--mcp"]
	};
}
function addToAgent(options = {}) {
	const agent = options.agent ?? "claude-code";
	const requested = options.name ?? "douze";
	const name = resolveServerName(requested);
	const scope = options.scope ?? "user";
	const target = configTarget(agent, scope, options.cwd ?? process.cwd());
	const { command, args } = launcher(options.command);
	const config = readJson(target.path);
	const node = ensurePath(config, target.container);
	node[name] = {
		type: "stdio",
		command,
		args
	};
	mkdirSync(dirname(target.path), { recursive: true });
	writeFileSync(target.path, `${JSON.stringify(config, null, 2)}\n`);
	return {
		agent,
		name,
		...name === requested ? {} : { requested },
		scope,
		path: target.path,
		command,
		args
	};
}
/** What to hand someone whose client we do not write config for: the block, ready to paste. */
function snippet(name = "douze", command) {
	const launch = launcher(command);
	return JSON.stringify({ mcpServers: { [name]: {
		type: "stdio",
		...launch
	} } }, null, 2);
}
function ensurePath(root, keys) {
	let node = root;
	for (const key of keys) {
		const existing = node[key];
		if (typeof existing !== "object" || existing === null || Array.isArray(existing)) node[key] = {};
		node = node[key];
	}
	return node;
}
function readJson(path) {
	if (!existsSync(path)) return {};
	try {
		const parsed = JSON.parse(readFileSync(path, "utf8"));
		return typeof parsed === "object" && parsed !== null ? parsed : {};
	} catch {
		throw new Error(`${path} is not valid JSON; fix it before registering an MCP server.`);
	}
}
/** Parses the `mcp add` argv incur would otherwise have handled. */
function parseMcpAdd(argv) {
	const parsed = {};
	for (let i = 0; i < argv.length; i++) {
		const flag = argv[i];
		const value = argv[i + 1];
		if (!value || value.startsWith("-")) continue;
		if (flag === "--agent") parsed.agent = value;
		else if (flag === "--name") parsed.name = value;
		else if (flag === "--scope") parsed.scope = value;
		else if (flag === "--command" || flag === "-c") parsed.command = value;
	}
	return parsed;
}
//#endregion
//#region src/commands/maintenance.ts
/**
* The two maintenance commands: `doctor` (has the target drifted?) and `eject` (an artifact you
* own). Inference and review are the daemon's, served at its own `/review/:sessionId`, so no CLI
* command starts a UI. The ejector is imported lazily so ADR-006 holds at the CLI boundary too:
* the inference code is never loaded for an ordinary tool call.
*/
function register(cli, daemon) {
	cli.command("doctor", {
		description: "Replay a recipe read-only fixtures against the live target and report drift",
		args: object({ recipe: string().describe("Recipe name") }),
		mcp: false,
		async run(c) {
			try {
				return await daemon.request(`/doctor/${c.args.recipe}`, {
					method: "POST",
					body: "{}"
				});
			} catch (cause) {
				return c.error({
					code: "DOCTOR_FAILED",
					message: cause.message,
					exitCode: 1
				});
			}
		}
	});
	cli.command("eject", {
		description: "Emit a standalone incur package for one recipe",
		args: object({ recipe: string().describe("Recipe name") }),
		options: object({ out: string().describe("Directory to write the package into") }),
		mcp: false,
		async run(c) {
			const { eject } = await import("./src2.js");
			const recipes = await daemon.request("/recipes");
			const recipe = recipes.find((r) => r.name === c.args.recipe);
			if (!recipe) return c.error({
				code: "NO_RECIPE",
				message: `No recipe "${c.args.recipe}". Known: ${recipes.map((r) => r.name).join(", ") || "none"}.`,
				exitCode: 1
			});
			try {
				const result = eject({
					recipe,
					out: c.options.out,
					fixturesDir: join(douzeHome(), "fixtures")
				});
				return {
					ejected: c.args.recipe,
					out: c.options.out,
					files: result.files.length,
					tools: result.tools
				};
			} catch (cause) {
				return c.error({
					code: "EJECT_FAILED",
					message: cause.message,
					exitCode: 1
				});
			}
		}
	});
}
//#endregion
//#region src/index.ts
var VERSION = "0.1.0";
/**
* Commands that answer without the recipe surface. `status` in particular must be able to
* report a stopped daemon rather than starting one to ask it how it is.
*/
var SURFACE_FREE = /* @__PURE__ */ new Set([
	"start",
	"stop",
	"status",
	"sessions",
	"import",
	"bundle",
	"doctor",
	"eject"
]);
function createCli() {
	const cli = create("douze", {
		description: "Call your own authenticated dashboards as tools, executed in your signed-in browser.",
		version: VERSION,
		mcp: {
			name: "douze",
			title: "Douze"
		}
	});
	register$2(cli);
	register$1(cli);
	register(cli, new DaemonClient());
	return cli;
}
async function main(argv = process.argv.slice(2)) {
	if (argv.includes("--mcp")) return runMcp();
	const mcpAdd = parseMcpAddArgv(argv);
	if (mcpAdd) return runMcpAdd(mcpAdd);
	const cli = createCli();
	if (needsSurface(argv)) await attachSurface(cli, argv);
	await cli.serve(argv);
}
/**
* The MCP process: no argv parsing, no output on stdout except the protocol itself. It is built
* from the same `createCli()` as the shell, so `mcp doctor` and `tools/list` cannot disagree —
* the daemon-lifecycle commands opt out with `mcp: false`, leaving `status` and `sessions` as
* the only non-recipe tools, which is what lets an agent diagnose REQ-CON-004 from inside a chat.
*/
async function runMcp() {
	hostDaemonInProcess();
	const daemon = new DaemonClient();
	await serveMcp({
		builder: new ToolSurfaceBuilder(createCli(), new RelayClient(daemon)),
		daemon,
		version: VERSION
	});
	await new Promise(() => void 0);
}
/**
* AC-RUN-001.1 — the CLI's commands are built from the registry at load, the same registry the
* MCP server reads, so the two surfaces cannot disagree about which tools exist.
*/
async function attachSurface(cli, argv) {
	const passive = isPassive(argv);
	const daemon = new DaemonClient(passive ? { autoStart: false } : {});
	const builder = new ToolSurfaceBuilder(cli, new RelayClient(daemon));
	try {
		const result = builder.apply(await daemon.registry());
		for (const skipped of result.skipped) process.stderr.write(`douze: recipe "${skipped}" shadows a built-in command and was not mounted.\n`);
		for (const failure of result.errors) process.stderr.write(`douze: recipe "${failure.recipe}" failed to load — ${failure.error}\n`);
	} catch (error) {
		if (!passive) throw error;
	}
}
var isPassive = (argv) => argv.length === 0 || [
	"--help",
	"-h",
	"--version",
	"-v",
	"--llms",
	"--llms-full"
].includes(argv[0] ?? "");
var needsSurface = (argv) => !SURFACE_FREE.has(argv[0] ?? "");
function parseMcpAddArgv(argv) {
	const start = argv[0] === "douze" ? 1 : 0;
	if (argv[start] !== "mcp" || argv[start + 1] !== "add") return null;
	return parseMcpAdd(argv.slice(start + 2));
}
/**
* A client we cannot write config for still gets a working answer: the block to paste, with the
* absolute paths already filled in. Naming the clients we do know is the only useful next step.
*/
function runMcpAdd(parsed) {
	const agent = parsed.agent ?? "claude-code";
	if (!isAgent(agent)) {
		const block = snippet(parsed.name, parsed.command);
		process.stdout.write(`Douze does not write ${agent}'s config. Paste this into its MCP settings:\n\n${block}\n\nClients Douze registers itself with: ${AGENTS.join(", ")}\n`);
		return;
	}
	const result = addToAgent({
		agent,
		...parsed.name === void 0 ? {} : { name: parsed.name },
		...parsed.scope === void 0 ? {} : { scope: parsed.scope },
		...parsed.command === void 0 ? {} : { command: parsed.command }
	});
	process.stdout.write(`${result.requested ? `"${result.requested}" is a reserved name; registered as "${result.name}".\n` : ""}Registered "${result.name}" with ${result.agent} at ${result.scope} scope in ${result.path}\n  ${result.command} ${result.args.join(" ")}\nRestart ${result.agent} to pick it up.\n`);
}
//#endregion
//#region src/bin.ts
main().catch((error) => {
	process.stderr.write(`${error instanceof Error ? error.message : String(error)}\n`);
	process.exit(1);
});
//#endregion
export {};
